SELECT DISTINCT O.PCode
	  ,CAST(D.fin_year AS VARCHAR(4))+' '+'Q'+ RIGHT(CAST(fin_quarter AS VARCHAR(10)),1)  AS [FiscalYearandQuarter]
	  ,sr.[Mortgage Type]
	  ,CASE WHEN CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) = [FirstMortgageNumberOfOutstandingRLFLoans] THEN  'First Mortgage'
	  		WHEN CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) = [SubMortgageNumberOfOutstandingRLFLoans] THEN 'Subordinate Mortgage' END AS [Outstanding Loans]
	  ,CASE WHEN CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) = [FirstMortgageAmountOfOutstandingRLFLoans] THEN 'First Mortgage'
			WHEN CONVERT(MONEY,[Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) = [SubMortgageAmountOfOutstandingRLFLoans] THEN 'Subordinate Mortgage' END AS [AmountOfOutstandingRLFLoans] 
	  ,CASE WHEN CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) = [FirstMortgageNumberOfRLFLoans30to59DaysDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) = [SubMortgageNumberOfRLFLoans30to59DaysDelinquent] THEN 'Subordinate Mortgage' END AS [NumberOfRLFLoans30to59DaysDelinquent]
	  ,CASE WHEN CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) = [FirstMortgageAmountOfRLFLoans30to59DaysDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) = [SubMortgageAmountOfRLFLoans30to59DaysDelinquent] THEN 'Subordinate Mortgage' END AS [AmountOfRLFLoans30to59DaysDelinquent]
	  ,CASE WHEN CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) = [FirstMortgageNumberOfRLFLoans60to89DaysDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) = [SubMortgageNumberOfRLFLoans60to89DaysDelinquent] THEN 'Subordinate Mortgage' END AS [NumberOfRLFLoans60to89DaysDelinquent]
	  ,CASE WHEN CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) = [FirstMortgageAmountOfRLFLoans60to89DaysDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) = [SubMortgageAmountOfRLFLoans60to89DaysDelinquent] THEN 'Subordinate Mortgage' END AS [AmountOfRLFLoans60to89DaysDelinquent]
      ,CASE WHEN CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) = [FirstMortgageNumberOfRLFLoans90+DaysDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) = [SubMortgageNumberOfRLFLoans90+DaysDelinquent] THEN 'Subordinate Mortgage' END AS [NumberOfRLFLoans90+DaysDelinquent]
	  ,CASE WHEN CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) = [FirstMortgageAmountOfRLFLoans90DaysPlusDelinquent] THEN 'First Mortgage'
			WHEN CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) = [SubMortgageAmountOfRLFLoans90+DaysDelinquent] THEN 'Subordinate Mortgage' END AS [AmountOfRLFLoans90+DaysDelinquent]
	  ,CASE WHEN CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) = [1st% of $ 90+ Delinquent] THEN 'First Mortgage'
			WHEN CONVERT(DECIMAL(4,3),[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) = [2nd% of $ 90+ Delinquent] THEN 'Subordinate Mortgage' END AS [% of $ 90+ Delinquent]  
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT JOIN StgResdentialPortfolio SR
ON O.PCode = SR.PCODE
LEFT JOIN [dbo].[dim_date] D
ON R.dim_ReportingQuarter_key = D.dim_date_key  
WHERE O.PCODE IS NOT NULL


  
 






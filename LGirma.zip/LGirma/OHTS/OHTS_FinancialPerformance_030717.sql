/*SQL code to produce Financial Performance on OHTS report
We use tblFinancialAudits tables*/
--==========================================================================================
--SELECT * INTO OHTS_FinancialPerformance
--FROM OPENROWSET('SQLNCLI', 
--                'Server=localhost;Trusted_Connection=yes;', 
--                'EXEC [HARP].[dbo].[OHTS_FinancialPerformanceFromtheAudits]')

--==========================================================================================

--CREATE PROCEDURE Financial_Performance
--AS
--BEGIN
DECLARE @FirstLatestYear_FA INT;
DECLARE @SecondLatestYear_FA INT;
DECLARE @ThirdLatestYear_FA INT;
DECLARE @FourthLatestYear_FA INT;
DECLARE @FifthLatestYear_FA INT;

SELECT @FirstLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM(
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit
		 ) a
	)a 
	 WHERE FiscalYear_FA_Rank=1;

SELECT @SecondLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit
		 ) a
	)a 
	 WHERE FiscalYear_FA_Rank=2;

SELECT @ThirdLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit
		  ) a
	)a 
	 WHERE FiscalYear_FA_Rank=3;

SELECT @FourthLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM(
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit
		  ) a
	)a 
	 WHERE FiscalYear_FA_Rank=4;

SELECT @FifthLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear 
		  FROM tblFinancialAudit
		  ) a
	)a 
	 WHERE FiscalYear_FA_Rank=5;
;WITH CTE
AS
(
SELECT PCODE
	  ,FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS [Rank]
	  ,FA.CashAndCashEquivalentsAmount
	  ,FA.CurrentLiabilitiesOverNetAssetsPercentage 
	  ,FA.DefensiveIntRatio
	  ,FA.DepreciationExpenseAmount
	  ,FA.ExpenseAmount
	  ,FA.LiabilitiesOverNetAssetsPercentage
	  ,(ISNULL(fa.MAndGExpenseOverTotalPercentage,0)) AS MAndGExpenseOverTotalPercentage
	  ,FA.NetAssetsAmount
	  ,FA.CAssets
	  ,FA.CLiab
	  ,FA.NetCashFromOperationsAmount
	  ,FA.NetIncomeAmount
	  ,FA.RevenueAmount
	  ,FA.UnrestrictedCurrentRatio
	  ,FA.CurrentRatio
	  ,FA.QuickCashRatio
	  ,FA.TotalDaysCash
	  ,FA.UnrestrictedNetAssetsAmount
	  ,FA.UnrestrictedNetAssetsOverNetAssetsPercentage
	  ,FA.UnrestrictedNetIncomeAmount
	  ,FA.UnrestrictedNumberOfDaysCash
	  ,FA.UnrestrictedCash
	  ,FA.ReservesCash
	  ,FA.Loans
	  ,FA.FixedAssets
	  ,FA.TAssets
	  ,FA.LTLiab
	  ,FA.TLiab
	  ,FA.NonControllingActivityAmount
	  ,FA.PriorPeriodAdjustmentsAmount
	  ,(SELECT OHPSummaryComments_FA_Text 
		FROM(
			  SELECT OHPSummaryComments_FA_Text,PCODE
			  FROM(
					SELECT fa.PCODE
						  ,fa.FiscalYear
						  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
						  ,OHPSummaryComments_FA_Text
					FROM(
						  SELECT fa.PCODE
								,fa.FiscalYear
								,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
					   			,OHPSummaryComments AS OHPSummaryComments_FA_Text
						  FROM (
								SELECT fa.PCODE
									  ,fa.FiscalYear
									  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
									  ,OHPSummaryComments
								FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
								WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
	  													,@FourthLatestYear_FA)
				)fa
				WHERE fa.Rank_FA IN (1,2,3,4)
					  )fa
				WHERE ((FiscalYear=@FirstLatestYear_FA)AND (OHPSummaryComments_FA_Text IS NOT NULL))
					  OR (fa.FiscalYear IN (@SecondLatestYear_FA,@ThirdLatestYear_FA,@FourthLatestYear_FA)
                             )
					)fa
					WHERE Rank_FA IN (1)
			)a WHERE a.PCODE=fa.PCODE
	   ) AS OHPSummaryComments_FA_Text 																 
	  ,FA.FiscalYearEndMonthAndDay
	  ,(SELECT CompDate_Text
	    FROM(
			SELECT CompDate_Text,PCODE
			FROM(
				 SELECT fa.PCODE
					   ,fa.FiscalYear
					   ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
					   ,OHPSummaryComments_FA_Text
					   ,CompDate_Text
				FROM(
					 SELECT fa.PCODE
						   ,fa.FiscalYear
						   ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
						   ,OHPSummaryComments AS OHPSummaryComments_FA_Text
						   ,CompDate_Text
					 FROM(
						  SELECT fa.PCODE
								,fa.FiscalYear
								,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
								,OHPSummaryComments
								,CompDate AS CompDate_Text
						  FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
						  WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA,@FourthLatestYear_FA)
					)fa
					WHERE fa.Rank_FA IN (1,2,3,4)
				   )fa
				 WHERE((FiscalYear=@FirstLatestYear_FA)AND (OHPSummaryComments_FA_Text IS NOT NULL))
					  OR (fa.FiscalYear IN (@SecondLatestYear_FA,@ThirdLatestYear_FA,@FourthLatestYear_FA)
				 )
				)fa
				WHERE Rank_FA IN (1)
	  )a WHERE a.PCODE=fa.PCODE) AS CompDate_Text 
	  ,FA.A133Risk
	  ,GETDATE() AS CREATEDDATE
FROM tblFinancialAudit FA
WHERE FA.FiscalYear>=2013
)

SELECT *
FROM CTE
ORDER BY PCODE, CTE.FiscalYear DESC
--END
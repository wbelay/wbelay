SELECT E.PCODE 
	  ,E.NAME
	  ,CONVERT(VARCHAR(20),E.[AUDIT DUE],101) AS [AUDIT DUE]
	  ,dbo.fn_BooleanToYN(E.Recieved)AS Recieve
	  ,E.Year
	  ,dbo.fn_BooleanToYN (R.Watch) AS WatchList
	  ,dbo.fn_BooleanToYN (R.Review) AS OnSiteReview
	  ,dbo.fn_BooleanToYN(R.ReviewPRO) AS OffSiteReview
	  ,ROW_NUMBER()OVER(PARTITION BY E.PCODE,E.NAME,E.[AUDIT DUE],E.Recieved,E.Year,R.Watch,R.Review,R.ReviewPRO ORDER BY E.PCODE)RN
	   INTO #T
FROM [datatrf].[dbo].[Grant Eligibility] E
JOIN dbo.stgRankings R
ON E.PCODE = R.PCODE
JOIN dbo.tblFinHealth F
ON E.PCODE = F.PCODE
WHERE E.Recieved = 1 AND (R.Watch != 0 OR R.Review !=0 OR R.ReviewPRO != 0)
	  AND F.CompDate IS NOT NULL
	  AND F.CompDate >= CONVERT(VARCHAR(10),GETDATE(),101) 
	  AND YEAR(F.CompDate) >= E.Year

--SELECT * INTO stgFinAudit
--FROM
--(
SELECT PCODE 
	  ,NAME
	  ,[AUDIT DUE]
	  ,Recieve
	  ,Year
	  ,WatchList
	  ,OnSiteReview
	  ,OffSiteReview 
FROM #T
WHERE RN = 1
--) AS Financial

DROP TABLE #T
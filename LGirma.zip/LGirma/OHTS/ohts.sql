DECLARE @MaxMeetingDate Date = (SELECT Max(MeetingDate)
                                FROM tblRating)
SELECT  Name
	    ,pcode
	    ,CASE WHEN Name IN ('#ReviewNOPRO', '#ReviewPRO', '#WatchNOPRO', '#WatchNOPROOHS', '#WatchPRO') 
                              THEN Name ELSE pcode + ' - ' + Name END AS PName
     /*,Cast((Cast((ReportType) as varchar(1)) + '(' + Cast((PCODE) as varchar(10)) + ')') as varchar(30))*/ 
FROM
    (SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
			,1 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE tr.MeetingDate = @MaxMeetingDate 
     AND tr.WatchFlag = 'y' AND tr.ReviewPROFlag = 'Y'
     
     UNION ALL
 
     SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
            ,2 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate
     AND tr.WatchFlag = 'y' AND tr.ReviewFlag = 'N'  
     AND tr.ReviewPROFlag = 'N'
     
     UNION ALL
     
     SELECT o.Name
		    ,CAST(o.pcode AS VARCHAR(100)) pcode
		    ,3 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE tr.MeetingDate = @MaxMeetingDate 
     AND tr.WatchFlag = 'N' AND tr.RankChangeFlag = 'Y' 
     AND tr.ReviewPROFlag = 'N'
     
     UNION ALL
              
     SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
			,4 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE tr.MeetingDate = @MaxMeetingDate 
     AND tr.WatchFlag = 'N' AND tr.ReviewPROFlag = 'Y' 
     AND tr.ReviewFlag = 'N' AND tr.RankChangeFlag = 'N'
     
     UNION ALL
     
     SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
			,5 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate
     AND tr.WatchFlag = 'N' AND tr.ReviewPROFlag = 'N' 
     AND tr.ReviewFlag = 'Y' AND tr.RankChangeFlag = 'N'
     
     UNION ALL
     
     SELECT o.Name
            ,CAST(o.pcode AS VARCHAR(100)) pcode
            ,7 AS ReportType
     FROM tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate
     AND tr.WatchFlag = 'N' 
     AND tr.RankChangeFlag = 'Y'  
     AND tr.ReviewPROFlag = 'Y'
     
     UNION ALL
     
     SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
			,8 AS ReportType
     FROM  tblOrganization O 
     LEFT JOIN tblRating tr 
     ON O.PCODE = tr.PCODE
     WHERE tr.MeetingDate = @MaxMeetingDate 
     AND   tr.WatchFlag = 'Y' AND tr.ReviewFlag = 'Y'  
     AND   tr.ReviewPROFlag = 'N'
     
     UNION ALL
     
     /*-------------------------AdHoc Request for adding all remaining organizations*/ 
     SELECT o.Name
			,CAST(o.pcode AS VARCHAR(100)) pcode
			,9 AS ReportType
     FROM  tblOrganization O
     WHERE o.Name NOT IN (SELECT o.Name
                                 /*,1 as ReportType */ 
                          FROM tblOrganization O 
                          LEFT JOIN tblRating tr 
                          ON O.PCODE = tr.PCODE
                          WHERE tr.MeetingDate = @MaxMeetingDate  
                          AND tr.WatchFlag = 'y'  
                          AND tr.ReviewPROFlag = 'Y'
                          
      UNION ALL
      
      SELECT o.Name
             /*,2 as ReportType */ 
      FROM tblOrganization O 
      LEFT JOIN tblRating tr
      ON O.PCODE = tr.PCODE
      WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate 
      AND tr.WatchFlag = 'y'  
      AND tr.ReviewFlag = 'N'  
      AND tr.ReviewPROFlag = 'N'
      
      UNION ALL
      
      SELECT o.Name
             /*,3 as ReportType */ 
      FROM tblOrganization O  
      LEFT JOIN tblRating tr  
      ON O.PCODE = tr.PCODE
      WHERE tr.MeetingDate = @MaxMeetingDate  
      AND tr.WatchFlag = 'N'  
      AND tr.RankChangeFlag = 'Y'  
      AND tr.ReviewPROFlag = 'N'
      
      UNION ALL
      
      SELECT  o.Name
              /*,4 as ReportType */ 
      FROM tblOrganization O 
      LEFT JOIN tblRating tr 
      ON O.PCODE = tr.PCODE
      WHERE tr.MeetingDate = @MaxMeetingDate  
      AND tr.WatchFlag = 'N'  
      AND tr.ReviewPROFlag = 'Y' 
      AND tr.ReviewFlag = 'N'  
      AND tr.RankChangeFlag = 'N'
      
      UNION ALL
      
      SELECT o.Name
             /*,5 as ReportType */ 
      FROM tblOrganization O 
      LEFT JOIN tblRating tr
      ON O.PCODE = tr.PCODE
      WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate 
      AND tr.WatchFlag = 'N'  
      AND tr.ReviewPROFlag = 'N' 
      AND tr.ReviewFlag = 'Y'  
      AND tr.RankChangeFlag = 'N'
      
      UNION ALL
      
      SELECT o.Name
             /*,7 as ReportType */ 
      FROM tblOrganization O 
      LEFT JOIN tblRating tr
      ON O.PCODE = tr.PCODE
      WHERE /*fnm.FiscalYear=2010 and*/ tr.MeetingDate = @MaxMeetingDate  
      AND tr.WatchFlag = 'N'  
      AND tr.RankChangeFlag = 'Y' 
      AND tr.ReviewPROFlag = 'Y'
      
      UNION ALL
      
      SELECT o.Name
             /*,8 as ReportType */ 
      FROM tblOrganization O 
      LEFT JOIN tblRating tr
      ON O.PCODE = tr.PCODE
      WHERE tr.MeetingDate = @MaxMeetingDate  
      AND tr.WatchFlag = 'Y'  
      AND tr.ReviewFlag = 'Y' 
      AND tr.ReviewPROFlag = 'N')
      /*--------AdHoc Request Ends*/ 
      
      UNION ALL
                                                                                                                                                                                                                                                SELECT        '#WatchPRO' AS Name, '#WatchPRO', 
      1 AS ReportType
      
      UNION ALL
      
       SELECT  '#WatchNOPRO' AS Name
			   ,'#WatchNOPRO' 
               ,2 AS ReportType
               /*,3 as ReportType*/ 
               
       UNION ALL
       
       SELECT '#ReviewPRO' AS Name
			  ,'#ReviewPRO' 
              ,4 AS ReportType
              
       UNION ALL
       
       SELECT  '#ReviewNOPRO' AS Name
			   ,'#ReviewNOPRO' 
               ,5 AS ReportType
               /*,7 as ReportType*/ 
               
        UNION ALL
        
        SELECT '#WatchNOPROOHS' AS Name
			   ,'#WatchNOPROOHS'
               ,8 AS ReportType) OHP
        ORDER BY OHP.Name , OHP.pcode ASC
        
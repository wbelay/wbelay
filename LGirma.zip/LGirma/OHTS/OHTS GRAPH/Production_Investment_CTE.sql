--CREATE VIEW VWOAD_OHTS_Production_Investment
--AS 
----[fact_Owner_Occupied_Repairs_and_Counseling]
WITH CTE
AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(isnull(A.Total_Value_Of_Repairs_To_Owner_Occupied_Units,0)) AS [Total Reported Investment]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] a
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
--where a.Total_Value_Of_Repairs_To_Owner_Occupied_Units is null
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
		
 )
------------------------------------
--6220
-------------------------------------
----[fact_Real_Estate_Development]
,CTE2 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(isnull([Total_Development_Costs],0)) AS [Total Reported Investment]
FROM [dbo].[fact_Real_Estate_Development] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
------------------------------------
--6216
-------------------------------------
---[fact_Rental_Production]
,CTE3 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Sum_Of_Costs]) AS [Total Reported Investment]
FROM[dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
--104
-------------------------------------
-----[fact_Special_Projects]
,CTE4 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Project_Cost]) AS [Total Reported Investment]
FROM [dbo].[fact_Special_Projects] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
-------------------------------------
--6218
-------------------------------------
---[fact_Commercial_Lending_Activity]
,CTE5 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Direct_Loan_Value_From_RLF]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
--6218
-------------------------------------
----[fact_Commercial_Lending_Activity]
,CTE6 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Direct_Loan_Value_From_Now_Other_Sources]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
--6218
-------------------------------------
---[fact_Commercial_Lending_Activity]
,CTE7 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
--6218
-------------------------------------
--[fact_Commercial_Lending_Activity]
,CTE8 AS 
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Owners_Portion_Out_Of_Pocket_Equity]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
--6218
-------------------------------------
-----[fact_Commercial_Real_Estate_Development]
,CTE9 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Total_Cost]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Real_Estate_Development] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
	    ,c.fin_year
	    ,c.fin_quarter
)
-------------------------------------
--3428
-------------------------------------
---[fact_Financing]
,CTE10 AS
(
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM([Financing_Amount]) AS [Total Reported Investment]
FROM [dbo].[fact_Financing] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
)
-------------------------------------
----6215
-------------------------------------
,CTE11 AS(
SELECT COALESCE(A.pcode,B.pcode,C.pcode,D.pcode,E.pcode,F.pcode,G.pcode,H.pcode,I.pcode,J.pcode) AS Pcode
	  ,COALESCE(A.fin_year,B.fin_year,C.fin_year,D.fin_year,E.fin_year,
                F.fin_year,G.fin_year,H.fin_year,I.fin_year,J.fin_year) AS ReportingYear
	  ,COALESCE(A.fin_quarter,B.fin_quarter,C.fin_quarter,D.fin_quarter,E.fin_quarter,F.fin_quarter
	           ,G.fin_quarter,H.fin_quarter,I.fin_quarter,J.fin_quarter) AS ReportingQuarter
	  ,ISNULL(A.[Total Reported Investment],0) +
	   ISNULL(B.[Total Reported Investment],0) +
	   ISNULL(C.[Total Reported Investment],0) +
	   ISNULL(D.[Total Reported Investment],0) +
	   ISNULL(E.[Total Reported Investment],0) +
	   ISNULL(F.[Total Reported Investment],0) +
	   ISNULL(G.[Total Reported Investment],0) +
	   ISNULL(H.[Total Reported Investment],0) +
	   ISNULL(I.[Total Reported Investment],0) +
	   ISNULL(J.[Total Reported Investment],0)  AS [Total Reported Investment_10]
FROM CTE10 A
FULL OUTER JOIN CTE5 B 
ON A.PCode=B.pcode
   AND A.fin_year=B.fin_year
   AND A.fin_quarter=B.fin_quarter
FULL OUTER JOIN CTE6 C
ON A.PCode=C.pcode
   AND A.fin_year=C.fin_year
   AND A.fin_quarter=C.fin_quarter
FULL OUTER JOIN CTE7 D
ON A.PCode=D.pcode
   AND A.fin_year=D.fin_year
   AND A.fin_quarter=D.fin_quarter
FULL OUTER JOIN CTE8 E
ON A.PCode=E.pcode
   AND A.fin_year=E.fin_year
   AND A.fin_quarter=E.fin_quarter
FULL OUTER JOIN CTE9 F
ON A.PCode=F.pcode
   AND A.fin_year=F.fin_year
   AND A.fin_quarter=F.fin_quarter
FULL OUTER JOIN CTE G
ON A.PCode=G.pcode
   AND A.fin_year=G.fin_year
   AND A.fin_quarter=G.fin_quarter
FULL OUTER JOIN CTE2 H
ON A.PCode=H.pcode
   AND A.fin_year=H.fin_year
   AND A.fin_quarter=H.fin_quarter
FULL OUTER JOIN CTE3 I
ON A.PCode=I.pcode
   AND A.fin_year=I.fin_year
   AND A.fin_quarter=I.fin_quarter
FULL OUTER JOIN CTE4 J
ON A.PCode=J.pcode
   AND A.fin_year=J.fin_year
   AND A.fin_quarter=J.fin_quarter
)

SELECT *
FROM CTE11 
WHERE PCODE IS NOT NULL


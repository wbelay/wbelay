USE [DataWarehouse]
GO

---Total Owner-Occupied Units Repaired 6463
DECLARE @TotalOwnerOccupiedUnitsRepaired TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Total Owner-Occupied Units Repaired] MONEY 
)
INSERT INTO @TotalOwnerOccupiedUnitsRepaired 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(A.[Total_Value_Of_Repairs_To_Owner_Occupied_Units]) AS [Total Owner-Occupied Units Repaired]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
---======================================================
--Real Estate Total Development Costs 6459
DECLARE @RealEstateTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Real Estate Total Development Costs] MONEY 
)
INSERT INTO @RealEstateTotalDevelopmentCosts 
SELECT a.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(B.[Total_Development_Costs]) AS [Real Estate Total Development Costs]
FROM  [dbo].[fact_Real_Estate_Development] B
JOIN dbo.dim_Organization a
ON b.dim_Organization_key=a.dim_Organization_key
JOIN dbo.dim_date c
ON b.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY a.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Rental Production Total Development Costs 104
DECLARE @RentalProductionTotalDevelopmentCosts TABLE  
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Rental Production Total Development Costs] MONEY 
)
INSERT INTO @RentalProductionTotalDevelopmentCosts 
SELECT b.pcode 
	  ,a.fin_year
	  ,a.fin_quarter
	  ,SUM(C.[Sum_Of_Costs]) AS [Real Estate Total Development Costs]
FROM [dbo].[fact_Rental_Production] C
JOIN dbo.dim_Organization b
ON c.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date a
ON c.[dim_ReportingQuarter_key]=a.dim_date_key
GROUP BY b.PCode
		,a.fin_year
		,a.fin_quarter

--====================================================
--Commercial RED Total Development Costs 3671
DECLARE @CommercialREDTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Commercial RED Total Development Costs] MONEY 
)
INSERT INTO @CommercialREDTotalDevelopmentCosts 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM(D.[Total_Cost]) AS [Commercial RED Total Development Costs]
FROM [dbo].[fact_Commercial_Real_Estate_Development] D
JOIN dbo.dim_Organization b
ON d.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON d.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Special Project Cost 6461
DECLARE @SpecialProjectCost TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Special Project Cost] MONEY 
)
INSERT INTO @SpecialProjectCost 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter  
	  ,SUM(E.[Project_Cost]) AS [Special Project Cost]
FROM [dbo].[fact_Special_Projects] E
JOIN dbo.dim_Organization b
ON E.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON E.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Infrastructure Improvement Contribution Amount 2790
DECLARE @InfrastructureImprovementContributionAmount TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Infrastructure Improvement Contribution Amount] Money 
)
INSERT INTO @InfrastructureImprovementContributionAmount 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM(F.[Contribution_Amount]) AS [Infrastructure Improvement Contribution Amount]
FROM [dbo].[fact_Infrastructure_Improvement] F
JOIN dbo.dim_Organization b
ON F.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON F.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter 
--=====================================================================
--REO Land Bank Production 5731
DECLARE @REOLandBankProductionTotalCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[REO Land Bank Production Total Costs] MONEY 
)
INSERT INTO @REOLandBankProductionTotalCosts 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM( G.[Total_Costs]) AS [REO Land Bank Production Total Costs]
FROM [dbo].[fact_REO_Land_Bank_Production] G
JOIN dbo.dim_Organization b
ON G.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON G.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
---Commercial Lending Activity Direct Loan Value from RLF 6461
DECLARE @CommercialLendingActivityRLF TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Direct Loan Value from RLF] MONEY 
)
INSERT INTO @CommercialLendingActivityRLF 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(H.[Direct_Loan_Value_From_RLF]) AS [CLA Direct Loan Value from RLF]
FROM [dbo].[fact_Commercial_Lending_Activity] H
JOIN dbo.dim_Organization b
ON H.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON H.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
--Commercial Lending Activity Direct Loan Value from NWO Other Sources 6461
DECLARE @CommercialLendingActivityNWO TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Direct Loan Value from NWO Other Sources] MONEY 
)
INSERT INTO @CommercialLendingActivityNWO 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(I.[Direct_Loan_Value_From_Now_Other_Sources]) AS [CLA Direct Loan Value from NWO Other Sources]
FROM [dbo].[fact_Commercial_Lending_Activity] I
JOIN dbo.dim_Organization b
ON I.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON I.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 6461
DECLARE @CommercialLendingActivityLeveragedAmount TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityLeveragedAmount 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM( J.[Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion]) AS [CLA Leveraged Amount (excludes NWO funds and Owner's Portion)]
FROM [dbo].[fact_Commercial_Lending_Activity] J
JOIN dbo.dim_Organization b
ON J.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON J.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--================================================================ 
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 6461
DECLARE @CommercialLendingActivityOwnersPortion TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityOwnersPortion 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM( K.[Owners_Portion_Out_Of_Pocket_Equity]) AS [CLA Owner's Portion (out-of-pocket equity)]
FROM [dbo].[fact_Commercial_Lending_Activity] K
JOIN dbo.dim_Organization b
ON K.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON K.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
SELECT   
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode)  AS PCode
,Coalesce(A.Reporting_Year , B.Reporting_Year, C.Reporting_Year,D.Reporting_Year,E.Reporting_Year,F.Reporting_Year,G.Reporting_Year,H.Reporting_Year,I.Reporting_Year,J.Reporting_Year,K.Reporting_Year) AS Reporting_Year 
,Coalesce(A.Reporting_Quarter, B.Reporting_Quarter ,C.Reporting_Quarter,D.Reporting_Quarter,E.Reporting_Quarter,F.Reporting_Quarter,G.Reporting_Quarter,H.Reporting_Quarter,I.Reporting_Quarter,J.Reporting_Quarter,K.Reporting_Quarter) AS Reporting_Quarter 
,sum(ISNULL(A.[Total Owner-Occupied Units Repaired] , 0)
+ISNULL(B.[Real Estate Total Development Costs] , 0)
+ISNULL(C.[Rental Production Total Development Costs], 0) 
+ISNULL(D.[Commercial RED Total Development Costs] , 0)
+ISNULL(E.[Special Project Cost] , 0)
+ISNULL(F.[Infrastructure Improvement Contribution Amount] , 0)
+ISNULL(G.[REO Land Bank Production Total Costs] , 0)
+ISNULL(H.[CLA Direct Loan Value from RLF] , 0)
+ISNULL(I.[CLA Direct Loan Value from NWO Other Sources] , 0) 
+ISNULL(J.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)
+ISNULL(K.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)) AS  [Total Direct Investment]
INTO #TotalDirectInvestment
FROM @TotalOwnerOccupiedUnitsRepaired A
FULL OUTER JOIN 
@RealEstateTotalDevelopmentCosts B
ON A.PCode = B.PCode 
AND A.Reporting_Year = B.Reporting_Year 
AND A.Reporting_Quarter = B.Reporting_Quarter 
FULL OUTER JOIN 
@RentalProductionTotalDevelopmentCosts C
ON A.PCode = C.PCode 
AND A.Reporting_Year = C.Reporting_Year 
AND A.Reporting_Quarter = C.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialREDTotalDevelopmentCosts D
ON A.PCode = D.PCode 
AND A.Reporting_Year = D.Reporting_Year
AND A.Reporting_Quarter = D.Reporting_Quarter 
FULL OUTER JOIN 
@SpecialProjectCost E
ON A.PCode = E.PCode 
AND A.Reporting_Year = E.Reporting_Year 
AND A.Reporting_Quarter = E.Reporting_Quarter 
FULL OUTER JOIN 
@InfrastructureImprovementContributionAmount F
ON A.PCode = F.PCode 
AND A.Reporting_Year = F.Reporting_Year 
AND A.Reporting_Quarter = F.Reporting_Quarter 
FULL OUTER JOIN 
@REOLandBankProductionTotalCosts G 
ON A.PCode = G.PCode 
AND A.Reporting_Year = G.Reporting_Year 
AND A.Reporting_Quarter = G.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialLendingActivityRLF H
ON A.PCode = H.PCode 
AND A.Reporting_Year = H.Reporting_Year 
AND A.Reporting_Quarter = H.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialLendingActivityNWO I 
ON A.PCode = I.PCode 
AND A.Reporting_Year = I.Reporting_Year 
AND A.Reporting_Quarter = I.Reporting_Quarter
FULL OUTER JOIN 
@CommercialLendingActivityLeveragedAmount J
ON A.PCode = J.PCode 
AND A.Reporting_Year = J.Reporting_Year 
AND A.Reporting_Quarter = J.Reporting_Quarter
FULL OUTER JOIN 
@CommercialLendingActivityOwnersPortion K
ON  A.PCode = K.PCode 
AND A.Reporting_Year = K.Reporting_Year 
AND A.Reporting_Quarter = K.Reporting_Quarter
GROUP BY 
 COALESCE(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode)  
,COALESCE(A.Reporting_Year , B.Reporting_Year, C.Reporting_Year,D.Reporting_Year,E.Reporting_Year,F.Reporting_Year,G.Reporting_Year,H.Reporting_Year,I.Reporting_Year,J.Reporting_Year,K.Reporting_Year) 
,COALESCE(A.Reporting_Quarter, B.Reporting_Quarter ,C.Reporting_Quarter,D.Reporting_Quarter,E.Reporting_Quarter,F.Reporting_Quarter,G.Reporting_Quarter,H.Reporting_Quarter,I.Reporting_Quarter,J.Reporting_Quarter,K.Reporting_Quarter)  
SELECT *
FROM  #TotalDirectInvestment
WHERE PCODE IS NOT NULL AND PCODE = 8364
DROP TABLE #TotalDirectInvestment
USE [QUARTERLY]
GO
DECLARE                
 @ReportingYear INT =2016 
,@ReportingQuarter INT =1
--============================================
IF OBJECT_ID(N'tempdb..#RentalAssistedNotOwnedNotManaged') IS NOT NULL
BEGIN
DROP TABLE #RentalAssistedNotOwnedNotManaged
END
--============================================
--============================================
IF OBJECT_ID(N'tempdb..#TotalOwnerOccupiedUnitsRepaired') IS NOT NULL
BEGIN
DROP TABLE #TotalOwnerOccupiedUnitsRepaired
END
--============================================
--============================================
IF OBJECT_ID(N'tempdb..#Temp1') IS NOT NULL
BEGIN
DROP TABLE #Temp1
END
--============================================
--============================================
IF OBJECT_ID(N'tempdb..#temp') IS NOT NULL
BEGIN
DROP TABLE #temp
END
--============================================
IF OBJECT_ID(N'tempdb..#TotalDirectInvestment') IS NOT NULL
BEGIN
DROP TABLE  #TotalDirectInvestment
END
--============================================
--============================================
IF OBJECT_ID(N'tempdb..#OwnerOccupiedUnits') IS NOT NULL
BEGIN
DROP TABLE  #OwnerOccupiedUnits 
END
--============================================
--============================================
IF OBJECT_ID(N'tempdb..#RentalProductionRepairedUnits') IS NOT NULL
BEGIN
DROP TABLE  #RentalProductionRepairedUnits 
END
--============================================
  IF OBJECT_ID(N'tempdb..#ReportedInvestmentOwnerOccupiedRepairsandCounseling') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentOwnerOccupiedRepairsandCounseling
END
----------------------------------------------------------------------------
--============================================
  IF OBJECT_ID(N'tempdb..#ReportedInvestmentOwnerOccupiedRepairsandCounseling') IS NOT NULL
BEGIN
DROP TABLE #Repaired2016
END
----------------------------------------------------------------------------
SELECT 
 RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
,SUM(ISNULL(RP.[# Units],0) ) AS [# Units]
INTO #Repaired2016
FROM QUARTERLY.ProjectsandSummary.[Fact_Rental Production]  RP
WHERE  RP.[Rental Activity Type] = 'Repaired' AND RP.ReportingYear =2016
GROUP BY  RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
-------------------------------------------------------------------------
--FY2016: Sum (21699 + 21722 + 21741 + 21755 + 21775 + 21776 + 21777 + 21778 + 24279) + Sum 21681
---------------------------------------------------------
--21699
SELECT 
   A.pcode
  ,A.ReportingYear
  ,A.ReportingQuarter
,SUM(A.[Total Value of Repairs to Owner-Occupied Units]) AS [Total Reported Investment]
INTO #ReportedInvestmentOwnerOccupiedRepairsandCounseling
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling] a
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
------------------------------------
--21722
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestmentRED') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentRED
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Total Development Costs] ) AS [Total Reported Investment]
INTO #ReportedInvestmentRED
FROM ProjectsandSummary.[Fact_Real Estate Development For Sale] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
------------------------------------
--21741
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestmentRentalProduction') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentRentalProduction
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Sum of Costs] ) AS [Total Reported Investment]
INTO #ReportedInvestmentRentalProduction
FROM ProjectsandSummary.[Fact_Rental Production] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--21755
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedSpecialProjects') IS NOT NULL
BEGIN
DROP TABLE #ReportedSpecialProjects
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Project Cost] ) AS [Total Reported Investment]
INTO #ReportedSpecialProjects
FROM ProjectsandSummary.[Fact_Special Projects] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
-------------------------------------
--21775
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_1') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_1
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Direct Loan Value from RLF] ) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_1
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--21776
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_2') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_2
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Direct Loan Value from NWO Other Sources] ) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_2
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
-------------------------------------
--21777
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_3') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_3
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Leveraged Amount (excludes NWO funds and Owner's Portion)] ) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_3
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--21778
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_4') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_4
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Owner's Portion (out-of-pocket equity)] ) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_4
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--24279
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialRealEstateDevelopment') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialRealEstateDevelopment
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Total Costs] ) AS [Total Reported Investment]
INTO #ReportedCommercialRealEstateDevelopment
FROM ProjectsandSummary.[Fact_Commercial Real Estate Development] A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--21681
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedFinancing') IS NOT NULL
BEGIN
DROP TABLE #ReportedFinancing
END
---------------------------------------------------
SELECT 
 A.pcode
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.Amount ) AS [Total Reported Investment]
INTO #ReportedFinancing
FROM ClientsandFinancing.Fact_Financing A
GROUP BY  A.pcode
,A.ReportingYear
,A.ReportingQuarter
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestment') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestment
END
---------------------------------------------------
SELECT 
Coalesce(A.pcode,B.pcode,C.pcode,D.pcode,E.pcode,F.pcode,G.pcode,H.pcode,I.pcode,J.pcode) AS Pcode
, Coalesce(A.ReportingYear,B.ReportingYear,C.ReportingYear,D.ReportingYear,E.ReportingYear,
                                                F.ReportingYear,G.ReportingYear,H.ReportingYear,I.ReportingYear,J.ReportingYear) AS ReportingYear
, Coalesce(A.ReportingQuarter,B.ReportingQuarter,C.ReportingQuarter,D.ReportingQuarter,E.ReportingQuarter,
F.ReportingQuarter,G.ReportingQuarter,H.ReportingQuarter,I.ReportingQuarter,J.ReportingQuarter) AS ReportingQuarter
,ISNULL(A.[Total Reported Investment],0) +
ISNULL(B.[Total Reported Investment],0) +
ISNULL(C.[Total Reported Investment],0) +
ISNULL(D.[Total Reported Investment],0) +
ISNULL(E.[Total Reported Investment],0) +
ISNULL(F.[Total Reported Investment],0) +
ISNULL(G.[Total Reported Investment],0) +
ISNULL(H.[Total Reported Investment],0) +
ISNULL(I.[Total Reported Investment],0) +
ISNULL(J.[Total Reported Investment],0)  AS [Total Reported Investment]
INTO #ReportedInvestment
FROM #ReportedFinancing A
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_1 B
ON A.PCode=B.pcode
AND A.ReportingYear=B.ReportingYear
AND A.ReportingQuarter=B.ReportingQuarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_2 C
ON A.PCode=C.pcode
AND A.ReportingYear=C.ReportingYear
AND A.ReportingQuarter=C.ReportingQuarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_3 D
ON A.PCode=D.pcode
AND A.ReportingYear=D.ReportingYear
AND A.ReportingQuarter=D.ReportingQuarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_4 E
ON A.PCode=E.pcode
AND A.ReportingYear=E.ReportingYear
AND A.ReportingQuarter=E.ReportingQuarter
FULL OUTER JOIN 
#ReportedCommercialRealEstateDevelopment F
ON A.PCode=F.pcode
AND A.ReportingYear=F.ReportingYear
AND A.ReportingQuarter=F.ReportingQuarter
FULL OUTER JOIN 
#ReportedInvestmentOwnerOccupiedRepairsandCounseling G
ON A.PCode=G.pcode
AND A.ReportingYear=G.ReportingYear
AND A.ReportingQuarter=G.ReportingQuarter
FULL OUTER JOIN 
#ReportedInvestmentRED H
ON A.PCode=H.pcode
AND A.ReportingYear=H.ReportingYear
AND A.ReportingQuarter=H.ReportingQuarter
FULL OUTER JOIN 
#ReportedInvestmentRentalProduction I
ON A.PCode=I.pcode
AND A.ReportingYear=I.ReportingYear
AND A.ReportingQuarter=I.ReportingQuarter
FULL OUTER JOIN 
#ReportedSpecialProjects J
ON A.PCode=J.pcode
AND A.ReportingYear=J.ReportingYear
AND A.ReportingQuarter=J.ReportingQuarter

----------------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestment2016') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestment2016
END
---------------------------------------------------
--------------------------------------------
SELECT 
A.Pcode , A.ReportingYear, A.ReportingQuarter
,SUM(A.[Total Reported Investment]) AS [TotalReportedInvestment] 
INTO #ReportedInvestment2016
FROM #ReportedInvestment A
WHERE A.ReportingYear= @ReportingYear AND A.ReportingQuarter= @ReportingQuarter
GROUP BY A.Pcode , A.ReportingYear, A.ReportingQuarter


---==============================================================================
----Total Direct Investment
/*
FY2010: Sum (21699 + 21722 + 21741 + 21750 + 21755 + 21760 + 21763 + 21775 + 21776 + 21777 + 21778) + (if 21619 is 1 - 6, then Sum 21681) + (if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)

FY2011 and FY2012: Sum (21699 + 21722 + 21741 + 21755 + 21760 + 21763 + 21775 + 21776 + 21777 + 21778) + (if 21619 is 1 - 6, then Sum 21681) + (if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)

FY2013: Sum (21699 + 21722 + 21741 + 21755 + 21763 + 21775 + 21776 + 21777 + 21778 + 23915) + (if 21619 is 1 - 6, 8 then Sum 21681) + (if 21619 is 7 AND if 21657 is  1 - 6, then Sum 21681)

FY2014: Sum (21699 + 21722 + 21741 + 21755 + 21763 + 21775 + 21776 + 21777 + 21778 + 23915 + 24279) + (if 21619 is 1 - 6, 8 then Sum 21681) + (if 21619 is 7 AND if 21657 is  1 - 6, then Sum 21681)
--======================================================= 
*/
---Total Owner-Occupied Units Repaired 21699
DECLARE @TotalOwnerOccupiedUnitsRepaired TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Total Owner-Occupied Units Repaired] MONEY 
)
INSERT INTO @TotalOwnerOccupiedUnitsRepaired 
SELECT 
 A.pcode 
,A.ReportingYear
,A.ReportingQuarter
,SUM(A.[Total Value of Repairs to Owner-Occupied Units]) AS [Total Owner-Occupied Units Repaired]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling] A

GROUP BY  A.pcode 
,A.ReportingYear
,A.ReportingQuarter
---======================================================
--Real Estate Total Development Costs 21722
DECLARE @RealEstateTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Real Estate Total Development Costs] MONEY 
)
INSERT INTO @RealEstateTotalDevelopmentCosts 
SELECT 
 B.pcode 
,B.ReportingYear
,B.ReportingQuarter
,SUM(B.[Total Development Costs] ) AS [Real Estate Total Development Costs]
FROM  
ProjectsandSummary.[Fact_Real Estate Development For Sale] B

GROUP BY 
 B.pcode 
,B.ReportingYear
,B.ReportingQuarter
--====================================================
--Rental Production Total Development Costs 21741
DECLARE @RentalProductionTotalDevelopmentCosts TABLE  
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Rental Production Total Development Costs] MONEY 
)
INSERT INTO @RentalProductionTotalDevelopmentCosts 
SELECT 
 C.pcode 
,C.ReportingYear
,C.ReportingQuarter
,SUM(C.[Sum of Costs] ) AS [Real Estate Total Development Costs]
FROM  
ProjectsandSummary.[Fact_Rental Production] C

GROUP BY 
 C.pcode 
,C.ReportingYear
,C.ReportingQuarter

--====================================================
--Commercial RED Total Development Costs 21750
DECLARE @CommercialREDTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Commercial RED Total Development Costs] MONEY 
)
INSERT INTO @CommercialREDTotalDevelopmentCosts 
SELECT 
D.pcode 
,D.ReportingYear 
,D.ReportingQuarter 
,SUM(D.[Total Costs]) AS [Commercial RED Total Development Costs]
FROM ProjectsandSummary.[Fact_Commercial Real Estate Development] D
GROUP BY D.pcode 
,D.ReportingYear 
,D.ReportingQuarter
--====================================================
--Special Project Cost 21755
DECLARE @SpecialProjectCost TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Special Project Cost] MONEY 
)
INSERT INTO @SpecialProjectCost 
SELECT 
 E.pcode 
,E.ReportingYear 
,E.ReportingQuarter 
,SUM(E.[Project Cost] ) AS [Special Project Cost]
FROM ProjectsandSummary.[Fact_Special Projects] E

GROUP BY  E.pcode 
,E.ReportingYear 
,E.ReportingQuarter 
--====================================================
--Infrastructure Improvement Contribution Amount 21760
DECLARE @InfrastructureImprovementContributionAmount TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[Infrastructure Improvement Contribution Amount] Money 
)
INSERT INTO @InfrastructureImprovementContributionAmount 
SELECT 
 F.pcode 
,F.ReportingYear 
,F.ReportingQuarter 
,SUM(F.[Contribution Amount] ) AS [Infrastructure Improvement Contribution Amount]
FROM ProjectsandSummary.[Fact_Infrastructure Improvement] F

GROUP BY  F.pcode 
,F.ReportingYear 
,F.ReportingQuarter 
--=====================================================================
--REO Land Bank Production 21763
DECLARE @REOLandBankProductionTotalCosts TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[REO Land Bank Production Total Costs] MONEY 
)
INSERT INTO @REOLandBankProductionTotalCosts 
SELECT 
 G.pcode 
,G.ReportingYear 
,G.ReportingQuarter 
,SUM( G.[Total Costs] ) AS [REO Land Bank Production Total Costs]
FROM ProjectsandSummary.[Fact_REO Land Bank Production] G

GROUP BY  G.pcode 
,G.ReportingYear 
,G.ReportingQuarter 
--=======================================================
---Commercial Lending Activity Direct Loan Value from RLF 21775
DECLARE @CommercialLendingActivityRLF TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[CLA Direct Loan Value from RLF] MONEY 
)
INSERT INTO @CommercialLendingActivityRLF 
SELECT 
 H.pcode 
,H.ReportingYear 
,H.ReportingQuarter 
,SUM(H.[Direct Loan Value from RLF] ) AS [CLA Direct Loan Value from RLF]
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] H

GROUP BY  H.pcode 
,H.ReportingYear 
,H.ReportingQuarter 
--=======================================================
--Commercial Lending Activity Direct Loan Value from NWO Other Sources 21776
DECLARE @CommercialLendingActivityNWO TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[CLA Direct Loan Value from NWO Other Sources] MONEY 
)
INSERT INTO @CommercialLendingActivityNWO 
SELECT 
 I.pcode 
,I.ReportingYear 
,I.ReportingQuarter 
,SUM(I.[Direct Loan Value from NWO Other Sources] ) AS [CLA Direct Loan Value from NWO Other Sources]
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] I

GROUP BY  I.pcode 
,I.ReportingYear 
,I.ReportingQuarter
--=======================================================
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 21777
DECLARE @CommercialLendingActivityLeveragedAmount TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityLeveragedAmount 
SELECT 
 J.pcode 
,J.ReportingYear 
,J.ReportingQuarter 
,SUM( J.[Leveraged Amount (excludes NWO funds and Owner's Portion)] ) AS [CLA Leveraged Amount (excludes NWO funds and Owner's Portion)]
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] J

GROUP BY  J.pcode 
,J.ReportingYear 
,J.ReportingQuarter
--================================================================ 
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 21778
DECLARE @CommercialLendingActivityOwnersPortion TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityOwnersPortion 
SELECT 
 K.pcode 
,K.ReportingYear 
,K.ReportingQuarter 
,SUM( K.[Owner's Portion (out-of-pocket equity)]  ) AS [CLA Owner's Portion (out-of-pocket equity)]
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] K

GROUP BY  K.pcode 
,K.ReportingYear 
,K.ReportingQuarter
--================================================================ 
----(if 21619 is 1 - 6, then Sum 21681)
--2015
--(if 21619 is 1 - 6, 8, 9, 10, then Sum 21681)
DECLARE @CFNWORoleOnetoSixAndEight TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,Amount MONEY
)

INSERT INTO @CFNWORoleOnetoSixAndEight 
SELECT 
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter 
,SUM(m.Amount) AS  Amount
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
ON  L.pcode =                                    m.pcode 
and L.ReportingYear =   m.ReportingYear 
and L.ReportingQuarter = M.ReportingQuarter 
and L.[Client ID] = M.[Client ID] 
WHERE L.[NWO Role] IN 
(
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Counselor Only Resulting in Ownership for New Home Owner'
,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
,'Directly provides Rehab Service'  
,'Counselor and/or Broker/Lender to an Existing Owner'
,'Broker/Lender Resulting in Ownership for New Home Owner'
--2015
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
)
GROUP BY  L.pcode
,L.ReportingYear 
,L.ReportingQuarter 
---================================================
--(if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)
DECLARE @CFNWORoleSeven TABLE 
(
  PCode INT 
 ,ReportingYear INT 
 ,ReportingQuarter INT
,Amount MONEY
)

INSERT INTO @CFNWORoleSeven 
SELECT 
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter 
,SUM(m.Amount) AS  Amount
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
ON  L.pcode =                                    m.pcode 
and L.ReportingYear =   m.ReportingYear 
and L.ReportingQuarter = M.ReportingQuarter 
and L.[Client ID] = M.[Client ID] 
WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
AND L.[Foreclosure Counseling Outcome] IN 
(
'Mortgage refinanced'  
,'Brought mortgage current'  
,'Mortgage modified'  
,'Received second mortgage'  
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
)

GROUP BY  
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter


--========================================================================
  
 
 
SELECT   
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  AS PCode
,Coalesce(A.ReportingYear , B.ReportingYear, C.ReportingYear,D.ReportingYear,E.ReportingYear,F.ReportingYear,G.ReportingYear,H.ReportingYear,I.ReportingYear,J.ReportingYear,K.ReportingYear,L.ReportingYear,M.ReportingYear) AS ReportingYear 
,Coalesce(A.ReportingQuarter, B.ReportingQuarter ,C.ReportingQuarter,D.ReportingQuarter,E.ReportingQuarter,F.ReportingQuarter,G.ReportingQuarter,H.ReportingQuarter,I.ReportingQuarter,J.ReportingQuarter,K.ReportingQuarter,L.ReportingQuarter,M.ReportingQuarter) AS ReportingQuarter 
,
sum(ISNULL(A.Amount , 0) + ISNULL(B.Amount,0) + ISNULL(C.[Total Owner-Occupied Units Repaired] , 0)
+ISNULL(D.[Real Estate Total Development Costs] , 0)
+ISNULL(E.[Rental Production Total Development Costs], 0) 
+ISNULL(F.[Commercial RED Total Development Costs] , 0)
+ISNULL(G.[Special Project Cost] , 0)
+ISNULL(H.[Infrastructure Improvement Contribution Amount] , 0)
+ISNULL(I.[REO Land Bank Production Total Costs] , 0)
+ISNULL(J.[CLA Direct Loan Value from RLF] , 0)
+ISNULL(K.[CLA Direct Loan Value from NWO Other Sources] , 0)
+ISNULL(L.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)
+ISNULL(M.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)) AS  [Total Direct Investment] 
INTO #TotalDirectInvestment
FROM @CFNWORoleOnetoSixAndEight A 
FULL OUTER JOIN 
@CFNWORoleSeven B 
ON A.PCode =                                   B.PCode 
AND A.ReportingYear =    B.ReportingYear 
AND A.ReportingQuarter = B.ReportingQuarter 
FULL OUTER JOIN 
@TotalOwnerOccupiedUnitsRepaired C
ON A.PCode = C.PCode 
AND A.ReportingYear = C.ReportingYear 
AND A.ReportingQuarter = C.ReportingQuarter 
FULL OUTER JOIN 
@RealEstateTotalDevelopmentCosts D
ON A.PCode = D.PCode 
AND A.ReportingYear = D.ReportingYear 
AND A.ReportingQuarter = D.ReportingQuarter 
FULL OUTER JOIN 
@RentalProductionTotalDevelopmentCosts E
ON A.PCode = E.PCode 
AND A.ReportingYear = E.ReportingYear 
AND A.ReportingQuarter = E.ReportingQuarter 
FULL OUTER JOIN 
@CommercialREDTotalDevelopmentCosts F
ON A.PCode = F.PCode 
AND A.ReportingYear = F.ReportingYear
AND A.ReportingQuarter = F.ReportingQuarter 
FULL OUTER JOIN 
@SpecialProjectCost G
ON A.PCode = G.PCode 
AND A.ReportingYear = G.ReportingYear 
AND A.ReportingQuarter = G.ReportingQuarter 
FULL OUTER JOIN 
@InfrastructureImprovementContributionAmount H 
ON A.PCode = H.PCode 
AND A.ReportingYear = H.ReportingYear 
AND A.ReportingQuarter = H.ReportingQuarter 
FULL OUTER JOIN 
@REOLandBankProductionTotalCosts I 
ON A.PCode = I.PCode 
AND A.ReportingYear = I.ReportingYear 
AND A.ReportingQuarter = I.ReportingQuarter 
FULL OUTER JOIN 
@CommercialLendingActivityRLF J 
ON A.PCode = J.PCode 
AND A.ReportingYear = J.ReportingYear 
AND A.ReportingQuarter = J.ReportingQuarter 
FULL OUTER JOIN 
@CommercialLendingActivityNWO K 
ON A.PCode = K.PCode 
AND A.ReportingYear = K.ReportingYear 
AND A.ReportingQuarter = K.ReportingQuarter
FULL OUTER JOIN 
@CommercialLendingActivityLeveragedAmount L
ON A.PCode = L.PCode 
AND A.ReportingYear = L.ReportingYear 
AND A.ReportingQuarter = L.ReportingQuarter
FULL OUTER JOIN 
@CommercialLendingActivityOwnersPortion M
ON  A.PCode = M.PCode 
AND A.ReportingYear = M.ReportingYear 
AND A.ReportingQuarter = M.ReportingQuarter
group by 
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  
,Coalesce(A.ReportingYear , B.ReportingYear, C.ReportingYear,D.ReportingYear,E.ReportingYear,F.ReportingYear,G.ReportingYear,H.ReportingYear,I.ReportingYear,J.ReportingYear,K.ReportingYear,L.ReportingYear,M.ReportingYear) 
,Coalesce(A.ReportingQuarter, B.ReportingQuarter ,C.ReportingQuarter,D.ReportingQuarter,E.ReportingQuarter,F.ReportingQuarter,G.ReportingQuarter,H.ReportingQuarter,I.ReportingQuarter,J.ReportingQuarter,K.ReportingQuarter,L.ReportingQuarter,M.ReportingQuarter)  
--=========================================================
--2013
--Rental Assisted Not Owned Not Managed
--FY2010: N/A
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 
--FY2012 - FY2013: if 21729 is 7 AND 23089 = 'No', than Sum 21730
--2014
--Rental Homes, Development Services, Not Managed
--FY2010: Null
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 + 
----           if 21729 is 8, than Sum 21730

---=======================================================

DECLARE @RentalAssistedNotOwnedNotManaged2011 TABLE 
(
pcode  INT 
,ReportingYear  INT 
,ReportingQuarter INT 
,Units2011 FLOAT 
)

INSERT INTO @RentalAssistedNotOwnedNotManaged2011 
SELECT
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM(CAST(CAST(A.[# Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM ProjectsandSummary.[Fact_Rental Production] A
WHERE A.ReportingYear = 2011 AND 
A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND A.[Assisted Activity Type (including fee developer)] IN 
(
'Planning' 
,'Asset Management'
,'Resource Development'
,'Direct Investment'
,'Site Related Services'
,'Construction Management'
,'General Contracting'
) AND A.[Does your organization Manage these units] = 'No'
GROUP BY 
 A.pcode 
,A.ReportingYear 
,A.ReportingQuarter
---=======================================================
--2013
--FY2012 - FY2013: if 21729 is 7 AND 23089 = 'No', than Sum 21730
--2014
--Rental Homes, Development Services, Not Managed
--FY2012 - FY2014: if 21729 is 7 AND 23089 = 'No', than Sum 21730 + 
--if 21729 is 8, than Sum 21730
--2016
--FY2016: if 25046 = 3, then Sum 21730
/*
1. Owned (reported in the Rental Portfolio)
2. Managed not Owned (reported in the Rental Portfolio)
3. Not Owned and Not Managed (NOT reported in the Rental Portfolio)
*/
-----------------------------------------------------------------
DECLARE @RentalAssistedNotOwnedNotManaged2012_2013 TABLE 
(
pcode  INT 
,ReportingYear  INT 
,ReportingQuarter INT 
,Units2012_2013 FLOAT 
)
INSERT INTO @RentalAssistedNotOwnedNotManaged2012_2013 
SELECT
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM(CAST(CAST(A.[# Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM ProjectsandSummary.[Fact_Rental Production] A
WHERE A.ReportingYear IN (2012, 2013,2014,2015) AND 
 A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND A.[Does your organization Manage these units] = 'No'
GROUP BY 
 A.pcode 
,A.ReportingYear 
,A.ReportingQuarter

union all

SELECT
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM(CAST(CAST(A.[# Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM ProjectsandSummary.[Fact_Rental Production] A
WHERE A.ReportingYear IN (2012, 2013,2014,2015) AND 
 A.[Rental Activity Type] LIKE 'NWO is responsible for rehabilitation of units but does not take title of property%'
GROUP BY 
 A.pcode 
,A.ReportingYear 
,A.ReportingQuarter

union all
--if 25046 = 3 AND 21729 = 11 or 12, then Sum 21730
SELECT
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM(CAST(CAST(A.[# Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM ProjectsandSummary.[Fact_Rental Production] A
WHERE A.ReportingYear =2016 AND 
 A.Type_of_Ownership = 'Not Owned and Not Managed (NOT reported in the Rental Portfolio)'
AND A.[Rental Activity Type] IN (
  'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
,'Assisted Not Owned (including fee developer)'
)

GROUP BY 
 A.pcode 
,A.ReportingYear 
,A.ReportingQuarter
--============================================================================================
SELECT 
 coalesce(A.pcode , B.pcode ,0)AS  pcode
,coalesce(A.ReportingYear , B.ReportingYear ,0) AS ReportingYear 
,coalesce(A.ReportingQuarter , B.ReportingQuarter ,0) AS  ReportingQuarter
,SUM(ISNULL(A.Units2011,0)  + ISNULL(B.Units2012_2013,0) ) AS [Rental Homes, Development Services, Not Managed]
INTO #RentalAssistedNotOwnedNotManaged
FROM @RentalAssistedNotOwnedNotManaged2011 A 
FULL OUTER JOIN 
@RentalAssistedNotOwnedNotManaged2012_2013 B
ON A.pcode = B.pcode 
AND A.ReportingYear = B.ReportingYear 
AND A.ReportingQuarter = B.ReportingQuarter 
GROUP BY           coalesce(A.pcode , B.pcode ,0)
,coalesce(A.ReportingYear , B.ReportingYear ,0)
,coalesce(A.ReportingQuarter , B.ReportingQuarter ,0)

--=========================================================
--============================================================================================
--Rental Production Units
--2013 
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 - FY2014: if 21729 is 1 - 5, 7, 8, then Sum 21730
--2014
----Rental Homes Constructed, Acquired, and Preserved
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 and FY2013: if 21729 is 1 - 5, 7, 8, then Sum 21730
--====================================================================================
DECLARE @RentalProductionUnits TABLE 
(
pcode INT 
,ReportingYear INT 
,ReportingQuarter INT 
,[Rental Homes Constructed, Acquired, and Preserved] INT 
)

INSERT INTO @RentalProductionUnits
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [Rental Homes Constructed, Acquired, and Preserved]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear = 2010
and a.[Rental Activity Type] in ( 'Constructed' ,'Purchased for new renters' ,'Purchased with existing renters' 
 ,'Re-financed to extend affordability of property for > 10 years' ,'Rehabilitated'
,'Assisted (not owned or managed)'
)
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
INSERT INTO @RentalProductionUnits
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear = 2011
and (a.[Rental Activity Type] IN ( 
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP)'
)
OR 
(
A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND A.[Assisted Activity Type (including fee developer)] IN 
(
'Planning' 
,'Asset Management'
,'Resource Development'
,'Direct Investment'
,'Site Related Services'
,'Construction Management'
,'General Contracting'
)
)
)
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
INSERT INTO @RentalProductionUnits
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear  = 2012 AND 
 
A.[Rental Activity Type] IN 
(
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 

INSERT INTO @RentalProductionUnits
SELECT   
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear  = 2013     and 
 
A.[Rental Activity Type] IN 
(
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 

INSERT INTO @RentalProductionUnits
SELECT   
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear  = 2014     and 
 
A.[Rental Activity Type] IN 
(
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter

INSERT INTO @RentalProductionUnits
SELECT   
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear  = 2015     and 
 
A.[Rental Activity Type] IN 
(
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter
--2016
--FY2016: if 21729 is 1-5, 8-9, 11-12, then Sum 21730
INSERT INTO @RentalProductionUnits
SELECT   
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear  = 2016     and 
A.[Rental Activity Type] <>'Repaired'
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter
--============================================================================================
--select *
--from (
--SELECT 
--R.*
--,ROW_NUMBER () OVER (PARTITION BY PCode order by PCode) rn 
--FROM @RentalProductionUnits R
--where r.ReportingQuarter = 4 and r.ReportingYear = 2013
--) x 
--where x.rn <> 1

--==================================================================================================
--2013
--Repaired 
--FY2010: if 21729 is 7, than Sum 21730
--FY2011: if 21729 is 6 OR (if 21729 is 7 AND 23088 is 8), than Sum 21730
--FY2012 and FY2013: if 21729 is 6,  then Sum 21730
--2014 
---Rental Homes, Repaired
--FY2010: if 21729 is 7, than Sum 21730
--FY2011: if 21729 is 6 OR (if 21729 is 7 AND 23088 is 8), than Sum 21730
--FY2012 - FY2014: if 21729 is 6,  then Sum 21730
--==============================================================
--FY2011: (Sum 21698) + ((if 21729 is 6) OR (if 21729 is 7 AND 23088 is 8), than Sum 21730)

--==============================================================
SELECT *
INTO  #RentalProductionRepairedUnits
FROM (
SELECT 
 RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
,SUM(ISNULL(RP.[# Units],0) ) AS [# Units]
FROM QUARTERLY.ProjectsandSummary.[Fact_Rental Production]  RP
WHERE RP.ReportingYear = 2011 AND 
(
RP.[Rental Activity Type] = 'Repaired' 
OR RP.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND RP.[Assisted Activity Type (including fee developer)] = 'Repaired'
) 
GROUP BY  RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
 UNION ALL 
 
--==============================================================
SELECT 
 RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
,SUM(ISNULL(RP.[# Units],0) ) AS [# Units]
FROM QUARTERLY.ProjectsandSummary.[Fact_Rental Production]  RP
WHERE  RP.[Rental Activity Type] = 'Repaired' AND RP.ReportingYear IN (2010, 2012, 2013,2014, 2015,2016)
GROUP BY  RP.pcode 
,RP.ReportingYear 
,RP.ReportingQuarter 
) X 
--==============================================================
--2013
--Owner Occupied Repair Units
--Sum 21698
--2014
--Owner-Occupied Repairs - Homes
--Sum 21698
---------------------------------------
SELECT 
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM (ISNULL ([Total Owner-Occupied Units Repaired],0) ) AS [# Units]
INTO #OwnerOccupiedUnits
FROM QUARTERLY.ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY 
A.pcode 
,A.ReportingYear 
,A.ReportingQuarter
--=================================================================================
---2013
---Total Repair Units
--FY2010: (Sum 21698) + (if 21729 is 7, than Sum 21730)
--FY2011: (Sum 21698) + ((if 21729 is 6) OR (if 21729 is 7 AND 23088 is 8), than Sum 21730)
--FY2012 and FY2013: (Sum 21698) + (if 21729 is 6,  then Sum 21730)
--2014
--Total Repaired - Homes
--FY2010: (Sum 21698) + (if 21729 is 7, than Sum 21730)
--FY2011: (Sum 21698) + ((if 21729 is 6) OR (if 21729 is 7 AND 23088 is 8), than Sum 21730)
--FY2012 and FY2014: (Sum 21698) + (if 21729 is 6,  then Sum 21730)
--2016
--FY2016: (Sum 21698) + (if 21729 is 6, 7, or 10, then Sum 21730)
-------------------------------------------
SELECT 
  ISNULL (A.pcode , B.pcode)  AS pcode
,ISNULL (A.ReportingYear , B.ReportingYear)  AS ReportingYear
,ISNULL (A.ReportingQuarter , B.ReportingQuarter)  AS ReportingQuarter
,ISNULL(A.[# Units],0) + ISNULL(B.[# Units] ,0) AS [Total Repaired Units]
INTO #Temp1 
FROM #RentalProductionRepairedUnits  A
FULL OUTER JOIN 
#OwnerOccupiedUnits  B
ON A.pcode = B.pcode 
AND A.ReportingYear = B.ReportingYear 
AND A.ReportingQuarter = B.ReportingQuarter 
---------------------------------------------
select 
t.pcode 
,t.ReportingYear
,t.ReportingQuarter  
,sum(t.[Total Repaired Units] ) as [Total Repaired Units]
INTO #TotalOwnerOccupiedUnitsRepaired
from #Temp1 t 
group by 
t.pcode 
,t.ReportingYear
,t.ReportingQuarter 
 
--SELECT * FROM #TotalOwnerOccupiedUnitsRepaired T ORDER BY PCode , ReportingYear, ReportingQuarter 

--==========================================

SELECT DISTINCT 
 A.pcode 
,A.ReportingYear 
,A.ReportingQuarter 
,A1.[Homeowners Created - Customers] 
,B.[Homeowners Created - Homes] 
,C.[Homeowners Created - Investment] 
,D.[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] 
,E.[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes] 
,F.[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment] 
,G.[Preserved Homeownership, Refinancing - Customers] 
,H.[Preserved Homeownership, Refinancing - Homes] 
,I.[Preserved Homeownership, Refinancing - Investment]
,G1.[Preserved Homeownership, Reverse Mortgage - Customers] 
,H1.[Preserved Homeownership, Reverse Mortgage - Homes] 
,I1.[Preserved Homeownership, Reverse Mortgage - Investment] 
,A2.[Preserved Homeownership, Foreclosure Mitigation - Customers] 
,A4.[Preserved Homeownership, Foreclosure Mitigation - Homes]
,A3.[Preserved Homeownership, Foreclosure Mitigation - Investment] 
,A5.[Preserved Homeownership - Customers] 
,A6.[Preserved Homeownership - Homes] 
,A7.[Preserved Homeownership - Investment] 
,A8.[Rental Homes, Constructed] 
,A9.[Rental Homes, Purchased for New Renters] 
,A10.[Rental Homes, Purchased with Existing Renters] 
,A11.[Rental Homes, Refinanced] 
,A12.[Rental Homes, Rehabilitated] 
,A13.[Rental Homes, Development Services] 
,A14.[Rental Homes, Rehabilitated with NSP Funds]
,J.[Rental Homes Constructed, Acquired, and Preserved] 
,K.[Rental Homes, Repaired]
,A15.[Rental Homes, Development Services, Not Managed] 
,L.[Rental Homes - Investment] 
,A16.[Rental Homes, Constructed - Investment] 
,M.[Commercial Development - Investment] 
,N.[Commercial Lending - Investment] 
,O.[Special Projects - Investment]
,Q.[For-Sale Homes Developed - Investment]
,R.[Land Banking - Investment] 
,S.[Owner-Occupied Repairs - Homes] 
,T.[Owner-Occupied Repairs - Investment] 
,U.[Total Repaired - Homes] 
,A.TotalReportedInvestment AS  [Total Direct Investment] 
,V.[Pre-purchase Homebuyer Group Education - Customers] 
,v1.[Pre-purchase Financial Literacy Group Education - Customers] 
,W.[Post-Purchase and Other Group Education - Customers] 
,X.[Other Counseling - Customers] 
,Y.[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
,Z.[Foreclosure Mitigation Counseling Intake - Customers] 
,AA.[Rental Homes Portfolio, Owned] 
,AA.[Rental Homes Portfolio, Managed not Owned] 
,AA.[Rental Homes Portfolio, Owned and/or Managed] 
,A17.[Residents Trained] 
,A18.[Volunteer Hours] 
,A19.[Volunteer Hours, NeighborWorks Week] 
,A20.[Preserved Homeownership, Replacement - Customers]
,A21.[Preserved Homeownership, Replacement - Homes]
,A22.[Preserved Homeownership, Replacement - Investment]

INTO #temp 
FROM 
(
SELECT *
FROM #ReportedInvestment2016 
)A
FULL OUTER JOIN 
(
--================================================================
/*
--2013
---Home Ownership Clients
--FY2010 - FY2012: if 21619 is 1 - 4, then Count 21617
--FY2013: if 21619 is 1 - 4, 8 then Count 21617
--2014
--Homeowners Created - Customers
--FY2010 - FY2012: if 21619 is 1 - 4, then Count 21617
--FY2013- FY2014: if 21619 is 1 - 4, 8 then Count 21617
--2015
---FY2015: if 21619 is 1 - 4, 8, 9, 10 then Count 21617
--2016
--FY2016: If 21619 is 1-5, then Count 21617
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
---------------------------------------------------------*/

SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,COUNT(A.[Client ID] ) AS [Homeowners Created - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE  A.[NWO Role] IN 
(
-- 'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
) A1
ON A.PCode = A1.pcode 
AND A.ReportingYear = A1.ReportingYear 
AND A.ReportingQuarter = A1.ReportingQuarter  
FULL OUTER JOIN 
(
--===============================================
--2013
--Home Ownership Units
--FY2010 - FY2012: if 21619 is 1 - 4, then Count 21650
--FY2013: if 21619 is 1 - 4, 8 then Count 21650
--2014
--Homeowners Created - Homes
--FY2010 - FY2012: if 21619 is 1 - 4, then Count 21650
--FY2013- FY2014 if 21619 is 1 - 4, 8 then Count 21650
--2015
--FY2015: if 21619 is 1 - 4, 8, 9, 10 then Sum 21650
--2016
--FY2016: if 21619 is 1-5, then Sum 21650
------------------------------------------------------

SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM(A.[# Units] ) AS [Homeowners Created - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE  A.[NWO Role] IN 
(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter

) B
ON A.pcode = B.pcode 
AND A.ReportingYear = B.ReportingYear 
AND A.ReportingQuarter = B.ReportingQuarter 
FULL OUTER JOIN 
---============================================
--2013
--Home Ownership Investment
--FY2010 - FY2012: if 21619 is 1 - 4, then Sum 21681
--FY2013: if 21619 is 1 - 4, 8 then Sum 21681
--2014
--Homeowners Created - Investment
--FY2010 - FY2012: if 21619 is 1 - 4, then Sum 21681
--FY2013- FY2014 if 21619 is 1 - 4, 8 then Sum 21681
--2015
--FY2015: if 21619 is 1 - 4, 8, 9, 10 then Sum 21681
--2016
--FY2016: if 21619 is 1-5, then Sum 21681
-----------------------------------------------------
(

SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM( B.Amount ) AS [Homeowners Created - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.ReportingQuarter = B.ReportingQuarter 
AND A.ReportingYear = B.ReportingYear 
WHERE  A.[NWO Role] IN 
(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
----2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter

) C
ON A.pcode = C.pcode 
AND A.ReportingYear = C.ReportingYear 
AND A.ReportingQuarter = C.ReportingQuarter 

FULL OUTER JOIN 
---==================================
--2013
--Owner Occupied Rehab Clients
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Count 21617
--2014
--Preserved Homeownership, Owner-Occupied Rehabilitation - Customers
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Count 21617
--2016
--FY2016: if 21619 is 6 AND if 21620 is 1, then Count 21617
/*
--2016
--FY2016: If 21619 is 1-5, then Count 21617
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
*/
--================================================================
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)D
ON A.pcode = D.pcode 
AND A.ReportingYear = D.ReportingYear 
AND A.ReportingQuarter = D.ReportingQuarter 
FULL OUTER JOIN 
---==================================
--2013
--Owner Occupied Rehab Units
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Sum 21650
--2014
--Preserved Homeownership, Owner-Occupied Rehabilitation - Homes
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Sum 21650
--2016
--FY2016: if 21619 is 6 AND if 21620 is 1, then Sum 21650
---------------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM(A.[# Units] ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)E
ON A.pcode = E.pcode 
AND A.ReportingYear = E.ReportingYear 
AND A.ReportingQuarter = E.ReportingQuarter 
FULL OUTER JOIN 
---==================================
--2013
--Owner Occupied Rehab Investment
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Sum 21681
--2014
--Preserved Homeownership, Owner-Occupied Rehabilitation - Investment
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Sum 21681
--2016
--FY2016: if 21619 is 6 AND if 21620 is 1, then Sum 21681
-----------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,sum(B.Amount  ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.ReportingQuarter = B.ReportingQuarter 
AND A.ReportingYear = B.ReportingYear 
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)F
ON A.pcode = F.pcode 
AND A.ReportingYear = F.ReportingYear 
AND A.ReportingQuarter = F.ReportingQuarter 
FULL OUTER JOIN 
---================================================
--2013
--Refinance Foreclosure Reverse Clients
--(if 21619 is 6 AND if 21620 2 - 3) OR (if 21619 is 7 AND if 21657 is 1 - 6), then Count 21617
--2014
--Preserved Homeownership, Refinancing - Customers
--if 21619 is 6 AND if 21620 is 2, then Count 21617
----------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Refinancing - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)

GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)G
ON A.pcode = G.pcode 
AND A.ReportingYear = G.ReportingYear 
AND A.ReportingQuarter = G.ReportingQuarter 

FULL OUTER JOIN 
---================================================
--2013
--Refinance Foreclosure Reverse Units
----(if 21619 is 6 AND if 21620 2 - 3) OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
--2014
--Preserved Homeownership, Refinancing - Homes
--if 21619 is 6 AND if 21620 is 2, then Sum 21650
------------------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM(A.[# Units] ) AS [Preserved Homeownership, Refinancing - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)

GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)H
ON A.pcode = H.pcode 
AND A.ReportingYear = H.ReportingYear 
AND A.ReportingQuarter = H.ReportingQuarter 

FULL OUTER JOIN 
---================================================
--2013
--Refinance Foreclosure Reverse Investment
----(if 21619 is 6 AND if 21620 2 - 3) OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21681
--2014
--Preserved Homeownership, Refinancing - Investment
--if 21619 is 6 AND if 21620 is 2, then Sum 21681
-------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,sum(B.Amount ) AS [Preserved Homeownership, Refinancing - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.ReportingQuarter = B.ReportingQuarter 
AND A.ReportingYear = B.ReportingYear
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)I
ON A.pcode = I.pcode 
AND A.ReportingYear = I.ReportingYear 
AND A.ReportingQuarter = I.ReportingQuarter 
------------------------------------------------------------------------------------------------------*
FULL OUTER JOIN 
---================================================
--2014
--Preserved Homeownership, Reverse Mortgage - Customers
--if 21619 is 6 AND if 21620 is 3, then Count 21617
----------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Reverse Mortgage - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)

GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)G1
ON A.pcode = G1.pcode 
AND A.ReportingYear = G1.ReportingYear 
AND A.ReportingQuarter = G1.ReportingQuarter 

FULL OUTER JOIN 
---================================================
--2014
--Preserved Homeownership, Reverse Mortgage - Homes
--if 21619 is 6 AND if 21620 is 3, then Sum 21650
------------------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM(A.[# Units] ) AS [Preserved Homeownership, Reverse Mortgage - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)

GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)H1
ON A.pcode = H1.pcode 
AND A.ReportingYear = H1.ReportingYear 
AND A.ReportingQuarter = H1.ReportingQuarter 

FULL OUTER JOIN 
---================================================

--2014
--Preserved Homeownership, Reverse Mortgage - Investment
--if 21619 is 6 AND if 21620 is 3, then Sum 21681
-------------------------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,sum(B.Amount ) AS [Preserved Homeownership, Reverse Mortgage - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.ReportingQuarter = B.ReportingQuarter 
AND A.ReportingYear = B.ReportingYear
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)I1
ON A.pcode = I1.pcode 
AND A.ReportingYear = I1.ReportingYear 
AND A.ReportingQuarter = I1.ReportingQuarter 
------------------------------------------------------------------------------------------------------*
FULL OUTER JOIN 
--=====================================================================
(
---=Rental Production Units
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 and FY2013: if 21729 is 1 - 5, 7, 8, then Sum 21730
---Rental Homes Constructed, Acquired, and Preserved
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 - FY2014: if 21729 is 1 - 5, 7, 8, then Sum 21730
--------------------------------------------------------------
SELECT *
FROM @RentalProductionUnits R
) J
ON A.pcode = J.pcode 
AND A.ReportingYear = J.ReportingYear 
AND A.ReportingQuarter = J.ReportingQuarter 

FULL OUTER JOIN 
--========================================================
(

---=Rental Repaired Units
-------------------------------------------------------------
--2013
--FY2010: if 21729 is 7, than Sum 21730
--FY2011: if 21729 is 6 OR (if 21729 is 7 AND 23088 is 8), than Sum 21730
--FY2012 and FY2013: if 21729 is 6,  then Sum 21730
--2014
--Rental Homes, Repaired
--FY2010: if 21729 is 7, than Sum 21730
--FY2011: if 21729 is 6 OR (if 21729 is 7 AND 23088 is 8), than Sum 21730
--FY2012 - FY2014: if 21729 is 6,  then Sum 21730
---------------------------------------------------------------

SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [Rental Homes, Repaired]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear = 2010
and a.[Rental Activity Type] = 'Repaired'
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
union all 
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear = 2011
and a.[Rental Activity Type] ='Repaired'
OR 
(
A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND A.[Assisted Activity Type (including fee developer)] ='Repaired'
)
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
union all 
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(Cast(Cast(a.[# Units] as varchar(20)) as INT)) as [# Units]
FROM ProjectsandSummary.[Dim_Rental Production] a
where a.ReportingYear in (2012, 2013,2014,2015,2016) AND 
A.[Rental Activity Type] = 'Repaired'
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
)K
ON A.pcode = K.pcode 
AND A.ReportingYear = K.ReportingYear 
AND A.ReportingQuarter = K.ReportingQuarter 
FULL OUTER JOIN 
--============================================
--2013
----Rental Investment
--Sum 21741
--2014
--Rental Homes - Investment
--Sum 21741
----------------------------------------------
(
SELECT
a.pcode ,a.ReportingYear ,a.ReportingQuarter 
,sum(a.[Sum of Costs] ) as [Rental Homes - Investment]
FROM ProjectsandSummary.[Dim_Rental Production] a
Group by a.pcode  ,a.ReportingYear  ,a.ReportingQuarter 
) L 
ON A.pcode = L.pcode 
AND A.ReportingYear = L.ReportingYear 
AND A.ReportingQuarter = L.ReportingQuarter
FULL OUTER JOIN 
--====================================================
(
--2013
--Commercial Development Investment
--FY2010: Sum 21750
--FY2011 and FY2012: N/A
--FY2013: 23915
--2014
--Commercial Development - Investment
--FY2010: Sum 21750
--FY2011 - FY2012: Null
--FY2013: 23915
--FY2014: 24279
-------------------------------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(A.[Total Costs] ) AS [Commercial Development - Investment]
FROM ProjectsandSummary.[Fact_Commercial Real Estate Development] A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
) M
ON A.pcode = M.pcode 
AND A.ReportingYear = M.ReportingYear 
AND A.ReportingQuarter = M.ReportingQuarter
--=======================================================
FULL OUTER JOIN 
(
---2013
--Commercial Lending Investment
--Sum (21775 + 21776 + 21777 + 21778)
--2014
--Commercial Lending - Investment
--Sum (21775 + 21776 + 21777 + 21778)
---------------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(A.[Direct Loan Value from RLF]  ,0.0)+
ISNULL(A.[Direct Loan Value from NWO Other Sources]  ,0)+
ISNULL(A.[Owner's Portion (out-of-pocket equity)] ,0.0) +
ISNULL(A.[Leveraged Amount (excludes NWO funds and Owner's Portion)]  ,0.0)
) AS [Commercial Lending - Investment]
FROM ProjectsandSummary.[Fact_Commercial Lending Activity] A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
) N
ON A.pcode = N.pcode 
AND A.ReportingYear = N.ReportingYear 
AND A.ReportingQuarter = N.ReportingQuarter
FULL OUTER JOIN 
---=================================================
(
--2013
--Special Project Investment
--Sum 21755
--2014
--Special Projects - Investment
---FY2010 - FY2012: Sum (21755 + 21760)
--FY2013 - FY2014: Sum 21755
----***********************************************************Change on 2014
SELECT 
SPI.pcode 
,SPI.ReportingYear 
,SPI.ReportingQuarter 
,SPI.[Special Projects - Investment] 
FROM (
SELECT 
 ISNULL(SP.pcode , II.pcode)  AS pcode
,ISNULL(SP.ReportingYear , II.ReportingYear)    AS ReportingYear
,ISNULL(SP.ReportingQuarter , II.ReportingQuarter)  AS  ReportingQuarter
,(ISNULL(SP.[Special Projects - Investment],0.00) + ISNULL(II.[Special Projects - Investment],0.00)) AS  [Special Projects - Investment]
FROM ( 
SELECT 
a.pcode 
,a.ReportingYear 
,a.ReportingQuarter 
,SUM (ISNULL(a.[Contribution Amount], 0.00)) as [Special Projects - Investment]
FROM ProjectsandSummary.[Fact_Infrastructure Improvement] A
GROUP BY a.pcode 
,a.ReportingYear 
,a.ReportingQuarter 
)II
FULL OUTER JOIN 
(
SELECT 
a.pcode 
,a.ReportingYear 
,a.ReportingQuarter 
,SUM (ISNULL(A.[Project Cost],0.00)) AS [Special Projects - Investment]
FROM   ProjectsandSummary.[Fact_Special Projects] A
GROUP BY a.pcode 
,a.ReportingYear 
,a.ReportingQuarter 
)SP 
ON II.pcode = SP.pcode 
AND II.ReportingYear = SP.ReportingYear 
AND II.ReportingQuarter = SP.ReportingQuarter
) SPI 
) O
ON A.pcode = O.pcode 
AND A.ReportingYear = O.ReportingYear 
AND A.ReportingQuarter = O.ReportingQuarter

FULL OUTER JOIN 
--================================================
(
--2013
--Infrastructure Investment
--FY2010 - FY2012: Sum 21760
--FY2013: N/A
--2014
--Collected under Special Projects
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Contribution Amount] AS VARCHAR(20)) AS FLOAT)) AS [Infrastructure Investment]
FROM ProjectsandSummary.[Fact_Infrastructure Improvement]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
) P 
ON A.pcode = P.pcode 
AND A.ReportingYear = P.ReportingYear 
AND A.ReportingQuarter = P.ReportingQuarter
FULL OUTER JOIN 
--============================================
(
--2013
--Real Estate Development For Sale Investment
--Sum 21722
--2014
--For-Sale Homes Developed - Investment
--Sum 21722
-------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Total Development Costs] AS VARCHAR(20)) AS FLOAT)) AS [For-Sale Homes Developed - Investment]
FROM ProjectsandSummary.[Fact_Real Estate Development For Sale]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)Q
ON A.pcode = Q.pcode 
AND A.ReportingYear = Q.ReportingYear 
AND A.ReportingQuarter = Q.ReportingQuarter
---====================================================
FULL OUTER JOIN 
(
--2013
--Land Bank Invest
--Sum 21763
--2014
--Land Banking - Investment
--Sum 21763
-------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Total Costs] AS VARCHAR(20)) AS FLOAT)) AS [Land Banking - Investment]
FROM ProjectsandSummary.[Fact_REO Land Bank Production]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)R
ON A.pcode = R.pcode 
AND A.ReportingYear = R.ReportingYear 
AND A.ReportingQuarter = R.ReportingQuarter
---====================================================
FULL OUTER JOIN 
(
--2013
--Owner Occupied Repair Units
--Sum 21698
--2014
--Owner-Occupied Repairs - Homes
--Sum 21698
-----------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Total Owner-Occupied Units Repaired] AS VARCHAR(20)) AS FLOAT)) AS [Owner-Occupied Repairs - Homes]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)S
ON A.pcode = S.pcode 
AND A.ReportingYear = S.ReportingYear 
AND A.ReportingQuarter = S.ReportingQuarter
---=========================================================
FULL OUTER JOIN 
(
--2013
--Owner Occupied Repair Investment
--Sum 21699
--2014
--Owner-Occupied Repairs - Investment
--Sum 21699
-----------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Total Value of Repairs to Owner-Occupied Units] AS VARCHAR(20)) AS FLOAT)) AS [Owner-Occupied Repairs - Investment]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)T
ON A.pcode = T.pcode 
AND A.ReportingYear = T.ReportingYear 
AND A.ReportingQuarter = T.ReportingQuarter
FULL OUTER JOIN 
(
--==========================================
---2013
---Total Repair Units
--FY2010: (Sum 21698) + (if 21729 is 7, than Sum 21730)
--FY2011: (Sum 21698) + ((if 21729 is 6) OR (if 21729 is 7 AND 23088 is 8), than Sum 21730)
--FY2012 and FY2013: (Sum 21698) + (if 21729 is 6,  then Sum 21730)
--2014
--Total Repaired - Homes
--FY2010: (Sum 21698) + (if 21729 is 7, than Sum 21730)
--FY2011: (Sum 21698) + ((if 21729 is 6) OR (if 21729 is 7 AND 23088 is 8), than Sum 21730)
--FY2012 and FY2014: (Sum 21698) + (if 21729 is 6,  then Sum 21730)
-------------------------------------------

SELECT 
A.PCode 
,A.ReportingYear 
,A.ReportingQuarter 
,SUM(A.[Total Repaired Units] ) AS [Total Repaired - Homes]
FROM #Temp1 A
GROUP BY A.PCode 
,A.ReportingYear 
,A.ReportingQuarter 
)U
ON A.pcode = U.pcode 
AND A.ReportingYear = U.ReportingYear 
AND A.ReportingQuarter = U.ReportingQuarter

FULL OUTER JOIN 
(
--===============================================
--2013
--HBE Workshop
--Sum 21706
--2014
--Pre-purchase Homebuyer Group Education - Customers
--Sum 21706
--======----------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Pre-purchase homebuyer education workshop] AS VARCHAR(20)) AS FLOAT)) AS [Pre-purchase Homebuyer Group Education - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter

)V
ON A.pcode = V.pcode 
AND A.ReportingYear = V.ReportingYear 
AND A.ReportingQuarter = V.ReportingQuarter
FULL OUTER JOIN 
(
--===============================================
--2013
--Pre-Purchase Financial Literacy Education
--Sum 21706
--2014
--Pre-purchase Financial Literacy Group Education - Customers
--Sum 21707
--======----------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(CAST(CAST(A.[Financial literacy workshop, including home financing budgeting and/or credit repair] AS VARCHAR(20)) AS FLOAT)) AS [Pre-purchase Financial Literacy Group Education - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter

)V1
ON A.pcode = V1.pcode 
AND A.ReportingYear = V1.ReportingYear 
AND A.ReportingQuarter = V1.ReportingQuarter
FULL OUTER JOIN 
(
--===========================================================
--2013
--Other Education
--Sum ( 21708 + 21709 + 21710 + 21711)
--2014
--Post-Purchase and Other Group Education - Customers
--FY2010- FY2014: Sum (21708 + 21709 + 21710 + 21711)
-----------------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
  ISNULL(CAST(CAST(A.[Resolving or preventing mortgage delinquency workshop]AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Non-delinquency post-purchase wkshop, incl home maintenance and/or financial mngmt for homeowners] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Fair housing workshop]AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Predatory lending workshop]AS VARCHAR(20)) AS FLOAT),0)
) AS [Post-Purchase and Other Group Education - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)W
ON A.pcode = W.pcode 
AND A.ReportingYear = W.ReportingYear 
AND A.ReportingQuarter = W.ReportingQuarter
FULL OUTER JOIN 
--==================================================
(

--2013
----Non-Foreclosure Individual Counseling Results
--FY2010 and FY2011: Sum (21701 + 21702 + 21703 + 21704 + 21705)
--FY2012: Sum (23575 + 21701 + 21702 + 21703 + 21704 + 21705)
--FY2013: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705)
--2014
--Other Counseling - Customers
--FY2010 and FY2011: Sum (21701 + 21702 + 21703 + 21704 + 21705)
--FY2012: Sum (23575 + 21701 + 21702 + 21703 + 21704 + 21705)
--FY2013: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705)
--FY2014: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705 + 24237)
-------------------------------------------------------------------
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Other Counseling - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2010
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
UNION ALL 
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Other Counseling - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2011
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
UNION ALL 

--FY2012: Sum (23575 + 21701 + 21702 + 21703 + 21704 + 21705)
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(

ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Pre-purchase Homebuyer Individual Counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Non-Foreclosure Individual Counseling Results]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2012
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
UNION ALL 
----FY2013: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705)
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Non-Foreclosure Individual Counseling Results]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2013
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter

UNION ALL 
--FY2014: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705 + 24237)
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2014
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter


UNION ALL 
--FY2014: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705 + 24237)
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2015
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
UNION ALL 
--FY2014: Sum (23842 + 23843 + 23844 + 21701 + 21702 + 21704 + 21705 + 24237)
SELECT A.PCode, A.ReportingYear , A.ReportingQuarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained a Home Equity Conversion Mortgage (HECM)] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled on HECM; decided not to obtain mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled and referred to other social service agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed financial management/ budget counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed home maintenance counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling]  A
WHERE A.ReportingYear = 2016
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)X
ON A.pcode = X.pcode 
AND A.ReportingYear = X.ReportingYear 
AND A.ReportingQuarter = X.ReportingQuarter
FULL OUTER JOIN 
(
--=========================================================
--2013
----Foreclosure Mitigation Counseling Outcomes (home not retained)
--Sum (if 21619 is 7 AND if 21657 is 7 - 14, then Count 21617)
--2014
--Foreclosure Mitigation Counseling, Home Not Retained - Customers
--Sum (if 21619 is 7 AND if 21657 is 7 - 14, then Count 21617)
-----------------------------------------------------------

SELECT 
C.PCode
,C.ReportingYear 
,C.ReportingQuarter 
,COUNT(C.[Client ID]) AS [Foreclosure Mitigation Counseling, Home Not Retained - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client C 
WHERE C.[NWO Role] =
'Foreclosure Mitigation Counseling'
AND C.[Foreclosure Counseling Outcome] IN 
(
'Executed a deed-in-lieu'
,'Sold property/chose alternative housing solution' 
,'Pre-foreclosure sale'  
,'Mortgage Foreclosed'    
,'Bankruptcy'  
,'Entered debt management'  
,'Counseled and referred for legal assistance'
,'Other (final result not listed above)'
)
GROUP BY 
 C.PCode
,C.ReportingYear 
,C.ReportingQuarter 
)Y
ON A.pcode = Y.pcode 
AND A.ReportingYear = Y.ReportingYear 
AND A.ReportingQuarter = Y.ReportingQuarter
FULL OUTER JOIN 
(
--=============================================================
--2013
--Sum 21700
---Foreclosure Intake
--2014
--Foreclosure Mitigation Counseling Intake - Customers
--Sum 21700
-----------------------------------------------------------------
SELECT 
 K.pcode 
,K.ReportingYear 
,K.ReportingQuarter 
,SUM(ISNULL(K.[Foreclosure Intake (Households)], 0) ) 
 AS [Foreclosure Mitigation Counseling Intake - Customers]
FROM ProjectsandSummary.[Fact_Owner Occupied Repairs and Counseling] K
GROUP BY K.pcode 
,K.ReportingYear 
,K.ReportingQuarter
)Z
ON A.pcode = Z.pcode 
AND A.ReportingYear = Z.ReportingYear 
AND A.ReportingQuarter = Z.ReportingQuarter
FULL OUTER JOIN 
(
--========================================
--2013
--Owned
--FY2010 - FY2013: 21781

--Managed and not owned
--FY2010 - FY2013: 21787

--Total Owned/Managed
--FY2010 - FY2013: 21781 + 21787

--2014
--Rental Homes Portfolio, Owned
--FY2014: Sum 24210

--Rental Homes Portfolio, Managed not Owned
--FY2014: Sum 24211

--Rental Homes Portfolio, Owned and/or Managed
--FY2014: Sum (24210 + 24211)
-----------------------------------------------
--SELECT A.pcode , A.ReportingYear , A.ReportingQuarter 
--,SUM(ISNULL(CAST(CAST(A.[Total Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
--,SUM(ISNULL(CAST(CAST(A.[Total housing units Managed and not owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
--,SUM(ISNULL(CAST(CAST(A.[Total Owned] AS VARCHAR(20)) AS INT),0) + 
-- ISNULL(CAST(CAST(A.[Total housing units Managed and not owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM ProjectsandSummary.[Dim_Rental _Mutual Housing Portfolio_1] A
--GROUP BY A.pcode , A.ReportingYear , A.ReportingQuarter 

--UNION ALL 
--SELECT 
-- A.pcode , A.ReportingYear , A.ReportingQuarter 
-- ,SUM (A.[Rental Homes Portfolio, Owned]) AS [Rental Homes Portfolio, Owned]
-- ,SUM (A.[Rental Homes Portfolio, Managed not Owned]) AS [Rental Homes Portfolio, Managed not Owned]
-- ,SUM (A.[Rental Homes Portfolio, Owned and/or Managed]) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM (
--SELECT A.pcode , A.ReportingYear , A.ReportingQuarter 
--,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
--,SUM(ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
--,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0) + 
-- ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM ProjectsandSummary.[Dim_Rental _Mutual Housing Portfolio_3] A
--GROUP BY A.pcode , A.ReportingYear , A.ReportingQuarter 


--) A 
--GROUP BY  A.pcode , A.ReportingYear , A.ReportingQuarter 

--UNION ALL 
SELECT 
 A.pcode , A.ReportingYear , A.ReportingQuarter 
 ,SUM (A.[Rental Homes Portfolio, Owned]) AS [Rental Homes Portfolio, Owned]
,SUM (A.[Rental Homes Portfolio, Managed not Owned]) AS [Rental Homes Portfolio, Managed not Owned]
,SUM (A.[Rental Homes Portfolio, Owned and/or Managed]) AS [Rental Homes Portfolio, Owned and/or Managed]
FROM (
SELECT A.pcode , A.ReportingYear , A.ReportingQuarter 
,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
,SUM(ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0) + 
 ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
FROM ProjectsandSummary.[Fact_Rental_Mutual_Housing_Portfolio]  A
GROUP BY A.pcode , A.ReportingYear , A.ReportingQuarter 
) A 

GROUP BY  A.pcode , A.ReportingYear , A.ReportingQuarter


)AA
ON A.pcode = AA.pcode 
AND A.ReportingYear = AA.ReportingYear 
AND A.ReportingQuarter = AA.ReportingQuarter
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FULL OUTER JOIN 
(
--====================================================
--2013
--Foreclosure Mitigation Clients
--if 21619 is 7 AND if 21657 is 1 - 6, then Count 21617
--2014
--Preserved Homeownership, Foreclosure Mitigation - Customers
--if 21619 is 7 AND if 21657 is 1 - 6, then Count 21617
------------------------------------------------------- 
SELECT  
  c.pcode 
, c.ReportingYear
, c.ReportingQuarter  
,count (c.[Client ID] ) AS [Preserved Homeownership, Foreclosure Mitigation - Customers]
  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
  where c.[NWO Role] = 'Foreclosure Mitigation Counseling'
  AND  C.[Foreclosure Counseling Outcome] IN (
  'Mortgage refinanced'  
,'Brought mortgage current' 
,'Mortgage modified'  
,'Received second mortgage' 
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
  )  
GROUP BY   
 c.pcode 
,c.ReportingYear
,c.ReportingQuarter
) A2
ON  A.pcode                                                      = A2.pcode 
AND A.ReportingYear                    = A2.ReportingYear  
AND A.ReportingQuarter  = A2.ReportingQuarter 
FULL OUTER JOIN 
(
--====================================================
--2013
--Foreclosure Mitigation Investment
--if 21619 is 7 AND if 21657 is 1 - 6, then Sum 21681
--2014
--Preserved Homeownership, Foreclosure Mitigation - Investment
--if 21619 is 7 AND if 21657 is 1 - 6, then Sum 21681
------------------------------------------------------- 
SELECT 
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter 
,SUM(m.Amount) AS  [Preserved Homeownership, Foreclosure Mitigation - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
ON  L.pcode =                                    m.pcode 
and L.ReportingYear =   m.ReportingYear 
and L.ReportingQuarter = M.ReportingQuarter 
and L.[Client ID] = M.[Client ID] 
WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
AND L.[Foreclosure Counseling Outcome] IN 
(
'Mortgage refinanced'  
,'Brought mortgage current'  
,'Mortgage modified'  
,'Received second mortgage'  
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
)

GROUP BY  
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter
)A3
ON  A.pcode                                                      = A3.pcode 
AND A.ReportingYear                    = A3.ReportingYear  
AND A.ReportingQuarter  = A3.ReportingQuarter 
FULL OUTER JOIN 
(
--====================================================
--2013
--Foreclosure Mitigation Units
--if 21619 is 7 AND if 21657 is 1 - 6, then Sum 21650
--2014
--Preserved Homeownership, Foreclosure Mitigation - Homes
--if 21619 is 7 AND if 21657 is 1 - 6, then Sum 21650
------------------------------------------------------- 
SELECT 
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter 
,SUM(L.[# Units]) AS  [Preserved Homeownership, Foreclosure Mitigation - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode =                                m.pcode 
--and L.ReportingYear =   m.ReportingYear 
--and L.ReportingQuarter = M.ReportingQuarter 
--and L.[Client ID] = M.[Client ID] 
WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
AND L.[Foreclosure Counseling Outcome] IN 
(
'Mortgage refinanced'  
,'Brought mortgage current'  
,'Mortgage modified'  
,'Received second mortgage'  
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
)

GROUP BY  
 L.pcode
,L.ReportingYear 
,L.ReportingQuarter
)A4
ON  A.pcode                                                      = A4.pcode 
AND A.ReportingYear                    = A4.ReportingYear  
AND A.ReportingQuarter  = A4.ReportingQuarter
FULL OUTER JOIN 
( 
--==================================================================
--2013
--Total Preservation
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Count 21617

--2014
--Preserved Homeownership - Customers
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Count 21617
--2016
--FY2016: if 21619 is 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Count 21617
---------------------------------------------------------------
SELECT  
  c.pcode 
, c.ReportingYear
, c.ReportingQuarter  
, count (c.[Client ID] ) AS [Preserved Homeownership - Customers]
  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
  WHERE 
-- c.[NWO Role]  IN 
-- (
-- 'Directly provides Rehab Service'  
--,'Counselor and/or Broker/Lender to an Existing Owner'
--)
--2016
  C.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
  OR ( c.[NWO Role] = 'Foreclosure Mitigation Counseling'
  AND  C.[Foreclosure Counseling Outcome] IN (
'Mortgage refinanced'  
,'Brought mortgage current' 
,'Mortgage modified'  
,'Received second mortgage' 
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
  )  
  )
GROUP BY   
 c.pcode 
,c.ReportingYear
,c.ReportingQuarter
) A5
ON  A.pcode                                                      = A5.pcode 
AND A.ReportingYear                    = A5.ReportingYear  
AND A.ReportingQuarter  = A5.ReportingQuarter
FULL OUTER JOIN 
( 
--==================================================================
--2013
--Total Preservation Units
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650

--2014
--Preserved Homeownership - Homes
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
--2016
--FY2016: if 21619 is 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
---------------------------------------------------------------
SELECT  
  c.pcode 
, c.ReportingYear
, c.ReportingQuarter  
, SUM (c.[# Units] ) AS [Preserved Homeownership - Homes]
  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
 where 
-- c.[NWO Role]  IN 
-- (
-- 'Directly provides Rehab Service'  
--,'Counselor and/or Broker/Lender to an Existing Owner'
--)
--2016
  C.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
  OR ( c.[NWO Role] = 'Foreclosure Mitigation Counseling'
  AND  C.[Foreclosure Counseling Outcome] IN (
'Mortgage refinanced'  
,'Brought mortgage current' 
,'Mortgage modified'  
,'Received second mortgage' 
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
  )  
  )
GROUP BY   
 c.pcode 
,c.ReportingYear
,c.ReportingQuarter
) A6
ON  A.pcode                                                      = A6.pcode 
AND A.ReportingYear                    = A6.ReportingYear  
AND A.ReportingQuarter  = A6.ReportingQuarter
FULL OUTER JOIN 
( 
--==================================================================
--2013
--Total Preservation Investment
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
----------------------------------------------------------------------
--2014
--Preserved Homeownership - Investment
--if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
--2016
--FY2016: if 21619 is 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21681
---------------------------------------------------------------
SELECT  
  L.pcode 
, L.ReportingYear
, L.ReportingQuarter  
, SUM(M.Amount ) AS [Preserved Homeownership - Investment]
  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] L
  INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
ON  L.pcode =                                    m.pcode 
and L.ReportingYear =   m.ReportingYear 
and L.ReportingQuarter = M.ReportingQuarter 
and L.[Client ID] = M.[Client ID] 
  where 
-- c.[NWO Role]  IN 
-- (
-- 'Directly provides Rehab Service'  
--,'Counselor and/or Broker/Lender to an Existing Owner'
--)
--2016
  L.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
  OR ( L.[NWO Role] = 'Foreclosure Mitigation Counseling'
  AND  L.[Foreclosure Counseling Outcome] IN (
'Mortgage refinanced'  
,'Brought mortgage current' 
,'Mortgage modified'  
,'Received second mortgage' 
,'Initiated forbearance agreement/repayment plan' 
,'Obtained partial claim loan from FHA lender'
  )  
  )
GROUP BY   
 L.pcode 
,L.ReportingYear
,L.ReportingQuarter
) A7
ON  A.pcode                                                      = A7.pcode 
AND A.ReportingYear                    = A7.ReportingYear  
AND A.ReportingQuarter  = A7.ReportingQuarter
FULL OUTER JOIN 
( 
--===============================================
--2013
---Constructed
---if 21729 is 1, than Sum 21730
--2014
--Rental Homes, Constructed
--if 21729 is 1, than Sum 21730
-----------------------------------------------
SELECT 
 A.pcode , A.ReportingYear , A.ReportingQuarter
,SUM(ISNULL(CAST(CAST(A.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Constructed]
FROM ProjectsandSummary.[Dim_Rental Production]   A 
WHERE A.[Rental Activity Type] = 'Constructed'
GROUP BY A.pcode , A.ReportingYear , A.ReportingQuarter

)A8
ON  A.pcode                                                      = A8.pcode 
AND A.ReportingYear                    = A8.ReportingYear  
AND A.ReportingQuarter  = A8.ReportingQuarter
FULL OUTER JOIN 
( 
--===============================================
--2013
---Purchased for New Renters
---if 21729 is 2, than Sum 21730
--2014
--Rental Homes, Purchased for New Renters
--if 21729 is 2, than Sum 21730
-----------------------------------------------
SELECT  A.pcode , A.ReportingYear , A.ReportingQuarter
,SUM(ISNULL(CAST(CAST(A.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Purchased for New Renters]
FROM ProjectsandSummary.[Dim_Rental Production]   A 
WHERE A.[Rental Activity Type] = 'Purchased for new renters'
GROUP BY A.pcode , A.ReportingYear , A.ReportingQuarter
) A9
ON  A.pcode                                                      = A9.pcode 
AND A.ReportingYear                    = A9.ReportingYear  
AND A.ReportingQuarter  = A9.ReportingQuarter
FULL OUTER JOIN 
( 
--===============================================
--2013
---Purchased with Existing Renters
---if 21729 is 3, than Sum 21730 
--2014
--Rental Homes, Purchased with Existing Renters
--if 21729 is 3, than Sum 21730 
-----------------------------------------------
SELECT  C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Purchased with Existing Renters]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE C.[Rental Activity Type] = 'Purchased with existing renters'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
)A10

ON  A.pcode                                                      = A10.pcode 
AND A.ReportingYear                    = A10.ReportingYear  
AND A.ReportingQuarter  = A10.ReportingQuarter
FULL OUTER JOIN 
( 
--===============================================
--2013
---Refinanced
---if 21729 is 4, than Sum 21730
--2014
--Rental Homes, Refinanced
--if 21729 is 4, than Sum 21730
-----------------------------------------------
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Refinanced]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE C.[Rental Activity Type] = 'Re-financed to extend affordability of property for > 10 years'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
) A11
ON  A.pcode                                                      = A11.pcode 
AND A.ReportingYear                    = A11.ReportingYear  
AND A.ReportingQuarter  = A11.ReportingQuarter
FULL OUTER JOIN 
( 
--===============================================
--2013
---Rehabilitated
---if 21729 is 5, than Sum 21730
--2014
--Rental Homes, Rehabilitated
--if 21729 is 5, than Sum 21730
-----------------------------------------------
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Rehabilitated]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE C.[Rental Activity Type] IN('Rehabilitated', 'Rehabilitated Existing Property')
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter

) A12
ON  A.pcode                                                      = A12.pcode 
AND A.ReportingYear                    = A12.ReportingYear  
AND A.ReportingQuarter  = A12.ReportingQuarter
FULL OUTER JOIN 
--=====================================================
(

/*
--2013
                Assisted Not Owned
                FY2010: if 21729 is 6, than Sum 21730
                FY2011: if 21729 is 7 AND 23088 is 1 - 7, than Sum 21730 
                FY2012 - FY2013: if 21729 is 7, than Sum 21730 
--2014
                Rental Homes, Development Services
                FY2010: if 21729 is 6, than Sum 21730
                FY2011: if 21729 is 7 AND 23088 is 1 - 7, than Sum 21730 
                FY2012 - FY2014: if 21729 is 7, than Sum 21730 
*/

SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Development Services]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE  C.ReportingYear = 2010 AND 
C.[Rental Activity Type] = 'Assisted (not owned or managed)'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
UNION ALL 
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE  C.ReportingYear = 2011 AND (
C.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
AND C.[Assisted Activity Type (including fee developer)] IN 
(
'Planning' 
,'Asset Management'
,'Resource Development'
,'Direct Investment'
,'Site Related Services'
,'Construction Management'
,'General Contracting'
)

)
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
UNION ALL 
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE  C.ReportingYear IN (2012, 2013,2014,2015) AND 
C.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
--2016
--FY2016: if 21729 is 8 or 11, then Sum 21730
UNION ALL 
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE  C.ReportingYear =2016 AND 
C.[Rental Activity Type] 
IN( 'Assisted Not Owned (including fee developer)','Assisted Not Owned (including fee developer)')
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter 
) A13

ON  A.pcode                                                      = A13.pcode 
AND A.ReportingYear                    = A13.ReportingYear  
AND A.ReportingQuarter  = A13.ReportingQuarter
FULL OUTER JOIN 
--=====================================================
(
--2013
--NSP Rehab
--FY2010: N/A
--FY2011 - FY2014: if 21729 is 8, than Sum 21730
--2014
--Rental Homes, Rehabilitated with NSP Funds
--FY2010: N/A
--FY2011 - FY2014: if 21729 is 8, than Sum 21730
--2016
--FY2016: if 21729 is 9 or 12, then Sum 21730
------------------------------------------------------- 

SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(CAST(CAST(C.[# Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Rehabilitated with NSP Funds]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE C.[Rental Activity Type] = 
 'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
)A14
ON  A.pcode                                                      = A14.pcode 
AND A.ReportingYear                    = A14.ReportingYear  
AND A.ReportingQuarter  = A14.ReportingQuarter
FULL OUTER JOIN 
(
--==============================================
--2013
--Rental Assisted Not Owned Not Managed
--FY2010: N/A
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 
--FY2012 - FY2013: if 21729 is 7 AND 23089 = 'No', than Sum 21730
--2014
--Rental Homes, Development Services, Not Managed
--FY2010: Null
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 + 
----           if 21729 is 8, than Sum 21730
-------------------------------------------------
SELECT *
FROM #RentalAssistedNotOwnedNotManaged A

) A15
ON  A.pcode                                                      = A15.pcode 
AND A.ReportingYear                    = A15.ReportingYear  
AND A.ReportingQuarter  = A15.ReportingQuarter
FULL OUTER JOIN 
(
--===================================================
--2013
--Constructed Units Rental Investment
--if 21729 is 1, than Sum 21741
--2014
---Rental Homes, Constructed - Investment
--if 21729 is 1, than Sum 21741
--------------------------------------------------
SELECT C.pcode , C.ReportingYear , C.ReportingQuarter
,SUM(ISNULL(C.[Sum of Costs],0)) AS  [Rental Homes, Constructed - Investment]
FROM ProjectsandSummary.[Dim_Rental Production]   C 
WHERE  C.[Rental Activity Type] = 'Constructed'
GROUP BY C.pcode , C.ReportingYear , C.ReportingQuarter
)A16
ON  A.pcode                                                      = A16.pcode 
AND A.ReportingYear                    = A16.ReportingYear  
AND A.ReportingQuarter  = A16.ReportingQuarter
FULL OUTER JOIN 
(
--=================================================================
--2013
--Number of Residents Trained
--CB&O Survey.  Question: CBON1 - Number of Residents Participating in Leadership Training Sponsored or Supported by NWO. [22215]
--2014
--Residents Trained
--FY2010 - FY2013:  CB&O Survey.  Question: CBON1 - Number of Residents Participating in Leadership Training Sponsored or Supported by NWO. [22215]
--FY2014: 24259

------------------------------------------------------------------
  SELECT 
  R.PCode 
 ,R.ReportingYear 
 ,R.ReportingQuarter 
 ,SUM( CAST(CAST(REPLACE(R.Answer,'No response',0) AS VARCHAR(20))AS INT)) AS [Residents Trained] 
 FROM EDW_Staging.dbo.vw_ExtractResponses R
WHERE CAST(R.DataPointID AS VARCHAR(20)) IN('12', '22215', '24259')
GROUP BY R.PCode 
 ,R.ReportingYear 
 ,R.ReportingQuarter

)A17
ON  A.pcode                                                      = A17.pcode 
AND A.ReportingYear                    = A17.ReportingYear  
AND A.ReportingQuarter  = A17.ReportingQuarter
FULL OUTER JOIN 
(
--===========================================================
--2013
--Number of Volunteer Hours
--FY2010 - FY2013: CB&O Survey.  Question: CBON2 (a + b) - Volunteer person hours this quarter. [22217] + [22218]
--2014
--Volunteer Hours
--FY2010 - FY2013: CB&O Survey.  Question: CBON2 (a + b) - Volunteer person hours this quarter. [22217] + [22218]
--FY2014: 24255 + 24256
------------------------------------------------------------
SELECT 
r.PCode 
,r.ReportingYear 
,r.ReportingQuarter 
,SUM(CAST(REPLACE(r.Answer, 'No response',0) AS INT)) AS [Volunteer Hours]
FROM SSIS.Projects_and_Summary r 
where DataPointID =25014
GROUP BY r.PCode 
,r.ReportingYear 
,r.ReportingQuarter 

)A18
ON  A.pcode                                                      = A18.pcode 
AND A.ReportingYear                    = A18.ReportingYear  
AND A.ReportingQuarter  = A18.ReportingQuarter

FULL OUTER JOIN 
(
--=======================================================
--2013
--Number of Volunteer Hours that were dedicated to NeighborWorks Week
--FY2010 - FY2012: Null
--FY2013: CB&O Survey.  Question: CBON4 [23925]
--2014
--Volunteer Hours, NeighborWorks Week
--FY2010 - FY2012: Null
--FY2013: CB&O Survey.  Question: CBON4 [23925]
--FY2014: 24257
---------------------------------------------------------
SELECT 
r.PCode 
,r.ReportingYear 
,r.ReportingQuarter 
,SUM(CAST(REPLACE(r.Answer, 'No response',0) AS INT)) AS [Volunteer Hours, NeighborWorks Week]
FROM EDW_Staging.dbo.vw_ExtractResponses r 
where DataPointID IN ( 23925, 24257)
GROUP BY r.PCode 
,r.ReportingYear 
,r.ReportingQuarter 
) A19
ON  A.pcode                                                      = A19.pcode 
AND A.ReportingYear                    = A19.ReportingYear  
AND A.ReportingQuarter  = A19.ReportingQuarter
FULL OUTER JOIN 
---==================================
--FY2016
--Preserved Homeownership, Replacement - Customers
--FY2010 - FY2015: NULL
--FY2016: if 21619 is 6 AND 21620 is 4, then Count 21617
/*
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
*/
/*
"1. Rehab
2. Refinance not foreclosure
3. Reverse mortgage
4. Replacement
5. Not Applicable   [use with NWO Role = 1]
6. Not Applicable   [use with NWO Role = 2]
7. Not Applicable   [use with NWO Role = 3]
8. Not Applicable   [use with NWO Role = 4]
9. Not Applicable   [use with NWO Role = 5]
10. Not Applicable   [use with NWO Role = 7]"

*/
-----------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,COUNT(A.[Client ID]  ) AS [Preserved Homeownership, Replacement - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A

WHERE 
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Replacement'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)A20
ON A.pcode = A20.pcode 
AND A.ReportingYear = A20.ReportingYear 
AND A.ReportingQuarter = A20.ReportingQuarter 
FULL OUTER JOIN 
---==================================
--FY2016
--Preserved Homeownership, Replacement - Homes
--FY2010 - FY2015: NULL
--FY2016: if 21619 is 6 AND 21620 is 4, then Sum 21650
/*
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
*/
/*
"1. Rehab
2. Refinance not foreclosure
3. Reverse mortgage
4. Replacement
5. Not Applicable   [use with NWO Role = 1]
6. Not Applicable   [use with NWO Role = 2]
7. Not Applicable   [use with NWO Role = 3]
8. Not Applicable   [use with NWO Role = 4]
9. Not Applicable   [use with NWO Role = 5]
10. Not Applicable   [use with NWO Role = 7]"

*/
-----------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM(A.[# Units]  ) AS [Preserved Homeownership, Replacement - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A

WHERE 
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Replacement'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)A21
ON A.pcode = A21.pcode 
AND A.ReportingYear = A21.ReportingYear 
AND A.ReportingQuarter = A21.ReportingQuarter 
FULL OUTER JOIN 
---==================================
--FY2016
--Preserved Homeownership, Replacement - Investment
--FY2010 - FY2015: NULL
--FY2016: if 21619 is 6 AND if 21620 is 4, then Sum 21681
/*
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
*/
/*
"1. Rehab
2. Refinance not foreclosure
3. Reverse mortgage
4. Replacement
5. Not Applicable   [use with NWO Role = 1]
6. Not Applicable   [use with NWO Role = 2]
7. Not Applicable   [use with NWO Role = 3]
8. Not Applicable   [use with NWO Role = 4]
9. Not Applicable   [use with NWO Role = 5]
10. Not Applicable   [use with NWO Role = 7]"

*/
-----------------------------------------
(
SELECT 
A.PCode, A.ReportingYear , A.ReportingQuarter 
,SUM( B.Amount ) AS [Preserved Homeownership, Replacement - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.ReportingQuarter = B.ReportingQuarter 
AND A.ReportingYear = B.ReportingYear 
 
WHERE 
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Replacement'
GROUP BY A.PCode, A.ReportingYear , A.ReportingQuarter
)A22
ON A.pcode = A22.pcode 
AND A.ReportingYear = A22.ReportingYear 
AND A.ReportingQuarter = A22.ReportingQuarter 
   

-------------------------------------------------------------------------------
DELETE [EDW_Staging].[Quarterly].[tblQPR_Comprehensive_Quarterly_Report]
WHERE ReportingYear = @ReportingYear AND ReportingQuarter = @ReportingQuarter
INSERT INTO [EDW_Staging].[Quarterly].[tblQPR_Comprehensive_Quarterly_Report]
(
[pcode]
      ,[ReportingYear]
      ,[ReportingQuarter]
      ,[Homeowners Created - Customers]
      ,[Homeowners Created - Homes]
      ,[Homeowners Created - Investment]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
      ,[Preserved Homeownership, Refinancing - Customers]
      ,[Preserved Homeownership, Refinancing - Homes]
      ,[Preserved Homeownership, Refinancing - Investment]
      ,[Preserved Homeownership, Reverse Mortgage - Customers]
      ,[Preserved Homeownership, Reverse Mortgage - Homes]
      ,[Preserved Homeownership, Reverse Mortgage - Investment]
      ,[Preserved Homeownership, Foreclosure Mitigation - Customers]
      ,[Preserved Homeownership, Foreclosure Mitigation - Homes]
      ,[Preserved Homeownership, Foreclosure Mitigation - Investment]
      ,[Preserved Homeownership - Customers]
      ,[Preserved Homeownership - Homes]
      ,[Preserved Homeownership - Investment]
      ,[Rental Homes, Constructed]
      ,[Rental Homes, Purchased for New Renters]
      ,[Rental Homes, Purchased with Existing Renters]
      ,[Rental Homes, Refinanced]
      ,[Rental Homes, Rehabilitated]
      ,[Rental Homes, Development Services]
      ,[Rental Homes, Rehabilitated with NSP Funds]
      ,[Rental Homes Constructed, Acquired, and Preserved]
      ,[Rental Homes, Repaired]
      ,[Rental Homes, Development Services, Not Managed]
      ,[Rental Homes - Investment]
      ,[Rental Homes, Constructed - Investment]
      ,[Commercial Development - Investment]
      ,[Commercial Lending - Investment]
      ,[Special Projects - Investment]
      ,[For-Sale Homes Developed - Investment]
      ,[Land Banking - Investment]
      ,[Owner-Occupied Repairs - Homes]
      ,[Owner-Occupied Repairs - Investment]
      ,[Total Repaired - Homes]
      ,[Total Direct Investment]
      ,[Pre-purchase Homebuyer Group Education - Customers]
      ,[Pre-purchase Financial Literacy Group Education - Customers]
      ,[Post-Purchase and Other Group Education - Customers]
      ,[Other Counseling - Customers]
      ,[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
      ,[Foreclosure Mitigation Counseling Intake - Customers]
      ,[Rental Homes Portfolio, Owned]
      ,[Rental Homes Portfolio, Managed not Owned]
      ,[Rental Homes Portfolio, Owned and/or Managed]
      ,[Residents Trained]
      ,[Volunteer Hours]
      ,[Volunteer Hours, NeighborWorks Week]
      ,[Preserved Homeownership, Replacement - Customers]
      ,[Preserved Homeownership, Replacement - Homes]
      ,[Preserved Homeownership, Replacement - Investment]
)
---------------------------------------------------------------------------------
SELECT 
[pcode]
      ,[ReportingYear]
      ,[ReportingQuarter]
      ,[Homeowners Created - Customers]
      ,[Homeowners Created - Homes]
      ,[Homeowners Created - Investment]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
      ,[Preserved Homeownership, Refinancing - Customers]
      ,[Preserved Homeownership, Refinancing - Homes]
      ,[Preserved Homeownership, Refinancing - Investment]
      ,[Preserved Homeownership, Reverse Mortgage - Customers]
      ,[Preserved Homeownership, Reverse Mortgage - Homes]
      ,[Preserved Homeownership, Reverse Mortgage - Investment]
      ,[Preserved Homeownership, Foreclosure Mitigation - Customers]
      ,[Preserved Homeownership, Foreclosure Mitigation - Homes]
      ,[Preserved Homeownership, Foreclosure Mitigation - Investment]
      ,[Preserved Homeownership - Customers]
      ,[Preserved Homeownership - Homes]
      ,[Preserved Homeownership - Investment]
      ,[Rental Homes, Constructed]
      ,[Rental Homes, Purchased for New Renters]
      ,[Rental Homes, Purchased with Existing Renters]
      ,[Rental Homes, Refinanced]
      ,[Rental Homes, Rehabilitated]
      ,[Rental Homes, Development Services]
      ,[Rental Homes, Rehabilitated with NSP Funds]
      ,[Rental Homes Constructed, Acquired, and Preserved]
      ,[Rental Homes, Repaired]
      ,[Rental Homes, Development Services, Not Managed]
      ,[Rental Homes - Investment]
      ,[Rental Homes, Constructed - Investment]
      ,[Commercial Development - Investment]
      ,[Commercial Lending - Investment]
      ,[Special Projects - Investment]
      ,[For-Sale Homes Developed - Investment]
      ,[Land Banking - Investment]
      ,[Owner-Occupied Repairs - Homes]
      ,[Owner-Occupied Repairs - Investment]
      ,[Total Repaired - Homes]
      ,[Total Direct Investment]
      ,[Pre-purchase Homebuyer Group Education - Customers]
      ,[Pre-purchase Financial Literacy Group Education - Customers]
      ,[Post-Purchase and Other Group Education - Customers]
      ,[Other Counseling - Customers]
      ,[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
      ,[Foreclosure Mitigation Counseling Intake - Customers]
      ,[Rental Homes Portfolio, Owned]
      ,[Rental Homes Portfolio, Managed not Owned]
      ,[Rental Homes Portfolio, Owned and/or Managed]
      ,[Residents Trained]
      ,[Volunteer Hours]
      ,[Volunteer Hours, NeighborWorks Week]
      ,[Preserved Homeownership, Replacement - Customers]
      ,[Preserved Homeownership, Replacement - Homes]
      ,[Preserved Homeownership, Replacement - Investment]
FROM #temp
WHERE ReportingYear = @ReportingYear AND ReportingQuarter = @ReportingQuarter






DROP TABLE #temp 
DROP TABLE #TotalDirectInvestment 
DROP TABLE #OwnerOccupiedUnits 
DROP TABLE #RentalProductionRepairedUnits 
DROP TABLE #Temp1 
DROP TABLE #TotalOwnerOccupiedUnitsRepaired 
DROP TABLE #RentalAssistedNotOwnedNotManaged

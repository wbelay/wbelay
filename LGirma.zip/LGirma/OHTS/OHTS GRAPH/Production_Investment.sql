IF OBJECT_ID(N'tempdb..#ReportedInvestmentOwnerOccupiedRepairsandCounseling') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentOwnerOccupiedRepairsandCounseling
END
---------------------------------------------------------
----[fact_Owner_Occupied_Repairs_and_Counseling]

SELECT 
   b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM(A.Total_Value_Of_Repairs_To_Owner_Occupied_Units) AS [Total Reported Investment]
INTO #ReportedInvestmentOwnerOccupiedRepairsandCounseling
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] a
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
------------------------------------
--6220
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestmentRED') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentRED
END
---------------------------------------------------
----[fact_Real_Estate_Development]
SELECT 
  b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Total_Development_Costs]) AS [Total Reported Investment]
INTO #ReportedInvestmentRED
FROM [dbo].[fact_Real_Estate_Development] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
------------------------------------
--6216
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestmentRentalProduction') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestmentRentalProduction
END
---------------------------------------------------
---[fact_Rental_Production]
SELECT 
   b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Sum_Of_Costs]) AS [Total Reported Investment]
INTO #ReportedInvestmentRentalProduction
FROM[dbo].[fact_Rental_Production] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--104
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedSpecialProjects') IS NOT NULL
BEGIN
DROP TABLE #ReportedSpecialProjects
END
---------------------------------------------------
-----[fact_Special_Projects]
SELECT 
   b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Project_Cost]) AS [Total Reported Investment]
INTO #ReportedSpecialProjects
FROM [dbo].[fact_Special_Projects] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
-------------------------------------
--6218
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_1') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_1
END
---------------------------------------------------
---[fact_Commercial_Lending_Activity]
SELECT 
 b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Direct_Loan_Value_From_RLF]) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_1
FROM [dbo].[fact_Commercial_Lending_Activity] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--6218
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_2') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_2
END
---------------------------------------------------
----[fact_Commercial_Lending_Activity]
SELECT 
b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Direct_Loan_Value_From_Now_Other_Sources]) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_2
FROM [dbo].[fact_Commercial_Lending_Activity] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--6218
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_3') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_3
END
---------------------------------------------------
---[fact_Commercial_Lending_Activity]
SELECT 
b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion]) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_3
FROM [dbo].[fact_Commercial_Lending_Activity] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--6218
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialLendingActivity_4') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialLendingActivity_4
END
---------------------------------------------------
--[fact_Commercial_Lending_Activity]
SELECT 
b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Owners_Portion_Out_Of_Pocket_Equity]) AS [Total Reported Investment]
INTO #ReportedCommercialLendingActivity_4
FROM [dbo].[fact_Commercial_Lending_Activity] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--6218
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedCommercialRealEstateDevelopment') IS NOT NULL
BEGIN
DROP TABLE #ReportedCommercialRealEstateDevelopment
END
---------------------------------------------------
-----[fact_Commercial_Real_Estate_Development]
SELECT 
b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Total_Cost]) AS [Total Reported Investment]
INTO #ReportedCommercialRealEstateDevelopment
FROM [dbo].[fact_Commercial_Real_Estate_Development] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
--3428
-------------------------------------
--============================================
IF OBJECT_ID(N'tempdb..#ReportedFinancing') IS NOT NULL
BEGIN
DROP TABLE #ReportedFinancing
END
---------------------------------------------------
---[fact_Financing]
SELECT 
b.PCode
  ,c.fin_year
  ,c.fin_quarter
,SUM([Financing_Amount]) AS [Total Reported Investment]
INTO #ReportedFinancing
FROM [dbo].[fact_Financing] A
join dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
join dbo.dim_date c
on a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY    b.PCode
  ,c.fin_year
  ,c.fin_quarter
-------------------------------------
----6215
--============================================
IF OBJECT_ID(N'tempdb..#ReportedInvestment') IS NOT NULL
BEGIN
DROP TABLE #ReportedInvestment
END
---------------------------------------------------
SELECT 
Coalesce(A.pcode,B.pcode,C.pcode,D.pcode,E.pcode,F.pcode,G.pcode,H.pcode,I.pcode,J.pcode) AS Pcode
, Coalesce(A.fin_year,B.fin_year,C.fin_year,D.fin_year,E.fin_year,
                     F.fin_year,G.fin_year,H.fin_year,I.fin_year,J.fin_year) AS ReportingYear
, Coalesce(A.fin_quarter,B.fin_quarter,C.fin_quarter,D.fin_quarter,E.fin_quarter,F.fin_quarter
	       ,G.fin_quarter,H.fin_quarter,I.fin_quarter,J.fin_quarter) AS ReportingQuarter
,ISNULL(A.[Total Reported Investment],0) +
ISNULL(B.[Total Reported Investment],0) +
ISNULL(C.[Total Reported Investment],0) +
ISNULL(D.[Total Reported Investment],0) +
ISNULL(E.[Total Reported Investment],0) +
ISNULL(F.[Total Reported Investment],0) +
ISNULL(G.[Total Reported Investment],0) +
ISNULL(H.[Total Reported Investment],0) +
ISNULL(I.[Total Reported Investment],0) +
ISNULL(J.[Total Reported Investment],0)  AS [Total Reported Investment_10]
INTO #ReportedInvestment
FROM #ReportedFinancing A
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_1 B
ON A.PCode=B.pcode
AND A.fin_year=B.fin_year
AND A.fin_quarter=B.fin_quarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_2 C
ON A.PCode=C.pcode
AND A.fin_year=C.fin_year
AND A.fin_quarter=C.fin_quarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_3 D
ON A.PCode=D.pcode
AND A.fin_year=D.fin_year
AND A.fin_quarter=D.fin_quarter
FULL OUTER JOIN 
#ReportedCommercialLendingActivity_4 E
ON A.PCode=E.pcode
AND A.fin_year=E.fin_year
AND A.fin_quarter=E.fin_quarter
FULL OUTER JOIN 
#ReportedCommercialRealEstateDevelopment F
ON A.PCode=F.pcode
AND A.fin_year=F.fin_year
AND A.fin_quarter=F.fin_quarter
FULL OUTER JOIN 
#ReportedInvestmentOwnerOccupiedRepairsandCounseling G
ON A.PCode=G.pcode
AND A.fin_year=G.fin_year
AND A.fin_quarter=G.fin_quarter
FULL OUTER JOIN 
#ReportedInvestmentRED H
ON A.PCode=H.pcode
AND A.fin_year=H.fin_year
AND A.fin_quarter=H.fin_quarter
FULL OUTER JOIN 
#ReportedInvestmentRentalProduction I
ON A.PCode=I.pcode
AND A.fin_year=I.fin_year
AND A.fin_quarter=I.fin_quarter
FULL OUTER JOIN 
#ReportedSpecialProjects J
ON A.PCode=J.pcode
AND A.fin_year=J.fin_year
AND A.fin_quarter=J.fin_quarter



SELECT *
FROM #ReportedInvestment


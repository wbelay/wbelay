CREATE VIEW [dbo].[VWOAD_OHTS_Investment]
AS 
SELECT [pcode]
      ,[ReportingYear]
      ,[ReportingQuarter]
      ,[Total Direct Investment]
  FROM [QUARTERLY].[ProjectsandSummary].[Fact_Comprehensive]
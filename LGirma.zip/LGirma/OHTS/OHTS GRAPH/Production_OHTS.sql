CREATE VIEW [dbo].[VWOAD_OHTS_Production]
AS 
SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,ISNULL([Rental Homes, Purchased for New Renters] ,0)+
	   ISNULL([Rental Homes, Development Services, Not Managed] ,0)+
	   ISNULL([Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] ,0)+
	   ISNULL([Homeowners Created - Customers] ,0)+
	   ISNULL([Preserved Homeownership, Refinancing - Customers] ,0)+
	   ISNULL([Preserved Homeownership, Foreclosure Mitigation - Customers] ,0)+
	   ISNULL([Rental Homes, Refinanced] ,0)+
	   ISNULL([Rental Homes, Rehabilitated] ,0) AS TotalProductionNumber
FROM ProjectsandSummary.Fact_Comprehensive C
WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))
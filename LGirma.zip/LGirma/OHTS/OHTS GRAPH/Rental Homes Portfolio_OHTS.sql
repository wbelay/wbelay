CREATE VIEW [dbo].[VWOAD_OHTS_RentalHomes Portfolio, Owned and/or Managed]
AS 
SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,[Rental Homes Portfolio, Owned] AS NumberOwned
	  ,[Rental Homes Portfolio, Managed not Owned] AS NumberManaged
FROM ProjectsandSummary.Fact_Comprehensive C
WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))
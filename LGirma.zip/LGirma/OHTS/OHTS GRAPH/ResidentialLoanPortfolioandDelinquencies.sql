--CREATE VIEW VWOAD_OHTS_ResidentialLoanPortfolioandDelinquencies
--AS
SELECT [PCODE]
,'First Mortgage' AS TypeofMortgage
,CAST(ReportingYear AS VARCHAR(4)) +' '+'Q'+ CAST(ReportingQuarter AS VARCHAR(2))AS [FiscalYearandQuarter]
,CONVERT(int, [1st Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [NumberOfOutstandingLoans]
,CONVERT(money,[1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [AmountOfOutstandingLoans]
,CONVERT(int, [1st Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [NumberOf 30 to 59 Days Delinqunet]
,CONVERT(money, [1st Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [AmountOf 30 to 59 Days Delinqunet]
,CONVERT(int, [1st Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [NumberOf 60 to 89 Days Delinqunet]
,CONVERT(money, [1st Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [AmountOf 60 to 89 Days Delinqunet]
,CONVERT(int, [1st Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [NumberOf 90 + Days Delinqunet]
,CONVERT(money, [1st Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [AmountOf 90 + Days Delinqunet]
,CONVERT(decimal(4,3), ([1st Mortgages: Value of RLF loans currently > 90 days delinquent]/ nullif([1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [% of $ 90+ Delinquent]
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 

UNION ALL

SELECT [PCODE]
,'Subordinate Mortgage' AS TypeofMortgage
,CAST(ReportingYear AS VARCHAR(4)) +' '+'Q'+ CAST(ReportingQuarter AS VARCHAR(2))AS [FiscalYearandQuarter]
,CONVERT(int, [2nd Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [NumberOfOutstandingLoans]
,CONVERT(money, [2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [AmountOfOutstandingLoans]
,CONVERT(int, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [SNumberOf 30 to 59 Days Delinqunet]
,CONVERT(money, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [AmountOf 30 to 59 Days Delinqunet]
,CONVERT(int, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [NumberOf 60 to 89 Days Delinqunet]
,CONVERT(money, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [AmountOf 60 to 89 Days Delinqunet]
,CONVERT(int, [2nd Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [NumberOf 90 + Days Delinqunet]
,CONVERT(money, [2nd Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [AmountOf 90 + Days Delinqunet]
,CONVERT(decimal(4,3), ([2nd Mortgages: Value of RLF loans currently > 90 days delinquent]/ nullif([2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [% of $ 90+ Delinquent] 
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 



USE [DataWarehouse]
GO
DECLARE                
 @Reporting_Year INT =2016 
,@Reporting_Quarter INT =1
---==============================================================================

---Total Owner-Occupied Units Repaired 6463
DECLARE @TotalOwnerOccupiedUnitsRepaired TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Total Owner-Occupied Units Repaired] MONEY 
)
INSERT INTO @TotalOwnerOccupiedUnitsRepaired 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(A.[Total_Value_Of_Repairs_To_Owner_Occupied_Units]) AS [Total Owner-Occupied Units Repaired]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN dbo.dim_Organization b
ON a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
---======================================================
--Real Estate Total Development Costs 6459
DECLARE @RealEstateTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Real Estate Total Development Costs] MONEY 
)
INSERT INTO @RealEstateTotalDevelopmentCosts 
SELECT a.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(B.[Total_Development_Costs]) AS [Real Estate Total Development Costs]
FROM  [dbo].[fact_Real_Estate_Development] B
JOIN dbo.dim_Organization a
ON b.dim_Organization_key=a.dim_Organization_key
JOIN dbo.dim_date c
ON b.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY a.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Rental Production Total Development Costs 104
DECLARE @RentalProductionTotalDevelopmentCosts TABLE  
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Rental Production Total Development Costs] MONEY 
)
INSERT INTO @RentalProductionTotalDevelopmentCosts 
SELECT b.pcode 
	  ,a.fin_year
	  ,a.fin_quarter
	  ,SUM(C.[Sum_Of_Costs]) AS [Real Estate Total Development Costs]
FROM [dbo].[fact_Rental_Production] C
JOIN dbo.dim_Organization b
ON c.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date a
ON c.[dim_ReportingQuarter_key]=a.dim_date_key
GROUP BY b.PCode
		,a.fin_year
		,a.fin_quarter

--====================================================
--Commercial RED Total Development Costs 3671
DECLARE @CommercialREDTotalDevelopmentCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Commercial RED Total Development Costs] MONEY 
)
INSERT INTO @CommercialREDTotalDevelopmentCosts 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM(D.[Total_Cost]) AS [Commercial RED Total Development Costs]
FROM [dbo].[fact_Commercial_Real_Estate_Development] D
JOIN dbo.dim_Organization b
ON d.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON d.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Special Project Cost 6461
DECLARE @SpecialProjectCost TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Special Project Cost] MONEY 
)
INSERT INTO @SpecialProjectCost 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter  
	  ,SUM(E.[Project_Cost]) AS [Special Project Cost]
FROM [dbo].[fact_Special_Projects] E
JOIN dbo.dim_Organization b
ON E.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON E.[dim_ReportingQuarter_key]=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--====================================================
--Infrastructure Improvement Contribution Amount 2790
DECLARE @InfrastructureImprovementContributionAmount TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[Infrastructure Improvement Contribution Amount] Money 
)
INSERT INTO @InfrastructureImprovementContributionAmount 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM(F.[Contribution_Amount]) AS [Infrastructure Improvement Contribution Amount]
FROM [dbo].[fact_Infrastructure_Improvement] F
JOIN dbo.dim_Organization b
ON F.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON F.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter 
--=====================================================================
--REO Land Bank Production 5731
DECLARE @REOLandBankProductionTotalCosts TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[REO Land Bank Production Total Costs] MONEY 
)
INSERT INTO @REOLandBankProductionTotalCosts 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM( G.[Total_Costs]) AS [REO Land Bank Production Total Costs]
FROM [dbo].[fact_REO_Land_Bank_Production] G
JOIN dbo.dim_Organization b
ON G.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON G.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
---Commercial Lending Activity Direct Loan Value from RLF 6461
DECLARE @CommercialLendingActivityRLF TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Direct Loan Value from RLF] MONEY 
)
INSERT INTO @CommercialLendingActivityRLF 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(H.[Direct_Loan_Value_From_RLF]) AS [CLA Direct Loan Value from RLF]
FROM [dbo].[fact_Commercial_Lending_Activity] H
JOIN dbo.dim_Organization b
ON H.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON H.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
--Commercial Lending Activity Direct Loan Value from NWO Other Sources 6461
DECLARE @CommercialLendingActivityNWO TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Direct Loan Value from NWO Other Sources] MONEY 
)
INSERT INTO @CommercialLendingActivityNWO 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(I.[Direct_Loan_Value_From_Now_Other_Sources]) AS [CLA Direct Loan Value from NWO Other Sources]
FROM [dbo].[fact_Commercial_Lending_Activity] I
JOIN dbo.dim_Organization b
ON I.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON I.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--=======================================================
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 6461
DECLARE @CommercialLendingActivityLeveragedAmount TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityLeveragedAmount 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM( J.[Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion]) AS [CLA Leveraged Amount (excludes NWO funds and Owner's Portion)]
FROM [dbo].[fact_Commercial_Lending_Activity] J
JOIN dbo.dim_Organization b
ON J.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON J.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--================================================================ 
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 6461
DECLARE @CommercialLendingActivityOwnersPortion TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
)
INSERT INTO @CommercialLendingActivityOwnersPortion 
SELECT b.pcode 
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM( K.[Owners_Portion_Out_Of_Pocket_Equity]) AS [CLA Owner's Portion (out-of-pocket equity)]
FROM [dbo].[fact_Commercial_Lending_Activity] K
JOIN dbo.dim_Organization b
ON K.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON K.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY b.PCode
		,c.fin_year
		,c.fin_quarter
--================================================================ 

DECLARE @CFNWORoleOnetoSixAndEight TABLE 
(
  PCode INT 
 ,Reporting_Year INT 
 ,Reporting_Quarter INT
,Amount MONEY
)
-----=====================
--I CAN'T FIND THE TABLES
---=======================


--INSERT INTO @CFNWORoleOnetoSixAndEight 
--SELECT L.pcode
	  --,L.Reporting_Year 
	  --,L.Reporting_Quarter 
	  --,SUM(m.Amount) AS  Amount
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode = m.pcode 
--and L.Reporting_Year = m.Reporting_Year 
--and L.Reporting_Quarter = M.Reporting_Quarter 
--and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] IN 
--(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Directly provides Rehab Service'  
--,'Counselor and/or Broker/Lender to an Existing Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--)
--GROUP BY  L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter 
---================================================
--(if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)
--DECLARE @CFNWORoleSeven TABLE 
--(
--  PCode INT 
-- ,Reporting_Year INT 
-- ,Reporting_Quarter INT
--,Amount MONEY
--)

--INSERT INTO @CFNWORoleSeven 
--SELECT 
-- L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter 
--,SUM(m.Amount) AS  Amount
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode = m.pcode 
--and L.Reporting_Year =   m.Reporting_Year 
--and L.Reporting_Quarter = M.Reporting_Quarter 
--and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
--AND L.[Foreclosure Counseling Outcome] IN 
--(
--'Mortgage refinanced'  
--,'Brought mortgage current'  
--,'Mortgage modified'  
--,'Received second mortgage'  
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--)

--GROUP BY L.pcode
		--,L.Reporting_Year 
		--,L.Reporting_Quarter
--======================================================================== 
 
SELECT   
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  AS PCode
,Coalesce(A.Reporting_Year , B.Reporting_Year, C.Reporting_Year,D.Reporting_Year,E.Reporting_Year,F.Reporting_Year,G.Reporting_Year,H.Reporting_Year,I.Reporting_Year,J.Reporting_Year,K.Reporting_Year,L.Reporting_Year,M.Reporting_Year) AS Reporting_Year 
,Coalesce(A.Reporting_Quarter, B.Reporting_Quarter ,C.Reporting_Quarter,D.Reporting_Quarter,E.Reporting_Quarter,F.Reporting_Quarter,G.Reporting_Quarter,H.Reporting_Quarter,I.Reporting_Quarter,J.Reporting_Quarter,K.Reporting_Quarter,L.Reporting_Quarter,M.Reporting_Quarter) AS Reporting_Quarter 
,sum(ISNULL(A.Amount , 0) + ISNULL(B.Amount,0) + ISNULL(C.[Total Owner-Occupied Units Repaired] , 0)
+ISNULL(D.[Real Estate Total Development Costs] , 0)
+ISNULL(E.[Rental Production Total Development Costs], 0) 
+ISNULL(F.[Commercial RED Total Development Costs] , 0)
+ISNULL(G.[Special Project Cost] , 0)
+ISNULL(H.[Infrastructure Improvement Contribution Amount] , 0)
+ISNULL(I.[REO Land Bank Production Total Costs] , 0)
+ISNULL(J.[CLA Direct Loan Value from RLF] , 0)
+ISNULL(K.[CLA Direct Loan Value from NWO Other Sources] , 0)
+ISNULL(L.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)
+ISNULL(M.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)) AS  [Total Direct Investment] 
INTO #TotalDirectInvestment
FROM @CFNWORoleOnetoSixAndEight A 
FULL OUTER JOIN 
@CFNWORoleSeven B 
ON A.PCode = B.PCode 
AND A.Reporting_Year = B.Reporting_Year 
AND A.Reporting_Quarter = B.Reporting_Quarter 
FULL OUTER JOIN 
@TotalOwnerOccupiedUnitsRepaired C
ON A.PCode = C.PCode 
AND A.Reporting_Year = C.Reporting_Year 
AND A.Reporting_Quarter = C.Reporting_Quarter 
FULL OUTER JOIN 
@RealEstateTotalDevelopmentCosts D
ON A.PCode = D.PCode 
AND A.Reporting_Year = D.Reporting_Year 
AND A.Reporting_Quarter = D.Reporting_Quarter 
FULL OUTER JOIN 
@RentalProductionTotalDevelopmentCosts E
ON A.PCode = E.PCode 
AND A.Reporting_Year = E.Reporting_Year 
AND A.Reporting_Quarter = E.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialREDTotalDevelopmentCosts F
ON A.PCode = F.PCode 
AND A.Reporting_Year = F.Reporting_Year
AND A.Reporting_Quarter = F.Reporting_Quarter 
FULL OUTER JOIN 
@SpecialProjectCost G
ON A.PCode = G.PCode 
AND A.Reporting_Year = G.Reporting_Year 
AND A.Reporting_Quarter = G.Reporting_Quarter 
FULL OUTER JOIN 
@InfrastructureImprovementContributionAmount H 
ON A.PCode = H.PCode 
AND A.Reporting_Year = H.Reporting_Year 
AND A.Reporting_Quarter = H.Reporting_Quarter 
FULL OUTER JOIN 
@REOLandBankProductionTotalCosts I 
ON A.PCode = I.PCode 
AND A.Reporting_Year = I.Reporting_Year 
AND A.Reporting_Quarter = I.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialLendingActivityRLF J 
ON A.PCode = J.PCode 
AND A.Reporting_Year = J.Reporting_Year 
AND A.Reporting_Quarter = J.Reporting_Quarter 
FULL OUTER JOIN 
@CommercialLendingActivityNWO K 
ON A.PCode = K.PCode 
AND A.Reporting_Year = K.Reporting_Year 
AND A.Reporting_Quarter = K.Reporting_Quarter
FULL OUTER JOIN 
@CommercialLendingActivityLeveragedAmount L
ON A.PCode = L.PCode 
AND A.Reporting_Year = L.Reporting_Year 
AND A.Reporting_Quarter = L.Reporting_Quarter
FULL OUTER JOIN 
@CommercialLendingActivityOwnersPortion M
ON  A.PCode = M.PCode 
AND A.Reporting_Year = M.Reporting_Year 
AND A.Reporting_Quarter = M.Reporting_Quarter
GROUP BY 
 COALESCE(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  
,COALESCE(A.Reporting_Year , B.Reporting_Year, C.Reporting_Year,D.Reporting_Year,E.Reporting_Year,F.Reporting_Year,G.Reporting_Year,H.Reporting_Year,I.Reporting_Year,J.Reporting_Year,K.Reporting_Year,L.Reporting_Year,M.Reporting_Year) 
,COALESCE(A.Reporting_Quarter, B.Reporting_Quarter ,C.Reporting_Quarter,D.Reporting_Quarter,E.Reporting_Quarter,F.Reporting_Quarter,G.Reporting_Quarter,H.Reporting_Quarter,I.Reporting_Quarter,J.Reporting_Quarter,K.Reporting_Quarter,L.Reporting_Quarter,M.Reporting_Quarter)  
--=========================================================
--RENTAL HOMES PORTFOLIO AND/OR MANAGED
---=======================================================

DECLARE @RentalAssistedNotOwnedNotManaged2011 TABLE 
(
pcode  INT 
,Reporting_Year  INT 
,Reporting_Quarter INT 
,Units2011 FLOAT 
)

INSERT INTO @RentalAssistedNotOwnedNotManaged2011 
SELECT b.pcode 
	  ,c.[Reporting_Year]
	  ,c.[Reporting_Quarter]
	  ,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
ON A.dim_Organization_key=b.dim_Organization_key
JOIN [dbo].[dim_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE c.[Reporting_Year] = 2011 AND 
C.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
----====&&&&&& I CAN'T FIND THIS FIELDS
--AND A.[Assisted Activity Type (including fee developer)] IN 
--(
--'Planning' 
--,'Asset Management'
--,'Resource Development'
--,'Direct Investment'
--,'Site Related Services'
--,'Construction Management'
--,'General Contracting'
--) AND A.[Does your organization Manage these units] = 'No'
GROUP BY b.PCode
		,c.[Reporting_Year]
	    ,c.[Reporting_Quarter]
---=======================================================
----3 
DECLARE @RentalAssistedNotOwnedNotManaged2012_2013 TABLE 
(
pcode  INT 
,Reporting_Year  INT 
,Reporting_Quarter INT 
,Units2012_2013 FLOAT 
)
INSERT INTO @RentalAssistedNotOwnedNotManaged2012_2013 
SELECT b.pcode 
	  ,c.[Reporting_Year]
	  ,c.[Reporting_Quarter]
,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
ON A.dim_Organization_key=b.dim_Organization_key
JOIN [dbo].[dim_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE C.Reporting_Year IN (2012, 2013,2014,2015) AND 
 C.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'

---&&&&& CAN'T FIND THIS COLUMN &&&&&&&--------

--AND A.[Does your organization Manage these units] = 'No'
GROUP BY b.PCode
		,c.[Reporting_Year]
	    ,c.[Reporting_Quarter]

UNION ALL

SELECT b.pcode 
	  ,c.[Reporting_Year]
	  ,c.[Reporting_Quarter]
	  ,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
ON A.dim_Organization_key=b.dim_Organization_key
JOIN [dbo].[dim_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE C.Reporting_Year IN (2012, 2013,2014,2015)  
AND  C.[Rental_Activity_Type] LIKE 'NWO is responsible for rehabilitation of units but does not take title of property%'
GROUP BY b.PCode
		,c.[Reporting_Year]
	    ,c.[Reporting_Quarter]

UNION ALL

--if 25046 = 3 AND 21729 = 11 or 12, then Sum 21730
SELECT b.pcode 
	  ,c.[Reporting_Year]
	  ,c.[Reporting_Quarter]
	  ,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
ON A.dim_Organization_key=b.dim_Organization_key
JOIN [dbo].[dim_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE C.Reporting_Year =2016  
AND C.[Type_Of_Ownership] = 'Not Owned and Not Managed (NOT reported in the Rental Portfolio)'
AND C.[Rental_Activity_Type] IN (
  'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
,'Assisted Not Owned (including fee developer)'
)
GROUP BY b.PCode
		,c.[Reporting_Year]
	    ,c.[Reporting_Quarter]
--============================================================================================
SELECT COALESCE(A.pcode , B.pcode ,0)AS  pcode
	  ,COALESCE(A.Reporting_Year , B.Reporting_Year ,0) AS Reporting_Year 
	  ,COALESCE(A.Reporting_Quarter , B.Reporting_Quarter ,0) AS  Reporting_Quarter
	  ,SUM(ISNULL(A.Units2011,0)  + ISNULL(B.Units2012_2013,0) ) AS [Rental Homes, Development Services, Not Managed]
INTO #RentalAssistedNotOwnedNotManaged
FROM @RentalAssistedNotOwnedNotManaged2011 A 
FULL OUTER JOIN 
@RentalAssistedNotOwnedNotManaged2012_2013 B
ON A.pcode = B.pcode 
AND A.Reporting_Year = B.Reporting_Year 
AND A.Reporting_Quarter = B.Reporting_Quarter 
GROUP BY COALESCE(A.pcode , B.pcode ,0)
		,COALESCE(A.Reporting_Year , B.Reporting_Year ,0)
		,COALESCE(A.Reporting_Quarter , B.Reporting_Quarter ,0)

--====================================================================================
DECLARE @RentalProductionUnits TABLE 
(
pcode INT 
,Reporting_Year INT 
,Reporting_Quarter INT 
,[Rental Homes Constructed, Acquired, and Preserved] INT 
)

INSERT INTO @RentalProductionUnits
SELECT B.pcode ,a.[Reporting_Year] ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [Rental Homes Constructed, Acquired, and Preserved]
FROM [dbo].[dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
where a.Reporting_Year = 2010
and a.[Rental_Activity_Type]  in ('Constructed' ,'Purchased for new renters' ,'Purchased with existing renters' 
								   ,'Re-financed to extend affordability of property for > 10 years' ,'Rehabilitated'
								   ,'Assisted (not owned or managed)'
)
Group by b.pcode, a.Reporting_Year, a.Reporting_Quarter 
INSERT INTO @RentalProductionUnits
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM[Dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
where a.Reporting_Year = 2011
and (a.[Rental_Activity_Type] 
IN ('Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP)'
)
OR 
(
A.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
--AND A. .[Assisted_Activity_Type (including fee developer)] IN 
--(
--'Planning' 
--,'Asset Management'
--,'Resource Development'
--,'Direct Investment'
--,'Site Related Services'
--,'Construction Management'
--,'General Contracting'
--)
)
)
GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter 
INSERT INTO @RentalProductionUnits
---2432
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [Dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE a.Reporting_Year  = 2012 
AND A.[Rental_Activity_Type]  
IN(
'Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter 

INSERT INTO @RentalProductionUnits
----1216
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON A.[dim_Rental_Production_key]=a.[dim_Rental_Production_key]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE a.Reporting_Year  = 2013     
and A.[Rental_Activity_Type]  
IN('Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter 

INSERT INTO @RentalProductionUnits
---608
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE a.Reporting_Year  = 2014     
and A.[Rental_Activity_Type]  
IN('Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)

GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter

INSERT INTO @RentalProductionUnits
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE a.Reporting_Year = 2015
and A.[Rental_Activity_Type]  
IN('Constructed'
,'Purchased for new renters'
,'Purchased with existing renters'
,'Re-financed to extend affordability of property for > 10 years'
,'Rehabilitated Existing Property'
,'Assisted Not Owned (including fee developer)'
,'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
)
GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter

INSERT INTO @RentalProductionUnits
---1216
SELECT b.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
	  ,sum(Cast(Cast(c.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [dim_Rental_Production] a
JOIN dbo.dim_Organization b
ON a.[Organization_ID]=b.[Organization_ID]
JOIN [dbo].[fact_Rental_Production] c
ON A.[dim_Rental_Production_key]=c.[dim_Rental_Production_key]
WHERE a.Reporting_Year  = 2016      
and A.[Rental_Activity_Type] <>'Repaired'
GROUP BY b.pcode, a.Reporting_Year, a.Reporting_Quarter
--==============================================================
----9728
SELECT *
INTO  #RentalProductionRepairedUnits
FROM (
SELECT b.pcode 
	  ,a.Reporting_Year 
	  ,a.Reporting_Quarter 
	  ,SUM(ISNULL(RP.[Number_Of_Units],0) ) AS [# Units]
FROM [fact_Rental_Production]  RP
JOIN [dim_Rental_Production] a
ON A.[dim_Rental_Production_key]=RP.[dim_Rental_Production_key]
JOIN dbo.dim_Organization b
ON A.[dim_Rental_Production_key]=a.[dim_Rental_Production_key]
WHERE a.Reporting_Year = 2011  
AND(
a.[Rental_Activity_Type] = 'Repaired' 
OR a.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
--AND RP.[Assisted Activity Type (including fee developer)] = 'Repaired'
) 
GROUP BY  b.pcode 
		 ,a.Reporting_Year 
		 ,a.Reporting_Quarter 
 
 UNION ALL 
 
SELECT b.pcode 
	  ,a.Reporting_Year 
	  ,a.Reporting_Quarter 
	  ,SUM(ISNULL(RP.[Number_Of_Units],0) ) AS [# Units]
FROM [fact_Rental_Production]  RP
JOIN [dim_Rental_Production] a
ON A.[dim_Rental_Production_key]=RP.[dim_Rental_Production_key]
JOIN dbo.dim_Organization b
ON RP.[dim_Rental_Production_key]=a.[dim_Rental_Production_key]
WHERE  a.[Rental_Activity_Type] = 'Repaired' AND a.Reporting_Year IN (2010, 2012, 2013,2014, 2015,2016)
GROUP BY  b.pcode 
		 ,a.Reporting_Year 
		 ,a.Reporting_Quarter 
) X 
--==============================================================
SELECT c.pcode 
	  ,b.Reporting_Year 
	  ,b.Reporting_Quarter 
	  ,SUM (ISNULL ([Total_Owner_Occupied_Units_Repaired],0) ) AS [# Units]
INTO #OwnerOccupiedUnits
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode 
		,b.Reporting_Year 
		,b.Reporting_Quarter
--=================================================================================
SELECT ISNULL (A.pcode , B.pcode)  AS pcode
	  ,ISNULL (A.Reporting_Year , B.Reporting_Year)  AS Reporting_Year
	  ,ISNULL (A.Reporting_Quarter , B.Reporting_Quarter)  AS Reporting_Quarter
	  ,ISNULL(A.[# Units],0) + ISNULL(B.[# Units] ,0) AS [Total Repaired Units]
INTO #Temp1 
FROM #RentalProductionRepairedUnits  A
FULL OUTER JOIN 
#OwnerOccupiedUnits  B
ON A.pcode = B.pcode 
AND A.Reporting_Year = B.Reporting_Year 
AND A.Reporting_Quarter = B.Reporting_Quarter 
---------------------------------------------
SELECT t.pcode 
	  ,t.Reporting_Year
	  ,t.Reporting_Quarter  
	  ,sum(t.[Total Repaired Units] ) as [Total Repaired Units]
INTO #TotalOwnerOccupiedUnitsRepaired
FROM #Temp1 t 
GROUP BY t.pcode 
	    ,t.Reporting_Year
		,t.Reporting_Quarter 
 
--==========================================

SELECT DISTINCT 
 A.pcode 
,A.Reporting_Year 
,A.Reporting_Quarter 
,A1.[Homeowners Created - Customers] 
,B.[Homeowners Created - Homes] 
,C.[Homeowners Created - Investment] 
,D.[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] 
,E.[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes] 
,F.[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment] 
,G.[Preserved Homeownership, Refinancing - Customers] 
,H.[Preserved Homeownership, Refinancing - Homes] 
,I.[Preserved Homeownership, Refinancing - Investment]
,G1.[Preserved Homeownership, Reverse Mortgage - Customers] 
,H1.[Preserved Homeownership, Reverse Mortgage - Homes] 
,I1.[Preserved Homeownership, Reverse Mortgage - Investment] 
,A2.[Preserved Homeownership, Foreclosure Mitigation - Customers] 
,A4.[Preserved Homeownership, Foreclosure Mitigation - Homes]
,A3.[Preserved Homeownership, Foreclosure Mitigation - Investment] 
,A5.[Preserved Homeownership - Customers] 
,A6.[Preserved Homeownership - Homes] 
,A7.[Preserved Homeownership - Investment] 
,A8.[Rental Homes, Constructed] 
,A9.[Rental Homes, Purchased for New Renters] 
,A10.[Rental Homes, Purchased with Existing Renters] 
,A11.[Rental Homes, Refinanced] 
,A12.[Rental Homes, Rehabilitated] 
,A13.[Rental Homes, Development Services] 
,A14.[Rental Homes, Rehabilitated with NSP Funds]
,J.[Rental Homes Constructed, Acquired, and Preserved] 
,K.[Rental Homes, Repaired]
,A15.[Rental Homes, Development Services, Not Managed] 
,L.[Rental Homes - Investment] 
,A16.[Rental Homes, Constructed - Investment] 
,M.[Commercial Development - Investment] 
,N.[Commercial Lending - Investment] 
,O.[Special Projects - Investment]
,Q.[For-Sale Homes Developed - Investment]
,R.[Land Banking - Investment] 
,S.[Owner-Occupied Repairs - Homes] 
,T.[Owner-Occupied Repairs - Investment] 
,U.[Total Repaired - Homes] 
,A.TotalReportedInvestment AS  [Total Direct Investment] 
,V.[Pre-purchase Homebuyer Group Education - Customers] 
,v1.[Pre-purchase Financial Literacy Group Education - Customers] 
,W.[Post-Purchase and Other Group Education - Customers] 
,X.[Other Counseling - Customers] 
,Y.[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
,Z.[Foreclosure Mitigation Counseling Intake - Customers] 
,AA.[Rental Homes Portfolio, Owned] 
,AA.[Rental Homes Portfolio, Managed not Owned] 
,AA.[Rental Homes Portfolio, Owned and/or Managed] 
,A17.[Residents Trained] 
,A18.[Volunteer Hours] 
,A19.[Volunteer Hours, NeighborWorks Week] 
,A20.[Preserved Homeownership, Replacement - Customers]
,A21.[Preserved Homeownership, Replacement - Homes]
,A22.[Preserved Homeownership, Replacement - Investment]

INTO #temp 
FROM 
(
SELECT *
FROM #ReportedInvestment2016 
)A
FULL OUTER JOIN 
(
--================================================================
/* I CAN'T FIND THIS TABLES..................
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,COUNT(A.[Client ID] ) AS [Homeowners Created - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE  A.[NWO Role] IN 
(
-- 'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
) A1
ON A.PCode = A1.pcode 
AND A.Reporting_Year = A1.Reporting_Year 
AND A.Reporting_Quarter = A1.Reporting_Quarter  
FULL OUTER JOIN 
(
--===============================================

SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,SUM(A.[# Units] ) AS [Homeowners Created - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE  A.[NWO Role] IN 
(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter

) B
ON A.pcode = B.pcode 
AND A.Reporting_Year = B.Reporting_Year 
AND A.Reporting_Quarter = B.Reporting_Quarter 
FULL OUTER JOIN 
---============================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,SUM( B.Amount ) AS [Homeowners Created - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.Reporting_Quarter = B.Reporting_Quarter 
AND A.Reporting_Year = B.Reporting_Year 
WHERE  A.[NWO Role] IN 
(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
----2016
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
) C
ON A.pcode = C.pcode 
AND A.Reporting_Year = C.Reporting_Year 
AND A.Reporting_Quarter = C.Reporting_Quarter 

FULL OUTER JOIN 
---==================================
--2013
--Owner Occupied Rehab Clients
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Count 21617
--2014
--Preserved Homeownership, Owner-Occupied Rehabilitation - Customers
--if 21619 is 5 OR (if 21619 is 6 AND if 21620 is 1), then Count 21617
--2016
--FY2016: if 21619 is 6 AND if 21620 is 1, then Count 21617
/*
--2016
--FY2016: If 21619 is 1-5, then Count 21617
1. NWO Constructs New Unit for New Home Owner
2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
3. Directly provides Self-Help Housing for New Home Owner
4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
5. Counselor and/or Broker/Lender ONLY for New Home Owner
6. NWO Provides Services to an Existing Home Owner
7. Foreclosure Mitigation Counseling
*/
--================================================================
(
SELECT 
A.PCode, A.Reporting_Year, A.Reporting_Quarter 
,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)D
ON A.pcode = D.pcode 
AND A.Reporting_Year = D.Reporting_Year 
AND A.Reporting_Quarter = D.Reporting_Quarter 
FULL OUTER JOIN 
---==================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,SUM(A.[# Units] ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)E
ON A.pcode = E.pcode 
AND A.Reporting_Year = E.Reporting_Year 
AND A.Reporting_Quarter = E.Reporting_Quarter 
FULL OUTER JOIN 
---==================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,sum(B.Amount  ) AS [Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.Reporting_Quarter = B.Reporting_Quarter 
AND A.Reporting_Year = B.Reporting_Year 
WHERE 
--A.[NWO Role] = 'Directly provides Rehab Service'
--OR (A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--AND A.[Type of Existing Home Owner] ='Rehab')
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner]='Rehab'
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)F
ON A.pcode = F.pcode 
AND A.Reporting_Year = F.Reporting_Year 
AND A.Reporting_Quarter = F.Reporting_Quarter 
FULL OUTER JOIN 
---================================================
(
SELECT 
A.PCode, A.Reporting_Year, A.Reporting_Quarter 
,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Refinancing - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)

GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)G
ON A.pcode = G.pcode 
AND A.Reporting_Year = G.Reporting_Year 
AND A.Reporting_Quarter = G.Reporting_Quarter 

FULL OUTER JOIN 
---================================================
(
SELECT 
A.PCode, A.Reporting_Year, A.Reporting_Quarter 
,SUM(A.[# Units] ) AS [Preserved Homeownership, Refinancing - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)

GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)H
ON A.pcode = H.pcode 
AND A.Reporting_Year = H.Reporting_Year 
AND A.Reporting_Quarter = H.Reporting_Quarter 

FULL OUTER JOIN 
---================================================
(
SELECT 
A.PCode, A.Reporting_Year, A.Reporting_Quarter 
,sum(B.Amount ) AS [Preserved Homeownership, Refinancing - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.Reporting_Quarter = B.Reporting_Quarter 
AND A.Reporting_Year = B.Reporting_Year
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
--2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Refinance not foreclosure'
)
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)I
ON A.pcode = I.pcode 
AND A.Reporting_Year = I.Reporting_Year 
AND A.Reporting_Quarter = I.Reporting_Quarter 
------------------------------------------------------------------------------------------------------*
FULL OUTER JOIN 
---================================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,COUNT(A.[Client ID] ) AS [Preserved Homeownership, Reverse Mortgage - Customers]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)

GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)G1
ON A.pcode = G1.pcode 
AND A.Reporting_Year = G1.Reporting_Year 
AND A.Reporting_Quarter = G1.Reporting_Quarter 

FULL OUTER JOIN 
---================================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,SUM(A.[# Units] ) AS [Preserved Homeownership, Reverse Mortgage - Homes]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)

GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)H1
ON A.pcode = H1.pcode 
AND A.Reporting_Year = H1.Reporting_Year 
AND A.Reporting_Quarter = H1.Reporting_Quarter 

FULL OUTER JOIN 
---================================================
(
SELECT A.PCode, A.Reporting_Year, A.Reporting_Quarter 
	  ,sum(B.Amount ) AS [Preserved Homeownership, Reverse Mortgage - Investment]
FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
INNER JOIN 
QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
ON A.[Client ID] = B.[Client ID] 
AND A.PCode = B.pcode 
AND A.Reporting_Quarter = B.Reporting_Quarter 
AND A.Reporting_Year = B.Reporting_Year
WHERE 
(
--A.[NWO Role] = 'Counselor and/or Broker/Lender to an Existing Owner'
----2016
A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
AND A.[Type of Existing Home Owner] = 'Reverse mortgage'
)
GROUP BY A.PCode, A.Reporting_Year, A.Reporting_Quarter
)I1
ON A.pcode = I1.pcode 
AND A.Reporting_Year = I1.Reporting_Year 
AND A.Reporting_Quarter = I1.Reporting_Quarter 
------------------------------------------------------------------------------------------------------*
FULL OUTER JOIN 

I CAN'T FIND THIS TABLES------------------------*/
--=====================================================================
(
---=Rental Production Units
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 and FY2013: if 21729 is 1 - 5, 7, 8, then Sum 21730
---Rental Homes Constructed, Acquired, and Preserved
--FY2010: if 21729 is 1 - 6, than Sum 21730
--FY2011: if 21729 1 - 5, 8, OR (if 21729 is 7 AND 23088 is 1 - 7), than Sum 21730
--FY2012 - FY2014: if 21729 is 1 - 5, 7, 8, then Sum 21730
--------------------------------------------------------------
SELECT *
FROM @RentalProductionUnits R
) J
ON A.pcode = J.pcode 
AND A.Reporting_Year = J.Reporting_Year 
AND A.Reporting_Quarter = J.Reporting_Quarter 

FULL OUTER JOIN 
--========================================================
(--62
SELECT
c.pcode, a.Reporting_Year, a.Reporting_Quarter 
,sum(Cast(Cast(b.[Number_Of_Units] as varchar(20)) as INT)) as [Rental Homes, Repaired]
FROM [dbo].[dim_Rental_Production] a
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
WHERE a.Reporting_Year = 2010
AND a.[Rental_Activity_Type] = 'Repaired'
GROUP BY c.pcode, a.Reporting_Year, a.Reporting_Quarter 

UNION ALL 

SELECT c.pcode, a.Reporting_Year, a.Reporting_Quarter 
	  ,sum(Cast(Cast(b.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [Dim_Rental_Production] a
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
WHERE a.Reporting_Year = 2011
AND a.[Rental_Activity_Type] ='Repaired'
OR 
(a.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
--AND A.[Assisted Activity Type (including fee developer)] ='Repaired'
)
GROUP BY c.pcode, a.Reporting_Year, a.Reporting_Quarter 

UNION ALL 

SELECT c.pcode, a.Reporting_Year, a.Reporting_Quarter 
	  ,sum(Cast(Cast(b.[Number_Of_Units] as varchar(20)) as INT)) as [# Units]
FROM [dim_Rental_Production] a
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
WHERE a.Reporting_Year in (2012, 2013,2014,2015,2016)  
AND A.[Rental_Activity_Type] = 'Repaired'
GROUP BY c.pcode, a.Reporting_Year, a.Reporting_Quarter 
)K
ON A.pcode = K.pcode 
AND A.Reporting_Year = K.Reporting_Year 
AND A.Reporting_Quarter = K.Reporting_Quarter 
FULL OUTER JOIN 
--============================================
(--102
SELECT
c.pcode ,a.Reporting_Year ,a.Reporting_Quarter 
,sum(b.[Number_Of_Units]) as [Rental Homes - Investment]
FROM [dim_Rental_Production] a
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode, a.Reporting_Year, a.Reporting_Quarter 
) L 
ON A.pcode = L.pcode 
AND A.Reporting_Year = L.Reporting_Year 
AND A.Reporting_Quarter = L.Reporting_Quarter
FULL OUTER JOIN 
--====================================================
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(A.[Total_Cost] ) AS [Commercial Development - Investment]
FROM [dbo].[fact_Commercial_Real_Estate_Development] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.[Reporting_Quarter]
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
) M
ON A.pcode = M.pcode 
AND A.Reporting_Year = M.Reporting_Year 
AND A.Reporting_Quarter = M.Reporting_Quarter
--=======================================================
FULL OUTER JOIN 
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(
ISNULL(A.[Direct_Loan_Value_From_RLF] ,0.0)+
ISNULL(A.[Direct_Loan_Value_From_Now_Other_Sources] ,0)+
ISNULL(A.[Owners_Portion_Out_Of_Pocket_Equity] ,0.0) +
ISNULL(A.[Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion] ,0.0)
) AS [Commercial Lending - Investment]
FROM[dbo].[fact_Commercial_Lending_Activity] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
) N
ON A.pcode = N.pcode 
AND A.Reporting_Year = N.Reporting_Year 
AND A.Reporting_Quarter = N.Reporting_Quarter
FULL OUTER JOIN 
---=================================================
(
SELECT 
SPI.pcode 
,SPI.Reporting_Year 
,SPI.Reporting_Quarter 
,SPI.[Special Projects - Investment] 
FROM (
SELECT 
 ISNULL(SP.pcode , II.pcode)  AS pcode
,ISNULL(SP.Reporting_Year , II.Reporting_Year)    AS Reporting_Year
,ISNULL(SP.Reporting_Quarter , II.Reporting_Quarter)  AS  Reporting_Quarter
,(ISNULL(SP.[Special Projects - Investment],0.00) + ISNULL(II.[Special Projects - Investment],0.00)) AS  [Special Projects - Investment]
FROM ( 
SELECT 
c.pcode 
,b.Reporting_Year 
,b.Reporting_Quarter 
,SUM (ISNULL(a.[Contribution_Amount], 0.00)) as [Special Projects - Investment]
FROM [dbo].[fact_Infrastructure_Improvement] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode 
,b.Reporting_Year 
,b.Reporting_Quarter  
)II
FULL OUTER JOIN 
(
SELECT 
c.pcode 
,b.Reporting_Year 
,b.Reporting_Quarter 
,SUM (ISNULL(A.[Project_Cost],0.00)) AS [Special Projects - Investment]
FROM  [dbo].[fact_Special_Projects] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode 
,b.Reporting_Year 
,b.Reporting_Quarter 
)SP 
ON II.pcode = SP.pcode 
AND II.Reporting_Year = SP.Reporting_Year 
AND II.Reporting_Quarter = SP.Reporting_Quarter
) SPI 
) O
ON A.pcode = O.pcode 
AND A.Reporting_Year = O.Reporting_Year 
AND A.Reporting_Quarter = O.Reporting_Quarter

FULL OUTER JOIN 
--================================================
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Contribution_Amount] AS VARCHAR(20)) AS FLOAT)) AS [Infrastructure Investment]
FROM [dbo].[fact_Infrastructure_Improvement] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
) P 
ON A.pcode = P.pcode 
AND A.Reporting_Year = P.Reporting_Year 
AND A.Reporting_Quarter = P.Reporting_Quarter
FULL OUTER JOIN 
--============================================
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Total_Development_Costs]AS VARCHAR(20)) AS FLOAT)) AS [For-Sale Homes Developed - Investment]
FROM [dbo].[fact_Real_Estate_Development] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)Q
ON A.pcode = Q.pcode 
AND A.Reporting_Year = Q.Reporting_Year 
AND A.Reporting_Quarter = Q.Reporting_Quarter
---====================================================
FULL OUTER JOIN 
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Total_Costs] AS VARCHAR(20)) AS FLOAT)) AS [Land Banking - Investment]
FROM [dbo].[fact_REO_Land_Bank_Production] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)R
ON A.pcode = R.pcode 
AND A.Reporting_Year = R.Reporting_Year 
AND A.Reporting_Quarter = R.Reporting_Quarter
---====================================================
FULL OUTER JOIN 
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Total_Owner_Occupied_Units_Repaired] AS VARCHAR(20)) AS FLOAT)) AS [Owner-Occupied Repairs - Homes]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)S
ON A.pcode = S.pcode 
AND A.Reporting_Year = S.Reporting_Year 
AND A.Reporting_Quarter = S.Reporting_Quarter
---=========================================================
FULL OUTER JOIN 
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Total_Value_Of_Repairs_To_Owner_Occupied_Units] AS VARCHAR(20)) AS FLOAT)) AS [Owner-Occupied Repairs - Investment]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)T
ON A.pcode = T.pcode 
AND A.Reporting_Year = T.Reporting_Year 
AND A.Reporting_Quarter = T.Reporting_Quarter
FULL OUTER JOIN 
(
--==========================================

SELECT 
A.PCode 
,A.Reporting_Year 
,A.Reporting_Quarter 
,SUM(A.[Total Repaired Units] ) AS [Total Repaired - Homes]
FROM #Temp1 A
GROUP BY A.PCode 
,A.Reporting_Year 
,A.Reporting_Quarter 
)U
ON A.pcode = U.pcode 
AND A.Reporting_Year = U.Reporting_Year 
AND A.Reporting_Quarter = U.Reporting_Quarter

FULL OUTER JOIN 
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Pre_Purchase_Homebuyer_Education_Workshop] AS VARCHAR(20)) AS FLOAT)) AS [Pre-purchase Homebuyer Group Education - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter

)V
ON A.pcode = V.pcode 
AND A.Reporting_Year = V.Reporting_Year 
AND A.Reporting_Quarter = V.Reporting_Quarter
FULL OUTER JOIN 
(
--===============================================
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(CAST(CAST(A.[Financial_Literacy_Workshop] AS VARCHAR(20)) AS FLOAT)) AS [Pre-purchase Financial Literacy Group Education - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)V1
ON A.pcode = V1.pcode 
AND A.Reporting_Year = V1.Reporting_Year 
AND A.Reporting_Quarter = V1.Reporting_Quarter
FULL OUTER JOIN 
(
--===========================================================
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(
  ISNULL(CAST(CAST(A.[Resolving_Or_Preventing_Mortgage_Delinquency_Workshop] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Non_Delinquency_Post_Purchase_Workshop] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Fair_Housing_Workshop]AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Predatory_Lending_Workshop]AS VARCHAR(20)) AS FLOAT),0)
) AS [Post-Purchase and Other Group Education - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
)W
ON A.pcode = W.pcode 
AND A.Reporting_Year = W.Reporting_Year 
AND A.Reporting_Quarter = W.Reporting_Quarter
FULL OUTER JOIN 
--==================================================
(
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Other Counseling - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling]  A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2010
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter
UNION ALL 
SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Other Counseling - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2011
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter

UNION ALL 

SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Pre_Purchase_Homebuyer_Education_Workshop] AS VARCHAR(20)) AS FLOAT),0)
) AS [Non-Foreclosure Individual Counseling Results]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2012
GROUP BY c.PCode, b.Reporting_Year, b.Reporting_Quarter

UNION ALL 

SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
) AS [Non-Foreclosure Individual Counseling Results]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2013
GROUP BY c.PCode, b.Reporting_Year , b.Reporting_Quarter

UNION ALL 

SELECT c.PCode, b.Reporting_Year, b.Reporting_Quarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2014
GROUP BY c.PCode, b.Reporting_Year , b.Reporting_Quarter

UNION ALL 

SELECT c.PCode, b.Reporting_Year , b.Reporting_Quarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2015
GROUP BY c.PCode, b.Reporting_Year , b.Reporting_Quarter

UNION ALL 

SELECT c.PCode, b.Reporting_Year , b.Reporting_Quarter
,SUM(
ISNULL(CAST(CAST(A.[Obtained_A_Home_Equity_Conversion_Mortgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_On_HECM_Decided_Not_To_Obtain_Morgage] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Counseled_And_Referred_To_Other_Social_Service_Agency] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Financial_Management_Budget_Counseling] AS VARCHAR(20)) AS FLOAT),0)
+ ISNULL(CAST(CAST(A.[Completed_Home_Maintenance_Counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling decided not to purchase] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling entered lease purchase program] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed pre-purchase homebuyer individual counseling withdrew from counseling] AS VARCHAR(20)) AS FLOAT),0)
--+ ISNULL(CAST(CAST(A.[Number of households that completed Post Purchase financial management/budget counseling] AS VARCHAR(20)) AS FLOAT),0)

) AS [Non-Foreclosure Individual Counseling Results]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling]  A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
WHERE b.Reporting_Year = 2016
GROUP BY c.PCode, b.Reporting_Year , b.Reporting_Quarter
)X
ON A.pcode = X.pcode 
AND A.Reporting_Year = X.Reporting_Year 
AND A.Reporting_Quarter = X.Reporting_Quarter
FULL OUTER JOIN 
(
/*Can't find Dim_DW_Qtrly_Client*/
--SELECT a.PCode
		--,b.Reporting_Year 
		--,b.Reporting_Quarter 
		--,COUNT(C.[Client ID]) AS [Foreclosure Mitigation Counseling, Home Not Retained - Customers]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client C 
--JOIN [dim_Rental_Production] b
--ON c.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
--JOIN dbo.dim_Organization a
--ON c.[dim_Organization_key]=a.[dim_Organization_key]
--WHERE C.[NWO Role] =
--'Foreclosure Mitigation Counseling'
--AND C.[Foreclosure Counseling Outcome] IN 
--(
--'Executed a deed-in-lieu'
--,'Sold property/chose alternative housing solution' 
--,'Pre-foreclosure sale'  
--,'Mortgage Foreclosed'    
--,'Bankruptcy'  
--,'Entered debt management'  
--,'Counseled and referred for legal assistance'
--,'Other (final result not listed above)'
--)
--GROUP BY C.PCode
		--,C.Reporting_Year 
		--,C.Reporting_Quarter 
--)Y
--ON A.pcode = Y.pcode 
--AND A.Reporting_Year = Y.Reporting_Year 
--AND A.Reporting_Quarter = Y.Reporting_Quarter
FULL OUTER JOIN 
(
--=============================================================
SELECT c.pcode 
	  ,b.Reporting_Year 
	  ,b.Reporting_Quarter 
	  ,SUM(ISNULL(K.[Foreclosure_Intake], 0) ) AS [Foreclosure Mitigation Counseling Intake - Customers]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] K
JOIN [dim_Rental_Production] b
ON K.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON k.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode 
		,b.Reporting_Year 
		,b.Reporting_Quarter
)Z
ON A.pcode = Z.pcode 
AND A.Reporting_Year = Z.Reporting_Year 
AND A.Reporting_Quarter = Z.Reporting_Quarter
FULL OUTER JOIN 
(
--========================================
--SELECT A.pcode, A.Reporting_Year, A.Reporting_Quarter 
--,SUM(ISNULL(CAST(CAST(A.[Total Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
--,SUM(ISNULL(CAST(CAST(A.[Total housing units Managed and not owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
--,SUM(ISNULL(CAST(CAST(A.[Total Owned] AS VARCHAR(20)) AS INT),0) + 
-- ISNULL(CAST(CAST(A.[Total housing units Managed and not owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM ProjectsandSummary.[Dim_Rental _Mutual Housing Portfolio_1] A
--GROUP BY A.pcode , A.Reporting_Year , A.Reporting_Quarter 

--UNION ALL 

--SELECT 
-- A.pcode , A.Reporting_Year , A.Reporting_Quarter 
-- ,SUM (A.[Rental Homes Portfolio, Owned]) AS [Rental Homes Portfolio, Owned]
-- ,SUM (A.[Rental Homes Portfolio, Managed not Owned]) AS [Rental Homes Portfolio, Managed not Owned]
-- ,SUM (A.[Rental Homes Portfolio, Owned and/or Managed]) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM (
--SELECT A.pcode , A.Reporting_Year , A.Reporting_Quarter 
--,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
--,SUM(ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
--,SUM(ISNULL(CAST(CAST(A.[Units Owned] AS VARCHAR(20)) AS INT),0) + 
-- ISNULL(CAST(CAST(A.[Units Managed Not Owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
--FROM ProjectsandSummary.[Dim_Rental _Mutual Housing Portfolio_3] A
--GROUP BY A.pcode , A.Reporting_Year , A.Reporting_Quarter 


--) A 
--GROUP BY  A.pcode , A.Reporting_Year , A.Reporting_Quarter 

--UNION ALL 

SELECT A.pcode, A.Reporting_Year, A.Reporting_Quarter 
	  ,SUM (A.[Rental Homes Portfolio, Owned]) AS [Rental Homes Portfolio, Owned]
	  ,SUM (A.[Rental Homes Portfolio, Managed not Owned]) AS [Rental Homes Portfolio, Managed not Owned]
	  ,SUM (A.[Rental Homes Portfolio, Owned and/or Managed]) AS [Rental Homes Portfolio, Owned and/or Managed]
FROM (
SELECT c.pcode , b.Reporting_Year , b.Reporting_Quarter 
,SUM(ISNULL(CAST(CAST(A.[Units_Owned] AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Owned]
,SUM(ISNULL(CAST(CAST(A.[Units_Managed_Not_Owned]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes Portfolio, Managed not Owned]
,SUM(ISNULL(CAST(CAST(A.[Units_Owned] AS VARCHAR(20)) AS INT),0) + 
 ISNULL(CAST(CAST(A.[Units_Managed_Not_Owned]AS VARCHAR(20)) AS INT) ,0)) AS [Rental Homes Portfolio, Owned and/or Managed]
FROM [dbo].[fact_Rental_Mutual_Housing_Portfolio] A
JOIN [dim_Rental_Production] b
ON A.[dim_ReportingQuarter_key]=b.Reporting_Quarter
JOIN dbo.dim_Organization c
ON A.[dim_Organization_key]=c.[dim_Organization_key]
GROUP BY c.pcode, b.Reporting_Year, b.Reporting_Quarter 
) A 

GROUP BY  A.pcode, A.Reporting_Year, A.Reporting_Quarter

)AA
ON A.pcode = AA.pcode 
AND A.Reporting_Year = AA.Reporting_Year 
AND A.Reporting_Quarter = AA.Reporting_Quarter
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FULL OUTER JOIN 
(
--====================================================
--SELECT  
--  c.pcode 
--, c.Reporting_Year
--, c.Reporting_Quarter  
--,count (c.[Client ID] ) AS [Preserved Homeownership, Foreclosure Mitigation - Customers]
--  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
--  where c.[NWO Role] = 'Foreclosure Mitigation Counseling'
--  AND  C.[Foreclosure Counseling Outcome] IN (
--  'Mortgage refinanced'  
--,'Brought mortgage current' 
--,'Mortgage modified'  
--,'Received second mortgage' 
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--  )  
--GROUP BY   
-- c.pcode 
--,c.Reporting_Year
--,c.Reporting_Quarter
--) A2
--ON  A.pcode = A2.pcode 
--AND A.Reporting_Year = A2.Reporting_Year  
--AND A.Reporting_Quarter = A2.Reporting_Quarter 
--FULL OUTER JOIN 
--(
--====================================================
--SELECT 
-- L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter 
--,SUM(m.Amount) AS  [Preserved Homeownership, Foreclosure Mitigation - Investment]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode = m.pcode 
--and L.Reporting_Year = m.Reporting_Year 
--and L.Reporting_Quarter = M.Reporting_Quarter 
--and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
--AND L.[Foreclosure Counseling Outcome] IN 
--(
--'Mortgage refinanced'  
--,'Brought mortgage current'  
--,'Mortgage modified'  
--,'Received second mortgage'  
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--)

--GROUP BY  
-- L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter
--)A3
--ON  A.pcode = A3.pcode 
--AND A.Reporting_Year = A3.Reporting_Year  
--AND A.Reporting_Quarter = A3.Reporting_Quarter 
--FULL OUTER JOIN 
----(
----====================================================
--SELECT 
-- L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter 
--,SUM(L.[# Units]) AS  [Preserved Homeownership, Foreclosure Mitigation - Homes]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
----INNER JOIN 
----QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
----ON  L.pcode = m.pcode 
----and L.Reporting_Year = m.Reporting_Year 
----and L.Reporting_Quarter = M.Reporting_Quarter 
----and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
--AND L.[Foreclosure Counseling Outcome] IN 
--(
--'Mortgage refinanced'  
--,'Brought mortgage current'  
--,'Mortgage modified'  
--,'Received second mortgage'  
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--)

--GROUP BY  
-- L.pcode
--,L.Reporting_Year 
--,L.Reporting_Quarter
--)A4
--ON  A.pcode = A4.pcode 
--AND A.Reporting_Year = A4.Reporting_Year  
--AND A.Reporting_Quarter  = A4.Reporting_Quarter
--FULL OUTER JOIN 
--( 
----==================================================================
--SELECT  
--  c.pcode 
 --,c.Reporting_Year
 --,c.Reporting_Quarter  
 --,count (c.[Client ID] ) AS [Preserved Homeownership - Customers]
--FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
--WHERE 
---- c.[NWO Role]  IN 
---- (
---- 'Directly provides Rehab Service'  
----,'Counselor and/or Broker/Lender to an Existing Owner'
----)
----2016
--  C.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--  OR ( c.[NWO Role] = 'Foreclosure Mitigation Counseling'
--  AND  C.[Foreclosure Counseling Outcome] IN (
--'Mortgage refinanced'  
--,'Brought mortgage current' 
--,'Mortgage modified'  
--,'Received second mortgage' 
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--)  
-- )
--GROUP BY   
-- c.pcode 
--,c.Reporting_Year
--,c.Reporting_Quarter
--) A5
--ON  A.pcode = A5.pcode 
--AND A.Reporting_Year = A5.Reporting_Year  
--AND A.Reporting_Quarter  = A5.Reporting_Quarter
--FULL OUTER JOIN 
--( 
----==================================================================
----2013
----Total Preservation Units
----if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650

----2014
----Preserved Homeownership - Homes
----if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
----2016
----FY2016: if 21619 is 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
---------------------------------------------------------------
--SELECT  
  --c.pcode 
 --,c.Reporting_Year
 --,c.Reporting_Quarter  
 --,SUM (c.[# Units] ) AS [Preserved Homeownership - Homes]
--FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] c
--where 
---- c.[NWO Role]  IN 
---- (
---- 'Directly provides Rehab Service'  
----,'Counselor and/or Broker/Lender to an Existing Owner'
----)
----2016
--  C.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--  OR ( c.[NWO Role] = 'Foreclosure Mitigation Counseling'
--  AND  C.[Foreclosure Counseling Outcome] IN (
--'Mortgage refinanced'  
--,'Brought mortgage current' 
--,'Mortgage modified'  
--,'Received second mortgage' 
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--  )  
--  )
--GROUP BY   
-- c.pcode 
--,c.Reporting_Year
--,c.Reporting_Quarter
--) A6
--ON  A.pcode = A6.pcode 
--AND A.Reporting_Year = A6.Reporting_Year  
--AND A.Reporting_Quarter = A6.Reporting_Quarter
--FULL OUTER JOIN 
--( 
----==================================================================
----2013
----Total Preservation Investment
----if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
------------------------------------------------------------------------
----2014
----Preserved Homeownership - Investment
----if 21619 is 5 - 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21650
----2016
----FY2016: if 21619 is 6 OR (if 21619 is 7 AND if 21657 is 1 - 6), then Sum 21681
-----------------------------------------------------------------
--SELECT  
--  L.pcode 
--, L.Reporting_Year
--, L.Reporting_Quarter  
--, SUM(M.Amount ) AS [Preserved Homeownership - Investment]
--  FROM [QuarterlyProduction_T].[dbo].[Dim_DW_Qtrly_Client] L
--  INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode = m.pcode 
--and L.Reporting_Year = m.Reporting_Year 
--and L.Reporting_Quarter = M.Reporting_Quarter 
--and L.[Client ID] = M.[Client ID] 
--  where 
---- c.[NWO Role]  IN 
---- (
---- 'Directly provides Rehab Service'  
----,'Counselor and/or Broker/Lender to an Existing Owner'
----)
----2016
--  L.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--  OR ( L.[NWO Role] = 'Foreclosure Mitigation Counseling'
--  AND  L.[Foreclosure Counseling Outcome] IN (
--'Mortgage refinanced'  
--,'Brought mortgage current' 
--,'Mortgage modified'  
--,'Received second mortgage' 
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--  )  
--  )
--GROUP BY   
-- L.pcode 
--,L.Reporting_Year
--,L.Reporting_Quarter
--) A7
--ON  A.pcode = A7.pcode 
--AND A.Reporting_Year = A7.Reporting_Year  
--AND A.Reporting_Quarter  = A7.Reporting_Quarter
--FULL OUTER JOIN 
--( 
----===============================================
----2013
-----Constructed
-----if 21729 is 1, than Sum 21730
----2014
----Rental Homes, Constructed
----if 21729 is 1, than Sum 21730
-------------------------------------------------
---3
SELECT 
 c.pcode, A.Reporting_Year, A.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Constructed]
FROM [dbo].[dim_Rental_Production] A 
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
WHERE A.[Rental_Activity_Type] = 'Constructed'
GROUP BY c.pcode, A.Reporting_Year, A.Reporting_Quarter

)A8
ON  A.pcode = A8.pcode 
AND A.Reporting_Year = A8.Reporting_Year  
AND A.Reporting_Quarter  = A8.Reporting_Quarter
FULL OUTER JOIN 
( 
--===============================================
--4
SELECT  c.pcode, A.Reporting_Year, A.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Purchased for New Renters]
FROM [dim_Rental_Production] A
JOIN [fact_Rental_Production] b
ON A.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization c
ON b.[dim_Organization_key]=c.[dim_Organization_key]
WHERE A.[Rental_Activity_Type] = 'Purchased for new renters'
GROUP BY c.pcode, A.Reporting_Year, A.Reporting_Quarter
) A9
ON  A.pcode = A9.pcode 
AND A.Reporting_Year = A9.Reporting_Year  
AND A.Reporting_Quarter  = A9.Reporting_Quarter
FULL OUTER JOIN 
( 
--===============================================
---4
SELECT  a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Purchased with Existing Renters]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key]
WHERE C.[Rental_Activity_Type] = 'Purchased with existing renters'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter
)A10

ON  A.pcode = A10.pcode 
AND A.Reporting_Year = A10.Reporting_Year  
AND A.Reporting_Quarter  = A10.Reporting_Quarter
FULL OUTER JOIN 
( 
--===============================================
--1
SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Refinanced]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key]
WHERE C.[Rental_Activity_Type] = 'Re-financed to extend affordability of property for > 10 years'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter
) A11
ON  A.pcode = A11.pcode 
AND A.Reporting_Year = A11.Reporting_Year  
AND A.Reporting_Quarter  = A11.Reporting_Quarter
FULL OUTER JOIN 
( 
--===============================================
--9
SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Rehabilitated]
FROM [dim_Rental_Production]   C
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE C.[Rental_Activity_Type] IN('Rehabilitated', 'Rehabilitated Existing Property')
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter
) A12
ON  A.pcode = A12.pcode 
AND A.Reporting_Year = A12.Reporting_Year  
AND A.Reporting_Quarter  = A12.Reporting_Quarter
FULL OUTER JOIN 
--=====================================================
(--3
SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Development Services]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE  C.Reporting_Year = 2010 AND 
C.[Rental_Activity_Type]= 'Assisted (not owned or managed)'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter

UNION ALL 

SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE  C.Reporting_Year = 2011 AND (
C.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
--AND C.[Assisted Activity Type (including fee developer)] IN /*I can't find this field*/
--(
--'Planning' 
--,'Asset Management'
--,'Resource Development'
--,'Direct Investment'
--,'Site Related Services'
--,'Construction Management'
--,'General Contracting'
--)
)
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter

UNION ALL 

SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM [Dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE  C.Reporting_Year IN (2012, 2013,2014,2015) AND 
C.[Rental_Activity_Type] = 'Assisted Not Owned (including fee developer)'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter

UNION ALL 

SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [# Units]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE  C.Reporting_Year =2016 AND 
C.[Rental_Activity_Type] 
IN( 'Assisted Not Owned (including fee developer)','Assisted Not Owned (including fee developer)')
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter 
) A13

ON  A.pcode = A13.pcode 
AND A.Reporting_Year = A13.Reporting_Year  
AND A.Reporting_Quarter  = A13.Reporting_Quarter
FULL OUTER JOIN 
--=====================================================
(

SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(CAST(CAST(b.[Number_Of_Units]AS VARCHAR(20)) AS INT),0)) AS [Rental Homes, Rehabilitated with NSP Funds]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE C.[Rental_Activity_Type] = 
 'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter
)A14
ON  A.pcode = A14.pcode 
AND A.Reporting_Year = A14.Reporting_Year  
AND A.Reporting_Quarter  = A14.Reporting_Quarter
FULL OUTER JOIN 
(
--==============================================
SELECT *
FROM #RentalAssistedNotOwnedNotManaged A
) A15
ON  A.pcode = A15.pcode 
AND A.Reporting_Year = A15.Reporting_Year  
AND A.Reporting_Quarter  = A15.Reporting_Quarter
FULL OUTER JOIN 
(
--===================================================
--3
SELECT a.pcode, C.Reporting_Year, C.Reporting_Quarter
,SUM(ISNULL(b.[Sum_Of_Costs],0)) AS  [Rental Homes, Constructed - Investment]
FROM [dim_Rental_Production]   C 
JOIN [fact_Rental_Production] b
ON C.[dim_Rental_Production_key]=b.[dim_Rental_Production_key]
JOIN dbo.dim_Organization a
ON b.[dim_Organization_key]=a.[dim_Organization_key] 
WHERE  C.[Rental_Activity_Type] = 'Constructed'
GROUP BY a.pcode, C.Reporting_Year, C.Reporting_Quarter
)A16
ON  A.pcode = A16.pcode 
AND A.Reporting_Year = A16.Reporting_Year  
AND A.Reporting_Quarter  = A16.Reporting_Quarter
--FULL OUTER JOIN 
--(
----=================================================================
--/*I CAN'T FIND THIS TABLE*/
--  SELECT 
--  R.PCode 
-- ,R.Reporting_Year 
-- ,R.Reporting_Quarter 
-- ,SUM( CAST(CAST(REPLACE(R.Answer,'No response',0) AS VARCHAR(20))AS INT)) AS [Residents Trained] 
-- FROM EDW_Staging.dbo.vw_ExtractResponses R
--WHERE CAST(R.DataPointID AS VARCHAR(20)) IN('12', '22215', '24259')
--GROUP BY R.PCode 
-- ,R.Reporting_Year 
-- ,R.Reporting_Quarter

--)A17
--ON  A.pcode = A17.pcode 
--AND A.Reporting_Year = A17.Reporting_Year  
--AND A.Reporting_Quarter  = A17.Reporting_Quarter
--FULL OUTER JOIN 
--(
----===========================================================
--SELECT 
--r.PCode 
--,r.Reporting_Year 
--,r.Reporting_Quarter 
--,SUM(CAST(REPLACE(r.Answer, 'No response',0) AS INT)) AS [Volunteer Hours]
--FROM SSIS.Projects_and_Summary r 
--where DataPointID =25014
--GROUP BY r.PCode 
--,r.Reporting_Year 
--,r.Reporting_Quarter 

--)A18
--ON  A.pcode = A18.pcode 
--AND A.Reporting_Year = A18.Reporting_Year  
--AND A.Reporting_Quarter  = A18.Reporting_Quarter

--FULL OUTER JOIN 
--(
----=======================================================
--SELECT 
--r.PCode 
--,r.Reporting_Year 
--,r.Reporting_Quarter 
--,SUM(CAST(REPLACE(r.Answer, 'No response',0) AS INT)) AS [Volunteer Hours, NeighborWorks Week]
--FROM EDW_Staging.dbo.vw_ExtractResponses r 
--where DataPointID IN ( 23925, 24257)
--GROUP BY r.PCode 
--,r.Reporting_Year 
--,r.Reporting_Quarter 
--) A19
--ON  A.pcode = A19.pcode 
--AND A.Reporting_Year  = A19.Reporting_Year  
--AND A.Reporting_Quarter  = A19.Reporting_Quarter
--FULL OUTER JOIN 
-----==================================
----FY2016
----Preserved Homeownership, Replacement - Customers
----FY2010 - FY2015: NULL
----FY2016: if 21619 is 6 AND 21620 is 4, then Count 21617
--/*
--1. NWO Constructs New Unit for New Home Owner
--2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
--3. Directly provides Self-Help Housing for New Home Owner
--4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
--5. Counselor and/or Broker/Lender ONLY for New Home Owner
--6. NWO Provides Services to an Existing Home Owner
--7. Foreclosure Mitigation Counseling
--*/
--/*
--"1. Rehab
--2. Refinance not foreclosure
--3. Reverse mortgage
--4. Replacement
--5. Not Applicable   [use with NWO Role = 1]
--6. Not Applicable   [use with NWO Role = 2]
--7. Not Applicable   [use with NWO Role = 3]
--8. Not Applicable   [use with NWO Role = 4]
--9. Not Applicable   [use with NWO Role = 5]
--10. Not Applicable   [use with NWO Role = 7]"

--*/
-------------------------------------------
--(
--SELECT 
--A.PCode, A.Reporting_Year , A.Reporting_Quarter 
--,COUNT(A.[Client ID]  ) AS [Preserved Homeownership, Replacement - Customers]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A

--WHERE 
--A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--AND A.[Type of Existing Home Owner]='Replacement'
--GROUP BY A.PCode, A.Reporting_Year , A.Reporting_Quarter
--)A20
--ON A.pcode = A20.pcode 
--AND A.Reporting_Year = A20.Reporting_Year 
--AND A.Reporting_Quarter = A20.Reporting_Quarter 
--FULL OUTER JOIN 
-----==================================
----FY2016
----Preserved Homeownership, Replacement - Homes
----FY2010 - FY2015: NULL
----FY2016: if 21619 is 6 AND 21620 is 4, then Sum 21650
--/*
--1. NWO Constructs New Unit for New Home Owner
--2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
--3. Directly provides Self-Help Housing for New Home Owner
--4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
--5. Counselor and/or Broker/Lender ONLY for New Home Owner
--6. NWO Provides Services to an Existing Home Owner
--7. Foreclosure Mitigation Counseling
--*/
--/*
--"1. Rehab
--2. Refinance not foreclosure
--3. Reverse mortgage
--4. Replacement
--5. Not Applicable   [use with NWO Role = 1]
--6. Not Applicable   [use with NWO Role = 2]
--7. Not Applicable   [use with NWO Role = 3]
--8. Not Applicable   [use with NWO Role = 4]
--9. Not Applicable   [use with NWO Role = 5]
--10. Not Applicable   [use with NWO Role = 7]"

--*/
-------------------------------------------
--(
--SELECT 
--A.PCode, A.Reporting_Year , A.Reporting_Quarter 
--,SUM(A.[# Units]  ) AS [Preserved Homeownership, Replacement - Homes]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A

--WHERE 
--A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--AND A.[Type of Existing Home Owner]='Replacement'
--GROUP BY A.PCode, A.Reporting_Year , A.Reporting_Quarter
--)A21
--ON A.pcode = A21.pcode 
--AND A.Reporting_Year = A21.Reporting_Year 
--AND A.Reporting_Quarter = A21.Reporting_Quarter 
--FULL OUTER JOIN 
-----==================================
----FY2016
----Preserved Homeownership, Replacement - Investment
----FY2010 - FY2015: NULL
----FY2016: if 21619 is 6 AND if 21620 is 4, then Sum 21681
--/*
--1. NWO Constructs New Unit for New Home Owner
--2. NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner
--3. Directly provides Self-Help Housing for New Home Owner
--4. Plays Intermediary role in providing Self-Help Housing for New Home Owner
--5. Counselor and/or Broker/Lender ONLY for New Home Owner
--6. NWO Provides Services to an Existing Home Owner
--7. Foreclosure Mitigation Counseling
--*/
--/*
--"1. Rehab
--2. Refinance not foreclosure
--3. Reverse mortgage
--4. Replacement
--5. Not Applicable   [use with NWO Role = 1]
--6. Not Applicable   [use with NWO Role = 2]
--7. Not Applicable   [use with NWO Role = 3]
--8. Not Applicable   [use with NWO Role = 4]
--9. Not Applicable   [use with NWO Role = 5]
--10. Not Applicable   [use with NWO Role = 7]"

--*/
-------------------------------------------
--(
--SELECT 
--A.PCode, A.Reporting_Year , A.Reporting_Quarter 
--,SUM( B.Amount ) AS [Preserved Homeownership, Replacement - Investment]
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client A
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing B
--ON A.[Client ID] = B.[Client ID] 
--AND A.PCode = B.pcode 
--AND A.Reporting_Quarter = B.Reporting_Quarter 
--AND A.Reporting_Year = B.Reporting_Year 
 
--WHERE 
--A.[NWO Role] ='NWO Provides Services to an Existing Home Owner'
--AND A.[Type of Existing Home Owner]='Replacement'
--GROUP BY A.PCode, A.Reporting_Year , A.Reporting_Quarter
--)A22
--ON A.pcode = A22.pcode 
--AND A.Reporting_Year = A22.Reporting_Year 
--AND A.Reporting_Quarter = A22.Reporting_Quarter 
   
-------------------------------------------------------------------------------
DELETE [EDW_Staging].[Quarterly].[tblQPR_Comprehensive_Quarterly_Report]
WHERE Reporting_Year = @Reporting_Year AND Reporting_Quarter = @Reporting_Quarter
INSERT INTO [EDW_Staging].[Quarterly].[tblQPR_Comprehensive_Quarterly_Report]
(
[pcode]
      ,[Reporting_Year]
      ,[Reporting_Quarter]
      ,[Homeowners Created - Customers]
      ,[Homeowners Created - Homes]
      ,[Homeowners Created - Investment]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
      ,[Preserved Homeownership, Refinancing - Customers]
      ,[Preserved Homeownership, Refinancing - Homes]
      ,[Preserved Homeownership, Refinancing - Investment]
      ,[Preserved Homeownership, Reverse Mortgage - Customers]
      ,[Preserved Homeownership, Reverse Mortgage - Homes]
      ,[Preserved Homeownership, Reverse Mortgage - Investment]
      ,[Preserved Homeownership, Foreclosure Mitigation - Customers]
      ,[Preserved Homeownership, Foreclosure Mitigation - Homes]
      ,[Preserved Homeownership, Foreclosure Mitigation - Investment]
      ,[Preserved Homeownership - Customers]
      ,[Preserved Homeownership - Homes]
      ,[Preserved Homeownership - Investment]
      ,[Rental Homes, Constructed]
      ,[Rental Homes, Purchased for New Renters]
      ,[Rental Homes, Purchased with Existing Renters]
      ,[Rental Homes, Refinanced]
      ,[Rental Homes, Rehabilitated]
      ,[Rental Homes, Development Services]
      ,[Rental Homes, Rehabilitated with NSP Funds]
      ,[Rental Homes Constructed, Acquired, and Preserved]
      ,[Rental Homes, Repaired]
      ,[Rental Homes, Development Services, Not Managed]
      ,[Rental Homes - Investment]
      ,[Rental Homes, Constructed - Investment]
      ,[Commercial Development - Investment]
      ,[Commercial Lending - Investment]
      ,[Special Projects - Investment]
      ,[For-Sale Homes Developed - Investment]
      ,[Land Banking - Investment]
      ,[Owner-Occupied Repairs - Homes]
      ,[Owner-Occupied Repairs - Investment]
      ,[Total Repaired - Homes]
      ,[Total Direct Investment]
      ,[Pre-purchase Homebuyer Group Education - Customers]
      ,[Pre-purchase Financial Literacy Group Education - Customers]
      ,[Post-Purchase and Other Group Education - Customers]
      ,[Other Counseling - Customers]
      ,[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
      ,[Foreclosure Mitigation Counseling Intake - Customers]
      ,[Rental Homes Portfolio, Owned]
      ,[Rental Homes Portfolio, Managed not Owned]
      ,[Rental Homes Portfolio, Owned and/or Managed]
      ,[Residents Trained]
      ,[Volunteer Hours]
      ,[Volunteer Hours, NeighborWorks Week]
      ,[Preserved Homeownership, Replacement - Customers]
      ,[Preserved Homeownership, Replacement - Homes]
      ,[Preserved Homeownership, Replacement - Investment]
)
---------------------------------------------------------------------------------
SELECT 
[pcode]
      ,[Reporting_Year]
      ,[Reporting_Quarter]
      ,[Homeowners Created - Customers]
      ,[Homeowners Created - Homes]
      ,[Homeowners Created - Investment]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Homes]
      ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Investment]
      ,[Preserved Homeownership, Refinancing - Customers]
      ,[Preserved Homeownership, Refinancing - Homes]
      ,[Preserved Homeownership, Refinancing - Investment]
      ,[Preserved Homeownership, Reverse Mortgage - Customers]
      ,[Preserved Homeownership, Reverse Mortgage - Homes]
      ,[Preserved Homeownership, Reverse Mortgage - Investment]
      ,[Preserved Homeownership, Foreclosure Mitigation - Customers]
      ,[Preserved Homeownership, Foreclosure Mitigation - Homes]
      ,[Preserved Homeownership, Foreclosure Mitigation - Investment]
      ,[Preserved Homeownership - Customers]
      ,[Preserved Homeownership - Homes]
      ,[Preserved Homeownership - Investment]
      ,[Rental Homes, Constructed]
      ,[Rental Homes, Purchased for New Renters]
      ,[Rental Homes, Purchased with Existing Renters]
      ,[Rental Homes, Refinanced]
      ,[Rental Homes, Rehabilitated]
      ,[Rental Homes, Development Services]
      ,[Rental Homes, Rehabilitated with NSP Funds]
      ,[Rental Homes Constructed, Acquired, and Preserved]
      ,[Rental Homes, Repaired]
      ,[Rental Homes, Development Services, Not Managed]
      ,[Rental Homes - Investment]
      ,[Rental Homes, Constructed - Investment]
      ,[Commercial Development - Investment]
      ,[Commercial Lending - Investment]
      ,[Special Projects - Investment]
      ,[For-Sale Homes Developed - Investment]
      ,[Land Banking - Investment]
      ,[Owner-Occupied Repairs - Homes]
      ,[Owner-Occupied Repairs - Investment]
      ,[Total Repaired - Homes]
      ,[Total Direct Investment]
      ,[Pre-purchase Homebuyer Group Education - Customers]
      ,[Pre-purchase Financial Literacy Group Education - Customers]
      ,[Post-Purchase and Other Group Education - Customers]
      ,[Other Counseling - Customers]
      ,[Foreclosure Mitigation Counseling, Home Not Retained - Customers]
      ,[Foreclosure Mitigation Counseling Intake - Customers]
      ,[Rental Homes Portfolio, Owned]
      ,[Rental Homes Portfolio, Managed not Owned]
      ,[Rental Homes Portfolio, Owned and/or Managed]
      ,[Residents Trained]
      ,[Volunteer Hours]
      ,[Volunteer Hours, NeighborWorks Week]
      ,[Preserved Homeownership, Replacement - Customers]
      ,[Preserved Homeownership, Replacement - Homes]
      ,[Preserved Homeownership, Replacement - Investment]
FROM #temp
WHERE Reporting_Year = @Reporting_Year AND Reporting_Quarter = @Reporting_Quarter






DROP TABLE #temp 
DROP TABLE #TotalDirectInvestment 
DROP TABLE #OwnerOccupiedUnits 
DROP TABLE #RentalProductionRepairedUnits 
DROP TABLE #Temp1 
DROP TABLE #TotalOwnerOccupiedUnitsRepaired 
DROP TABLE #RentalAssistedNotOwnedNotManaged

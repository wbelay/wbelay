CREATE VIEW [dbo].[VWOAD_OHTS_RentalHomes]
AS 
SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,[Rental Homes Constructed, Acquired, and Preserved] AS NumberOfRentalUnits
	  ,[Rental Homes, Purchased for New Renters] AS NumberOfRentalUnitsCreated
	  ,ISNULL([Rental Homes, Refinanced],0) +
	   ISNULL([Rental Homes, Rehabilitated],0) AS NumberOfRentalUnitsPreserved
	  ,[Rental Homes, Development Services, Not Managed] AS [NumberOfRentalAssistedUnits]
	  ,NULL AS NumberOther
FROM ProjectsandSummary.Fact_Comprehensive C
WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))

GO

--SELECT [dim_ReportingQuarter_key]
--       ,SUM(ISNULL([Units_Acquired_As_A_Result_Of_A_Foreclosure_Related_Event],0) ) AS [# Units]
--FROM [dbo].[fact_Rental_Production]
--GROUP BY  [dim_ReportingQuarter_key]
--UNION

--SELECT *
--FROM(
---============================================================
----Total_fact_Owner_Occupied_Repairs_and_Counseling
SELECT CONVERT(VARCHAR(10),[dim_ReportingQuarter_key],101) AS ReportingYear
	   ,dim_Organization_key
       ,SUM([Total_Value_Of_Repairs_To_Owner_Occupied_Units]) AS [Total Reported Investment]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

---=============================================================
----Total_fact_Real_Estate_Development

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Total_Development_Costs]) AS [Total Reported Investment]
FROM [dbo].[fact_Real_Estate_Development]
GROUP BY  [dim_ReportingQuarter_key],dim_Organization_key

--UNION

--===============================================================
---Total_fact_Rental_Production

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Sum_Of_Costs]) AS [Total Reported Investment]
FROM[dbo].[fact_Rental_Production] 
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

--================================================================
-----Total_fact_Special_Projects

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Project_Cost]) AS [Total Reported Investment]
FROM [dbo].[fact_Special_Projects]
GROUP BY  [dim_ReportingQuarter_key],dim_Organization_key

--UNION

---==================================================================
----TOTAL_fact_Commercial_Lending_Activity
SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Direct_Loan_Value_From_RLF]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

---========================================================================
----TOTAL_fact_Commercial_Lending_Activity

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Direct_Loan_Value_From_Now_Other_Sources]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

---==============================================================================
----TOTAL_fact_Commercial_Lending_Activity

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Leveraged_Amount_Excludes_Now_Funds_And_Owners_Portion]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

-----=============================================================================
------TOTAL_fact_Commercial_Lending_Activity

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Owners_Portion_Out_Of_Pocket_Equity]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Lending_Activity]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key

--UNION

----==================================================================================
-----TOTAL_fact_Commercial_Real_Estate_Development

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Total_Cost]) AS [Total Reported Investment]
FROM [dbo].[fact_Commercial_Real_Estate_Development]
GROUP BY[dim_ReportingQuarter_key],dim_Organization_key

--UNION

---=====================================================================================
---TOTAL_fact_Financing

SELECT [dim_ReportingQuarter_key]
	   ,dim_Organization_key
	   ,SUM([Financing_Amount]) AS [Total Reported Investment]
FROM [dbo].[fact_Financing]
GROUP BY [dim_ReportingQuarter_key],dim_Organization_key
--) AS P
----===============================================================================

SELECT COALESCE(A.dim_ReportingQuarter_key,B.dim_ReportingQuarter_key,C.dim_ReportingQuarter_key,D.dim_ReportingQuarter_key,E.dim_ReportingQuarter_key
				,F.dim_ReportingQuarter_key,G.dim_ReportingQuarter_key,H.dim_ReportingQuarter_key,I.dim_ReportingQuarter_key,J.dim_ReportingQuarter_key)
	   ,COALESCE(A.dim_Organization_key,B.dim_Organization_key,C.dim_Organization_key,D.dim_Organization_key,E.dim_Organization_key,F.dim_Organization_key
				,G.dim_Organization_key,H.dim_Organization_key,I.dim_Organization_key,J.dim_Organization_key)
	   ,ISNULL(A.[Total Reported Investment],0)+
	    ISNULL(B.[Total Reported Investment],0)+
		ISNULL(C.[Total Reported Investment],0)+
		ISNULL(D.[Total Reported Investment],0)+
		ISNULL(E.[Total Reported Investment],0)+
		ISNULL(F.[Total Reported Investment],0)+
		ISNULL(G.[Total Reported Investment],0)+
		ISNULL(H.[Total Reported Investment],0)+
		ISNULL(I.[Total Reported Investment],0)+
		ISNULL(J.[Total Reported Investment],0) AS [Total Reported Investment]
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
FULL JOIN [dbo].[fact_Real_Estate_Development] B
ON A.dim_ReportingQuarter_key = B.dim_ReportingQuarter_key
AND A.dim_Organization_key = B.dim_Organization_key
FULL JOIN [dbo].[fact_Rental_Production] C
ON A.dim_ReportingQuarter_key = C.dim_ReportingQuarter_key
AND A.dim_Organization_key = C.dim_Organization_key
FULL JOIN [dbo].[fact_Special_Projects] D
ON A.dim_ReportingQuarter_key = D.dim_ReportingQuarter_key
AND A.dim_Organization_key = D.dim_Organization_key
FULL JOIN [dbo].[fact_Commercial_Lending_Activity] E
ON A.dim_ReportingQuarter_key = E.dim_ReportingQuarter_key
AND A.dim_Organization_key = E.dim_Organization_key
FULL JOIN [dbo].[fact_Commercial_Lending_Activity] F
ON A.dim_ReportingQuarter_key = F.dim_ReportingQuarter_key 
AND A.dim_Organization_key = F.dim_Organization_key
FULL JOIN [dbo].[fact_Commercial_Lending_Activity] G
ON A.dim_ReportingQuarter_key = G.dim_ReportingQuarter_key 
AND A.dim_Organization_key = G.dim_Organization_key
FULL JOIN [dbo].[fact_Commercial_Lending_Activity] H
ON A.dim_ReportingQuarter_key = H.dim_ReportingQuarter_key 
AND A.dim_Organization_key = H.dim_Organization_key
FULL JOIN [dbo].[fact_Commercial_Real_Estate_Development] I
ON A.dim_ReportingQuarter_key = I.dim_ReportingQuarter_key
AND A.dim_Organization_key = I.dim_Organization_key
FULL JOIN [dbo].[fact_Financing] J
ON A.dim_ReportingQuarter_key = J.dim_ReportingQuarter_key
AND A.dim_Organization_key = J.dim_Organization_key

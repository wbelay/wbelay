--IF OBJECT_ID(N'tempdb..#ReportedInvestment2016') IS NOT NULL
--BEGIN
--DROP TABLE #ReportedInvestment2016
--END
-----------------------------------------------------
----------------------------------------------
--SELECT 
--A.Pcode , A.ReportingYear, A.ReportingQuarter
--,SUM(A.[Total Reported Investment]) AS [TotalReportedInvestment] 
--INTO #ReportedInvestment2016
--FROM #ReportedInvestment A
--WHERE A.ReportingYear= @ReportingYear AND A.ReportingQuarter= @ReportingQuarter
--GROUP BY A.Pcode , A.ReportingYear, A.ReportingQuarter


---==============================================================================
----Total Direct Investment
/*
FY2010: Sum (21699 + 21722 + 21741 + 21750 + 21755 + 21760 + 21763 + 21775 + 21776 + 21777 + 21778) + (if 21619 is 1 - 6, then Sum 21681) + (if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)

FY2011 and FY2012: Sum (21699 + 21722 + 21741 + 21755 + 21760 + 21763 + 21775 + 21776 + 21777 + 21778) + (if 21619 is 1 - 6, then Sum 21681) + (if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)

FY2013: Sum (21699 + 21722 + 21741 + 21755 + 21763 + 21775 + 21776 + 21777 + 21778 + 23915) + (if 21619 is 1 - 6, 8 then Sum 21681) + (if 21619 is 7 AND if 21657 is  1 - 6, then Sum 21681)

FY2014: Sum (21699 + 21722 + 21741 + 21755 + 21763 + 21775 + 21776 + 21777 + 21778 + 23915 + 24279) + (if 21619 is 1 - 6, 8 then Sum 21681) + (if 21619 is 7 AND if 21657 is  1 - 6, then Sum 21681)
--======================================================= 
*/
---Total Owner-Occupied Units Repaired 21699
--DECLARE @TotalOwnerOccupiedUnitsRepaired TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Total Owner-Occupied Units Repaired] MONEY 
--)
--INSERT INTO @TotalOwnerOccupiedUnitsRepaired 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(A.[Total_Value_Of_Repairs_To_Owner_Occupied_Units]) AS [Total Owner-Occupied Units Repaired]
INTO #TotalOwnerOccupiedUnitsRepaired 
FROM [dbo].[fact_Owner_Occupied_Repairs_and_Counseling] A
JOIN dbo.dim_Organization b
on a.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON a.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
---======================================================
--Real Estate Total Development Costs 21722
--DECLARE @RealEstateTotalDevelopmentCosts TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Real Estate Total Development Costs] MONEY 
--)
--INSERT INTO @RealEstateTotalDevelopmentCosts 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(A1.[Total_Development_Costs]) AS [Real Estate Total Development Costs]
INTO #RealEstateTotalDevelopmentCosts
FROM [dbo].[fact_Real_Estate_Development] A1
JOIN dbo.dim_Organization b
on A1.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A1.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--====================================================
--Rental Production Total Development Costs 21741
--DECLARE @RentalProductionTotalDevelopmentCosts TABLE  
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Rental Production Total Development Costs] MONEY 
--)
--INSERT INTO @RentalProductionTotalDevelopmentCosts 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(A2.[Sum_Of_Costs]) AS [Real Estate Total Development Costs]
INTO #RentalProductionTotalDevelopmentCosts 
FROM  [dbo].[fact_Rental_Production] A2
JOIN dbo.dim_Organization b
on A2.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A2.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter

--====================================================
--Commercial RED Total Development Costs 21750
--DECLARE @CommercialREDTotalDevelopmentCosts TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Commercial RED Total Development Costs] MONEY 
--)
--INSERT INTO @CommercialREDTotalDevelopmentCosts 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM(D.[Total_Cost]) AS [Commercial RED Total Development Costs]
INTO #CommercialREDTotalDevelopmentCosts 
FROM [dbo].[fact_Commercial_Real_Estate_Development] D
JOIN dbo.dim_Organization b
on D.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON D.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--====================================================
--Special Project Cost 21755
--DECLARE @SpecialProjectCost TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Special Project Cost] MONEY 
--)
--INSERT INTO @SpecialProjectCost 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter  
	  ,SUM(E.[Project_Cost]) AS [Special Project Cost]
INTO #SpecialProjectCost 
FROM [dbo].[fact_Special_Projects] E
JOIN dbo.dim_Organization b
on E.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON E.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--====================================================
--Infrastructure Improvement Contribution Amount 21760
--DECLARE @InfrastructureImprovementContributionAmount TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[Infrastructure Improvement Contribution Amount] Money 
--)
--INSERT INTO @InfrastructureImprovementContributionAmount 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
,SUM(F.[Contribution_Amount]) AS [Infrastructure Improvement Contribution Amount]
INTO #InfrastructureImprovementContributionAmount 
FROM [dbo].[fact_Infrastructure_Improvement] F
JOIN dbo.dim_Organization b
on F.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON F.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--=====================================================================
--REO Land Bank Production 21763
--DECLARE @REOLandBankProductionTotalCosts TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[REO Land Bank Production Total Costs] MONEY 
--)
--INSERT INTO @REOLandBankProductionTotalCosts 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM( G.[Total_Costs]) AS [REO Land Bank Production Total Costs]
FROM [dbo].[fact_REO_Land_Bank_Production] G
JOIN dbo.dim_Organization b
on G.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON G.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter 
--=======================================================
---Commercial Lending Activity Direct Loan Value from RLF 21775
--DECLARE @CommercialLendingActivityRLF TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[CLA Direct Loan Value from RLF] MONEY 
--)
--INSERT INTO @CommercialLendingActivityRLF 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
	  ,SUM(H.[Direct_Loan_Value_From_RLF]) AS [CLA Direct Loan Value from RLF]
INTO #CommercialLendingActivityRLF 
FROM [dbo].[fact_Commercial_Lending_Activity] H
JOIN dbo.dim_Organization b
on H.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON H.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter  
--=======================================================
--Commercial Lending Activity Direct Loan Value from NWO Other Sources 21776
--DECLARE @CommercialLendingActivityNWO TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[CLA Direct Loan Value from NWO Other Sources] MONEY 
--)
--INSERT INTO @CommercialLendingActivityNWO 
SELECT  b.PCode
	   ,c.fin_year
	   ,c.fin_quarter 
	   ,SUM(I.[Direct_Loan_Value_From_Now_Other_Sources]) AS [CLA Direct Loan Value from NWO Other Sources]
INTO #CommercialLendingActivityNWO 
FROM [dbo].[fact_Commercial_Lending_Activity] I
JOIN dbo.dim_Organization b
on I.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON I.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--=======================================================
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 21777
--DECLARE @CommercialLendingActivityLeveragedAmount TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
--)
--INSERT INTO @CommercialLendingActivityLeveragedAmount 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter
 -- ****&&&&& CAN'T FIND THIS COLUMN....,SUM( J.[Leveraged Amount (excludes NWO funds and Owner's Portion)] ) AS [CLA Leveraged Amount (excludes NWO funds and Owner's Portion)]
INTO #CommercialLendingActivityLeveragedAmount 
FROM [dbo].[fact_Commercial_Lending_Activity] J
JOIN dbo.dim_Organization b
on J.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON J.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--================================================================ 
--Commercial Lending Activity Leveraged Amount (excludes NWO funds and Owner's Portion) 21778
--DECLARE @CommercialLendingActivityOwnersPortion TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] MONEY 
--)
--INSERT INTO @CommercialLendingActivityOwnersPortion 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
	  ,SUM( K.[Owners_Portion_Out_Of_Pocket_Equity]) AS [CLA Owner's Portion (out-of-pocket equity)]
INTO #CommercialLendingActivityOwnersPortion 
FROM [dbo].[fact_Commercial_Lending_Activity] K
JOIN dbo.dim_Organization b
on K.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON K.dim_ReportingQuarter_key=c.dim_date_key
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--================================================================ 
---&&&&&&&&&& CAN'T FIND THE TABLES &&&&&&&&

----(if 21619 is 1 - 6, then Sum 21681)
--2015
--(if 21619 is 1 - 6, 8, 9, 10, then Sum 21681)
--DECLARE @CFNWORoleOnetoSixAndEight TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,Amount MONEY
--)

--INSERT INTO @CFNWORoleOnetoSixAndEight 
--SELECT 
-- L.pcode
--,L.ReportingYear 
--,L.ReportingQuarter 
--,SUM(m.Amount) AS  Amount
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode = m.pcode 
--and L.ReportingYear =   m.ReportingYear 
--and L.ReportingQuarter = M.ReportingQuarter 
--and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] IN 
--(
--'NWO Constructs New Unit for New Home Owner'
--,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
--,'Counselor Only Resulting in Ownership for New Home Owner'
--,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
--,'Directly provides Rehab Service'  
--,'Counselor and/or Broker/Lender to an Existing Owner'
--,'Broker/Lender Resulting in Ownership for New Home Owner'
----2015
--,'Directly provides Self-Help Housing for New Home Owner'
--,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
--)
--GROUP BY  L.pcode
--,L.ReportingYear 
--,L.ReportingQuarter 
---================================================

---&&&&&&&&&& CAN'T FIND THE TABLES &&&&&&&&

--(if 21619 is 7 AND if 21657 is 1 - 6, than Sum 21681)
--DECLARE @CFNWORoleSeven TABLE 
--(
--  PCode INT 
-- ,ReportingYear INT 
-- ,ReportingQuarter INT
--,Amount MONEY
--)

--INSERT INTO @CFNWORoleSeven 
--SELECT 
-- L.pcode
--,L.ReportingYear 
--,L.ReportingQuarter 
--,SUM(m.Amount) AS  Amount
--FROM QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Client L
--INNER JOIN 
--QuarterlyProduction_T.dbo.Dim_DW_Qtrly_Financing M
--ON  L.pcode =                                    m.pcode 
--and L.ReportingYear =   m.ReportingYear 
--and L.ReportingQuarter = M.ReportingQuarter 
--and L.[Client ID] = M.[Client ID] 
--WHERE L.[NWO Role] = 'Foreclosure Mitigation Counseling'
--AND L.[Foreclosure Counseling Outcome] IN 
--(
--'Mortgage refinanced'  
--,'Brought mortgage current'  
--,'Mortgage modified'  
--,'Received second mortgage'  
--,'Initiated forbearance agreement/repayment plan' 
--,'Obtained partial claim loan from FHA lender'
--)

--GROUP BY  
-- L.pcode
--,L.ReportingYear 
--,L.ReportingQuarter


--========================================================================
  
 
 
SELECT   
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  AS PCode
,Coalesce(A.ReportingYear , B.ReportingYear, C.ReportingYear,D.ReportingYear,E.ReportingYear,F.ReportingYear,G.ReportingYear,H.ReportingYear,I.ReportingYear,J.ReportingYear,K.ReportingYear,L.ReportingYear,M.ReportingYear) AS ReportingYear 
,Coalesce(A.ReportingQuarter, B.ReportingQuarter ,C.ReportingQuarter,D.ReportingQuarter,E.ReportingQuarter,F.ReportingQuarter,G.ReportingQuarter,H.ReportingQuarter,I.ReportingQuarter,J.ReportingQuarter,K.ReportingQuarter,L.ReportingQuarter,M.ReportingQuarter) AS ReportingQuarter 
,
sum(ISNULL(A.Amount , 0) + ISNULL(B.Amount,0) + ISNULL(C.[Total Owner-Occupied Units Repaired] , 0)
+ISNULL(D.[Real Estate Total Development Costs] , 0)
+ISNULL(E.[Rental Production Total Development Costs], 0) 
+ISNULL(F.[Commercial RED Total Development Costs] , 0)
+ISNULL(G.[Special Project Cost] , 0)
+ISNULL(H.[Infrastructure Improvement Contribution Amount] , 0)
+ISNULL(I.[REO Land Bank Production Total Costs] , 0)
+ISNULL(J.[CLA Direct Loan Value from RLF] , 0)
+ISNULL(K.[CLA Direct Loan Value from NWO Other Sources] , 0)
+ISNULL(L.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)
+ISNULL(M.[CLA Leveraged Amount (excludes NWO funds and Owner's Portion)] , 0)) AS  [Total Direct Investment] 
INTO #TotalDirectInvestment
FROM #CFNWORoleOnetoSixAndEight A 
FULL OUTER JOIN 
#CFNWORoleSeven B 
ON A.PCode = B.PCode 
AND A.fin_year = B.fin_year 
AND A.fin_quarter = B.fin_quarter
FULL OUTER JOIN 
#TotalOwnerOccupiedUnitsRepaired C
ON A.PCode = C.PCode 
AND A.fin_year = C.fin_year 
AND A.fin_quarter = C.fin_quarter 
FULL OUTER JOIN 
#RealEstateTotalDevelopmentCosts D
ON A.PCode = D.PCode 
AND A.fin_year = D.fin_year 
AND A.fin_quarter = D.fin_quarter 
FULL OUTER JOIN 
#RentalProductionTotalDevelopmentCosts E
ON A.PCode = E.PCode 
AND A.fin_year = E.fin_year 
AND A.fin_quarter = E.fin_quarter 
FULL OUTER JOIN 
#CommercialREDTotalDevelopmentCosts F
ON A.PCode = F.PCode 
AND A.fin_year = F.fin_year
AND A.fin_quarter = F.fin_quarter 
FULL OUTER JOIN 
#SpecialProjectCost G
ON A.PCode = G.PCode 
AND A.fin_year = G.fin_year 
AND A.fin_quarter = G.fin_quarter
FULL OUTER JOIN 
#InfrastructureImprovementContributionAmount H 
ON A.PCode = H.PCode 
AND A.fin_year = H.fin_year 
AND A.fin_quarter = H.fin_quarter 
FULL OUTER JOIN 
#REOLandBankProductionTotalCosts I 
ON A.PCode = I.PCode 
AND A.fin_year = I.fin_year
AND A.fin_quarter = I.fin_quarter 
FULL OUTER JOIN 
#CommercialLendingActivityRLF J 
ON A.PCode = J.PCode 
AND A.fin_year = J.fin_year
AND A.fin_quarter = J.fin_quarter 
FULL OUTER JOIN 
#CommercialLendingActivityNWO K 
ON A.PCode = K.PCode 
AND A.fin_year = K.fin_year 
AND A.fin_quarter = K.fin_quarter
FULL OUTER JOIN 
#CommercialLendingActivityLeveragedAmount L
ON A.PCode = L.PCode 
AND A.fin_year = L.fin_year 
AND A.fin_quarter = L.fin_quarter
FULL OUTER JOIN 
#CommercialLendingActivityOwnersPortion M
ON  A.PCode = M.PCode 
AND A.fin_year = M.fin_year 
AND A.fin_quarter = M.fin_quarter
group by 
 Coalesce(A.PCode ,B.PCode, C.PCode, D.PCode,E.PCode,F.PCode,G.PCode,H.PCode,I.PCode,J.PCode,K.PCode,L.PCode,M.PCode )  
,Coalesce(A.ReportingYear , B.ReportingYear, C.ReportingYear,D.ReportingYear,E.ReportingYear,F.ReportingYear,G.ReportingYear,H.ReportingYear,I.ReportingYear,J.ReportingYear,K.ReportingYear,L.ReportingYear,M.ReportingYear) 
,Coalesce(A.ReportingQuarter, B.ReportingQuarter ,C.ReportingQuarter,D.ReportingQuarter,E.ReportingQuarter,F.ReportingQuarter,G.ReportingQuarter,H.ReportingQuarter,I.ReportingQuarter,J.ReportingQuarter,K.ReportingQuarter,L.ReportingQuarter,M.ReportingQuarter)  
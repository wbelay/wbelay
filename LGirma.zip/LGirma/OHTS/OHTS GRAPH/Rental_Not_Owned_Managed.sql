--2013
--Rental Assisted Not Owned Not Managed
--FY2010: N/A
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 
--FY2012 - FY2013: if 21729 is 7 AND 23089 = 'No', than Sum 21730
--2014
--Rental Homes, Development Services, Not Managed
--FY2010: Null
--FY2011: if 21729 is 7 AND 23088 is 1 - 7 AND 23089 = 'No', than Sum 21730 + 
----           if 21729 is 8, than Sum 21730

---=======================================================

--DECLARE @RentalAssistedNotOwnedNotManaged2011 TABLE 
--(
--pcode  INT 
--,ReportingYear  INT 
--,ReportingQuarter INT 
--,Units2011 FLOAT 
--)

--INSERT INTO @RentalAssistedNotOwnedNotManaged2011 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
INTO #RentalAssistedNotOwnedNotManaged2011 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
on A.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A.dim_ReportingQuarter_key=c.dim_date_key
WHERE c.fin_year = 2011 --AND 
---CAN'T FIND THE COULMNS
--A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
--AND A.[Assisted Activity Type (including fee developer)] IN 
--(
--'Planning' 
--,'Asset Management'
--,'Resource Development'
--,'Direct Investment'
--,'Site Related Services'
--,'Construction Management'
--,'General Contracting'
--) AND A.[Does your organization Manage these units] = 'No'
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
---=======================================================
--2013
--FY2012 - FY2013: if 21729 is 7 AND 23089 = 'No', than Sum 21730
--2014
--Rental Homes, Development Services, Not Managed
--FY2012 - FY2014: if 21729 is 7 AND 23089 = 'No', than Sum 21730 + 
--if 21729 is 8, than Sum 21730
--2016
--FY2016: if 25046 = 3, then Sum 21730
/*
1. Owned (reported in the Rental Portfolio)
2. Managed not Owned (reported in the Rental Portfolio)
3. Not Owned and Not Managed (NOT reported in the Rental Portfolio)
*/
-----------------------------------------------------------------
--DECLARE @RentalAssistedNotOwnedNotManaged2012_2013 TABLE 
--(
--pcode  INT 
--,ReportingYear  INT 
--,ReportingQuarter INT 
--,Units2012_2013 FLOAT 
--)
--INSERT INTO @RentalAssistedNotOwnedNotManaged2012_2013 
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
INTO #RentalAssistedNotOwnedNotManaged2012_2013 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
on A.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A.dim_ReportingQuarter_key=c.dim_date_key
WHERE c.fin_year IN (2012, 2013,2014,2015) 
--AND A.[Rental Activity Type] = 'Assisted Not Owned (including fee developer)'
--AND A.[Does your organization Manage these units] = 'No'
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter

union all

SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
      ,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
on A.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A.dim_ReportingQuarter_key=c.dim_date_key
WHERE c.fin_year IN (2012, 2013,2014,2015)  
 --AND A.[Rental Activity Type] LIKE 'NWO is responsible for rehabilitation of units but does not take title of property%'
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter

union all
--if 25046 = 3 AND 21729 = 11 or 12, then Sum 21730
SELECT b.PCode
	  ,c.fin_year
	  ,c.fin_quarter 
,SUM(CAST(CAST(A.[Number_Of_Units] AS VARCHAR(20))AS FLOAT)) AS [Units] 
FROM [dbo].[fact_Rental_Production] A
JOIN dbo.dim_Organization b
on A.dim_Organization_key=b.dim_Organization_key
JOIN dbo.dim_date c
ON A.dim_ReportingQuarter_key=c.dim_date_key
WHERE c.fin_year =2016  
--AND c.Type_of_Ownership = 'Not Owned and Not Managed (NOT reported in the Rental Portfolio)'
--AND A.[Rental Activity Type] IN (
--  'NWO is responsible for rehabilitation of units but does not take title of property (NSP Consortium ONLY)'
--,'Assisted Not Owned (including fee developer)'
--)
GROUP BY  b.PCode
		 ,c.fin_year
		 ,c.fin_quarter
--============================================================================================
SELECT 
 coalesce(A.pcode , B.pcode ,0)AS  pcode
,coalesce(A.fin_year , B.fin_year ,0) AS ReportingYear 
,coalesce(A.fin_quarter , B.fin_quarter ,0) AS  ReportingQuarter
--,SUM(ISNULL(A.Units2011,0)  + ISNULL(B.Units2012_2013,0) ) AS [Rental Homes, Development Services, Not Managed]
INTO #RentalAssistedNotOwnedNotManaged
FROM #RentalAssistedNotOwnedNotManaged2011 A 
FULL OUTER JOIN 
#RentalAssistedNotOwnedNotManaged2012_2013 B
ON A.pcode = B.pcode 
AND A.fin_year = B.fin_year 
AND A.fin_quarter = B.fin_quarter 
GROUP BY  coalesce(A.pcode , B.pcode ,0)
,coalesce(A.fin_year , B.fin_year ,0)
,coalesce(A.fin_quarter , B.fin_quarter ,0)

SELECT *
FROM #RentalAssistedNotOwnedNotManaged

--DROP TABLE #RentalAssistedNotOwnedNotManaged2011
--DROP TABLE #RentalAssistedNotOwnedNotManaged2012_2013
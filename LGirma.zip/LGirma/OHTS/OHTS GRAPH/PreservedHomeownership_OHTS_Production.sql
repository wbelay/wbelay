CREATE VIEW [dbo].[VWOAD_OHTS_PreservedHomeownership]
AS 
SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] AS NumberOfHomeRehabClients
	  ,[Preserved Homeownership - Customers] AS NumberOfOtherPreservationClients
FROM ProjectsandSummary.Fact_Comprehensive C
WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))
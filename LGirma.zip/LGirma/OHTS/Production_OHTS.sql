CREATE VIEW [dbo].[VWOAD_OHTS_Production]
AS 
SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,[Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] AS NumberOfHomeRehabClients
	  ,[Preserved Homeownership - Customers] AS NumberOfOtherPreservationClients
	  ,[Homeowners Created - Customers] AS NumberOfHomeownershipClients
	  ,[Homeownership_Facilitated_Customers] AS  NumberOfHOFacilitatedClients
	  ,[Rental Homes Constructed, Acquired, and Preserved] AS NumberOfRentalUnits
	  ,[Rental Homes, Purchased for New Renters] AS NumberOfRentalUnitsCreated
	  ,ISNULL([Rental Homes, Refinanced],0) +
	   ISNULL([Rental Homes, Rehabilitated],0) AS NumberOfRentalUnitsPreserved
	  ,[Rental Homes, Development Services, Not Managed] AS [NumberOfRentalAssistedUnits]
	  ,NULL AS NumberOther
	  ,ISNULL([Rental Homes, Purchased for New Renters] ,0)+
	   ISNULL([Rental Homes, Development Services, Not Managed] ,0)+
	   ISNULL([Preserved Homeownership, Owner-Occupied Rehabilitation - Customers] ,0)+
	   ISNULL([Homeowners Created - Customers] ,0)+
	   ISNULL([Preserved Homeownership, Refinancing - Customers] ,0)+
	   ISNULL([Preserved Homeownership, Foreclosure Mitigation - Customers] ,0)+
	   ISNULL([Rental Homes, Refinanced] ,0)+
	   ISNULL([Rental Homes, Rehabilitated] ,0) AS TotalProductionNumber
	  ,[Rental Homes Portfolio, Owned] AS NumberOwned
	  ,[Rental Homes Portfolio, Managed not Owned] AS NumberManaged
FROM ProjectsandSummary.Fact_Comprehensive C
WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))

GO

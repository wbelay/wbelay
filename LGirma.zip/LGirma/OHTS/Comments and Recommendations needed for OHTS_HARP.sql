WITH CTE
AS 
(
SELECT PCODE, CASE WHEN [Field Rank Com] IS NOT NULL THEN [Field Rank Com] END AS [Field Summary]
FROM stgRankings
WHERE [Field Rank Com] IS NOT NULL
UNION ALL
SELECT PCODE,CASE WHEN [OAD Rank Com] IS NOT NULL THEN [OAD Rank Com] END AS [OAD Summary] 
FROM stgRankings
WHERE [OAD Rank Com] IS NOT NULL
UNION ALL
SELECT PCODE,CASE WHEN NISummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NISummary)END AS NISummary 
FROM dbo.tblRatingDetail
WHERE [NISummary] IS NOT NULL
UNION ALL
SELECT PCODE,CASE WHEN [RatingComment] IS NOT NULL THEN [RatingComment] END AS [[NFMC Summary]
FROM dbo.tblNFMC
WHERE [RatingComment] IS NOT NULL
UNION ALL
SELECT PCODE,CASE WHEN [HOC Comment] IS NOT NULL THEN [HOC Comment] END AS [NHP Summary]
FROM stgRankings
WHERE [HOC Comment] IS NOT NULL
UNION ALL
SELECT PCODE,CASE WHEN [MFI Comment] IS NOT NULL THEN [MFI Comment] END AS [NREP Summary]
FROM stgRankings
WHERE [MFI Comment] IS NOT NULL
)
SELECT DistrictName
	  ,o.PCODE
	  ,o.Name
	  ,RMName
	  ,r.[WatchFlag]
	  ,CASE WHEN r.ReviewFlag = 'Y' THEN 'On-Site Review'
			WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site Review'
		END AS [Review Reason]
	  ,r.CurrentRatingText
	  ,'' AS [Field Completed]
	  ,'' AS [OAD Completed]
	  ,'' AS [NI Completed]
	  ,'' AS [NFMC Completed]
	  ,'' AS [NHP Completed]
	  ,'' AS [NREP Completed]
	  --,CTE.[Field Summary] 
	  
FROM dbo.tblOrganization o
JOIN [HARP].[dbo].[tblRating] r
ON o.PCODE = r.PCODE
--JOIN CTE 
--ON CTE.PCODE = o.PCODE

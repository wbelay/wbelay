SELECT DISTINCT 
 ISNULL(A.pcode , B.pcode ) AS PCODE
,ISNULL(A.FiscalYear , B.FiscalYear ) AS FiscalYear
,ISNULL(A.FiscalYearQuarter , B.FiscalYearQuarter) as FiscalYearQuarter
,ISNULL(A.NumberOfUnitsForSale,0) As [For-Sale Homes Developed]
,ISNULL(B.NumberOfUnitsHeld,0) As [Units Held in Portfilio at End of Quarter]
FROM 
( 
 SELECT frd.PCODE 
	   ,frd.ReportingYear as [FiscalYear]
	   ,frd.ReportingQuarter as [FiscalYearQuarter]
	   ,SUM(frd.[Total Units]) as [NumberOfUnitsForSale]
 FROM ProjectsandSummary.[Fact_Real Estate Development For Sale] frd
 GROUP BY PCODE ,frd.ReportingYear  ,frd.ReportingQuarter  
 ) A
FULL OUTER JOIN 
(SELECT  frd.PCODE 
	    ,frd.ReportingYear as [FiscalYear]
	    ,frd.ReportingQuarter as [FiscalYearQuarter]
		,SUM(frd.[Total For-Sale Units Held in Portfolio at End of Quarter]) as [NumberOfUnitsHeld]
 FROM [ProjectsandSummary].[Dim_Inventory of For-Sale Units] frd  
 GROUP BY PCODE ,frd.ReportingYear  ,frd.ReportingQuarter 
 )B 
 ON A.pcode = B.pcode AND A.FiscalYear = B.FiscalYear AND A.FiscalYearQuarter = B.FiscalYearQuarter

SELECT DISTINCT *
FROM (
SELECT [PCODE]
,ReportingYear AS [FiscalYear]
,ReportingQuarter AS [FiscalYearQuarter]
,'First Mortgage' AS [Type of Mortgage]
,CONVERT(INT, [1st Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [NumberOfOutstandingRLFLoans]
,CONVERT(MONEY,[1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [AmountOfOutstandingRLFLoans]
,CONVERT(INT, [1st Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [NumberOfRLFLoans3059DaysDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [AmountOfRLFLoans3059DaysDelinquent]
,CONVERT(INT, [1st Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [NumberOfRLFLoans6089DaysDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [AmountOfRLFLoans6089DaysDelinquent]
,CONVERT(INT, [1st Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [NumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [AmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(DECIMAL(4,3), ([1st Mortgages: Value of RLF loans currently > 90 days delinquent]/ NULLIF([1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [Percentage90DaysPlusDelinquent]
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 

UNION ALL

SELECT [PCODE]
,ReportingYear AS [FiscalYear]
,ReportingQuarter AS [FiscalYearQuarter]
,'Subordinate Mortgage' AS [Type of Mortgage]
,CONVERT(INT, [2nd Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [NumberOfOutstandingRLFLoans]
,CONVERT(MONEY, [2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [AmountOfOutstandingRLFLoans]
,CONVERT(INT, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [NumberOfRLFLoans3059DaysDelinquent]
,CONVERT(MONEY, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [AmountOfRLFLoans3059DaysDelinquent]
,CONVERT(INT, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [NumberOfRLFLoans6089DaysDelinquent]
,CONVERT(MONEY, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [AmountOfRLFLoans6089DaysDelinquent]
,CONVERT(INT, [2nd Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [NumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(MONEY, [2nd Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [AmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(DECIMAL(4,3), ([2nd Mortgages: Value of RLF loans currently > 90 days delinquent]/ NULLIF([2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [Percentage90DaysPlusDelinquent] 
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 
--WHERE ReportingYear = (SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d)
--AND ReportingQuarter=(SELECT max(d.ReportingQuarter) FROM ProjectsandSummary.Dim_Time d WHERE D.ReportingYear
--=(SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d))
) AS N

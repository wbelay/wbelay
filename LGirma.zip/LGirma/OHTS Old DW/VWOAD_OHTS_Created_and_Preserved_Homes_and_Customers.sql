--CREATE VIEW VWOAD_OHTS_Created_and_Preserved_Homes_and_Customers
--AS
SELECT Pcode 
	   ,ReportingYear as [FiscalYear]
	   ,ReportingQuarter AS [FiscalYearQuarter]
	   ,[Homeowners Created - Customers] AS NumberOfHomeownershipClients
	   ,[Preserved Homeownership - Customers] AS NumberOfOtherPreservationClients
	   ,[Rental Homes Constructed, Acquired, and Preserved] AS NumberOfRentalUnits
FROM ProjectsandSummary.Fact_Comprehensive C
--WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
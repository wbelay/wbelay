SELECT Pcode 
	  ,ReportingYear as [FiscalYear]
	  ,ReportingQuarter AS [FiscalYearQuarter]
	  ,[Homeowners Created - Customers] AS NumberOfHomeownershipClients
	  ,[Homeownership_Facilitated_Customers] AS  NumberOfHOFacilitatedClients
FROM ProjectsandSummary.Fact_Comprehensive C
--WHERE C.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time)
--AND C.ReportingQuarter=(SELECT MAX(ReportingQuarter) FROM ProjectsandSummary.Dim_Time T
--                        WHERE T.ReportingYear= (SELECT MAX(ReportingYear) FROM ProjectsandSummary.Dim_Time))

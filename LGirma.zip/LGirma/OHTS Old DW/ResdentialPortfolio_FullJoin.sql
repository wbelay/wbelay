SELECT DISTINCT *
FROM (

SELECT * FROM
(
SELECT [PCODE]
,ReportingYear AS [FiscalYear]
,ReportingQuarter AS [FiscalYearQuarter]
,'First Mortgage' AS [Type of Mortgage]
,CONVERT(INT, [1st Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [FirstMortgageNumberOfOutstandingRLFLoans]
,CONVERT(MONEY,[1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [FirstMortgageAmountOfOutstandingRLFLoans]
,CONVERT(INT, [1st Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [FirstMortgageNumberOfRLFLoans3059DaysDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [FirstMortgageAmountOfRLFLoans3059DaysDelinquent]
,CONVERT(INT, [1st Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [FirstMortgageNumberOfRLFLoans6089DaysDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [FirstMortgageAmountOfRLFLoans6089DaysDelinquent]
,CONVERT(INT, [1st Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [FirstMortgageNumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(MONEY, [1st Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [FirstMortgageAmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(DECIMAL(4,3), ([1st Mortgages: Value of RLF loans currently > 90 days delinquent]/ NULLIF([1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [FirstMortgagePercentage90DaysPlusDelinquent]
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 
)A

FULL OUTER JOIN 

(
SELECT [PCODE]AS ORGID
,ReportingYear 
,ReportingQuarter 
,'Subordinate Mortgage' AS [Type of Mortgages]
,CONVERT(INT, [2nd Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) AS [SubMortgageNumberOfOutstandingRLFLoans]
,CONVERT(MONEY, [2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) AS [SubMortgageAmountOfOutstandingRLFLoans]
,CONVERT(INT, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) AS [SubMortgageNumberOfRLFLoans3059DaysDelinquent]
,CONVERT(MONEY, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) AS [SubMortgageAmountOfRLFLoans3059DaysDelinquent]
,CONVERT(INT, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) AS [SubMortgageNumberOfRLFLoans6089DaysDelinquent]
,CONVERT(MONEY, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) AS [SubMortgageAmountOfRLFLoans6089DaysDelinquent]
,CONVERT(INT, [2nd Mortgages: Number of RLF loans currently > 90 days delinquent]) AS [SubMortgageNumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(MONEY, [2nd Mortgages: Value of RLF loans currently > 90 days delinquent]) AS [SubMortgageAmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(DECIMAL(4,3), ([2nd Mortgages: Value of RLF loans currently > 90 days delinquent]/ NULLIF([2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) AS [SubMortgagePercentage90DaysPlusDelinquent] 
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 
--WHERE ReportingYear = (SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d)
--AND ReportingQuarter=(SELECT max(d.ReportingQuarter) FROM ProjectsandSummary.Dim_Time d WHERE D.ReportingYear
--=(SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d))
)B
ON A.PCODE = B.ORGID AND A.FiscalYear = B.ReportingYear AND A.FiscalYearQuarter=B.ReportingQuarter
)AS N
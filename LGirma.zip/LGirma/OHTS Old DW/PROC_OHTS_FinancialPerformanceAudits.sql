--SELECT * INTO OHTS_FinancialPerformance
--FROM OPENROWSET('SQLNCLI', 
--                'Server=localhost;Trusted_Connection=yes;', 
--                'EXEC [HARP].[dbo].[OHTS_FinancialPerformanceFromtheAudits]')
                                
ALTER PROC OHTS_FinancialPerformanceFromtheAudits
AS
BEGIN

DECLARE @FirstLatestYear_FA INT;
DECLARE @SecondLatestYear_FA INT;
DECLARE @ThirdLatestYear_FA INT;
DECLARE @FourthLatestYear_FA INT;
DECLARE @FifthLatestYear_FA INT;

SELECT @FirstLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM(
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit) a)a 
	 WHERE FiscalYear_FA_Rank=1;

SELECT @SecondLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit) a)a 
	 WHERE FiscalYear_FA_Rank=2;

SELECT @ThirdLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit) a)a 
	 WHERE FiscalYear_FA_Rank=3;

SELECT @FourthLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM(
		  SELECT DISTINCT FiscalYear  
		  FROM tblFinancialAudit) a)a 
	 WHERE FiscalYear_FA_Rank=4;

SELECT @FifthLatestYear_FA=FiscalYear 
FROM(
	 SELECT RANK() OVER (ORDER BY FiscalYear DESC) AS FiscalYear_FA_Rank,FiscalYear 
	 FROM( 
		  SELECT DISTINCT FiscalYear 
		  FROM tblFinancialAudit) a)a 
	 WHERE FiscalYear_FA_Rank=5;

;WITH CTE_Financial_Audit 
AS( 
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,CashAndCashEquivalentsAmount_FA
	  ,CurrentLiabilitiesOverNetAssetsPercentage_FA
	  ,DefensiveIntRatio_FA
	  ,DepreciationExpenseAmount_FA
	  ,ExpenseAmount_FA
	  ,FiscalYear_FA
	  ,FiscalYearEndMonthAndDay_FA
	  ,LiabilitiesOverNetAssetsPercentage_FA
	  ,MAndGExpenseOverTotalPercentage_FA
	  ,NetAssetsAmount_FA
	  ,CAssets_FA
	  ,CLiab_FA
	  ,NetCashFromOperationsAmount_FA
	  ,NetIncomeAmount_FA
	  ,RevenueAmount_FA
	  ,UnrestrictedCurrentRatio_FA
	  ,CurrentRatio_FA
	  ,QuickCashRatio_FA
	  ,TotalDaysCash_FA
	  ,UnrestrictedNetAssetsAmount_FA
	  ,UnrestrictedNetAssetsOverNetAssetsPercentage_FA
	  ,UnrestrictedNetIncomeAmount_FA
	  ,UnrestrictedNumberOfDaysCash_FA
	  ,UnrestrictedCash_FA
	  ,ReservesCash_FA
	  ,Loans_FA
	  ,FixedAssets_FA
	  ,TAssets_FA
	  ,LTLiab_FA
	  ,TLiab_FA
	  ,NonControllingActivityAmount_FA
	  ,PriorPeriodAdjustmentsAmount_FA 
,(SELECT RatingAndAFICAComments_FA_Text 
FROM(
	 SELECT RatingAndAFICAComments_FA_Text,PCODE
FROM(
	 SELECT fa.PCODE
		   ,fa.FiscalYear
		   ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
		   ,RatingAndAFICAComments_FA_Text
		   ,AuditorOpinionandCommunicationComments_FA_Text
		   ,NWCapitalFundComments_FA_Text
		   ,OHPSummaryComments_FA_Text
	 FROM(
		  SELECT fa.PCODE
				,fa.FiscalYear
				,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
				,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
				,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
				,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
				,OHPSummaryComments AS OHPSummaryComments_FA_Text
		  FROM(
			   SELECT fa.PCODE
					 ,fa.FiscalYear
					 ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
					 ,RatingAndAFICAComments
					 ,AuditorOpinionandCommunicationComments
					 ,NWCapitalFundComments
					 ,OHPSummaryComments
			   FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
			   WHERE  fa.FiscalYear in(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
									   ,@FourthLatestYear_FA)
			  )fa
			  WHERE fa.Rank_FA IN (1,2,3,4)
		  )fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
		 WHERE ((FiscalYear=@FirstLatestYear_FA)
		 AND (RatingAndAFICAComments_FA_Text IS NOT NULL
		 OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
		 OR NWCapitalFundComments_FA_Text IS NOT NULL
		 OR OHPSummaryComments_FA_Text IS NOT NULL)
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS RatingAndAFICAComments_FA_Text 
,(
  SELECT AuditorOpinionandCommunicationComments_FA_Text 
FROM(
	 SELECT AuditorOpinionandCommunicationComments_FA_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
					   ,@FourthLatestYear_FA)
	  )fa
	  WHERE fa.Rank_FA IN (1,2,3,4)
	)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
	WHERE ((FiscalYear=@FirstLatestYear_FA)
	AND (RatingAndAFICAComments_FA_Text IS NOT NULL
	OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
	OR NWCapitalFundComments_FA_Text IS NOT NULL
	OR OHPSummaryComments_FA_Text IS NOT NULL)
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS AuditorOpinionandCommunicationComments_FA_Text 

,(SELECT NWCapitalFundComments_FA_Text 
FROM(
	 SELECT NWCapitalFundComments_FA_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
FROM (
	  SELECT fa.PCODE
			,fa.FiscalYear
			,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
			,RatingAndAFICAComments
			,AuditorOpinionandCommunicationComments
			,NWCapitalFundComments
			,OHPSummaryComments
	   FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
	   WHERE fa.FiscalYear in(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
							   ,@FourthLatestYear_FA)
	 )fa
WHERE fa.Rank_FA in (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND(RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR(fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
					   ,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS NWCapitalFundComments_FA_Text 

,(SELECT OHPSummaryComments_FA_Text 
FROM(
SELECT OHPSummaryComments_FA_Text,PCODE
FROM(
	 SELECT fa.PCODE
		   ,fa.FiscalYear
		   ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
		   ,RatingAndAFICAComments_FA_Text
		   ,AuditorOpinionandCommunicationComments_FA_Text
		   ,NWCapitalFundComments_FA_Text
		   ,OHPSummaryComments_FA_Text
	 FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
	  				   ,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)
)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS OHPSummaryComments_FA_Text 

,(SELECT CASE------------------66666666666666666666666666666
WHEN LEN(FiscalYearEndMonthAndDay_FA_Text) = 4
THEN LEFT(FiscalYearEndMonthAndDay_FA_Text,2) +'/'+RIGHT(FiscalYearEndMonthAndDay_FA_Text,2)
WHEN LEN(FiscalYearEndMonthAndDay_FA_Text) = 3
THEN LEFT(FiscalYearEndMonthAndDay_FA_Text,1) +'/'+RIGHT(FiscalYearEndMonthAndDay_FA_Text,2)
ELSE ''
END AS FiscalYearEndMonthAndDay_FA_Text
FROM(
SELECT FiscalYearEndMonthAndDay_FA_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,FiscalYearEndMonthAndDay_FA_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,FiscalYearEndMonthAndDay_FA_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,FiscalYearEndMonthAndDay_FA_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE  fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
						,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL)
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS FiscalYearEndMonthAndDay_FA_Text ---------------777777777777777777777777

------------------888888888888888888888888888888
,(SELECT CompDate_Text
 FROM(
	  SELECT CompDate_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,CompDate_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,CompDate_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,CompDate AS CompDate_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE  fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
						,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS CompDate_Text ---------------9999999999999999999999

,(SELECT A133Risk_Text 
FROM(
SELECT A133Risk_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,A133Risk_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,A133Risk_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,A133Risk AS A133Risk_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE  fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
						,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS A133Risk_Text ----------A133Risk

,(SELECT MaterialWeaknesses_Text 
FROM(
	 SELECT MaterialWeaknesses_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,MaterialWeaknesses_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,MaterialWeaknesses_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,MaterialWeaknesses AS MaterialWeaknesses_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
					   ,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS MaterialWeaknesses_Text ----------MaterialWeaknesses

,(SELECT SignificantDeficiencies_Text 
FROM(
SELECT SignificantDeficiencies_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,SignificantDeficiencies_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,SignificantDeficiencies_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,SignificantDeficiencies AS SignificantDeficiencies_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
					   ,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a WHERE a.PCODE=fa.PCODE) AS SignificantDeficiencies_Text ----------SignificantDeficiencies

,(
SELECT FiscalYear_FA_Text 
FROM(
SELECT FiscalYear_FA_Text,PCODE
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments_FA_Text
	  ,FiscalYear_FA_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text
	  ,FiscalYear_FA_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,fa.fiscalyear AS FiscalYear_FA_Text
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
					   ,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1)
)a 
WHERE a.PCODE=fa.PCODE
) AS FiscalYear_FA_Text

FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,CashAndCashEquivalentsAmount_FA
	  ,CurrentLiabilitiesOverNetAssetsPercentage_FA
	  ,DefensiveIntRatio_FA
	  ,DepreciationExpenseAmount_FA
	  ,ExpenseAmount_FA
	  ,FiscalYear_FA
	  ,FiscalYearEndMonthAndDay_FA
	  ,LiabilitiesOverNetAssetsPercentage_FA
	  ,MAndGExpenseOverTotalPercentage_FA
	  ,NetAssetsAmount_FA
	  ,CAssets_FA
	  ,CLiab_FA
	  ,NetCashFromOperationsAmount_FA
	  ,NetIncomeAmount_FA
	  ,RevenueAmount_FA
	  ,UnrestrictedCurrentRatio_FA
	  ,CurrentRatio_FA
	  ,QuickCashRatio_FA
	  ,TotalDaysCash_FA
	  ,UnrestrictedNetAssetsAmount_FA
	  ,UnrestrictedNetAssetsOverNetAssetsPercentage_FA
	  ,UnrestrictedNetIncomeAmount_FA
	  ,UnrestrictedNumberOfDaysCash_FA
	  ,UnrestrictedCash_FA
	  ,ReservesCash_FA
	  ,Loans_FA
	  ,FixedAssets_FA
	  ,TAssets_FA
	  ,LTLiab_FA
	  ,TLiab_FA
	  ,NonControllingActivityAmount_FA
	  ,PriorPeriodAdjustmentsAmount_FA
	  ,RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments_FA_Text 
	  ,OHPSummaryComments_FA_Text 
	  ,FiscalYear_FA_Text
	  ,FiscalYearEndMonthandDay_FA_Text
	  ,CompDate_Text
	  ,A133Risk_Text
	  ,MaterialWeaknesses_Text
	  ,SignificantDeficiencies_Text
FROM(
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,CashAndCashEquivalentsAmount_FA
	  ,CurrentLiabilitiesOverNetAssetsPercentage_FA
	  ,DefensiveIntRatio_FA
	  ,DepreciationExpenseAmount_FA
	  ,ExpenseAmount_FA
	  ,FiscalYear_FA
	  ,FiscalYearEndMonthAndDay_FA
	  ,LiabilitiesOverNetAssetsPercentage_FA
	  ,MAndGExpenseOverTotalPercentage_FA
	  ,NetAssetsAmount_FA
	  ,CAssets_FA
	  ,CLiab_FA
	  ,NetCashFromOperationsAmount_FA
	  ,NetIncomeAmount_FA
	  ,RevenueAmount_FA
	  ,UnrestrictedCurrentRatio_FA
	  ,CurrentRatio_FA
	  ,QuickCashRatio_FA
	  ,TotalDaysCash_FA
	  ,UnrestrictedNetAssetsAmount_FA
	  ,UnrestrictedNetAssetsOverNetAssetsPercentage_FA
	  ,UnrestrictedNetIncomeAmount_FA
	  ,UnrestrictedNumberOfDaysCash_FA
	  ,UnrestrictedCash_FA
	  ,ReservesCash_FA
	  ,Loans_FA
	  ,FixedAssets_FA
	  ,TAssets_FA
	  ,LTLiab_FA
	  ,TLiab_FA
	  ,NonControllingActivityAmount_FA
	  ,PriorPeriodAdjustmentsAmount_FA
	  ,RatingAndAFICAComments AS RatingAndAFICAComments_FA_Text
	  ,AuditorOpinionandCommunicationComments AS AuditorOpinionandCommunicationComments_FA_Text
	  ,NWCapitalFundComments AS NWCapitalFundComments_FA_Text 
	  ,OHPSummaryComments AS OHPSummaryComments_FA_Text 
	  ,FiscalYear_FA_Text
	  ,FiscalYearEndMonthandDay_FA_Text
	  ,CompDate_Text
	  ,A133Risk_Text
	  ,MaterialWeaknesses_Text
	  ,SignificantDeficiencies_Text
FROM (
SELECT fa.PCODE
	  ,fa.FiscalYear
	  ,RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS Rank_FA
	  ,(fa.CashAndCashEquivalentsAmount) AS CashAndCashEquivalentsAmount_FA
	  ,(fa.CurrentLiabilitiesOverNetAssetsPercentage) AS CurrentLiabilitiesOverNetAssetsPercentage_FA
	  ,(fa.DefensiveIntRatio) AS DefensiveIntRatio_FA
	  ,(fa.DepreciationExpenseAmount) AS DepreciationExpenseAmount_FA
	  ,(fa.ExpenseAmount) AS ExpenseAmount_FA
	  ,(fa.FiscalYear) AS FiscalYear_FA
	  ,(fa.FiscalYearEndMonthAndDay) AS FiscalYearEndMonthAndDay_FA
	  ,(fa.LiabilitiesOverNetAssetsPercentage) AS LiabilitiesOverNetAssetsPercentage_fa
	  ,(ISNULL(fa.MAndGExpenseOverTotalPercentage,0)) AS MAndGExpenseOverTotalPercentage_FA
	  ,(fa.NetAssetsAmount ) AS NetAssetsAmount_FA
	  ,(fa.CAssets) AS CAssets_FA
	  ,(fa.CLiab) AS CLiab_FA
	  ,(fa.NetCashFromOperationsAmount) AS NetCashFromOperationsAmount_FA
	  ,(fa.NetIncomeAmount) AS NetIncomeAmount_FA
	  ,(fa.RevenueAmount ) AS RevenueAmount_FA
	  ,(fa.UnrestrictedCurrentRatio) AS UnrestrictedCurrentRatio_FA
	  ,(fa.CurrentRatio) AS CurrentRatio_FA
	  ,(fa.QuickCashRatio) AS QuickCashRatio_FA
	  ,(fa.TotalDaysCash) AS TotalDaysCash_FA
	  ,(fa.UnrestrictedNetAssetsAmount) AS UnrestrictedNetAssetsAmount_FA
	  ,(fa.UnrestrictedNetAssetsOverNetAssetsPercentage) AS UnrestrictedNetAssetsOverNetAssetsPercentage_FA
	  ,(fa.UnrestrictedNetIncomeAmount) AS UnrestrictedNetIncomeAmount_FA
	  ,(fa.UnrestrictedNumberOfDaysCash) AS UnrestrictedNumberOfDaysCash_FA
	  ,(fa.UnrestrictedCash) AS UnrestrictedCash_FA
	  ,(fa.ReservesCash) AS ReservesCash_FA
	  ,(fa.Loans) AS Loans_FA
	  ,(fa.FixedAssets) AS FixedAssets_FA
	  ,(fa.TAssets) AS TAssets_FA
	  ,(fa.LTLiab) AS LTLiab_FA
	  ,(fa.TLiab) AS TLiab_FA
	  ,(fa.NonControllingActivityAmount) AS NonControllingActivityAmount_FA
	  ,(fa.PriorPeriodAdjustmentsAmount) AS PriorPeriodAdjustmentsAmount_FA
	  ,RatingAndAFICAComments
	  ,AuditorOpinionandCommunicationComments
	  ,NWCapitalFundComments
	  ,OHPSummaryComments
	  ,FiscalYearEndMonthAndDay AS FiscalYearEndMonthandDay_FA_Text
	  ,FiscalYear AS FiscalYear_FA_Text
	  ,CompDate AS CompDate_Text
	  ,A133Risk AS A133Risk_Text
	  ,MaterialWeaknesses AS MaterialWeaknesses_Text
	  ,SignificantDeficiencies AS SignificantDeficiencies_Text  
FROM HARP.dbo.tblFinancialAudit fa WITH (NOLOCK)
WHERE fa.FiscalYear IN(@FirstLatestYear_FA,@SecondLatestYear_FA,@ThirdLatestYear_FA
					   ,@FourthLatestYear_FA)
)fa
WHERE fa.Rank_FA IN (1,2,3,4)

)fa
--where fa.FiscalYear=@FirstLatestYear_FA
--and RatingAndAFICAComments_FA_Text is not null
WHERE ((FiscalYear=@FirstLatestYear_FA)
AND (RatingAndAFICAComments_FA_Text IS NOT NULL
OR AuditorOpinionandCommunicationComments_FA_Text IS NOT NULL
OR NWCapitalFundComments_FA_Text IS NOT NULL
OR OHPSummaryComments_FA_Text IS NOT NULL  )
) OR (fa.FiscalYear IN (@FourthLatestYear_FA,@SecondLatestYear_FA
						,@ThirdLatestYear_FA)
)

)fa
WHERE Rank_FA IN (1,2,3)

)
SELECT * 
FROM CTE_Financial_Audit
END

--CREATE VIEW VWOAD_OHTS_AuditCompliance
--AS
SELECT A.PCODE
	  ,A.FiscalYear
	  ,NumberOfDaysEarlyOrLate AS [Status or Days Early(+) or Late(-)]
	  ,CASE WHEN AuditOpinion = AuditOpinion AND F.FiscalYear = 
	   (
		SELECT MAX(FiscalYear) FiscalYear
		FROM (
			  SELECT PCODE
			   	    ,MAX(C.FiscalYear) FiscalYear 
			  FROM dbo.tblFinancialAudit C 
			  GROUP BY PCODE
			  )C
		WHERE C.PCODE=F.PCODE AND A.PCODE=C.PCODE
		HAVING MAX(C.FiscalYear) =F.FiscalYear
       )THEN AuditOpinion END AS AuditOpinion
-------------------------------------------------------A133 Required 
	 ,CASE WHEN A133RecReq = 'A133Req' AND F.FiscalYear = 
	  (
	   SELECT MAX(FiscalYear) FiscalYear
	   FROM (
			 SELECT PCODE
				   ,MAX(C.FiscalYear) FiscalYear 
			 FROM dbo.tblFinancialAudit C 
			 GROUP BY PCODE
			 )C
	   WHERE C.PCODE=F.PCODE AND A.PCODE=C.PCODE
	   HAVING MAX(C.FiscalYear) =F.FiscalYear
      )THEN 'Yes'
      WHEN A133RecReq = 'A133Rec' AND F.FiscalYear = 
	  (
	   SELECT MAX(FiscalYear) FiscalYear
	   FROM(
			SELECT PCODE
				  ,MAX(C.FiscalYear) FiscalYear 
		    FROM dbo.tblFinancialAudit C 
			GROUP BY PCODE
		   )C
		WHERE C.PCODE=F.PCODE AND A.PCODE=C.PCODE
		HAVING MAX(C.FiscalYear) =F.FiscalYear
      ) THEN 'No' END AS [A133 Required]
------------------------------------------------A133 Finding
	 ,CASE WHEN (F.MaterialWeaknesses = 0 OR F.MaterialWeaknesses = ''OR F.MaterialWeaknesses IS NULL)  AND F.FiscalYear = 
	  (
	   SELECT MAX(FiscalYear) FiscalYear
	   FROM (
	         SELECT PCODE
				   ,MAX(C.FiscalYear) FiscalYear 
		     FROM dbo.tblFinancialAudit C 
			 GROUP BY PCODE
			)C
		WHERE C.PCODE=F.PCODE AND A.PCODE=C.PCODE
		HAVING MAX(C.FiscalYear) =F.FiscalYear
      )THEN 'No'
      WHEN F.MaterialWeaknesses = 1 AND F.FiscalYear = 
	  (
	   SELECT MAX(FiscalYear) FiscalYear
	   FROM (
			 SELECT PCODE
				   ,MAX(C.FiscalYear) FiscalYear 
			 FROM dbo.tblFinancialAudit C 
			 GROUP BY PCODE
			)C
		WHERE C.PCODE=F.PCODE AND A.PCODE=C.PCODE
		HAVING MAX(C.FiscalYear) =F.FiscalYear
      )THEN 'Yes' END AS [A133 Finding]
FROM  HARP.dbo.tblAuditCompliance A
LEFT JOIN dbo.tblFinancialAudit F
ON A.PCODE = F.PCODE AND A.FiscalYear = F.FiscalYear


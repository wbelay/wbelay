--CREATE VIEW VWOAD_OHTS_AuditCompliance
--AS
SELECT DISTINCT A.PCODE
	  ,A.FiscalYear
	  ,NumberOfDaysEarlyOrLate AS [Status or Days Early(+) or Late(-)]
	  ,AuditOpinion
	  ,CASE WHEN A133RecReq = 'A133Req'THEN 'Yes'
	        WHEN A133RecReq = 'A133Rec'THEN 'No' END AS [A133 Required]
	  ,CASE WHEN F.MaterialWeaknesses = 0 OR F.MaterialWeaknesses = ''OR F.MaterialWeaknesses IS NULL THEN 'No'
	        WHEN F.MaterialWeaknesses = 1 THEN 'Yes' END AS [A133 Finding]
FROM  HARP.dbo.tblAuditCompliance A
LEFT JOIN dbo.tblFinancialAudit F
ON A.PCODE = F.PCODE AND A.FiscalYear = F.FiscalYear




 


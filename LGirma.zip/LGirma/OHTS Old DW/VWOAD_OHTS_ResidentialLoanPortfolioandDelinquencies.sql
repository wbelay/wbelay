
--CREATE VIEW [dbo].[VWOAD_OHTS_ResidentialLoanPortfolioandDelinquencies]
--AS
SELECT [PCODE]
,ReportingYear as [FiscalYear]
,ReportingQuarter as [FiscalYearQuarter]
,CONVERT(int, [1st Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) as [FirstMortgageNumberOfOutstandingRLFLoans]
,CONVERT(money,[1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) as [FirstMortgageAmountOfOutstandingRLFLoans]
,CONVERT(int, [1st Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) as [FirstMortgageNumberOfRLFLoans3059DaysDelinquent]
,CONVERT(money, [1st Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) as [FirstMortgageAmountOfRLFLoans3059DaysDelinquent]
,CONVERT(int, [1st Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) as [FirstMortgageNumberOfRLFLoans6089DaysDelinquent]
,CONVERT(money, [1st Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) as [FirstMortgageAmountOfRLFLoans6089DaysDelinquent]
,CONVERT(int, [1st Mortgages: Number of RLF loans currently > 90 days delinquent]) as [FirstMortgageNumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(money, [1st Mortgages: Value of RLF loans currently > 90 days delinquent]) as [FirstMortgageAmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(int, [2nd Mortgages: Total number of outstanding RLF loans (excluding forgivable/ deferred)]) as [SubMortgageNumberOfOutstandingRLFLoans]
,CONVERT(money, [2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)]) as [SubMortgageAmountOfOutstandingRLFLoans]
,CONVERT(int, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 30 - 59 Days Delinquent]) as [SubMortgageNumberOfRLFLoans3059DaysDelinquent]
,CONVERT(money, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 30 - 59 Days Delinquent]) as [SubMortgageAmountOfRLFLoans3059DaysDelinquent]
,CONVERT(int, [Subordinate (2nd) Mortgages: Number of RLF Loans Currently 60 - 89 Days Delinquent]) as [SubMortgageNumberOfRLFLoans6089DaysDelinquent]
,CONVERT(money, [Subordinate (2nd) Mortgages: Value of RLF Loans Currently 60 - 89 Days Delinquent]) as [SubMortgageAmountOfRLFLoans6089DaysDelinquent]
,CONVERT(int, [2nd Mortgages: Number of RLF loans currently > 90 days delinquent]) as [SubMortgageNumberOfRLFLoans90DaysPlusDelinquent]
,CONVERT(money, [2nd Mortgages: Value of RLF loans currently > 90 days delinquent]) as [SubMortgageAmountOfRLFLoans90DaysPlusDelinquent]
,CONVERT(decimal(4,3), ([1st Mortgages: Value of RLF loans currently > 90 days delinquent]/ nullif([1st Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) as [FirstMortgagePercentage90DaysPlusDelinquent]
,CONVERT(decimal(4,3), ([2nd Mortgages: Value of RLF loans currently > 90 days delinquent]/ nullif([2nd Mortgages: Total $ value of outstanding RLF loans (excluding forgivable/ deferred)],0))) as [SubMortgagePercentage90DaysPlusDelinquent] 
FROM ProjectsandSummary.[Fact_RLF Portfolio Status] 
WHERE ReportingYear = (SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d)
AND ReportingQuarter=(SELECT max(d.ReportingQuarter) FROM ProjectsandSummary.Dim_Time d WHERE D.ReportingYear
=(SELECT max(d.ReportingYear) FROM ProjectsandSummary.Dim_Time d))

/*SQL code to produce conversion file Findings
we use tblFinding, tblFindingCategories and StgAssessment_MeetingDate tables
The script is run after we create StgAssessment_MeetingDate table*/
--=====================================================================================
SELECT pcode
	   ,CASE WHEN MeetingDate >(select max(meetingdate)from tblOHTSMeeting) THEN NULL
			 WHEN  MeetingDate = '12/15/15' THEN '12/16/15'
		     WHEN MeetingDate is not null and MeetingDate not in (SELECT meetingDate FROM dbo.tblOHTSMeeting OHTS 
		     WHERE F.PCODE=OHTS.PCODE and F.MeetingDate=OHTS.meetingDate) THEN 
			 (SELECT MIN(meetingDate) FROM dbo.tblOHTSMeeting OHTS WHERE F.PCODE=OHTS.PCODE and OHTS.meetingDate>F.MeetingDate)
			  ELSE CAST(MeetingDate AS DATE)---update 
	   END AS MeetingDate
	   ,'' AS AssessmentDate
	  ,FC.[Type] AS FindingGroup
	  ,CASE WHEN FC.ID = 5 THEN 'PL' ELSE FC.Category END AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(FindingDate AS DATE) AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,CASE WHEN F.closedflag=1 AND (F.OAD IS NULL OR F.OAD=' ') THEN 'Clear' 
	   ELSE F.OAD END AS OADRecommendation
	  ,CASE WHEN F.closedflag=1 AND F.Field IS NULL THEN 'Keep'
			WHEN  CONVERT(NVARCHAR(MAX),F.Field)=N' ' THEN 'Keep'  
	   ELSE F.Field END AS FieldRecommendation
	  ,dbo.fn_BooleanToYN(F.ClosedFlag) AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,REPLACE([dbo].[udf_StripHTML](Resolution),'CHAR(13) + CHAR(10)','') AS FieldResolutionComments
	  INTO #T
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND Year(FindingDate)>=2009
	    
--SELECT * INTO StgFinding
--FROM
--(
SELECT t.Pcode,t.MeetingDate,
	   CASE WHEN t.MeetingDate IS NULL 
                                 THEN (SELECT MAX(AssessmentDate) FROM StgAssessment B 
                                 WHERE t.pcode=B.PCODE AND B.AssessmentDate<=t.FindingDate)--we take Max AssessmentDate when AssessmentDate is less or equal to FindingDate
             ELSE (SELECT MAX(AssessmentDate) FROM StgAssessment_MeetingDate B 
                                 WHERE t.pcode=B.PCODE AND t.MeetingDate=B.MeetingDate)--we take Max AssessmentDate when they have the same MeetingDate
         END AS Assessmentdate--when meetingdate is null we take max assessmentdate from StgAssessement_MeetingDate tbl
         ,t.FindingGroup,t.FindingCategory,t.FindingType,t.FindingDate,t.FindingDescription,t.OADRecommendation,t.FieldRecommendation
         ,t.Isclosed,t.CreatedBy,t.CreatedDate,t.ModifiedBy,t.ModifiedDate,t.TaskDescription,t.TaskCompleted
         ,t.OADResolutionComments,t.FieldResolutionComments
FROM #T t
WHERE t.FindingDescription<>'Delete'
--)AS N
DROP TABLE #T

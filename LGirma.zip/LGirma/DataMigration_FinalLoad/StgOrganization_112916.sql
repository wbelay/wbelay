/*SQL code to produce StgOrganization
We use tblOrganization*/
--==========================================================
--SELECT * INTO StgOrganization
--FROM(
SELECT [PCODE]
	  ,[DistrictName]
      ,[Name]
      ,[PresidentCEOName] AS EDName
      ,[BusEmail] AS EDEmailAddress
      ,[CharterDate]
      ,CASE 
		WHEN LEN([FiscalYearEndMonthAndDay])= 3
		THEN LEFT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),1) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),2)
        ELSE LEFT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2) + '/'+
        RIGHT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2)
        END AS [FiscalYearEndMonthAndDay] 
      ,[City]
      ,[State]
      ,[RMName]
      ,[RMTitle]
      ,[OrgStatusName]
      ,[StreetAddrLine1]
      ,[StreetAddrLine2]
      ,[StreetAddrLine3]
      ,[StreetAddrZipCode]
      ,[BusPhone]
      ,[BusFax]
      ,[DateIncoporated]
      ,[MeetingDateID]
      ,[DateOrganizationDisaffiliated]
FROM [HARP].[dbo].[tblOrganization]
--) AS N
 
  

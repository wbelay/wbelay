/*SQL code to produce conversion file StgAssessment*/
--========================================================================
WITH CTE
AS
(
/*To reterive on-site data from onoffsitereviews table */
--======================================================================
SELECT PCODE 
	  ,CAST(ReviewDate AS DATE) AS ReviewDate
	  ,ReviewType
	  ,Leader AS AssignedTo
	  ,'' AS RN
FROM OnOffSiteReviews o
WHERE (reviewdate>getdate() and leader is not null) OR (reviewdate<getdate()) 
	  AND YEAR(ReviewDate)>=2009
	  AND ReviewType = 'On-Site'

UNION ALL

/*To reterive off-site data from tbloffsiterating, tblrating and tblratingdetail tables*/
--=======================================================================================
SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,MAX(rd.OADReviewerName)AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR),r.ReviewPROFlag ORDER BY OFS.PCODE)RN
FROM dbo.tblOffSiteRating OFS
LEFT JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	  CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND  r.ReviewPROFlag = 'Y'
	  AND CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)<=GETDATE()
GROUP BY OFS.PCODE,OFS.FiscalMonth,OFS.FiscalYearYear,R.ReviewPROFlag
)

--SELECT * INTO StgAssessment
--FROM(

--Reteriving on-site and off-site information from the above cte.
--=================================================================
SELECT PCODE
	  ,ReviewDate As AssessmentDate
	  ,ReviewType
	  ,AssignedTo
	  ,CASE WHEN CTE.PCODE IN (SELECT CTE.PCODE FROM [dbo].[tblOHTSMeeting] r WHERE cte.pcode=r.pcode and cte.ReviewDate<=r.meetingDate)
		THEN 'Complete' ELSE 'Current' END AS AssessmentStatus	
	  ,'History' AS RecordStatus----History is the default Value
	  ,CASE WHEN ReviewType = 'Off-Site' THEN '2000-01-01' ELSE '' END AS FinalReportApprovedDate
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate 
FROM CTE
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND YEAR(ReviewDate)<'2018'
	  AND PCODE IN(SELECT PCODE FROM tblOrganization)
	   
--) AS N 


/*SQL code to produce conversion file Risk Observed
We use tblEAROIssues*/
--==========================================================
--SELECT * INTO StgRiskObserved
--FROM
--(
 SELECT [PCODE]
	   ,CONVERT(VARCHAR(20),MeetingDate,101) AS MeetingDate
	   ,'' AS [RiskCategory]
	   ,'' AS [RiskType]
	   ,[dbo].[udf_StripHTML](IssueIdentified) AS [RiskIdentifiedDesc]
       ,[IssuedBy] AS [Division]
       ,[LastUpdate] AS [LastUpdateDesc]
       ,''AS [ResolvedWhenDesc]
       ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed] --to be used as flag for reporting
       ,[CreatedBy]
       ,[CreatedDate]
       ,[ModifiedBy]
       ,[ModifiedDate]
  FROM [HARP].[dbo].[tblEAROIssues]
  WHERE [Type]='Risk Observed' 
	and PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
--)AS N
/*SQL code to produce exclude NWOs list
we take the pcode list from ExcludedXLS2016*/
--SELECT * INTO StgExcludedNWOs
--FROM
--(
SELECT CASE WHEN PCODE IS NOT NULL THEN PCODE
			ELSE(SELECT [Pcodes to exclude from data migration] FROM dbo.ExcludedXLS2016) END AS PCODE
	  ,CASE WHEN OrgStatusName LIKE 'Disaffiliation' THEN 'Disaffiliation'
			WHEN OrgStatusName LIKE'Suspended' THEN 'Suspended'
			ELSE 'OHTS 3/17' END AS ExcludedReason	  ,[DistrictName]	  ,[Name]	  ,[PresidentCEOName]	  ,[CharterDate]	  ,CASE 
		WHEN LEN([FiscalYearEndMonthAndDay])= 3
		THEN LEFT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),1) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),2)
        ELSE LEFT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2) + '/'+
        RIGHT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2)
        END AS [FiscalYearEndMonthAndDay]       ,[City]      ,[State]      ,[Title]      ,[RMName]      ,[RMTitle]      ,[OrgStatusName]      ,[StreetAddrLine1]      ,[StreetAddrLine2]      ,[StreetAddrLine3]      ,[StreetAddrZipCode]      ,[BusPhone]      ,[BusFax]      ,[BusEmail]      ,[DateIncoporated]      ,[MeetingDateID]      ,[DateOrganizationDisaffiliated]      ,[ED_Name]      ,[OrgEmail]
      ,[Org_Phone]
FROM tblOrganization
WHERE PCODE IN(SELECT [Pcodes to exclude from data migration] FROM dbo.ExcludedXLS2016)OR(OrgStatusName LIKE 'Disaffiliation' OR OrgStatusName LIKE 'Suspended')  
--) AS N 
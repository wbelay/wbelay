--SELECT * INTO Test_Assessment
--FROM (
SELECT  r.PCODE AS PCODE
        , CASE 
            WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
            WHEN r.OthersFlag = 'Y' THEN 'Other'
            ELSE '' 
          END AS ReviewType
        , CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        --, CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
        , rd.OADReviewerName AS AssignedTo
        , '' AS CreatedBy
        , '' AS CreatedDate
FROM tblRating r
LEFT JOIN tblRatingDetail rd
   ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate
LEFT JOIN dbo.OnOffSiteReviews OFR
	ON (r.PCODE = OFR.PCODE 
	    AND (CASE 
				WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
				WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
				WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
				WHEN r.OthersFlag = 'Y' THEN 'OthersFlag' 
              ELSE '' 
             END) = OFR.ReviewType)
                        
WHERE --OFR.ReviewDate <= r.MeetingDate
--	  AND r.MeetingDate <= GETDATE()
       (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
GROUP BY r.PCODE,  r.ReviewFlag, r.ReviewPROFlag, r.AuditReviewFlag, r.OthersFlag,  rd.OADReviewerName, ReviewType
--) as n
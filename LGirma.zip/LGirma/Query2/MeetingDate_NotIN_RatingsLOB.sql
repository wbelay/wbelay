SELECT  PCODE 
	  ,MeetingDate
	  ,AssessmentDate
	  ,ReviewType
FROM dbo.New_Assessment
WHERE MeetingDate NOT IN (SELECT MeetingDate FROM dbo.New_RatingsandLOB)

SELECT MeetingDate
FROM dbo.New_RatingsandLOB
WHERE PCODE=3075-- IN (3010,3015,3020,3025,3050,3055,3070,3075)
SELECT PCODE
	  ,MeetingDate
	  ,r.ReviewFlag
	  ,r.ReviewPROFlag
FROM dbo.tblRating r
WHERE MeetingDate NOT IN (SELECT MeetingDate FROM dbo.Test_Assessment a
				WHERE a.PCODE = r.PCODE) --AND a.MeetingDate<>r.MeetingDate)
	  AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y')
	  AND MeetingDate <= GETDATE()
	  ORDER BY r.MeetingDate DESC
	
	  
	  
-------=====&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&====------------

SELECT PCODE 
      ,MeetingDate
FROM dbo.Test_Assessment a
WHERE MeetingDate NOT IN (SELECT MeetingDate FROM dbo.Test_RatingsandLOB r)
				--WHERE a.PCODE = r.PCODE) AND a.MeetingDate<>r.MeetingDate)
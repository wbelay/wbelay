WITH CTE2 AS
			(
			  SELECT A.PCODE
					,A.AssessmentDate				
			  FROM  dbo.StgAssessment_MEETINGDATE a 
			  
			 )
	 ,CTE3 AS 
			(
			  SELECT  os.PCODE
					 ,os.ReviewDate
					 ,os.ProductionProgramServicesText AS PROMPTRating_P
					 ,os.ResourceManagementText AS PROMPTRating_R
					 ,os.OrganizationalManagementText AS PROMPTRating_O
					 ,os.PersonnelManagementText AS PROMPTRating_M
					 ,os.PlanningText AS PROMPTRating_PM
					 ,os.TechnicalOperationsSystemsText AS PROMPTRating_T 
					 ,orv.HomeownershipPreservationFlag 
					 ,orv.HomeownershipPromotionServicesFlag 
					 ,orv.CommunityBuildingandOrganizingFlag 
					 ,orv.AssetAndPropertyManagementFlag
					 ,orv.RealEstateDevelopmentFlag 
					 ,orv.LendingandPortfolioManagementFlag 
				     ,orv.OtherServicesFlag 
			 FROM dbo.tblOnSiteRatings OS
			 LEFT OUTER JOIN [tblOnSiteReviewLineOfBusiness] ORV
			 ON OS.PCODE = ORV.PCODE
			 AND OS.ReviewDate = ORV.ReviewDate
			 
			  UNION ALL 
			  
			  SELECT [PCODE]
             ,CAST([Month] AS varchar(12)) + '/' + '1' + '/' + CAST(FYear as varchar(6)) AS ReviewDate
			 ,CASE WHEN ProdRate=1 THEN 'Exceed'
				   WHEN ProdRate=3 THEN 'Meet' 
				   WHEN ProdRate=5 THEN 'Fail' END AS PROMPTRating_P
			,CASE WHEN ResRate=1 THEN 'Exceed'
				  WHEN ResRate=3 THEN 'Meet' 
				  WHEN ResRate=5 THEN 'Fail' END AS  PROMPTRating_R
		    ,CASE WHEN OMRate=1 THEN 'Exceed'
				  WHEN OMRate=3 THEN 'Meet' 
				  WHEN OMRate=5 THEN 'Fail' END AS PROMPTRating_O
			,'' AS PROMPTRating_M
			,'' AS PROMPTRating_PM
			,'' AS PROMPTRating_T
			,dbo.fn_BooleanToYN(RE_Off) AS HomeonwhershipPreservationFlag
			,dbo.fn_BooleanToYN(HOME_Off) AS HomeownerhipPormotionServicesFlag
			,dbo.fn_BooleanToYN(CBE_Off) AS CommunityBuildingandOrganizingFlag
			,dbo.fn_BooleanToYN(PM_Off)AS AssetAndPropertyManagementFlag
			,dbo.fn_BooleanToYN(RED_Off)AS RealEstateDevelomentFlag
			,dbo.fn_BooleanToYN(LEND_Off)AS LendingandPortfolioManagementFlag
			,'' AS OtherServicesFlag
			FROM [HARP].[dbo].[RiskFactorOAD]
			 
		)
		   
	,CTE4 AS
		   (
		     SELECT CTE2.PCODE
				   ,CTE2.AssessmentDate
				   ,CTE3.PROMPTRating_P as PROMPTRating_P
				   , CTE3.PROMPTRating_R as PROMPTRating_R
				   ,CTE3.PROMPTRating_O  AS PROMPTRating_O
				   ,CTE3.PROMPTRating_PM  AS PROMPTRating_PM
				   , CTE3.PROMPTRating_M as PROMPTRating_M 
				   , CTE3.PROMPTRating_T  AS PROMPTRating_T 
				   --,ROW_NUMBER()OVER(PARTITION BY CTE2.PCODE,CTE2.ASSESSMENTDate,CTE2.MeetingDate,CTE2.Division--,cte2.ratingrecommendation
									--ORDER BY CTE2.PCODE)RN		
			FROM CTE2 
			JOIN CTE3 
			ON CTE2.PCODE=CTE3.PCODE --AND CTE2.AssessmentDate=CTE3.ReviewDate
			WHERE 
				   (CTE3.PROMPTRating_P IS NOT NULL OR CTE3.PROMPTRating_R IS NOT NULL OR CTE3.PROMPTRating_O IS NOT NULL
				      OR CTE3.PROMPTRating_PM IS NOT NULL OR CTE3.PROMPTRating_M IS NOT NULL OR CTE3.PROMPTRating_T IS NOT NULL)
				  
		   )
--SELECT * INTO New_StgRatingsandLOB
--FROM
--(
SELECT  DISTINCT CTE4.PCODE
	  ,CTE4.ASSESSMENTDATE
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_P ELSE '' END AS PROMPTRating_P
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_R ELSE '' END AS PROMPTRating_R
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_O ELSE '' END AS PROMPTRating_O
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_PM ELSE '' END AS PROMPTRating_PM
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_M ELSE '' END AS PROMPTRating_M 
	  ,CASE WHEN L.Division='OAD' THEN CTE3.PROMPTRating_T ELSE '' END AS PROMPTRating_T 
	  ,CASE WHEN L.Division = 'OAD'THEN HomeownershipPreservationFlag END AS HomeOwnershipPreservationServices
      ,CASE WHEN L.Division = 'OAD'THEN HomeownershipPromotionServicesFlag END AS HomeOwnershipPromotion
      ,CASE WHEN L.Division = 'OAD'THEN CommunityBuildingandOrganizingFlag END AS CommunityBuildingandEngagement
      ,CASE WHEN L.Division = 'OAD'THEN AssetAndPropertyManagementFlag END AS PropertyManagement
      ,CASE WHEN L.Division = 'OAD'THEN RealEstateDevelopmentFlag END AS RealEstateDevelopment
      ,CASE WHEN L.Division = 'OAD'THEN LendingandPortfolioManagementFlag END AS LendingandLoanPortfolio 
      ,CASE WHEN L.Division = 'OAD'THEN OtherServicesFlag ELSE '' END AS OtherServices
      
FROM cte4 
LEFT JOIN cte3
ON cte4.PCODE=cte3.PCODE and cte4.AssessmentDate=CTE3.ReviewDate
LEFT JOIN StgRatingsandLOB_Division L
ON CTE4.PCODE= L.PCODE
WHERE 
	   AssessmentDate<= GETDATE()


	  AND CTE4.PCODE IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
--order by cte4.pcode, cte4.meetingdate	  	  
--) AS N

  ORDER BY 2 DESC
  

  
  
  
  
  
  
 
 

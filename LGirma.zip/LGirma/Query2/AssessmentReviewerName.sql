SELECT DISTINCT r.PCODE AS PCODE
        , CASE 
            WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
            WHEN r.OthersFlag = 'Y' THEN 'Other'
            ELSE '' 
          END AS ReviewType
        , CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        , isnull(rd.OADReviewerName,'') AS AssignedTo
        , '' AS CreatedBy
        , '' AS CreatedDate
        into #t
FROM tblRating r
LEFT JOIN tblRatingDetail rd
   ON rd.PCODE = r.PCODE 
LEFT JOIN dbo.OnOffSiteReviews OFR
	ON (r.PCODE = OFR.PCODE 
	    AND (CASE 
				WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
				WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
				WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
				WHEN r.OthersFlag = 'Y' THEN 'OthersFlag' 
              ELSE '' 
             END) = OFR.ReviewType)
                        
WHERE (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')	
       --AND rd.OADReviewerName!=''
GROUP BY r.PCODE,  r.ReviewFlag, r.ReviewPROFlag, r.AuditReviewFlag, r.OthersFlag,  rd.OADReviewerName, ReviewType
ORDER BY PCODE
--select *,ROW_NUMBER()over(PARTITION by pcode,reviewtype,assessmentdate order by  assignedto)rn
----into #t1
--from #t 

select distinct PCODE,ReviewType,AssessmentDate,AssignedTo,CreatedBy,CreatedDate,ROW_NUMBER()over(PARTITION by pcode,reviewtype,assessmentdate order by  assignedto)rn
into #t1
from #t

select   PCODE,ReviewType,AssessmentDate,AssignedTo,CreatedBy,CreatedDate
from #t1 
where (rn = 1 and AssignedTo ='') 
union all
select distinct PCODE,ReviewType,AssessmentDate,AssignedTo,CreatedBy,CreatedDate
from #t1 
where AssignedTo != ''


drop table #t
drop table #t1
--select #t1.pcode,reviewtype,assessmentdate,#t1.CreatedBy,#t1.CreatedDate,MAX(rn) AS MaxCount
--into #t2
--from #t1 
--GROUP BY #t1.pcode,reviewtype,assessmentdate,#t1.CreatedBy,#t1.CreatedDate

--select tt.PCODE
--      ,tt.ReviewType
--      ,tt.AssessmentDate
--      --,rd.OADReviewerName
--      ,tt.CreatedBy
--      ,tt.CreatedDate
--      ,tt.MaxCount
--from #t2 tt 
----inner join tblRatingDetail rd
----on tt.PCODE = rd.PCODE and tt.AssessmentDate = rd.
----order by tt.PCODE,tt.AssessmentDate asc
 
----where rn =1



--drop table #t2

--select distinct top 100 rd.PCODE,isnull(rd.OADReviewerName,'') OADReviewerName
--from tblRatingDetail rd
--order by rd.PCODE
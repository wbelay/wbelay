MERGE dbo.tblFinHealth AS TARGET
USING (
		SELECT PCODE,RatingAFICA, AuditorOpinion, AuditHealth, Year, CompDate, OInterim, FinAnalysis
		FROM OPENROWSET('\\kmofil01p.neighborworks.nwo.org\RMU\M & A\OAD Tables Master.mdb') 
	  ) AS SOURCE
ON SOURCE.PCODE = TARGET.PCODE 
   AND SOURCE.RatingAFICA = TARGET.RatingAFICA
   AND SOURCE.AuditorOpinion = TARGET.AuditorOpinion
   AND SOURCE.AuditHealth = TARGET.AuditHealth
   AND SOURCE.Year = TARGET.Year
   AND SOURCE.CompDate = TARGET.CompDate
   AND SOURCE.OInterim = TARGET.OInterim
   AND SOURCE.FinAnalysis = TARGET.FinAnalysis
WHEN NOT MATCHED BY TARGET THEN
    INSERT ( PCODE
			 ,RatingAFICA
			 ,AuditorOpinion
			 ,AuditHealth
			 ,Year
			 ,CompDate
			 ,OInterim
			 ,FinAnalysis)
    VALUES ( SOURCE.PCODE
		    ,SOURCE.RatingAFICA
		    ,SOURCE.AuditorOpinion
		    ,SOURCE.AuditHealth
		    ,SOURCE.Year
		    ,SOURCE.CompDate
		    ,SOURCE.OInterim
		    ,SOURCE.FinAnalysis);
		    
		    
-------------------------------------------------------------------

------------------------------------------------------------------
SELECT X.* FROM (
SELECT DISTINCT 
       DistrictName AS Region
       ,O.PCODE
	  ,Name
	  ,ISNULL([City],'') +','+ ' '+ ISNULL([State],'') AS [City,State]
	  ,a.ReviewType 
	  ,a.ReviewDate AS [Off-Site Review]
	  ,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
FROM dbo.tblOrganization o
 JOIN dbo.tblAssessment a 
 ON o.PCODE = a.PCODE
 JOIN dbo.tblOrganizationMeetingDates om 
 ON om.PCODE = o.PCODE
 and a.ID= om.AssessmentID
WHERE a.ReviewType=2 AND (OM.IsOnWatchList=1 OR om.IsOnWatchList is null)
--AND ReviewDate = (
--SELECT max(c.ReviewDate) [On-Site Review]
--FROM dbo.tblAssessment c
--where c.PCODE=a.PCODE
--and a.ReviewType=c.ReviewType
--)
AND O.Name='NHS of South Florida, Inc.'
)X
JOIN 
(
SELECT 
C.PCODE
,max(c.ReviewDate) [Off-Site Review]
FROM dbo.tblAssessment c
where c.ReviewType=2
group by c.PCODE
) y on y.PCODE=x.PCODE and y.[Off-Site Review]=x.[Off-Site Review]		    
		    
		    
		    
--		    WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName 
--OR TARGET.Rate <> SOURCE.Rate THEN 
--UPDATE SET TARGET.ProductName = SOURCE.ProductName, 
--TARGET.Rate = SOURCE.Rate
		    
		    
--SELECT *
--FROM OPENROWSET( 'Microsoft.Jet.OLEDB.4.0','\\euro-dc\DOTS\2014\dots.mdb';'admin';'',TimeSeries)
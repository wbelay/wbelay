SELECT * INTO StgCurrentrating
from(
SELECT O.PCODE AS PCODE
       ,O.MeetingDate AS MeetingDate
       ,r.CurrentRatingText AS FinalOHTSRecommendation 
       ,r.OnWatchListSinceDate AS WatchListstartDate
       ,r.ProvisionalCharterFlag AS ProvisionalCharterStatus 
       ,r.ProvisionalStartDate AS ProvisionCharterStatusDate
 FROM [dbo].[tblOHTSMeeting]O
 JOIN tblRating r 
 ON O.PCODE = r.PCODE AND O.MeetingDate = r.MeetingDate
WHERE YEAR(r.MeetingDate) != '2050'
	  AND YEAR(r.MeetingDate)>2009
	  and o.PCODE in (8198,8149,8523,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8328,8528)
	  )n
	  
 
 



      
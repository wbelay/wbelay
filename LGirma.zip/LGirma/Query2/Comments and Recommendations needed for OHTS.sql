SELECT DistrictName
	  ,o.PCODE
	  ,Name
	  ,RMName
	  ,HARP.dbo.fn_BooleanToYN(om.IsOnWatchList) AS Watchlist
	  ,CASE WHEN om.ReviewReasonID = 1 THEN '[On-Site]'
			WHEN om.ReviewReasonID = 2 THEN '[Off-Site]'
		END AS [RieviewReason]
	  ,CASE WHEN [RecommendationID] = 1 THEN 'Exemplary'
			WHEN [RecommendationID] = 2 THEN 'Strong'
			WHEN [RecommendationID] = 3 THEN 'Satisfactory'
			WHEN [RecommendationID] = 4 THEN 'Vulnerable'
			WHEN [RecommendationID] = 5 THEN 'N/A'
		END AS [Current Ratings]	 
FROM dbo.tblOrganization o
JOIN dbo.tblOrganizationMeetingDates om
ON o.PCODE = om.PCODE
JOIN dbo.tblFinalRatingRecommendations f
ON o.PCODE = f.PCODE
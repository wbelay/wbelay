--SELECT * INTO Test_Assessment
--FROM (
WITH CTE
AS (
SELECT  r.PCODE AS PCODE
        , CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        --, CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
 FROM tblRating r
LEFT JOIN dbo.OnOffSiteReviews OFR
	ON r.PCODE = OFR.PCODE 

                        
WHERE OFR.ReviewDate <= r.MeetingDate
	  AND r.MeetingDate <= GETDATE() 
	 -- and r.PCODE = 3075 
	   
      --AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
GROUP BY r.PCODE
--) as n
)

 SELECT  OFR.PCODE AS PCODE
        , CONVERT(VARCHAR(20), OFR.ReviewDate, 101) AS AssessmentDate
        , CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
 FROM dbo.OnOffSiteReviews OFR INNER JOIN CTE 
 ON OFR.PCODE = cte.PCODE 
 AND OFR.ReviewDate = CTE.AssessmentDate 
 LEFT OUTER JOIN tblRating r
 ON r.PCODE = cte.PCODE 
 ORDER BY cte.PCODE


WITH CTE
AS
(
SELECT os.PCODE 
	  ,OS.ReviewDate
	  ,r.MeetingDate
	  ,ROW_NUMBER()OVER (PARTITION BY OS.PCODE,OS.REVIEWDATE ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOnSiteReviewLineOfBusiness OS
JOIN [dbo].[tblOHTSMeeting] r 
ON r.PCODE = os.PCODE 
AND YEAR(R.MeetingDate)>2009 
AND OS.ReviewDate<=R.MeetingDate
AND R.MeetingDate<=GETDATE()
AND OS.ReviewDate<=GETDATE()

UNION ALL

SELECT OFS.PCODE 
	   ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
	  ,r.MeetingDate
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar) ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOffSiteRating OFS
JOIN [dbo].[tblOHTSMeeting] r 
ON r.PCODE = OFS.PCODE 
AND YEAR(R.MeetingDate)>2009 
AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=R.MeetingDate
AND R.MeetingDate<=GETDATE()
AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=GETDATE()
)

SELECT PCODE
         ,Max(ReviewDate) AS AssessmentDate
         ,MeetingDate
         ,'SwitchBoardImport' AS CreatedBy
         ,CAST(GETDATE() AS DATE) AS CreatedDate
--into #t
FROM CTE
WHERE 
 PCODE IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
Group by
PCODE, MeetingDate
ORDER BY PCODE,MeetingDate Desc,Max(ReviewDate) Desc

--select * into StgAssessment_MeetingDate
--from
--(
--select *
--from #t
--)n

--drop table #t



UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE IN (SELECT PCODE FROM StgAssessment_MeetingDate
				WHERE DeferredFlag = 'Y' and StgAssessment.AssessmentDate=StgAssessment_MeetingDate.AssessmentDate)


UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE =8046 and AssessmentDate = '2016-06-20'

SELECT *
FROM dbo.StgAssessment 
WHERE AssessmentStatus='Current'

UPDATE dbo.StgAssessment 
SET RecordStatus= 'OADDraftReport'
WHERE AssessmentStatus= 'Current' 

UPDATE dbo.StgAssessment
SET AssignedTo='Promptoadreviewer1'
WHERE AssessmentStatus= 'Current'


ALTER TABLE dbo.StgAssessment
alter column  RecordStatus text

--update OnOffSiteReviews
--set InProcess=1
--where PCODE=8046 and  (cast(reviewdate as date)='06/20/2016')

 
 UPDATE [HARP].[dbo].[RiskFactorOAD]
SET Month = (CASE WHEN [Month]= 'January' THEN 1
           WHEN [Month]='February' THEN 2
           WHEN [Month]='March' THEN 3
           WHEN [Month]='April' THEN 4
           WHEN [Month]='May' THEN 5
           WHEN [Month]='June' THEN 6
           WHEN [Month]='July' THEN 7
           WHEN [Month]='August' THEN 8
           WHEN [Month]='September' THEN 9
           WHEN [Month]='October' THEN 10
           WHEN [Month]='November' THEN 11
           WHEN [Month]='December' THEN 12 END)
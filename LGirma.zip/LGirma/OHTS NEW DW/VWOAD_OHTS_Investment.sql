/*SQL code to produce Investment information on Production&Investment graph on OHTS report
We use agg_Comprensive, dim_Organization and dim_Date tables*/
--=============================================================================
SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalYearQuarter 
	  ,ISNULL([Owner_Occupied_Repairs_Investment],0)+
	   ISNULL([Rental_Homes_Investment],0)+
	   ISNULL([For_Sale_Homes_Developed_Investment],0)+
	   ISNULL([Special_Projects_Investment],0)+
	   ISNULL([Commercial_Development_Investment],0)+
	   ISNULL([Commercial_Lending_Investment],0)+
	   ISNULL([Homeowners_Created_Investment],0)+
	   ISNULL([Preserved_Homeownership_Foreclosure_Mitigation_Investment],0)+ 
	   ISNULL([Preserved_Homeownership_Owner_Occupied_Rehabilitation_Investment],0)+
	   ISNULL([Preserved_Homeownership_Refinancing_Investment],0)+ 
	   ISNULL([Preserved_Homeownership_Replacement_Investment],0)+
	   ISNULL([Preserved_Homeownership_Reverse_Mortgage_Investment],0) AS [Total Direct Investment]
FROM [DataWarehouse].[dbo].[agg_Comprehensive] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
WHERE PCODE IS NOT NULL --AND D.fin_year in ((select MAX(D.fin_year) from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R LEFT JOIN [dbo].[dim_date] D 
--ON R.dim_ReportingQuarter_key = D.dim_date_key),(select MAX(D.fin_year)-1 from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R LEFT JOIN [dbo].[dim_date] D ON R.dim_ReportingQuarter_key = D.dim_date_key))
--AND right(D.fin_quarter,1)=(select MAX(right(D.fin_quarter,1)) from [dbo].[dim_date] D)
ORDER BY PCODE ASC

SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,SUM([Volunteer_Hours]) AS [Volunteer_Hours]
FROM [dbo].[fact_Comprehensive_Summary] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
GROUP BY PCode
        ,D.fin_year



/*SQL code to produce Rental Homes Portfolio, Owned and/or Managed graph on OHTS report
We use agg_Comprensive, dim_Organization and dim_Date tables*/
--=============================================================================
SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalYearQuarter
	  ,[Rental_Homes_Portfolio_Owned]
	  ,[Rental_Homes_Portfolio_Managed_Not_Owned]
FROM [DataWarehouse].[dbo].[agg_Comprehensive] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key

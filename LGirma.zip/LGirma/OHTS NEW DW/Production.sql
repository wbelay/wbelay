SELECT PCODE
	  ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalQuarter
	  ,ISNULL([Rental_Homes_Purchased_For_New_Renters_Investment],0)+
	   ISNULL([Rental_Homes_Development_Services_Units],0)+
	   ISNULL([Preserved_Homeownership_Owner_Occupied_Rehabilitation_Customers],0)+
	   ISNULL([Homeowners_Created_Customers],0)+
	   ISNULL([Preserved_Homeownership_Refinancing_Customers],0)+
	   ISNULL([Preserved_Homeownership_Foreclosure_Mitigation_Customers],0)+
	   ISNULL([Rental_Homes_Refinanced_Investment],0)+
	   ISNULL([Rental_Homes_Rehabilitated_Investment],0) AS TotalProductionNumber
FROM [dbo].[fact_Comprehensive_Rollup] C
JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
WHERE PCODE IS NOT NULL
ORDER BY PCODE, fin_year
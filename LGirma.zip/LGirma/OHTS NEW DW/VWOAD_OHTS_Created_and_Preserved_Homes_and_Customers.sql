/*SQL code to produce Created and Preserved Homes and Cutomers graph on OHTS report
We use agg_Comprensive, dim_Organization and dim_Date tables*/
--=============================================================================
SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalYearQuarter
	  ,[Homeowners_Created_Customers] 
	  ,ISNULL([Preserved_Homeownership_Foreclosure_Mitigation_Customers],0)+
	   ISNULL([Preserved_Homeownership_Owner_Occupied_Rehabilitation_Customers],0)+
	   ISNULL([Preserved_Homeownership_Replacement_Customers],0)+
	   ISNULL([Preserved_Homeownership_Refinancing_Customers],0)+
	   ISNULL([Preserved_Homeownership_Reverse_Mortgage_Customers],0) AS NumberOfOtherPreservationClient
	  ,ISNULL([Rental_Homes_Constructed_Units],0) + 
	   ISNULL([Rental_Homes_Purchased_For_New_Renters_Units],0) + 
	   ISNULL([Rental_Homes_Purchased_With_Existing_Renters_Units],0) +
	   ISNULL([Rental_Homes_Refinanced_Units],0) +
	   ISNULL([Rental_Homes_Rehabilitated_Units],0) +
	   ISNULL([Rental_Homes_Rehabilitated_With_NSP_Funds_Units],0) +
	   ISNULL([Rental_Homes_Development_Services_Units],0) AS NumberOfRentalUnits
FROM [DataWarehouse].[dbo].[agg_Comprehensive] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key


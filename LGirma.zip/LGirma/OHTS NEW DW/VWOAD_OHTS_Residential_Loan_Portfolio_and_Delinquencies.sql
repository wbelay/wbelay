/*SQL code to produce Resdential Loan Portfolio and Delinquencies graph on OHTS report
We use fact_RLF_Portfolio_Status, dim_Organization and dim_Date tables*/
--=============================================================================
SELECT DISTINCT PCode
	  ,CAST(D.fin_year AS VARCHAR(4))+' '+'Q'+ RIGHT(CAST(fin_quarter AS VARCHAR(10)),1)  AS [FiscalYearandQuarter]
	  ,CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [FirstMortgageNumberOfOutstandingRLFLoans]
	  ,CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [FirstMortgageAmountOfOutstandingRLFLoans]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans30to59DaysDelinquent]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans60to89DaysDelinquent]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans90+DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans90DaysPlusDelinquent]
      ,CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [SubMortgageNumberOfOutstandingRLFLoans]
	  ,CONVERT(MONEY, [Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [SubMortgageAmountOfOutstandingRLFLoans]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans90+DaysDelinquent] 
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans90+DaysDelinquent]
	  ,CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [1st% of $ 90+ Delinquent]
	  ,CONVERT(DECIMAL(4,3),[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [2nd% of $ 90+ Delinquent]    
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON R.dim_ReportingQuarter_key = D.dim_date_key  
WHERE PCODE IS NOT NULL
--ORDER BY PCODE ASC

  
 






SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,SUM([For_Sale_Homes_Developed_Homes]) AS [For-Sale Homes Developed]
	  --,[Units Held in Portfolio at End of Quarter]
FROM [dbo].[fact_QPR_Projects_And_Summary_Rollup] Q
LEFT JOIN [dbo].[dim_Organization] O
ON Q.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON Q.dim_ReportingQuarter_key = D.dim_date_key
--WHERE PCODE IS NOT NULL AND D.fin_year in ((select MAX(D.fin_year) from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R LEFT JOIN [dbo].[dim_date] D 
--ON R.dim_ReportingQuarter_key = D.dim_date_key),(select MAX(D.fin_year)-1 from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R LEFT JOIN [dbo].[dim_date] D ON R.dim_ReportingQuarter_key = D.dim_date_key))
--AND right(D.fin_quarter,1)=(select MAX(right(D.fin_quarter,1)) from [dbo].[dim_date] D)
GROUP BY PCode
        ,D.fin_year
		

-------
--SELECT PCode
--      ,D.fin_year AS FisicalYear
--	  ,SUM([Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter]) AS [For-Sale Homes Developed]
--	  --,[Units Held in Portfolio at End of Quarter]
--FROM [dbo].[fact_Inventory_Of_For_Sale_Units] Q
--LEFT JOIN [dbo].[dim_Organization] O
--ON Q.dim_Organization_key = O.dim_Organization_key
--LEFT JOIN [dbo].[dim_date] D
--ON Q.dim_ReportingQuarter_key = D.dim_date_key
--GROUP BY PCode
--        ,D.fin_year	
		
		

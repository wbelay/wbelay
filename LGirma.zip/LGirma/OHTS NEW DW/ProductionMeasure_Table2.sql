SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,SUM([Preserved_Homeownership_Owner_Occupied_Rehabilitation_Customers]) AS [Preserved_Homeownership_Owner_Occupied_Rehabilitation_Customers]
	  ,SUM(ISNULL([Preserved_Homeownership_Refinancing_Customers],0)+
	   ISNULL([Preserved_Homeownership_Reverse_Mortgage_Customers],0)+
	   ISNULL([Preserved_Homeownership_Replacement_Customers],0)+
	   ISNULL([Preserved_Homeownership_Foreclosure_Mitigation_Customers],0))AS [Preserved HomeownershipRefinance, Reverse, Replacement, Foreclosure-Cutomers]
	  ,SUM([Homeowners_Created_Customers]) AS [Homeowners_Created_Customers]
	  --,[Facilitated Homeowners Crreated-Customers]----we don't have ths column
	  ,SUM([Rental_Homes_Constructed_Acquired_And_Preserved_Units])AS [Rental_Homes_Constructed_Acquired_And_Preserved_Units]
	  ,SUM(ISNULL([Rental_Homes_Constructed_Units],0)+
	   ISNULL([Rental_Homes_Purchased_For_New_Renters_Units],0)+
	   ISNULL([Rental_Homes_Purchased_With_Existing_Renters_Units],0)) AS [Rental Homes, Constructed and Purchased]
	  ,SUM(ISNULL([Rental_Homes_Rehabilitated_Units],0)+
	   ISNULL([Rental_Homes_Refinanced_Units],0)) AS [Rental Homes Rehabilitated and Refinanced]
	  ,SUM(ISNULL([Rental_Homes_Rehabilitated_Units],0)+
	   ISNULL([Rental_Homes_Rehabilitated_With_NSP_Funds_Units],0)) AS [Rental Homes Development Services and NSP Rehab]
	  ,SUM([Created_Preserved_Homes_And_Customers]) AS [Created_Preserved_Homes_And_Customers]
FROM [dbo].[fact_Comprehensive_Summary] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
GROUP BY PCode
        ,D.fin_year

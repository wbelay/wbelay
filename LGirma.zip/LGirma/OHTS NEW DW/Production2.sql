SELECT PCODE
	  ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalQuarter
	  ,[Preserved_Homeownership_Owner_Occupied_Rehabilitation_Customers] AS NumberOfHomeRehabClients
	  ,[Preserved_Homeownership_Customers] AS NumberOfOtherPreservationClients
	  ,[Homeowners_Created_Customers] AS NumberofHomeownershipClients
	  ,[Rental_Homes_Constructed_Acquired_And_Preserved_Units] AS NumberOfRentalUnits
	  ,[Rental_Homes_Purchased_For_New_Renters_Units] AS NumberOfRentalUnitsCreated
	  ,ISNULL([Rental_Homes_Refinanced_Units],0)+
	   ISNULL([Rental_Homes_Rehabilitated_Units],0) AS NumberOfRentalUnitsPreserved
	  ,[Rental_Homes_Development_Services_Units] AS NumberOfRentalAssistedUnits
	  ,NULL AS NumberOther
	  ,ISNULL([Homeowners_Created_Customers],0)+
	   ISNULL([Preserved_Homeownership_Customers],0)+
	   ISNULL([Rental_Homes_Constructed_Acquired_And_Preserved_Units],0) AS TotalProductionNumber
	  ,[Rental_Homes_Portfolio_Owned] AS NumberOwned
	  ,[Rental_Homes_Portfolio_Managed_Not_Owned] AS NumberManaged
FROM [dbo].[fact_Comprehensive_Summary] C
JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
--WHERE D.fin_year = (SELECT MAX(fin_year) FROM dim_date)
GO
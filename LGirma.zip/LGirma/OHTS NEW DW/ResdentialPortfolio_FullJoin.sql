SELECT DISTINCT A.PCode,A.FiscalYearandQuarter,A.[Type Of Mortgage],A.NumberOfOutstandingLoans,A.AmountOfOutstandingLoans,A.[NumberOf 30 to 59 Days Delinqunet]
	   ,A.[AmountOf 30 to 59 Days Delinqunet],A.[NumberOf 60 to 89 Days Delinqunet],A.[AmountOf 60 to 89 Days Delinqunet],A.[NumberOf 90 + Days Delinqunet]
	   ,A.[AmountOf 90 + Days Delinqunet],A.[% of $ 90+ Delinquent],B.[Type Of Mortgage],B.NumberOfOutstandingLoans,B.AmountOfOutstandingLoans,B.[NumberOf 30 to 59 Days Delinqunet]
	   ,B.[AmountOf 30 to 59 Days Delinqunet],B.[NumberOf 60 to 89 Days Delinqunet],B.[AmountOf 60 to 89 Days Delinqunet],B.[NumberOf 90 + Days Delinqunet],B.[AmountOf 90 + Days Delinqunet]
	   ,B.[% of $ 90+ Delinquent]
FROM (
SELECT PCode
	  ,CAST(D.fin_year AS VARCHAR(4))+' '+'Q'+ RIGHT(CAST(fin_quarter AS VARCHAR(10)),1)  AS [FiscalYearandQuarter]
	  ,'First Mortgage' AS [Type Of Mortgage]
	  ,CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [NumberOfOutstandingLoans]
      ,CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [AmountOfOutstandingLoans]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [NumberOf 30 to 59 Days Delinqunet]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [AmountOf 30 to 59 Days Delinqunet]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [NumberOf 60 to 89 Days Delinqunet]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [AmountOf 60 to 89 Days Delinqunet]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [NumberOf 90 + Days Delinqunet]
	  ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [AmountOf 90 + Days Delinqunet]
	  ,CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [% of $ 90+ Delinquent]
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON R.dim_ReportingQuarter_key = D.dim_date_key  
WHERE PCODE IS NOT NULL
) A

FULL OUTER JOIN

(
SELECT PCode
	  ,CAST(D.fin_year AS VARCHAR(4))+' '+'Q'+ RIGHT(CAST(fin_quarter AS VARCHAR(10)),1)  AS [FiscalYearandQuarter]
	  ,'Subordinate Mortgage' AS [Type Of Mortgage]
      ,CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [NumberOfOutstandingLoans]
	  ,CONVERT(MONEY, [Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [AmountOfOutstandingLoans]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [NumberOf 30 to 59 Days Delinqunet]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [AmountOf 30 to 59 Days Delinqunet]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [NumberOf 60 to 89 Days Delinqunet]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [AmountOf 60 to 89 Days Delinqunet]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [NumberOf 90 + Days Delinqunet] 
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [AmountOf 90 + Days Delinqunet]
	  ,CONVERT(DECIMAL(4,3),[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [% of $ 90+ Delinquent]    
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON R.dim_ReportingQuarter_key = D.dim_date_key  
WHERE PCODE IS NOT NULL
)B
ON A.PCode = B.PCode AND A.FiscalYearandQuarter = B.FiscalYearandQuarter

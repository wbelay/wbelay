SELECT Organization_ID
      ,Organization_Name
      ,YEAR(GETDATE())-1 AS ReportingYear
      ,sum(ISNULL([Full_Time_Staff],0)) + sum(ISNULL([Part_Time_Staff],0)/2) AS Staff
FROM [DataWarehouse].[dbo].[dim_Organization] A
WHERE A.Organization_Type='NWO' and pcode =8355
GROUP BY Organization_ID
        ,Organization_Name

SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,CASE WHEN SUM( ISNULL(CAST(ISNULL(c.[Individual_Counseling_Hrs],0) AS float	),0.00)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_Online_By_Your_Organization],0)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_By_Your_Organization_In_Pers],0) 
				 +CAST(ISNULL([Ind_Couns_Hrs_And_Group_Edu_Hrs_Provided_By_Other_Organization],0.00) AS decimal(8,2))
				 +ISNULL(CAST(ISNULL(c.[Group_Counseling_Hrs],0) AS float),0.00))= 0 THEN '0 Hours' 
			WHEN SUM( ISNULL(CAST(ISNULL(c.[Individual_Counseling_Hrs],0) AS float	),0.00)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_Online_By_Your_Organization],0)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_By_Your_Organization_In_Pers],0) 
				 +CAST(ISNULL([Ind_Couns_Hrs_And_Group_Edu_Hrs_Provided_By_Other_Organization],0.00) AS decimal(8,2))
				 +ISNULL(CAST(ISNULL(c.[Group_Counseling_Hrs],0) AS float),0.00))BETWEEN 0.001 AND 3.99 THEN '> 0 and <4 Hours' 
			WHEN SUM( ISNULL(CAST(ISNULL(c.[Individual_Counseling_Hrs],0) AS float	),0.00)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_Online_By_Your_Organization],0)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_By_Your_Organization_In_Pers],0) 
				 +CAST(ISNULL([Ind_Couns_Hrs_And_Group_Edu_Hrs_Provided_By_Other_Organization],0.00) AS decimal(8,2))
				 +ISNULL(CAST(ISNULL(c.[Group_Counseling_Hrs],0) AS float),0.00))BETWEEN	4 AND 7.99 THEN '=>4 and <8 Hours' 
			WHEN SUM( ISNULL(CAST(ISNULL(c.[Individual_Counseling_Hrs],0) AS float	),0.00)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_Online_By_Your_Organization],0)
				 +ISNULL(c.[FY15_Group_Education_Hours_Provided_By_Your_Organization_In_Pers],0) 
				 +CAST(ISNULL([Ind_Couns_Hrs_And_Group_Edu_Hrs_Provided_By_Other_Organization],0.00) AS decimal(8,2))
				 +ISNULL(CAST(ISNULL(c.[Group_Counseling_Hrs],0) AS float),0.00))>=8 THEN '=>8 Hours' 
		 END AS [Hours]
		 ,COUNT([Client_ID]) AS [# Clients]
		INTO Temp
FROM [dbo].[stage_fact_Client_3] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key 
LEFT JOIN [dbo].[dim_Client] DC
ON C.dim_Client_key = DC.dim_Client_key
GROUP BY PCode
        ,D.fin_year
		
------
 SELECT *
 FROM (
 SELECT 
 T.pcode , T.FisicalYear,  T.[Hours], ISNULL(T.[# Clients],0) [# Clients]
 FROM Temp T	
 )P
 PIVOT
(

 SUM([# Clients])
 FOR [Hours] IN (
  [0 Hours]
 ,[> 0 and <4 Hours]
 ,[=>4 and <8 Hours]
 ,[=>8 Hours]  ) 
 )AS pvt
 -----
/* SELECT 
 T.pcode, T.FisicalYear
,ISNULL(T.[0 Hours] ,0) AS [0 Hours]
,ISNULL(T.[% 0 Hours],0.00) AS [% 0 Hours]
,ISNULL(T.[> 0 and <4 Hours] ,0) AS [> 0 and <4 Hours]
,ISNULL(T.[% > 0 and <4 Hours],0.00) AS [% > 0 and <4 Hours]
,ISNULL(T.[=>4 and <8 Hours] ,0) AS [=>4 and <8 Hours]
,ISNULL(T.[% =>4 and <8 Hours],0.00) AS [% =>4 and <8 Hours]
,ISNULL(T.[=>8 Hours],0) AS [=>8 Hours]
,ISNULL(T.[% =>8 Hours],0.0) AS [% =>8 Hours]
FROM (
 SELECT
  t.pcode, T.FisicalYear
 ,t.[0 Hours] 
 ,CASE 
 WHEN t.[0 Hours] IS NOT NULL THEN (
 CAST(t.[0 Hours] AS float	)/
 (ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
 ) END AS [% 0 Hours]
 ,t.[> 0 and <4 Hours]
 ,CASE 
 WHEN t.[> 0 and <4 Hours] IS NOT NULL THEN (
 CAST(t.[> 0 and <4 Hours] AS float	)/
 (ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
 ) END AS [% > 0 and <4 Hours]

 , t.[=>4 and <8 Hours]
 ,CASE 
   WHEN CAST(t.[=>4 and <8 Hours] AS float	) IS NOT NULL 
   THEN (CAST(t.[=>4 and <8 Hours]AS float	)/(ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0)))  END AS [% =>4 and <8 Hours]
 , t.[=>8 Hours]
 ,CASE 
 WHEN t.[=>8 Hours] IS NOT NULL THEN (
 CAST(t.[=>8 Hours] AS float	)/
 (ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
 ) END AS [% =>8 Hours]

 FROM Temp t
 )T
  */
  DROP TABLE Temp
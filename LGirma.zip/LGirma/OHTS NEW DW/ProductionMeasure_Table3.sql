SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,[Rental_Homes_Portfolio_Owned]
	  ,[Rental_Homes_Portfolio_Managed_Not_Owned]
FROM [DataWarehouse].[dbo].[agg_Comprehensive] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON C.dim_ReportingQuarter_key = D.dim_date_key
WHERE PCODE IS NOT NULL 
AND D.fin_quarter=(SELECT MAX(fin_quarter) FROM [dbo].[dim_date])





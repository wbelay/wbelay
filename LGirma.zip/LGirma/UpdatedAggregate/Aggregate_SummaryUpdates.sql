
--------------------SummaryUpdate_HARP--------------------------
SELECT *
FROM(SELECT a.PCODE
			,a.Division
			--,PCODE AS OrgID
	 FROM dbo.stgSummaryUpdates1 a)p

PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([FIELD],[OAD],[NI],[NHP],[NREP],[NFMC],[CapCorps])
)pvt

--------------------SummaryUpdate_PROMPTPORTAL--------------------------
SELECT *
FROM(SELECT a.PCODE
			,CASE WHEN a.DivisionID = 1 THEN 'FIELD'
				  WHEN a.DivisionID = 2 THEN 'OAD'
				  WHEN a.DivisionID = 3 THEN 'NI'
				  WHEN a.DivisionID = 4 THEN 'NFMC'
				  WHEN a.DivisionID = 5 THEN 'NHP'
				  WHEN a.DivisionID = 6 THEN 'NREP'
				  WHEN a.DivisionID = 7 THEN 'CapCorps' 
				 ELSE '' 
			 END AS DivisionID
			--,PCODE AS OrgID
	 FROM [PromptPortal].[dbo].[tblDivisionalSummaryAndUpdates] a)p

PIVOT
(
	COUNT(PCODE)
	FOR DivisionID IN
	([FIELD],[OAD],[NI],[NHP],[NREP],[NFMC],[CapCorps])
)pvt

------------Aggregate_MOU_HARP-----------------
SELECT *
FROM (SELECT a.PCODE
			,a.IsClosed
			 --,PCODE AS OrgID
			 
	   FROM dbo.stgMOU a)p
	   
PIVOT
(
	COUNT(PCODE)
	FOR ISClosed IN
	([0] ,[1]) 
) as pvt

------------Aggregate_MOU_PROMPTPORTAL-----------------

SELECT *
FROM (
	  SELECT a.[PCODE]
			,a.[IsClosed]
			--,PCODE as OrgID
	  FROM [PromptPortal].[dbo].[tblMOU] a
	  )p
	   
PIVOT
(
	COUNT(PCODE)
	FOR ISClosed IN
	([0] ,[1]) 
) as pvt
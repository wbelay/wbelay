------------------------------Aggregate_stgFindings_HARP--------------------------  
SELECT *
FROM(SELECT a.PCODE
			,a.FindingCategory
			--,PCODE AS OrgID
	 FROM dbo.stgFinding a)p
	 
PIVOT
(
COUNT(PCODE)
FOR FindingCategory IN
([P],[R],[O],[M],[T],[OMBG])
)pvt

------------------------------Aggregate_stgFindings_PROMPTPORTAL--------------------------  
SELECT *
FROM(SELECT a.PCODE
		   ,CASE
				 WHEN a.FindingCategoryID = 1 THEN 'P'
				 WHEN a.FindingCategoryID = 2 THEN 'R'
				 WHEN a.FindingCategoryID = 4 THEN 'M'
				 WHEN a.FindingCategoryID = 6 THEN 'T'
				 WHEN a.FindingCategoryID = 7 THEN 'OMBG'
			 ELSE ''
			END AS FindingCategoryID
			--,PCODE AS OrgID
	 FROM [PromptPortal].[dbo].[tblFindings] a)p
	 
PIVOT
(
	COUNT(PCODE)
	FOR FindingCategoryID IN
	([P],[R],[O],[M],[T],[OMBG])
)pvt
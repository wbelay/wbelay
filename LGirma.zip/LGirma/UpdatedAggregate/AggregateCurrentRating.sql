SELECT *
FROM (SELECT a.PCODE 
            ,a.FinalOHTSRecommendation
            ,PCODE as Org_ID
       FROM dbo.stgCurrentRatings a
       WHERE YEAR(a.MeetingDate) != '2050'
	  )P

PIVOT
(
	COUNT (PCODE)
	FOR FinalOHTSRecommendation IN
	([Provisional  Satisfactory], [Provisional  Strong],[Exemplary],[Satisfactory],[Strong],
	 [Provisional  Vulnerable],[Vulnerable],[NULL])
) AS pvt
-------------------------------------HARP-----------------------------------------
SELECT *
FROM
(
   SELECT a.PCODE 
	     ,CASE 
		     WHEN a.ReviewType='On-Site' THEN 'On-Site'
		     WHEN a.ReviewType='Off-Site' THEN 'Off-Site' 
		  END AS [ReviewType]
	     --,COUNT(PCODE) as ReviewCounts
	     ,pcode AS OrgID
  FROM [HARP].[dbo].[stgAssessment]as a
)p
PIVOT
(
	COUNT (PCODE)
	FOR ReviewType IN
	([On-Site], [Off-Site])
) AS pvt

-------------------------------------PROMPT PORTAL-----------------------------------------
SELECT *
FROM
(
   SELECT a.PCODE 
	     ,CASE 
		     WHEN a.ReviewType=1 THEN 'On-Site'
		     WHEN a.ReviewType=2 THEN 'Off-Site' 
		  END AS [ReviewType]
	     --,COUNT(PCODE) as ReviewCounts
	     ,pcode AS OrgID
  FROM [PromptPortal].[dbo].[tblAssessment]as a
)p
PIVOT
(
	COUNT (PCODE)
	FOR ReviewType IN
	([On-Site], [Off-Site])
) AS pvt
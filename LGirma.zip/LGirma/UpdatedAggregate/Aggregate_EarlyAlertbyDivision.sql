
---------------------------------Aggregate_stgEarlyAlert_HARP----------------------------
SELECT *
FROM (SELECT a.PCODE
		    ,a.Division
		    --,PCODE AS OrgID
	  FROM [HARP].[dbo].[stgEarlyAlerts] a)p
	  
PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([Field],[OAD],[CapCorps])
)pvt

---------------------------------Aggregate_tblEAROIssues_PROMPTPORTAL----------------------------
SELECT *
FROM (SELECT a.PCODE
		    ,CASE 
				 WHEN a.IssuedByDivisionID= 1 THEN 'Field'
				 WHEN a.IssuedByDivisionID= 2 THEN 'OAD'
				 ELSE 'CapCorps'
			 END AS Division
		     --,PCODE AS OrgID
	  FROM [PromptPortal].[dbo].[tblEAROIssues] a)p
	  
PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([Field],[OAD],[CapCorps])
)pvt
 

-------------AGGREGATE_RISKOBSERVED_HARP-----------------
SELECT *
FROM (SELECT a.PCODE
		    ,a.Division
		     --,PCODE AS OrgID
	  FROM dbo.stgRiskObserved a)p
	  
PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([FIELD],[OAD],[NI],[NFMC],[NREP],[NHP])
)pvt

-------------AGGREGATE_RISKOBSERVED_PROMPTPORTAL-----------------
SELECT *
FROM (SELECT a.PCODE
		    ,CASE WHEN a.IssuedByDivisionID = 1 THEN 'Field'
				   WHEN a.IssuedByDivisionID = 2 THEN 'OAD'
				   WHEN a.IssuedByDivisionID = 3 THEN 'NI'
				   WHEN a.IssuedByDivisionID = 4 THEN 'NFMC'
				   WHEN a.IssuedByDivisionID = 5 THEN 'NHP'
				   WHEN a.IssuedByDivisionID = 6 THEN 'NREP'
				   ELSE ''
			 END AS Division
		     --,PCODE AS OrgID
	  FROM [PromptPortal].[dbo].[tblRiskObserved] a)p
	  
PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([FIELD],[OAD],[NI],[NFMC],[NREP],[NHP])
)pvt
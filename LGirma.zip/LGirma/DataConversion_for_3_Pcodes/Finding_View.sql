create view [dbo].[StgFinding_import]
as 
select 

	[Pcode],
	[MeetingDate] , 
	[Assessmentdate] ,
	cast ([FindingGroup] as [nvarchar](100)) as  [FindingGroup],
	cast ([FindingCategory] as [nvarchar](100)) as FindingCategory,
	cast ([FindingType] as [nvarchar](100)) as FindingType,
	[FindingDate] ,
	cast ([FindingDescription] as [nvarchar](100)) as FindingDescription,
	cast ([OADRecommendation] as [nvarchar](100)) as OADRecommendation,
	cast ([FieldRecommendation]as [nvarchar](100)) as FieldRecommendation,
	cast ([Isclosed] as [nvarchar](100)) as Isclosed,
	cast ([CreatedBy] as [nvarchar](100)) as CreatedBy,
	[CreatedDate] ,
	cast ([ModifiedBy] as [nvarchar](100)) as ModifiedBy,
	[ModifiedDate] ,
	cast ([TaskDescription] as [nvarchar](100)) as TaskDescription,
	cast ([TaskCompleted] as [nvarchar](100)) as TaskCompleted,
	cast ([OADResolutionComments] as [nvarchar](100)) as OADResolutionComments,
	cast ([FieldResolutionComments] as [nvarchar](100)) as FieldResolutionComments

from [dbo].[StgFinding_3_pcodes]
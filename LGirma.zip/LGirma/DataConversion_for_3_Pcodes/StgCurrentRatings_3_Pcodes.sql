--SELECT * INTO StgCurrentRating__3_Pcodes
--FROM(
SELECT DISTINCT M.PCODE AS PCODE
      ,r.CurrentRatingText AS FinalOHTSRecommendation 
      ,A.MeetingDate
      ,CASE WHEN r.WatchFlag = 'N' THEN NULL
		    WHEN r.WatchFlag = 'Y' AND r.OnWatchListSinceDate IS NULL THEN r.MeetingDate
		    ELSE r.OnWatchListSinceDate END AS WatchListStartDate
      ,r.ProvisionalCharterFlag AS ProvisionalCharterStatus 
      ,CASE WHEN r.ProvisionalCharterFlag = 'N' THEN NULL
			WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NOT NULL THEN r.ProvisionalStartDate 
			WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate < r.MeetingDate THEN P.MinProvisionalStartDate
            WHEN r.ProvisionalCharterFlag = 'Y' AND (r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate IS NULL AND P.MaxProvisionalStartDate< r.MeetingDate) THEN P.MaxProvisionalStartDate
            ELSE r.MeetingDate END AS ProvisionCharterStatusDate
FROM tblOHTSMeeting M
INNER JOIN tblRating r 
ON M.PCODE=R.PCODE AND M.MeetingDate=R.MeetingDate
INNER JOIN dbo.StgAssessment_MeetingDate_3_Pcodes A
ON M.PCODE = A.PCODE AND M.MeetingDate = A.MeetingDate
LEFT JOIN dbo.view_ProvisionalStartDate P
ON P.PCODE = r.PCODE
WHERE YEAR(r.MeetingDate)>2009
	  AND r.PCODE IN(SELECT [PCODE] FROM [HARP].[dbo].[tblOHTSMeeting] 
                   WHERE meetingdate='2017-03-09' and pcode IN (8069,8288,8388))
GROUP BY M.PCODE, r.CurrentRatingText, R.MeetingDate, A.MeetingDate, r.WatchFlag, r.OnWatchListSinceDate, r.ProvisionalCharterFlag, r.ProvisionalStartDate, P.MinProvisionalStartDate, P.MaxProvisionalStartDate
--) AS N
 





      
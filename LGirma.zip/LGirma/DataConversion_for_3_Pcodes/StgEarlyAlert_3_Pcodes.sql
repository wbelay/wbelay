--SELECT * INTO StgEarlyAlert_3_Pcodes
--FROM
--(
SELECT   /*SQL code to produce conversion file Early Alerts*/
       DISTINCT [PCODE]
      ,CASE WHEN CONVERT(VARCHAR(20),MeetingDate,101) = '01/01/2050' AND PCODE= 8487 THEN '12/16/2015'--we update the date'12/14/2015' to '12/16/2015'
       ELSE CONVERT(VARCHAR(20),MeetingDate,101)END AS MeetingDate
	  ,[dbo].[udf_StripHTML](IssueIdentified) AS [IssueIdentifiedDesc]
      ,[IssuedBy] AS [Division]
      ,[LastUpdate] AS [LastUpdateDesc]
      ,'' AS [ResolvedWhenDesc]
      ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed]--to be used as flag for reporting
      ,[CreatedBy]
      ,[CreatedDate]
      ,[ModifiedBy]
      ,[ModifiedDate]
FROM [HARP].[dbo].[tblEAROIssues]
WHERE [Type]='Early Alert'
	  AND PCODE IN(SELECT [PCODE] FROM [HARP].[dbo].[tblOHTSMeeting] 
                   WHERE meetingdate='2017-03-09' and pcode IN (8069,8288,8388))
--) AS N
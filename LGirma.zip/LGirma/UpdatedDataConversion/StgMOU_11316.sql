--SELECT * INTO StgMOU
--FROM 
--(
SELECT a.[PCODE]
      ,a.[MOUStartDate]
      ,a.[MOUExpirationDate]
      ,REPLACE([dbo].[udf_StripHTML]([MOUDescription]),'CHAR(13) + CHAR(10)','')AS [MOUDescription]
      ,[dbo].[udf_StripHTML]([MOUTopic])AS [MOUTopic]
      ,'' AS CreatedBy
      ,'' AS CreatedDate
      ,'' AS ModifiedBy
      ,'' AS ModifiedDate
      ,dbo.fn_BooleanToYN(a.MOUCreated) AS IsClosed  --- flag showing MoU closed or not
  FROM [HARP].[dbo].[tblMOU] as a
  WHERE YEAR(MOUStartDate)>=2009
		AND PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8046,8040,8255,8011,8231,8379,8411,8494,8044)--25 Test Pcodes  
--) AS N
	
	
	

	

	
	
	

SELECT OS.PCODE
         ,CONVERT(VARCHAR(10),MAX(AssessmentDate),101) AS AssessmentDate
         ,CASE WHEN MeetingDate IS NULL THEN (/*Replace NULL Meetingdate with known meetingdate from tblratingdetail*/
         SELECT CONVERT(VARCHAR(10),MAX(MEETINGDATE),101)
	     FROM tblRatingDetail r
		 JOIN StgAssessment a
		 ON r.PCODE = a.PCODE
		 where  MeetingDate>GETDATE() and year(MeetingDate)<2050/*TO ILLUMINATE 2050 DATE*/ AND MeetingDate>AssessmentDate) ELSE CONVERT(VARCHAR(10),MeetingDate,101) END AS MeetingDate
         ,'SwitchBoardImport' AS CreatedBy
         ,CONVERT(VARCHAR(10),GETDATE(),101) AS CreatedDate 
  FROM dbo.StgAssessment OS
LEFT OUTER JOIN [dbo].[tblOHTSMeeting] r--JOIN TO GET MEETINGDATE
ON r.PCODE = OS.PCODE AND OS.AssessmentDate<R.MeetingDate
WHERE OS.PCODE IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)--15 TEST PCODES
	  
GROUP BY OS.PCODE,MeetingDate
ORDER BY PCODE, MeetingDate  Desc




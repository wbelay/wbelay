WITH CTE 
AS(
	SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		   ,CASE				
			    WHEN FieldRating IS NOT NULL OR FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
			END AS Division		   
		   ,CASE 				
				WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
			END AS RatingRecommendation		    
		   ,CASE 				
			     WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			 END AS WatchListRecommendation		   
			,ModifiedBy		   
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  	                       
	UNION
	                       
	  SELECT R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				 WHEN OADRating IS NOT NULL OR OADWatchRecommendation IS NOT NULL THEN 'OAD' 
			 END AS Division
		    ,CASE 
				  WHEN 'OADRating' IS NOT NULL THEN OADRating
			  END AS RatingRecommendation
			 ,CASE 
				  WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
			  END AS WatchListRecommendation
			 ,ModifiedBy
			 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	   FROM dbo.tblRatingDetail R
	   
	UNION
					
	    SELECT R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				   WHEN NIRating IS NOT NULL OR NIWatchRecommendation IS NOT NULL THEN 'NI' 
			   END AS Division
			  ,CASE 
				   WHEN 'NIRating' IS NOT NULL THEN NIRating
			   END AS RatingRecommendation
			  ,CASE 
				   WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			   END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
							
	UNION
					
	    SELECT R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				   WHEN NFMCRating IS NOT NULL OR NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			   END AS Division
			  ,CASE 
				   WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
				END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		 FROM dbo.tblRatingDetail R
		 
	UNION

		SELECT R.PCODE
			   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	   ,CASE 
				   WHEN NHPRating IS NOT NULL OR NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			   END AS Division
			   ,CASE 
				   WHEN 'NHPRating' IS NOT NULL THEN NHPRating
			   END AS RatingRecommendation
			   ,CASE 
				   WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			   END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		
	UNION

		SELECT  R.PCODE
			   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN NREPRating IS NOT NULL OR NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
				END AS Division
			   ,CASE 
					WHEN 'NREPRating' IS NOT NULL THEN NREPRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
				END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
	)
--SELECT * INTO StgDivisionRatings
--FROM(
SELECT A.PCODE
	  ,A.MeetingDate
	  ,CTE.Division
	  ,CTE.RatingRecommendation
	  ,CTE.WatchListRecommendation
	  ,CTE.ModifiedBy
	  ,CTE.ModifiedDate
FROM dbo.StgAssessment_MeetingDate A 
LEFT JOIN  CTE
ON A.PCODE=CTE.PCODE AND A.Meetingdate = CTE.MeetingDate 
WHERE RatingRecommendation IS NOT NULL AND RatingRecommendation!=''
AND A.PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8046,8040,8255,8011,8231,8379,8411,8494,8044)--25 Test Pcodes  
--ORDER BY MeetingDate DESC
--)N
			
			 
			 
			 
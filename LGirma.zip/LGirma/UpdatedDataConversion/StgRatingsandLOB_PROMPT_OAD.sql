WITH CTE
AS 
(
	SELECT  os.PCODE
			,os.ReviewDate
			,os.ProductionProgramServicesText AS PROMPTRating_P
			,os.ResourceManagementText AS PROMPTRating_R
			,os.OrganizationalManagementText AS PROMPTRating_O
			,os.PersonnelManagementText AS PROMPTRating_M
			,os.PlanningText AS PROMPTRating_PM
			,os.TechnicalOperationsSystemsText AS PROMPTRating_T 
			,orv.HomeownershipPreservationFlag 
			,orv.HomeownershipPromotionServicesFlag 
			,orv.CommunityBuildingandOrganizingFlag 
			,orv.AssetAndPropertyManagementFlag
			,orv.RealEstateDevelopmentFlag 
			,orv.LendingandPortfolioManagementFlag 
			,orv.OtherServicesFlag 
	FROM dbo.tblOnSiteRatings OS
	LEFT OUTER JOIN [tblOnSiteReviewLineOfBusiness] ORV
	ON OS.PCODE = ORV.PCODE
	   AND OS.ReviewDate = ORV.ReviewDate
			 
UNION ALL 
			  
	  SELECT [PCODE]
             ,CAST([Month] AS varchar(12)) + '/' + '1' + '/' + CAST(FYear as varchar(6)) AS ReviewDate
			 ,CASE WHEN ProdRate=1 THEN 'Exceed'
				   WHEN ProdRate=3 THEN 'Meet' 
				   WHEN ProdRate=5 THEN 'Fail' END AS PROMPTRating_P
			 ,CASE WHEN ResRate=1 THEN 'Exceed'
				   WHEN ResRate=3 THEN 'Meet' 
				   WHEN ResRate=5 THEN 'Fail' END AS  PROMPTRating_R
		    ,CASE WHEN OMRate=1 THEN 'Exceed'
				  WHEN OMRate=3 THEN 'Meet' 
				  WHEN OMRate=5 THEN 'Fail' END AS PROMPTRating_O
			,'' AS PROMPTRating_M
			,'' AS PROMPTRating_PM
			,'' AS PROMPTRating_T
			,dbo.fn_BooleanToYN(RE_Off) AS HomeonwhershipPreservationFlag
			,dbo.fn_BooleanToYN(HOME_Off) AS HomeownerhipPormotionServicesFlag
			,dbo.fn_BooleanToYN(CBE_Off) AS CommunityBuildingandOrganizingFlag
			,dbo.fn_BooleanToYN(PM_Off)AS AssetAndPropertyManagementFlag
			,dbo.fn_BooleanToYN(RED_Off)AS RealEstateDevelomentFlag
			,dbo.fn_BooleanToYN(LEND_Off)AS LendingandPortfolioManagementFlag
			,'' AS OtherServicesFlag
	 FROM [HARP].[dbo].[RiskFactorOAD]
			 
)
		   
,CTE2 AS
	(
	    SELECT  A.PCODE
			   ,A.Reviewdate AS AssessmentDate
			   ,CTE.PROMPTRating_P as PROMPTRating_P
			   ,CTE.PROMPTRating_R as PROMPTRating_R
			   ,CTE.PROMPTRating_O  AS PROMPTRating_O
			   ,CTE.PROMPTRating_PM  AS PROMPTRating_PM
			   ,CTE.PROMPTRating_M as PROMPTRating_M 
			   ,CTE.PROMPTRating_T  AS PROMPTRating_T 
			  		  				
			FROM dbo.StgAssessment A  
			LEFT JOIN CTE 
			ON A.PCODE=CTE.PCODE 			  
		   )

SELECT  DISTINCT CTE2.PCODE
	  ,CTE2.ASSESSMENTDATE
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_P ELSE '' END AS PROMPTRating_P
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_R ELSE '' END AS PROMPTRating_R
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_O ELSE '' END AS PROMPTRating_O
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_PM ELSE '' END AS PROMPTRating_PM
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_M ELSE '' END AS PROMPTRating_M 
	  ,CASE WHEN L.Division='OAD' THEN CTE.PROMPTRating_T ELSE '' END AS PROMPTRating_T 
	  ,CASE WHEN L.Division = 'OAD'THEN HomeownershipPreservationFlag END AS HomeOwnershipPreservationServices
      ,CASE WHEN L.Division = 'OAD'THEN HomeownershipPromotionServicesFlag END AS HomeOwnershipPromotion
      ,CASE WHEN L.Division = 'OAD'THEN CommunityBuildingandOrganizingFlag END AS CommunityBuildingandEngagement
      ,CASE WHEN L.Division = 'OAD'THEN AssetAndPropertyManagementFlag END AS PropertyManagement
      ,CASE WHEN L.Division = 'OAD'THEN RealEstateDevelopmentFlag END AS RealEstateDevelopment
      ,CASE WHEN L.Division = 'OAD'THEN LendingandPortfolioManagementFlag END AS LendingandLoanPortfolio 
      ,CASE WHEN L.Division = 'OAD'THEN OtherServicesFlag ELSE '' END AS OtherServices
      
FROM cte2 
LEFT JOIN cte
ON cte2.PCODE=cte.PCODE and cte2.AssessmentDate=CTE.ReviewDate
LEFT JOIN StgRatingsandLOB_Division L
ON CTE2.PCODE= L.PCODE
WHERE 
	   AssessmentDate<= GETDATE()
	   AND CTE2.PCODE IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
	   AND (CTE.PROMPTRating_P IS NOT NULL AND CTE.PROMPTRating_R IS NOT NULL AND CTE.PROMPTRating_O IS NOT NULL AND
	       CTE.PROMPTRating_PM IS NOT NULL AND CTE.PROMPTRating_M IS NOT NULL AND CTE.PROMPTRating_T IS NOT NULL) 
ORDER BY 1,2 DESC
  


  
  
  
  
  
 
 

--SELECT * INTO stgRiskObserved
--FROM
--(
 SELECT [PCODE]
	   ,CONVERT(VARCHAR(20),MeetingDate,101) AS MeetingDate
	   ,'' AS [RiskCategory]
	   ,'' AS [RiskType]
	   ,[dbo].[udf_StripHTML](IssueIdentified) AS [RiskIdentifiedDesc]
       ,[IssuedBy] AS [Division]
       ,[LastUpdate] AS [LastUpdateDesc]
       ,''AS [ResolvedWhenDesc]
       ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed] --to be used as flag for reporting
       ,[CreatedBy]
       ,[CreatedDate]
       ,[ModifiedBy]
       ,[ModifiedDate]
  FROM [HARP].[dbo].[tblEAROIssues]
  WHERE [Type]='Risk Observed'
	and PCODE  IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
--)
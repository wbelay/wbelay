WITH CTE
AS
(
SELECT PCODE 
	  ,CAST(ReviewDate AS DATE) AS ReviewDate
	  ,ReviewType
	  ,Leader AS AssignedTo
	  ,'' AS RN
FROM OnOffSiteReviews
WHERE ReviewDate<= GETDATE()
	  AND YEAR(ReviewDate)>=2009
	  AND ReviewType = 'On-Site' 

UNION ALL

SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,MAX(rd.OADReviewerName) AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar),r.ReviewPROFlag ORDER BY OFS.PCODE)RN
FROM dbo.tblOffSiteRating OFS
LEFT JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	  CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND  r.ReviewPROFlag = 'Y'
	  AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=GETDATE()
GROUP BY OFS.PCODE,OFS.FiscalMonth,OFS.FiscalYearYear,R.ReviewPROFlag
)
--SELECT * INTO StgAssessment
--FROM(
SELECT PCODE
	  ,ReviewDate As AssessmentDate
	  ,ReviewType
	  ,AssignedTo
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate
FROM CTE
WHERE PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8255,8011)  
	  OR (PCODE = 8040 AND ReviewDate != '1/4/2016') OR (PCODE = 8046 AND ReviewDate != '6/20/2016') 
--ORDER BY AssessmentDate DESC
--) AS N

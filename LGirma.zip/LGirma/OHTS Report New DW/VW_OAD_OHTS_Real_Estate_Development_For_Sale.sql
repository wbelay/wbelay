/*SQL code to produce RealEstateDevelopmentForSale graph on OHTS report
We use fact_Real_Estate_Development, dim_Organization, dim_Date and fact_Inventory_Of_For_Sale_Units tables*/
--=============================================================================
--CREATE VIEW [dbo].[VW_OAD_OHTS_RealEstateDevelopmentForSale]
--AS
SELECT DISTINCT 
 ISNULL(A.pcode , B.pcode) AS PCODE
,ISNULL(A.FisicalYear , B.FisicalYear) AS FiscalYear
,ISNULL(A.FisicalYearQuarter , B.FisicalYearQuarter) AS FiscalYearQuarter
,ISNULL(A.NumberOfUnitsForSale,0) AS [For-Sale Homes Developed]
,ISNULL(B.NumberOfUnitsHeld,0) AS [Units Held in Portfilio at End of Quarter]
FROM
(
--To reterive information about numberofUnitsForSale
SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalYearQuarter 
	  ,SUM(Total_Units) AS NumberOfUnitsForSale
FROM [dbo].[fact_Real_Estate_Development] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON R.dim_ReportingQuarter_key = D.dim_date_key
GROUP BY PCode, D.fin_year, D.fin_quarter

)A
FULL OUTER JOIN 
(
--To reterive information about Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter
SELECT PCode
      ,D.fin_year AS FisicalYear
	  ,D.fin_quarter AS FisicalYearQuarter 
	  ,SUM([Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter]) AS NumberOfUnitsHeld
FROM[dbo].[fact_Inventory_Of_For_Sale_Units] A
LEFT JOIN [dbo].[dim_Organization] O
ON A.dim_Organization_key = O.dim_Organization_key
LEFT JOIN [dbo].[dim_date] D
ON A.dim_ReportingQuarter_key = D.dim_date_key
GROUP BY PCode, D.fin_year, D.fin_quarter
)B
ON A.pcode = B.pcode AND A.FisIcalYear = B.FisIcalYear AND A.FisicalYearQuarter = B.FisicalYearQuarter
WHERE A.PCODE IS NOT NULL OR B.PCODE IS NOT NULL
ORDER BY PCODE ASC


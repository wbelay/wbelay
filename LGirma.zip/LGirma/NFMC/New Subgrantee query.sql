USE [NFMC_EHLP_Contact_DB_06062019]
GO
/****** Object:  StoredProcedure [dbo].[GetAllSubGranteeContact]    Script Date: 07/21/2016 10:59:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [dbo].[GetAllSubGranteeContact]
--@Pcode VARCHAR(50),
@Round VARCHAR(20),
@Organization VARCHAR(MAX)
--@OrganizationType VARCHAR(MAX)
AS 
BEGIN
SELECT X.Pcode
,X.OrgName
, X.RoundID
, X.Round 
, X.GranteeID
, GranteeType
,  x.SubgranteeOrganization
, x.GranteeOrganization
,  OrganizationType
,  X.City
, X.[Address]
,  X.[State]
,  X.ZipCode
, X.FirstName
, X.LastName
, X.Email
, X.IsActive
FROM (
SELECT Grantee.Pcode
,g.OrgName
, R.RoundID
, R.Description AS Round 
, Grantee.GranteeID
, GT.[Description] as GranteeType
, CASE WHEN GT.GranteeTypeID = 2 THEN Grantee.OrgName END AS SubgranteeOrganization
,CASE WHEN GT.GranteeTypeID = 1 THEN Grantee.OrgName END AS GranteeOrganization
, OT.[Description] as OrganizationType
,Grantee.[Address]
,  Grantee.City
,  Grantee.[State]
,  Grantee.ZipCode
, uc.FirstName
, uc.LastName
, uc.Email
, Grantee.IsActive
FROM Grantee
FULL JOIN GranteeType GT
ON GT.GranteeTypeID = Grantee.GranteeTypeID 
FULL JOIN OrgType OT
ON OT.OrgTypeID = Grantee.OrgTypeID
LEFT JOIN UserContact UC
ON Grantee.GranteeID = UC.GranteeID
LEFT JOIN 
NFMCRounds R
ON R.RoundID = Grantee.RoundID 
left JOIN dbo.GranteeSubgrantee S
ON S.GranteeID = Grantee.GranteeID
left join Grantee g
on s.GranteeID = g.GranteeID
--WHERE GT.GranteeTypeID = 2
)X 
WHERE 
 X.RoundID in (select(Param)from dbo.FN_NFMCPARAM(@Round,','))
--AND CAST(Grantee.PCODE AS VARCHAR(MAX)) IN (select (Param)from dbo.FN_NFMCPARAM(@Pcode,','))
AND CAST(X.GranteeOrganization AS VARCHAR(MAX)) IN (select (Param)from dbo.FN_NFMCPARAM(@Organization,','))
--AND CAST(Grantee.[OrgTypeID] AS VARCHAR(MAX)) IN (select (Param)from dbo.FN_NFMCPARAM(@OrganizationType,','))
END

 
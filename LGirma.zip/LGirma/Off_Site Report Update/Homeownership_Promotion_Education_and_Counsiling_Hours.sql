--Homeownership Promotion Report
---1.Homeownership Customers: Education and Counseling Hours

SELECT 
X.ReportingYear, X.pcode, X.Hours
,COUNT(X.[# Clients]) AS [# Clients]
INTO #Temp
FROM (

SELECT

  c.ReportingYear
  ,c.ReportingQuarter
  ,c.pcode
,SUM( 

ISNULL(CAST(isnull(nullif(c.[Individual Counseling Hrs]     ,'(Not applicable)'),0) AS float ),0.00)
+ ISNULL(CAST(isnull(nullif(c.[Group Counseling Hrs],'(Not applicable)'),0) AS float),0.00)
+ ISNULL(c.[FY15 Group Education Hours Provided Online by your Organization] ,0)
  + CAST(ISNULL(NULLIF([Individual Counseling Hours and Group Education Hours Provided by the Other Organization],'(Not applicable)'),0.00) AS decimal(8,2))
+  ISNULL(c.[FY15 Group Education Hours Provided by your Organization in person via a classroom setting],0) 
) TotalHrs
,CASE 
      WHEN SUM( ISNULL(CAST(isnull(nullif(c.[Individual Counseling Hrs] ,'(Not applicable)'),0) AS float     ),0.00)
      + ISNULL(c.[FY15 Group Education Hours Provided Online by your Organization] ,0)
+  ISNULL(c.[FY15 Group Education Hours Provided by your Organization in person via a classroom setting],0) 
 + CAST(ISNULL(NULLIF([Individual Counseling Hours and Group Education Hours Provided by the Other Organization],'(Not applicable)'),0.00) AS decimal(8,2))
+ ISNULL(CAST(isnull(nullif(c.[Group Counseling Hrs],'(Not applicable)'),0) AS float),0.00))= 0 THEN '0 Hours' 

      WHEN SUM( ISNULL(CAST(isnull(nullif(c.[Individual Counseling Hrs] ,'(Not applicable)'),0) AS float     ),0.00)
      + ISNULL(c.[FY15 Group Education Hours Provided Online by your Organization] ,0)
+  ISNULL(c.[FY15 Group Education Hours Provided by your Organization in person via a classroom setting],0) 
 + CAST(ISNULL(NULLIF([Individual Counseling Hours and Group Education Hours Provided by the Other Organization],'(Not applicable)'),0.00) AS decimal(8,2))
+ ISNULL(CAST(isnull(nullif(c.[Group Counseling Hrs],'(Not applicable)'),0) AS float),0.00)) BETWEEN 0.001 AND 3.99 THEN '> 0 and <4 Hours' 

      WHEN SUM( ISNULL(CAST(isnull(nullif(c.[Individual Counseling Hrs] ,'(Not applicable)'),0) AS float     ),0.00)
      + ISNULL(c.[FY15 Group Education Hours Provided Online by your Organization] ,0)
+  ISNULL(c.[FY15 Group Education Hours Provided by your Organization in person via a classroom setting],0) 
 + CAST(ISNULL(NULLIF([Individual Counseling Hours and Group Education Hours Provided by the Other Organization],'(Not applicable)'),0.00) AS decimal(8,2))
+ ISNULL(CAST(isnull(nullif(c.[Group Counseling Hrs],'(Not applicable)'),0) AS float),0.00)) BETWEEN   4 AND 7.99 THEN '=>4 and <8 Hours' 

      WHEN SUM( ISNULL(CAST(isnull(nullif(c.[Individual Counseling Hrs] ,'(Not applicable)'),0) AS float     ),0.00)
      + ISNULL(c.[FY15 Group Education Hours Provided Online by your Organization] ,0)
+  ISNULL(c.[FY15 Group Education Hours Provided by your Organization in person via a classroom setting],0) 
 + CAST(ISNULL(NULLIF([Individual Counseling Hours and Group Education Hours Provided by the Other Organization],'(Not applicable)'),0.00) AS decimal(8,2))
+ ISNULL(CAST(isnull(nullif(c.[Group Counseling Hrs],'(Not applicable)'),0) AS float),0.00)) >=8 THEN '=>8 Hours' END AS [Hours]

,(c.[Client ID]) AS [# Clients]


FROM (
SELECT * 
FROM  QUARTERLY.[ClientsandFinancing].[Dim_Client] c
WHERE C.ReportingYear<>2016 AND 
c.[NWO Role]      IN (
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Counselor Only Resulting in Ownership for New Home Owner'
,'Counselor and Broker/Lender Resulting in Ownership for New Home Owner'
,'Broker/Lender Resulting in Ownership for New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
)
UNION ALL 
SELECT * 
FROM  QUARTERLY.[ClientsandFinancing].[Dim_Client] c
WHERE C.ReportingYear=2016 AND 
c.[NWO Role]      IN (
'NWO Constructs New Unit for New Home Owner'
,'NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner'
,'Directly provides Self-Help Housing for New Home Owner'
,'Plays Intermediary role in providing Self-Help Housing for New Home Owner'
,'Counselor and/or Broker/Lender ONLY for New Home Owner'
)
)C
GROUP BY   c.ReportingYear ,c.ReportingQuarter ,c.pcode, [Client ID]
)X
GROUP BY X.ReportingYear, X.ReportingQuarter, X.pcode, X.Hours


SELECT *
INTO #Temp2
FROM (
SELECT 
 G.pcode , G.ReportingYear,  G.[Hours], ISNULL(G.[# Clients],0) [# Clients]
FROM dbo.#Temp G 
)P
PIVOT
(

SUM([# Clients])
FOR [Hours] IN (
  [0 Hours]
,[> 0 and <4 Hours]
,[=>4 and <8 Hours]
,[=>8 Hours]  ) 
 )AS pvt

SELECT 
 T.pcode, T.ReportingYear
,ISNULL(T.[0 Hours] ,0) AS [0 Hours]
,ISNULL(T.[% 0 Hours],0.00) AS [% 0 Hours]
,ISNULL(T.[> 0 and <4 Hours] ,0) AS [> 0 and <4 Hours]
,ISNULL(T.[% > 0 and <4 Hours],0.00) AS [% > 0 and <4 Hours]
,ISNULL(T.[=>4 and <8 Hours] ,0) AS [=>4 and <8 Hours]
,ISNULL(T.[% =>4 and <8 Hours],0.00) AS [% =>4 and <8 Hours]
,ISNULL(T.[=>8 Hours],0) AS [=>8 Hours]
,ISNULL(T.[% =>8 Hours],0.0) AS [% =>8 Hours]
FROM (
SELECT
  t.pcode, t.ReportingYear
,t.[0 Hours] 
 ,CASE 
 WHEN t.[0 Hours] IS NOT NULL THEN (
CAST(t.[0 Hours] AS float    )/
(ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
) END AS [% 0 Hours]
,t.[> 0 and <4 Hours]
,CASE 
 WHEN t.[> 0 and <4 Hours] IS NOT NULL THEN (
CAST(t.[> 0 and <4 Hours] AS float )/
(ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
) END AS [% > 0 and <4 Hours]

, t.[=>4 and <8 Hours]
,CASE 
   WHEN CAST(t.[=>4 and <8 Hours] AS float      ) IS NOT NULL 
   THEN (CAST(t.[=>4 and <8 Hours]AS float      )/(ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0)))  END AS [% =>4 and <8 Hours]
, t.[=>8 Hours]
,CASE 
 WHEN t.[=>8 Hours] IS NOT NULL THEN (
CAST(t.[=>8 Hours] AS float  )/
(ISNULL(t.[0 Hours],0)+ ISNULL(t.[> 0 and <4 Hours],0)+ ISNULL(t.[=>4 and <8 Hours],0)+ ISNULL(t.[=>8 Hours],0))
) END AS [% =>8 Hours]

FROM dbo.#Temp2 t
)T
  
WHERE T.ReportingYear = ( 
SELECT   MAX(ReportingYear) AS ReportingYear
from [QUARTERLY].[ProjectsandSummary].[Dim_Time]
)

DROP TABLE dbo.#Temp    
DROP TABLE dbo.#Temp2

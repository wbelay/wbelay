SELECT 
       [PCode]
      ,[ReportingYear]
      ,[ReportingQuarter]
      ,ISNULL ( [Counselor Only Resulting in Ownership for New Home Owner Investment], 0) AS [Counselor Only Resulting in Ownership for New Home Owner Investment]
      ,ISNULL ( [Counselor Only Resulting in Ownership for New Home Owner Units], 0) AS [Counselor Only Resulting in Ownership for New Home Owner Units]
      ,ISNULL ( [Counselor Only Resulting in Ownership for New Home Owner Client], 0) AS [Counselor Only Resulting in Ownership for New Home Owner Clients]
      ,ISNULL ( [Counselor Only Resulting in Ownership for New Home Owner REO Units], 0) AS [Counselor Only Resulting in Ownership for New Home Owner REO Units]
      ,ISNULL ( [NWO Constructs New Unit for New Home Owner Investment], 0) AS [NWO Constructs New Unit for New Home Owner Investment]
      ,ISNULL ( [NWO Constructs New Unit for New Home Owner Units], 0) AS [NWO Constructs New Unit for New Home Owner Units]
      ,ISNULL ( [NWO Constructs New Unit for New Home Owner Client], 0) AS [NWO Constructs New Unit for New Home Owner Clients ]
      ,ISNULL ( [NWO Constructs New Unit for New Home Owner REO Units], 0) AS [NWO Constructs New Unit for New Home Owner REO Units]
      ,ISNULL ( T.[NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Investment], 0) AS [NWO Sells a Unit it Had Purchased to New Home Owner Investment]
      ,ISNULL ( T.[NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Units], 0) AS [NWO Sells a Unit it Had Purchased to New Home Owner Units]
      ,ISNULL ( T.[NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Client], 0) AS [NWO Sells a Unit it Had Purchased to New Home Owner Clients]
      ,ISNULL ( T.[NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner REO Units], 0) AS [NWO Sells a Unit it Had Purchased to New Home Owner REO Units]
      ,ISNULL ( [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Investment], 0) AS [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Investment]
      ,ISNULL ( [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Units], 0) AS [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Units]
      ,ISNULL ( [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Client], 0) AS [Counselor and Broker/Lender Resulting in Ownership for New Home Owner Clients]
      ,ISNULL ( [Counselor and Broker/Lender Resulting in Ownership for New Home Owner REO Units], 0) AS [Counselor and Broker/Lender Resulting in Ownership for New Home Owner REO Units]
      ,ISNULL ( [Broker/Lender Resulting in Ownership for New Home Owner Investment], 0) AS [Broker/Lender Resulting in Ownership for New Home Owner Investment]
      ,ISNULL ( [Broker/Lender Resulting in Ownership for New Home Owner Units], 0) AS [Broker/Lender Resulting in Ownership for New Home Owner Units]
      ,ISNULL ( [Broker/Lender Resulting in Ownership for New Home Owner Client], 0) AS [Broker/Lender Resulting in Ownership for New Home Owner Clients]
      ,ISNULL ( [Broker/Lender Resulting in Ownership for New Home Owner REO Units], 0) AS [Broker/Lender Resulting in Ownership for New Home Owner REO Units]
      ,ISNULL ( [Owner Occupied Rehab Investment], 0) AS [Owner Occupied Rehab Investment]
      ,ISNULL ( [Owner Occupied Rehab Units], 0) AS [Owner Occupied Rehab Units]
      ,ISNULL ( [Owner Occupied Rehab Client], 0) AS [Owner Occupied Rehab Clients]
      ,ISNULL ( [Refinance not foreclosure Investment], 0) AS [Refinance not foreclosure Investment]
      ,ISNULL ( [Refinance not foreclosure Units], 0) AS [Refinance not foreclosure Units]
      ,ISNULL ( [Refinance not foreclosure Client], 0) AS [Refinance not foreclosure Clients]
      ,ISNULL ( [Reverse mortgage Investment], 0) AS [Reverse mortgage Investment]
      ,ISNULL ( [Reverse mortgage Units], 0) AS [Reverse mortgage Units]
      ,ISNULL ( [Reverse mortgage Client], 0) AS [Reverse mortgage Clients]
      ,ISNULL ( [Foreclosure Mitigation Counseling Investment], 0) AS [Foreclosure Mitigation Counseling Investment]
      ,ISNULL ( [Foreclosure Mitigation Counseling Units], 0) AS [Foreclosure Mitigation Counseling Units]
      ,ISNULL ( T.[Foreclosure Mitigation Counseling Client], 0) AS [Foreclosure Mitigation Counseling Clients]
      ,ISNULL (T.[Directly provides Self-Help Housing for New Home Owner Units], 0) AS [Directly provides Self-Help Housing for New Home Owner Units]
      ,ISNULL (T.[Directly provides Self-Help Housing for New Home Owner Client], 0) AS [Directly provides Self-Help Housing for New Home Owner Client]
      ,ISNULL (T.[Directly provides Self-Help Housing for New Home Owner], 0) AS [Directly provides Self-Help Housing for New Home Owner]
      ,ISNULL (T.[Plays Intermediary role in providing Self-Help Housing for New Home Owner Owner Units], 0) AS [Plays Intermediary role in providing Self-Help Housing for New Home Owner Owner Units]
      ,ISNULL (T.[Plays Intermediary role in providing Self-Help Housing for New Home Owner Client], 0) AS [Plays Intermediary role in providing Self-Help Housing for New Home Owner Client]
      ,ISNULL (T.[Plays Intermediary role in providing Self-Help Housing for New Home Owner], 0) AS [Plays Intermediary role in providing Self-Help Housing for New Home Owner]
      
        ,CASE WHEN ReportingYear=2016 THEN 
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner Units], 0)
        ELSE NULL END AS 
        [Counselor and/or Broker/Lender ONLY for New Home Owner Units]
      ,CASE WHEN ReportingYear=2016 THEN 
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner Client], 0)
         ELSE NULL END AS [Counselor and/or Broker/Lender ONLY for New Home Owner Client]
      ,CASE WHEN ReportingYear=2016 THEN 
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner], 0) ELSE NULL END AS [Counselor and/or Broker/Lender ONLY for New Home Owner]
      ,CASE WHEN ReportingYear=2016 THEN ISNULL ([Replacement Units], 0) ELSE NULL END AS [Replacement Units]
      ,CASE WHEN ReportingYear=2016 THEN ISNULL ([Replacement Client], 0) ELSE NULL END AS [Replacement Client]
      ,CASE WHEN ReportingYear=2016 THEN ISNULL ([Replacement], 0) ELSE NULL END AS [Replacement]
      ,CASE WHEN ReportingYear=2016 THEN 
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner REO Homes], 0) ELSE NULL END AS [Counselor and/or Broker/Lender ONLY for New Home Owner REO Homes]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([NWO Constructs New Unit for New Home Owner Originated Loans], 0) ELSE NULL END AS [NWO Constructs New Unit for New Home Owner Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Originated Loans], 0)ELSE NULL END AS [NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Plays Intermediary role in providing Self-Help Housing for New Home Owner Originated Loans], 0)ELSE NULL END AS [Plays Intermediary role in providing Self-Help Housing for New Home Owner Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Directly provides Self-Help Housing for New Home Owner Originated Loans], 0)ELSE NULL END AS [Directly provides Self-Help Housing for New Home Owner Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner Originated Loans], 0)ELSE NULL END AS [Counselor and/or Broker/Lender ONLY for New Home Owner Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Owner Occupied Rehab Originated Loans], 0)ELSE NULL END AS [Owner Occupied Rehab Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Refinance not foreclosure Originated Loans], 0)ELSE NULL END AS [Refinance not foreclosure Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Reverse mortgage Originated Loans], 0)ELSE NULL END AS [Reverse mortgage Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Replacement Originated Loans], 0)ELSE NULL END AS [Replacement Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Foreclosure Mitigation Counseling (home retained) Originated Loans], 0) ELSE NULL END AS[Foreclosure Mitigation Counseling (home retained) Originated Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([NWO Constructs New Unit for New Home Owner Brokered Loans], 0) ELSE NULL END AS [NWO Constructs New Unit for New Home Owner Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Brokered Loans], 0) ELSE NULL END AS [NWO Sells a Unit it Had Purchased (with or without rehab) to New Home Owner Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Plays Intermediary role in providing Self-Help Housing for New Home Owner Brokered Loans], 0)ELSE NULL END AS [Plays Intermediary role in providing Self-Help Housing for New Home Owner Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Directly provides Self-Help Housing for New Home Owner Brokered Loans], 0)ELSE NULL END AS [Directly provides Self-Help Housing for New Home Owner Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Counselor and/or Broker/Lender ONLY for New Home Owner Brokered Loans], 0)ELSE NULL END AS [Counselor and/or Broker/Lender ONLY for New Home Owner Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Owner Occupied Rehab Brokered Loans], 0)ELSE NULL END AS [Owner Occupied Rehab Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Refinance not foreclosure Brokered Loans], 0)ELSE NULL END AS [Refinance not foreclosure Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Reverse mortgage Brokered Loans], 0)ELSE NULL END AS [Reverse mortgage Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Replacement Brokered Loans], 0) ELSE NULL END AS [Replacement Brokered Loans]
      ,CASE WHEN ReportingYear=2016 THEN
        ISNULL ([Foreclosure Mitigation Counseling (home retained) Brokered Loans], 0) ELSE NULL END AS [Foreclosure Mitigation Counseling (home retained) Brokered Loans]
  FROM [EDW_Staging].[Quarterly].[Quarterly Production Clients and Financing] T
  WHERE T.ReportingYear = ( 
SELECT   MAX(ReportingYear) AS ReportingYear
from [QUARTERLY].[ProjectsandSummary].[Dim_Time]
)
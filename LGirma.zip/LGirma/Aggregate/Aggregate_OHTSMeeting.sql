
---Aggregate for StgAssessment_MeetingDate
SELECT A.*
FROM dbo.StgAssessment_MeetingDate A
LEFT JOIN dbo.StgAssessment_MeetingDate_Test AM
ON A.PCODE = AM.PCODE AND A.AssessmentDate = AM.AssessmentDate AND A.MeetingDate= AM.MeetingDate
WHERE AM.PCODE IS NULL
ORDER BY PCODE, A.AssessmentDate DESC, A.MeetingDate DESC
-------------------------------------

----Aggregate for StgCurrentRating
SELECT C.*
FROM dbo.StgCurrentRating C
LEFT JOIN dbo.StgCurrentRating_Test CT
ON C.PCODE = CT.PCODE AND C.MeetingDate = CT.MeetingDate
WHERE CT.PCODE IS NULL
ORDER BY PCODE, C.MeetingDate DESC


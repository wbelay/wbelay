WITH cte 
AS 
(
 SELECT r.PCODE AS PCODE
       ,CASE 
		   WHEN ProvisionalCharterFlag = 'Y'THEN 'Provisional'+' '+' '+ r.CurrentRatingText
           ELSE r.CurrentRatingText 
        END AS CurrentOrgRecommendation 
       ,r.MeetingDate AS MeetingDate
       ,r.OnWatchListSinceDate AS WatchListstartDate 
       ,rn=ROW_NUMBER() OVER (PARTITION BY r.PCODE  order by r.MeetingDate desc) from tblRating r --where  PCODE in (8272,8187,8270,8342,8372,8205,8300,8308,8274,8425)
)       
--SELECT cte.PCODE
--       ,cte.CurrentOrgRecommendation AS FinalOHTSRecommendation
--       ,cte.MeetingDate
--       ,cte.WatchListstartDate 
--FROM cte 
--WHERE YEAR(cte.MeetingDate) != '2050'
--AND cte.CurrentOrgRecommendation like 'p%'

SELECT *
FROM (SELECT a.PCODE 
            ,a.CurrentOrgRecommendation
            --,PCODE as Org_ID
       FROM cte a
       WHERE YEAR(a.MeetingDate) != '2050'
	  )P

PIVOT
(
	COUNT (PCODE)
	FOR CurrentOrgRecommendation IN
	([Provisional  Satisfactory], [Provisional  Strong],[Exemplary],[Satisfactory],[Strong],
	 [Provisional  Vulnerable],[Vulnerable],[NULL])
) AS pvt


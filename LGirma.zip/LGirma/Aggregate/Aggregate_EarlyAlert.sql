SELECT   /*SQL code to produce conversion file Early Alerts*/
       [PCODE]
      ,CASE WHEN CONVERT(VARCHAR(20),MeetingDate,101) = '01/01/2050' AND PCODE= 8487 THEN '12/14/2015'
       ELSE CONVERT(VARCHAR(20),MeetingDate,101)END AS MeetingDate
	  ,[dbo].[udf_StripHTML](IssueIdentified) AS [IssueIdentifiedDesc]
      ,[IssuedBy] AS [Division]
      ,[LastUpdate] AS [LastUpdateDesc]
      , '' AS [ResolvedWhenDesc]
      ,[ClosedFlag] AS [IsClosed]--to be used as flag for reporting
      ,[CreatedBy]
      ,[CreatedDate]
      ,[ModifiedBy]
      ,[ModifiedDate]
      INTO #T
FROM [HARP].[dbo].[tblEAROIssues]
WHERE [Type]='Early Alert'
	  AND PCODE != 8551
	--AND [PCODE] in ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')--Values for initial conversion file
	
SELECT *
FROM ( SELECT a.PCODE
			 ,a.IsClosed
			 ,PCODE AS OrgID
	   FROM #T a)p
		   
PIVOT
(
  COUNT(PCODE)
  FOR IsClosed IN 
  ([0] ,[1]) 
) as pvt
  
DROP TABLE #t
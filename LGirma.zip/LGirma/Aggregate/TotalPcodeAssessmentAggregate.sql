WITH cte AS (
SELECT CORE.PCODE
            ,CORE.ReviewType
            ,CORE.AssessmentDate
            ,CORE.MeetingDate
            ,CASE 
                  WHEN CORE.AssignedTo IS NULL THEN ASG.Leader 
               ELSE CORE.AssignedTo 
             END AS AssignedTo, CORE.CreatedBy, CORE.CreatedDate
                ,rn=ROW_NUMBER() OVER (PARTITION BY CORE.PCODE,CORE.AssessmentDate ORDER BY ABS (DATEDIFF(day,CORE.AssessmentDate,CORE.MeetingDate)) ASC) 
FROM
(SELECT  r.PCODE AS PCODE
        ,CASE 
            WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
            WHEN r.OthersFlag = 'Y' THEN 'Other'
            ELSE '' 
          END AS ReviewType
        ,CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        ,CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
        ,rd.OADReviewerName AS AssignedTo
        ,'' AS CreatedBy
        ,'' AS CreatedDate
FROM tblRating r
LEFT JOIN tblRatingDetail rd
   ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate
LEFT JOIN dbo.OnOffSiteReviews OFR
      ON (r.PCODE = OFR.PCODE 
          AND (CASE 
                        WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
                        WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
                        WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
                        WHEN r.OthersFlag = 'Y' THEN 'OthersFlag' 
              ELSE '' 
             END) = OFR.ReviewType)
                        
WHERE OFR.ReviewDate <= r.MeetingDate
        AND r.MeetingDate <= GETDATE()
      AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
GROUP BY r.PCODE, r.MeetingDate, r.ReviewFlag, r.ReviewPROFlag, r.AuditReviewFlag, r.OthersFlag,  rd.OADReviewerName, ReviewType) CORE
LEFT OUTER JOIN dbo.OnOffSiteReviews ASG
ON CORE.PCODE=ASG.PCODE AND CORE.ReviewType=ASG.ReviewType AND CORE.AssessmentDate=ASG.ReviewDate
--WHERE CORE.PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
)

SELECT A.ReviewType
	  ,COUNT(distinct A.PCODE) AS NumberOfPcodes
FROM cte A
GROUP BY a.ReviewType


--SELECT * INTO stgRiskObserved
--FROM
--(
 SELECT [PCODE]
	   ,'' AS [RiskCategory]
	   ,'' AS [RiskType]
	   ,[dbo].[udf_StripHTML](IssueIdentified) AS [RiskIdentifiedDesc]
       ,[IssuedBy] AS [Division]
       ,[LastUpdate] AS [LastUpdateDesc]
       ,'' AS [ResolvedWhenDesc]
       ,[ClosedFlag] AS [IsClosed] --to be used as flag for reporting
       ,[CreatedBy]
       ,[CreatedDate]
       ,[ModifiedBy]
       ,[ModifiedDate]
        INTO #T
  FROM [HARP].[dbo].[tblEAROIssues]
  WHERE [Type]='Risk Observed'
	--AND [PCODE] in ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425') --Values for initial conversion file
--)

SELECT *
FROM (SELECT a.PCODE
		    ,a.Division
		    ,PCODE AS OrgID
	  FROM #T a)p
	  
PIVOT
(
	COUNT(PCODE)
	FOR Division IN
	([FIELD],[OAD],[NI],[NFMC],[NREP],[NHP])
)pvt

DROP TABLE #T


	  
	  
	  
	  
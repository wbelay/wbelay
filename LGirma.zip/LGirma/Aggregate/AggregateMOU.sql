--SELECT * INTO stgMOU
--FROM
--(
SELECT [PCODE]
      ,[MOUStartDate]
      ,[MOUExpirationDate]
      ,REPLACE([dbo].[udf_StripHTML]([MOUDescription]),'CHAR(13) + CHAR(10)','')AS [MOUDescription]
      ,[dbo].[udf_StripHTML]([MOUTopic])AS [MOUTopic]
      ,'' AS CreatedBy
      ,'' AS CreatedDate
      ,'' AS ModifiedBy
      ,'' AS ModifiedDate
      ,MOUCreated AS IsClosed  --- flag showing MoU closed or not
       INTO #t
FROM [HARP].[dbo].[tblMOU] -----where PCODE in (8272,8187,8270,8342,8372,8205,8300,8308,8274,8425);
 --)
  
SELECT *
FROM (SELECT a.PCODE
			,a.IsClosed
			,PCODE AS OrgID
			 
	   FROM #t a)p
	   
PIVOT
(
	COUNT(PCODE)
	FOR ISClosed IN
	([0] ,[1]) 
) as pvt
  
DROP TABLE #t
   
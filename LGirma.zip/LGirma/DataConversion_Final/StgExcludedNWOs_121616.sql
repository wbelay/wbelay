--SELECT * INTO StgExcludedNWOs
--FROM
(
SELECT PCODE,
	   CASE WHEN OrgStatusName LIKE 'Disaffiliation' THEN 'Disaffiliation'
			WHEN OrgStatusName LIKE'Suspended' THEN 'Suspended'
			ELSE 'OHTS 3/17' END AS ExcludedReason
	  ,[DistrictName],[Name],[PresidentCEOName],[CharterDate],[FiscalYearEndMonthAndDay],[City],[State],[Title]      ,[RMName],[RMTitle],[OrgStatusName],[StreetAddrLine1],[StreetAddrLine2],[StreetAddrLine3],[StreetAddrZipCode]      ,[BusPhone],[BusFax],[BusEmail],[DateIncoporated],[MeetingDateID],[DateOrganizationDisaffiliated],[ED_Name]      ,[OrgEmail],[Org_Phone]
FROM dbo.tblOrganization
WHERE (OrgStatusName LIKE 'Disaffiliation' OR OrgStatusName LIKE'Suspended')---Pcodes to exclude from data migration

UNION ALL 

SELECT [Pcodes to exclude from data migration] AS [PCODE]	  ,[DateExcluded] AS [ExcludedReason]      ,'' AS [DistrictName]      ,'' AS [Name]      ,'' AS [PresidentCEOName]      ,'' AS [CharterDate]      ,'' AS [FiscalYearEndMonthAndDay]      ,'' AS [City]      ,'' AS [State]      ,'' AS [Title]      ,'' AS [RMName]      ,'' AS [RMTitle]      ,'' AS [OrgStatusName]      ,'' AS [StreetAddrLine1]      ,'' AS [StreetAddrLine2]      ,'' AS [StreetAddrLine3]      ,'' AS [StreetAddrZipCode]      ,'' AS [BusPhone]      ,'' AS [BusFax]      ,'' AS [BusEmail]      ,'' AS [DateIncoporated]      ,'' AS [MeetingDateID]      ,'' AS [DateOrganizationDisaffiliated]      ,'' AS [ED_Name]      ,'' AS [OrgEmail]      ,'' AS [Org_Phone]  FROM [HARP].[dbo].[ExcludedXLS2016]

--) AS N 


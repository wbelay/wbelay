WITH cte
AS (
	 SELECT [pcode]
			,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
			,CASE 
				 WHEN [Field Rank Com]  IS NOT NULL THEN 'Field' 
			 END AS [Division]
			,CASE 
				 WHEN [Field Rank Com] IS NOT NULL THEN [Field Rank Com] 
			 END AS [Summary]
			,'' AS ModifiedBy
			,'' AS ModifiedDate
	  FROM stgRankings
	  	  		
UNION ALL

	 SELECT [pcode]
		   ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		   ,CASE
				WHEN [OAD Rank Com]   IS NOT NULL THEN 'OAD' 
			END AS [Division]
		   ,CASE 
				WHEN [OAD Rank Com] IS NOT NULL THEN [OAD Rank Com] 
			END AS [Summary]
		   ,'' AS ModifiedBy
		   ,'' AS ModifiedDate
	 FROM stgRankings
	
UNION ALL

	SELECT [pcode]
		  ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		  ,CASE 
				WHEN [MFI Comment] IS NOT NULL THEN 'NREP' 
			END AS [Division]
		  ,CASE 
				WHEN [MFI Comment] IS NOT NULL THEN [MFI Comment] 
			END AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM stgRankings

UNION ALL

	SELECT [pcode]
		  ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		  ,CASE 
    		  WHEN [HOC Comment] IS NOT NULL THEN 'NHP' 
		   END AS [Division]
		  ,CASE 
			  WHEN [HOC Comment] IS NOT NULL THEN [HOC Comment] 
		   END  AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM stgRankings
	 
UNION ALL

	SELECT PCODE
		  ,MeetingDate
		  ,CASE 
			  WHEN RatingComment IS NOT NULL THEN 'NFMC' 
		   END AS [Division]
		  ,CASE 
			  WHEN RatingComment IS NOT NULL THEN [RatingComment] 
		   END AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM dbo.tblNFMC
	WHERE [RatingComment] IS NOT NULL 
		  

UNION ALL
		
	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			   WHEN CapCorpsSummary IS NOT NULL THEN 'CapCorps'
		   END AS Division
		  ,CASE
				WHEN CapCorpsSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (CapCorpsSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	

UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
          ,CASE 
     			WHEN FieldSummary IS NOT NULL THEN 'Field'
		   END AS Division
		  ,CASE
				WHEN FieldSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (FieldSummary)
		  END AS Summary
		 ,ModifiedBy
		 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
				WHEN OADSummary IS NOT NULL THEN 'OAD'
		   END AS Division
		  ,CASE
				WHEN OADSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (OADSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
     		   WHEN NISummary IS NOT NULL THEN 'NI'
		   END AS Division
		  ,CASE
		  	  WHEN NISummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NISummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
     		  WHEN NFMCSummary IS NOT NULL THEN 'NFMC'
		   END AS Division
		  ,CASE
			  WHEN NFMCSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NFMCSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			  WHEN NHPSummary IS NOT NULL THEN 'NHP'
		   END AS Division
		  ,CASE
			  WHEN NHPSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NHPSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
			  
UNION ALL

	SELECT R.PCODE
	      ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			   WHEN NREPSummary IS NOT NULL THEN 'NREP'
		   END AS Division
		  ,CASE
			   WHEN NREPSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NREPSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
)	

SELECT C.PCODE
	  ,C.MeetingDate
	  ,C.Division
	  ,C.Summary
	  ,C.ModifiedBy
	  ,C.ModifiedDate 
	  ,ROW_NUMBER()OVER(PARTITION BY C.PCODE,C.MeetingDate,C.Division ORDER BY C.PCODE)AS RN
	   INTO #t 
FROM cte C
WHERE C.Division IS NOT NULL AND C.Summary IS NOT NULL
ORDER BY C.MeetingDate DESC

--SELECT * INTO StgSummaryUpdates
--FROM(
SELECT DISTINCT t.PCODE
	  ,CASE WHEN t.MeetingDate >(SELECT MAX(meetingdate)FROM tblOHTSMeeting) THEN NULL
		    WHEN t.MeetingDate IS NOT NULL AND MeetingDate NOT IN (SELECT MeetingDate FROM dbo.tblOHTSMeeting OHTS 
		    WHERE t.PCODE=OHTS.PCODE AND t.MeetingDate=OHTS.MeetingDate) THEN 
			(SELECT MIN(meetingDate) FROM dbo.tblOHTSMeeting OHTS WHERE t.PCODE=OHTS.PCODE AND OHTS.meetingDate>t.MeetingDate)
			 ELSE CAST(MeetingDate AS DATE)
	   END AS MeetingDate
	  ,t.Division
	  ,REPLACE(CAST(t.Summary AS VARCHAR(MAX)),'CHAR(13) + CHAR(10)',',')AS Summary
	  ,t.ModifiedBy
	  ,t.ModifiedDate 
FROM #t t
WHERE RN = 1 
	  --AND YEAR(MeetingDate) <> 2050 
	  AND YEAR(MeetingDate)>2009
	  AND PCODE IN(SELECT [PCODE] FROM [HARP].[dbo].[tblOHTSMeeting] 
                     WHERE meetingdate='2017-03-09' and pcode not in (8069,8288,8388)) 
										 
--) AS N
DROP TABLE #t 
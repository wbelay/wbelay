SELECT A.PCODE, A.ReviewType, A.AssessmentDate,
(SELECT MIN(M.MeetingDate) 
from StgAssessment_MeetingDate M INNER Join StgAssessment X on M.Pcode=X.Pcode and m.AssessmentDate=X.AssessmentDate 
where A.AssessmentDate<=M.MeetingDate and  M.PCODE=A.PCODE) AS MeetingDate
FROM dbo.StgAssessment_Z A
LEFT JOIN dbo.StgAssessment_MeetingDate_Z AM
ON A.Pcode=AM.Pcode and A.AssessmentDate=AM.AssessmentDate
WHERE AM.PCODE IS NULL and A.AssessmentDate is not null and A.AssessmentStatus='Complete'

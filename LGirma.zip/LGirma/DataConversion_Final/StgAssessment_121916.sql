WITH CTE
AS
(
SELECT PCODE 
	  ,CAST(ReviewDate AS DATE) AS ReviewDate
	  ,ReviewType
	  ,Leader AS AssignedTo
	  ,'' AS RN
FROM OnOffSiteReviews o
WHERE (reviewdate>getdate() and leader is not null) OR (reviewdate<getdate()) 
	  AND YEAR(ReviewDate)>=2009
	  AND ReviewType = 'On-Site'
	   	  
UNION ALL

SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,MAX(rd.OADReviewerName)AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar),r.ReviewPROFlag ORDER BY OFS.PCODE)RN
FROM dbo.tblOffSiteRating OFS
LEFT JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	  CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND  r.ReviewPROFlag = 'Y'
	  AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=GETDATE()
GROUP BY OFS.PCODE,OFS.FiscalMonth,OFS.FiscalYearYear,R.ReviewPROFlag
)
--SELECT * INTO StgAssessment
--FROM(
SELECT PCODE
	  ,ReviewDate As AssessmentDate
	  ,ReviewType
	  ,AssignedTo
	  ,CASE WHEN CTE.PCODE IN (SELECT CTE.PCODE FROM [dbo].[tblOHTSMeeting] r WHERE cte.pcode=r.pcode and cte.ReviewDate<=r.meetingDate)
		THEN 'Complete' ELSE 'Current' END AS AssessmentStatus	
	  ,'History' AS RecordStatus----History is the default Value
	  ,CASE WHEN ReviewType = 'Off-Site' THEN '2000-01-01' ELSE '' END AS FinalReportApprovedDate
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate 
FROM CTE
WHERE ---2017 final script
		((year(reviewdate)<'2017' and ReviewType='On-Site') or  (reviewdate<'2017-03-10' and ReviewType='Off-Site'))
	    AND PCODE IN(SELECT PCODE FROM tblOrganization)
	    AND PCODE IN(SELECT [PCODE] FROM [HARP].[dbo].[tblOHTSMeeting] 
                     WHERE meetingdate='2017-03-09' and pcode not in (8069,8288,8388))
	   
--) AS N 




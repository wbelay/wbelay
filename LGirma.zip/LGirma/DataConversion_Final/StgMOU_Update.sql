ALTER TABLE StgMOU
ADD Is_Closed_New Char(1)

UPDATE StgMOU
SET Is_Closed_New='Y'
WHERE IsClosed='N'

UPDATE StgMOU
SET Is_Closed_New='N'
WHERE IsClosed='Y'

SELECT *
FROM StgMOU

UPDATE StgMOU
SET IsClosed='Y'
WHERE Is_Closed_New='Y'

UPDATE StgMOU
SET IsClosed='N'
WHERE Is_Closed_New='N'

ALTER TABLE StgMOU
DROP COLUMN Is_Closed_New 
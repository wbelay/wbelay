/*SQL code to produce Production&Investment graph on OHTS report
I use fact_Comprehensive_Rollup, dim_Organization and dim_date tables*/
--=============================================================================
SELECT a.PCode,b.[Year],b.[Quarter],a.[Total Direct Investment],a.TotalProductionNumber
FROM (
SELECT PCode
      ,LEFT(C.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter 
	   ,ISNULL([Total_Reported_Investment],0) AS [Total Direct Investment]
	   ,ISNULL([Homeowners_Created_Client],0)+
       ISNULL([Preserved_Homeownership_Foreclosure_Mitigation_Client],0)+
       ISNULL([Preserved_Homeownership_Owner_Occupied_Rehabilitation_Client],0)+
       ISNULL([Preserved_Homeownership_Refinancing_Client],0)+
       ISNULL([Rental_Homes_Development_Services_Units],0)+
       ISNULL([Rental_Homes_Purchased_For_New_Renter_Units],0)+
       ISNULL([Rental_Homes_Refinanced_Units],0) +
       ISNULL([Rental_Homes_Rehabilitated_Units],0) AS TotalProductionNumber
FROM [dbo].[fact_Comprehensive_Rollup] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key
WHERE PCODE IS NOT NULL 
)A
LEFT JOIN
(
SELECT DISTINCT d.fin_year [Year],d.fin_quarter_no [Quarter],d.cal_year,d.cal_quarter_no
FROM  [dbo].[fact_Comprehensive_Rollup] C
LEFT JOIN dim_date d
ON LEFT(C.dim_ReportingQuarter_key,4)= d.fin_year and (CASE WHEN RIGHT(LEFT(C.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(C.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(C.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(C.dim_ReportingQuarter_key,6),2)=12 THEN 04 end) = d.fin_quarter_no
			)b
			on a.FisicalYear=b.cal_year and a.FisicalYearQuarter=b.cal_quarter_no  
WHERE (b.Year IS NOT NULL AND b.quarter IS NOT NULL)
ORDER BY pcode, fisicalyear, FisicalYearQuarter

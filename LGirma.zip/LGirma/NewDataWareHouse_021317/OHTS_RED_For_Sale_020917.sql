/*SQL code to produce RED For Sale graph on OHTS report
I use fact_Real_Estate_Development, dim_Organization and dim_date tables*/
--=============================================================================
SELECT a.pcode,b.fin_year AS [Year],b.fin_quarter_no AS [Quarter],a.NumberOfUnitsForSale,a.NumberOfUnitsHeld
FROM(
SELECT  pcode
		,ISNULL(SUM(R.Total_Units),0) AS NumberOfUnitsForSale
		,ISNULL(SUM(A.[Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter]),0) AS NumberOfUnitsHeld
		,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	   ,CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
FROM [dbo].[fact_Real_Estate_Development] R
LEFT OUTER JOIN [dbo].[fact_Inventory_Of_For_Sale_Units] A
ON r.dim_Organization_key=a.dim_Organization_key and r.dim_ReportingQuarter_key=a.dim_ReportingQuarter_key
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key 
GROUP BY PCode,R.dim_ReportingQuarter_key)a
LEFT JOIN
(
SELECT DISTINCT d.fin_year,d.fin_quarter_no,d.cal_year,d.cal_quarter_no
FROM  [dbo].[fact_Real_Estate_Development] r
LEFT JOIN dim_date d
ON LEFT(R.dim_ReportingQuarter_key,4)= d.cal_year and (CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END) = d.cal_quarter_no
			)b
			ON a.FisicalYear=b.cal_year AND a.FisicalYearQuarter=b.cal_quarter_no 
ORDER BY pcode, fisicalyear, FisicalYearQuarter



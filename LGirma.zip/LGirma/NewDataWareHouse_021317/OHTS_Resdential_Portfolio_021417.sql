/*SQL code to produce Resdential Loan Portfolio graph on OHTS report
I use fact_RLF_Portfolio_Status, dim_Organization and dim_date tables*/
--=============================================================================
SELECT  a.Pcode,b.fin_year as [Year], b.fin_quarter_no as [Quarter]
	  ,a.NumberOfOutstandingLoans,a.AmountOfOutstandingLoans,a.[NumberOf 30 to 59 Days Delinqunet],a.[AmountOf 30 to 59 Days Delinqunet]
	  ,a.[NumberOf 60 to 89 Days Delinqunet],a.[AmountOf 60 to 89 Days Delinqunet],a.[NumberOf 90 + Days Delinqunet],a.[AmountOf 90 + Days Delinqunet]
	  ,a.SubMortgageNumberOfOutstandingRLFLoans,a.SubMortgageAmountOfOutstandingRLFLoans,a.SubMortgageNumberOfRLFLoans30to59DaysDelinquent
	  ,a.SubMortgageAmountOfRLFLoans30to59DaysDelinquent,a.SubMortgageNumberOfRLFLoans60to89DaysDelinquent,a.SubMortgageAmountOfRLFLoans60to89DaysDelinquent
	  ,a.[SubMortgageNumberOfRLFLoans90+DaysDelinquent],a.[SubMortgageAmountOfRLFLoans90+DaysDelinquent]
	  ,a.[1st% of $ 90+ Delinquent],a.[2nd% of $ 90+ Delinquent]
FROM
(
SELECT Pcode
      ,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	 ,SUM(CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans])) AS [NumberOfOutstandingLoans]
	 ,SUM(CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans])) AS [AmountOfOutstandingLoans]
	 ,SUM(CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent])) AS [NumberOf 30 to 59 Days Delinqunet]
	 ,SUM(CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent])) AS [AmountOf 30 to 59 Days Delinqunet]
	 ,SUM(CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent])) AS [NumberOf 60 to 89 Days Delinqunet]
	 ,SUM(CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent])) AS [AmountOf 60 to 89 Days Delinqunet]
	 ,SUM(CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent])) AS [NumberOf 90 + Days Delinqunet]
	 ,SUM(CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent])) AS [AmountOf 90 + Days Delinqunet]
	 ,SUM(CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans])) AS [SubMortgageNumberOfOutstandingRLFLoans]
	 ,SUM(CONVERT(MONEY, [Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans])) AS [SubMortgageAmountOfOutstandingRLFLoans]
	 ,SUM(CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent])) AS [SubMortgageNumberOfRLFLoans30to59DaysDelinquent]
	 ,SUM(CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent])) AS [SubMortgageAmountOfRLFLoans30to59DaysDelinquent]
	 ,SUM(CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent])) AS [SubMortgageNumberOfRLFLoans60to89DaysDelinquent]
	 ,SUM(CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent])) AS [SubMortgageAmountOfRLFLoans60to89DaysDelinquent]
	 ,SUM(CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent])) AS [SubMortgageNumberOfRLFLoans90+DaysDelinquent] 
	 ,SUM(CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent])) AS [SubMortgageAmountOfRLFLoans90+DaysDelinquent]
	 ,SUM(CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0))) AS [1st% of $ 90+ Delinquent]
	 ,SUM(CONVERT(DECIMAL(4,3),[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0))) AS [2nd% of $ 90+ Delinquent]    
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
WHERE PCODE IS NOT NULL 
GROUP BY PCODE, dim_ReportingQuarter_key
) A
LEFT JOIN
(
SELECT DISTINCT d.fin_year,d.fin_quarter_no,d.cal_year,d.cal_quarter_no
FROM  [dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN dim_date d
ON LEFT(R.dim_ReportingQuarter_key,4)= d.cal_year and (CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END) = d.cal_quarter_no
)B
ON a.FisicalYear=b.cal_year AND a.FisicalYearQuarter=b.cal_quarter_no 
WHERE B.fin_year<2017
ORDER BY Pcode, FisicalYear, FisicalYearQuarter
SELECT * INTO New_MOU
FROM 
(
SELECT a.[PCODE]
	  ,b.MeetingDate
      ,a.[MOUStartDate]
      ,a.[MOUExpirationDate]
      ,REPLACE([dbo].[udf_StripHTML]([MOUDescription]),'CHAR(13) + CHAR(10)','')AS [MOUDescription]
      ,[dbo].[udf_StripHTML]([MOUTopic])AS [MOUTopic]
      ,'' AS CreatedBy
      ,'' AS CreatedDate
      ,'' AS ModifiedBy
      ,'' AS ModifiedDate
      ,a.MOUCreated AS IsClosed  --- flag showing MoU closed or not
  FROM [HARP].[dbo].[tblMOU] as a
  left outer join dbo.Assessment as b
	on a.PCODE=b.PCODE and b.MeetingDate between (select MAX(c.AssessmentDate) from Assessment c join tblMOU d on c.PCODE=d.PCODE and c.AssessmentDate <= d.MOUStartDate) and a.mouexpirationdate
	--order by a.PCODE asc
	) as n
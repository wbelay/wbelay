--SELECT * INTO stgFinding
--FROM
--(
SELECT pcode
	  ,CASE 
		  WHEN YEAR(MeetingDate)=2050 and YEAR(FindingDate)>=2014 THEN '12/08/2016' 
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8526 THEN '12/08/2016'
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8341 THEN '09/08/2016'
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8233 THEN '09/08/2016'
          WHEN YEAR(MeetingDate)=2050 AND PCODE = 8177 THEN ''
	   	  ELSE CONVERT(VARCHAR(20),MeetingDate,101)
	   END AS MeetingDate
	  ,FC.[Type] AS FindingGroup
	  ,FC.Category AS FindingCategory
	  ,'' AS FindingType 
	  ,CASE 
		  WHEN YEAR(MeetingDate)= 2050 AND YEAR(FindingDate)<=2014 THEN ''
		  ELSE CONVERT(VARCHAR(20),F.FindingDate,101)
	   END AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,F.OAD AS OADRecommendation
	  ,F.Field AS FieldRecommendation
	  ,F.ClosedFlag AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,'' AS FieldResolutionComments
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
--) AS stgFindings




-- Changes on 20161104  a) Exclude Reviews in process 
--                      b) No longer use future OHTS meeting dates from tblrating since only send at closed OHTS
--                      c) Allow review date .eq. to meetingdate
--
SELECT OS.PCODE
         ,CONVERT(VARCHAR(10),MAX(AssessmentDate),101) AS AssessmentDate
         ,CONVERT(VARCHAR(10),MeetingDate,101)  AS MeetingDate
         ,'SwitchBoardImport' AS CreatedBy
         ,CONVERT(VARCHAR(10),GETDATE(),101) AS CreatedDate
         ,CASE WHEN OS.PCODE IN(SELECT PCODE--MeetingDate,ActionsFromOHTSMeetingSummary
								FROM [HARP].[dbo].[tblOHTSMeeting]
								WHERE ActionsFromOHTSMeetingSummary like '%defer%' AND PCODE<>8271 
									  AND meetingdate=r.meetingdate AND meetingdate=(SELECT MAX(meetingdate)FROM [HARP].[dbo].[tblOHTSMeeting]))THEN 'Y'
		  ELSE 'N' END AS  DeferredFlag 
         INTO #T
FROM [dbo].[tblOHTSMeeting] r---We make it primary table to get rid of null
LEFT OUTER JOIN dbo.StgAssessment OS--JOIN TO GET ASSESSMENTDATE
ON r.PCODE = OS.PCODE AND OS.AssessmentDate<=R.MeetingDate
LEFT Outer JOIN [dbo].[OnOffSiteReviews] SB 
ON OS.Pcode=SB.PCODE and OS.AssessmentDate=SB.ReviewDate AND OS.ReviewType=SB.ReviewType
WHERE OS.PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
        AND SB.InProcess <> 1  
             
GROUP BY OS.PCODE,MeetingDate,CAST(R.ActionsFromOHTSMeetingSummary AS NVARCHAR),SB.InProcess
--SELECT * INTO StgAssessment_MeetingDate
--FROM(
SELECT *
FROM #T 
--)AS N
DROP TABLE #T


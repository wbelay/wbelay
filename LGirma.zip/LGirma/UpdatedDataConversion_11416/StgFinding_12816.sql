--SELECT * INTO StgFinding
--FROM
--(
SELECT pcode
	   ,CASE WHEN MeetingDate >(select max(meetingdate)from tblOHTSMeeting) THEN NULL
			 WHEN  MeetingDate = '12/15/15' THEN '12/16/15'
		     WHEN MeetingDate is not null and MeetingDate not in (SELECT meetingDate FROM dbo.tblOHTSMeeting OHTS 
		     WHERE F.PCODE=OHTS.PCODE and F.MeetingDate=OHTS.meetingDate) THEN 
			 (SELECT MIN(meetingDate) FROM dbo.tblOHTSMeeting OHTS WHERE F.PCODE=OHTS.PCODE and OHTS.meetingDate>F.MeetingDate)
			  ELSE CAST(MeetingDate AS DATE)---update 
	   END AS MeetingDate
	  ,FC.[Type] AS FindingGroup
	  ,CASE WHEN FC.ID = 5 THEN 'PL' ELSE FC.Category END AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(FindingDate AS DATE) AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,CASE WHEN F.closedflag=1 AND (F.OAD IS NULL OR F.OAD=' ') THEN 'Clear' 
	   ELSE F.OAD END AS OADRecommendation
	  ,CASE WHEN F.closedflag=1 AND (F.Field IS NULL OR F.Field=' ') THEN 'Keep'
	   ELSE F.Field END AS FieldRecommendation
	  ,dbo.fn_BooleanToYN(F.ClosedFlag) AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,REPLACE([dbo].[udf_StripHTML](Resolution),'CHAR(13) + CHAR(10)','') AS FieldResolutionComments
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
--)AS N

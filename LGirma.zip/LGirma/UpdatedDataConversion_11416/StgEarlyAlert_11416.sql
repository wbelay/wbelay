--SELECT * INTO StgEarlyAlert
--FROM
--(
SELECT   /*SQL code to produce conversion file Early Alerts*/
       [PCODE]
      ,CASE WHEN CONVERT(VARCHAR(20),MeetingDate,101) = '01/01/2050' AND PCODE= 8487 THEN '12/14/2015'
       ELSE CONVERT(VARCHAR(20),MeetingDate,101)END AS MeetingDate
	  ,[dbo].[udf_StripHTML](IssueIdentified) AS [IssueIdentifiedDesc]
      ,[IssuedBy] AS [Division]
      ,[LastUpdate] AS [LastUpdateDesc]
      ,'' AS [ResolvedWhenDesc]
      ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed]--to be used as flag for reporting
      ,[CreatedBy]
      ,[CreatedDate]
      ,[ModifiedBy]
      ,[ModifiedDate]
FROM [HARP].[dbo].[tblEAROIssues]
WHERE [Type]='Early Alert'
	  AND PCODE  IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8046,8040,8255,8011,8231,8379,8411,8494,8044,8355)--26 Test Pcodes  
--) AS N
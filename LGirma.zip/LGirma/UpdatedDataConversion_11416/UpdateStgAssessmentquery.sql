UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE IN (SELECT PCODE FROM StgAssessment_MeetingDate
				WHERE DeferredFlag = 'Y' and StgAssessment.AssessmentDate=StgAssessment_MeetingDate.AssessmentDate)


--UPDATE dbo.StgAssessment 
--SET AssessmentStatus= 'Current'
--WHERE PCODE =8046 and AssessmentDate = '2016-06-20'

UPDATE dbo.StgAssessment 
SET RecordStatus= 'OADDraftReport'---Default value is History
WHERE AssessmentStatus= 'Current' 

UPDATE dbo.StgAssessment
SET AssignedTo='Promptoadreviewer1'
WHERE AssessmentStatus= 'Current'


ALTER TABLE dbo.StgAssessment
ALTER COLUMN RecordStatus text

ALTER TABLE dbo.StgAssessment_MeetingDate
ALTER COLUMN MeetingDate DATE

UPDATE dbo.StgAssessment
SET  FinalReportApprovedDate='2000-01-01'
WHERE AssessmentStatus= 'Complete' AND CONVERT(NVARCHAR(MAX),RecordStatus) <> N'OADDraftReport'

--SELECT * INTO StgFinding
--FROM
--(
SELECT pcode
	  ,CASE 
		  WHEN MeetingDate >(select max(meetingdate)from tblOHTSMeeting) THEN NULL
          WHEN  MeetingDate = '12/15/15' THEN '12/16/15'
	   	  ELSE CAST(MeetingDate AS Date)
	   END AS MeetingDate
	  ,FC.[Type] AS FindingGroup
	  ,CASE WHEN FC.ID = 5 THEN 'PL' ELSE FC.Category END AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(FindingDate AS DATE) AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,CASE WHEN F.closedflag=1 AND (F.OAD IS NULL OR F.OAD=' ') THEN 'Clear' 
	   ELSE F.OAD END AS OADRecommendation
	  ,CASE WHEN F.closedflag=1 AND (F.Field IS NULL OR F.Field=' ') THEN 'Keep'
	   ELSE F.Field END AS FieldRecommendation
	  ,dbo.fn_BooleanToYN(F.ClosedFlag) AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,REPLACE([dbo].[udf_StripHTML](Resolution),'CHAR(13) + CHAR(10)','') AS FieldResolutionComments
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
--) AS N




 






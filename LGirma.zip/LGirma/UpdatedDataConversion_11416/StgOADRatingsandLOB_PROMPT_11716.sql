WITH CTE
AS 
(
	SELECT  os.PCODE
			,os.ReviewDate
			,os.ProductionProgramServicesText AS PROMPTRating_P
			,os.ResourceManagementText AS PROMPTRating_R
			,os.OrganizationalManagementText AS PROMPTRating_O
			,os.PersonnelManagementText AS PROMPTRating_M
			,os.PlanningText AS PROMPTRating_PM
			,os.TechnicalOperationsSystemsText AS PROMPTRating_T 
			,orv.HomeownershipPreservationFlag 
			,orv.HomeownershipPromotionServicesFlag 
			,orv.CommunityBuildingandOrganizingFlag 
			,orv.AssetAndPropertyManagementFlag
			,orv.RealEstateDevelopmentFlag 
			,orv.LendingandPortfolioManagementFlag 
			,orv.OtherServicesFlag
			,(SELECT Division FROM StgDivisionRatings WHERE Division = 'OAD')AS OADDivision 
	FROM dbo.tblOnSiteRatings OS
	LEFT OUTER JOIN [tblOnSiteReviewLineOfBusiness] ORV
	ON OS.PCODE = ORV.PCODE
	   AND OS.ReviewDate = ORV.ReviewDate
			 
UNION ALL 
			  
	  SELECT [PCODE]
             ,CAST([Month] AS varchar(12)) + '/' + '1' + '/' + CAST(FYear as varchar(6)) AS ReviewDate
			 ,CASE WHEN ProdRate=1 THEN 'Exceed'
				   WHEN ProdRate=3 THEN 'Meet' 
				   WHEN ProdRate=5 THEN 'Fail' END AS PROMPTRating_P
			 ,CASE WHEN ResRate=1 THEN 'Exceed'
				   WHEN ResRate=3 THEN 'Meet' 
				   WHEN ResRate=5 THEN 'Fail' END AS  PROMPTRating_R
		    ,CASE WHEN OMRate=1 THEN 'Exceed'
				  WHEN OMRate=3 THEN 'Meet' 
				  WHEN OMRate=5 THEN 'Fail' END AS PROMPTRating_O
			,'' AS PROMPTRating_M
			,'' AS PROMPTRating_PM
			,'' AS PROMPTRating_T
			,dbo.fn_BooleanToYN(RE_Off) AS HomeonwhershipPreservationFlag
			,dbo.fn_BooleanToYN(HOME_Off) AS HomeownerhipPormotionServicesFlag
			,dbo.fn_BooleanToYN(CBE_Off) AS CommunityBuildingandOrganizingFlag
			,dbo.fn_BooleanToYN(PM_Off)AS AssetAndPropertyManagementFlag
			,dbo.fn_BooleanToYN(RED_Off)AS RealEstateDevelomentFlag
			,dbo.fn_BooleanToYN(LEND_Off)AS LendingandPortfolioManagementFlag
			,'' AS OtherServicesFlag
			,(SELECT Division FROM StgDivisionRatings WHERE Division = 'OAD')AS OADDivision
	 FROM [HARP].[dbo].[RiskFactorOAD]
			 
)
		   

SELECT A.PCODE
	  ,A.AssessmentDate
	  ,CTE.PROMPTRating_P AS PROMPTRating_P
	  ,CTE.PROMPTRating_R AS PROMPTRating_R
	  ,CTE.PROMPTRating_O AS PROMPTRating_O
	  ,CTE.PROMPTRating_PM AS PROMPTRating_PM
	  ,CTE.PROMPTRating_M AS PROMPTRating_M 
	  ,CTE.PROMPTRating_T AS PROMPTRating_T 
	  ,CTE.HomeownershipPreservationFlag  AS HomeOwnershipPreservationServices
      ,CTE.HomeownershipPromotionServicesFlag AS HomeOwnershipPromotion
      ,CTE.CommunityBuildingandOrganizingFlag  AS CommunityBuildingandEngagement
      ,CTE.AssetAndPropertyManagementFlag  AS PropertyManagement
      ,CTE.RealEstateDevelopmentFlag  AS RealEstateDevelopment
      ,CTE.LendingandPortfolioManagementFlag AS LendingandLoanPortfolio 
      ,CTE.OtherServicesFlag  AS OtherServices   
      ,ROW_NUMBER() OVER(PARTITION BY A.PCODE,A.AssessmentDate, PROMPTRating_P, PROMPTRating_R,PROMPTRating_O, PROMPTRating_PM,PROMPTRating_M,PROMPTRating_T ORDER BY A.PCODE)RN
	  INTO #T
FROM dbo.StgAssessment A 
LEFT JOIN cte
ON A.PCODE=cte.PCODE and A.AssessmentDate=CTE.ReviewDate
WHERE A.AssessmentDate<= GETDATE()
	  AND A.PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8046,8040,8255,8011,8231,8379,8411,8494,8044,8355)--26 Test Pcodes  
	  AND (CTE.PROMPTRating_P IS NOT NULL AND CTE.PROMPTRating_R IS NOT NULL AND CTE.PROMPTRating_O IS NOT NULL AND
	       CTE.PROMPTRating_PM IS NOT NULL or CTE.PROMPTRating_M IS NOT NULL AND CTE.PROMPTRating_T IS NOT NULL) 
ORDER BY 1,2 DESC
  
--SELECT * INTO StgOADRatingsandLOB_PROMPT
--FROM(  
SELECT pcode,AssessmentDate, PROMPTRating_P,PROMPTRating_R, PROMPTRating_O,PROMPTRating_PM, PROMPTRating_M, PROMPTRating_T
	  ,HomeOwnershipPreservationServices, HomeOwnershipPromotion, CommunityBuildingandEngagement, PropertyManagement
	  ,RealEstateDevelopment, LendingandLoanPortfolio, OtherServices
FROM #T
WHERE RN = 1
--) AS N
DROP TABLE #T



  
  
  
  
  
 
 

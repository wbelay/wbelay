--SELECT * INTO StgMOU
--FROM 
--(
SELECT a.[PCODE]
      ,a.[MOUStartDate]
      ,a.[MOUExpirationDate]
      ,REPLACE([dbo].[udf_StripHTML]([MOUDescription]),'CHAR(13) + CHAR(10)','')AS [MOUDescription]
      ,[dbo].[udf_StripHTML]([MOUTopic])AS [MOUTopic]
      ,'' AS CreatedBy
      ,'' AS CreatedDate
      ,'' AS ModifiedBy
      ,'' AS ModifiedDate
      ,dbo.fn_BooleanToYN(a.MOUCreated) AS IsClosed  --- flag showing MoU closed or not
  FROM [HARP].[dbo].[tblMOU] as a
  WHERE YEAR(MOUStartDate)>=2009
		AND PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
--) AS N
	
	
	

	

	
	
	
USE HARP
GO

WITH cte
AS 
(
SELECT distinct dt.*
		   ,REPLACE(os.ProductionProgramServicesText,'Meet','Met') AS PROMPTRating_P
		   ,REPLACE(os.ResourceManagementText,'Meet','Met') AS PROMPTRating_R
		   ,REPLACE(os.OrganizationalManagementText,'Meet','Met') AS PROMPTRating_O
		   ,REPLACE(os.PersonnelManagementText,'Meet','Met') As PROMPTRating_M 
		   ,REPLACE(os.PlanningText,'Meet','Met') AS PROMPTRating_PM  
		   ,REPLACE(os.TechnicalOperationsSystemsText,'Meet','Met') AS PROMPTRating_T 
			   
      ,ISNULL(CASE dt.Division 
              WHEN 'Field' THEN tr.FieldRating
              WHEN 'OAD' THEN tr.OADRating
              WHEN 'NI' THEN tr.NIRating
              WHEN 'NFMC' THEN tr.NFMCRating 
              WHEN 'NHP' THEN tr.NHPRating
              ELSE tr.NREPRating
              END,'') AS RatingRecommendation
            
      ,ISNULL(CASE dt.Division 
              WHEN 'Field' THEN tr.FieldWatchRecommENDation
              WHEN 'OAD' THEN tr.OADWatchRecommENDation
              WHEN 'NI' THEN tr.NIWatchRecommENDation
              WHEN 'NFMC' THEN tr.NFMCWatchRecommENDation 
              WHEN 'NHP' THEN tr.NHPWatchRecommENDation
              ELSE tr.NREPWatchRecommENDation
              END,'') AS WatchRecommENDation
    
FROM (
	   SELECT R.PCODE
	          --,CONVERT(VARCHAR(20),F.[Review Date], 101) AS ASsessementDate
	         ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	         ,CASE WHEN FieldRating IS NOT NULL AND FieldWatchRecommENDation IS NOT NULL THEN 'Field'
	               WHEN OADRating IS NOT NULL AND  OADWatchRecommENDation IS NOT NULL THEN 'OAD' 
	               WHEN NIRating IS NOT NULL AND  NIWatchRecommENDation IS NOT NULL THEN 'NI' 
	               WHEN NFMCRating IS NOT NULL AND  NFMCWatchRecommENDation IS NOT NULL THEN 'NFMC' 
	               WHEN NHPRating IS NOT NULL AND  NHPWatchRecommENDation IS NOT NULL THEN 'NHP' 
	               WHEN NREPRating IS NOT NULL AND  NREPWatchRecommENDation IS NOT NULL THEN 'NREP' 
	         END AS Division
	        , ModifiedBy
	        ,CONVERT(VARCHAR(20),ModifiedDate ,101)AS ModifiedDate
        FROM dbo.tblRatingDetail R
--JOIN dbo.stgFindings F
--ON F.pcode = R.PCODE
        WHERE (FieldRating IS NOT NULL AND FieldWatchRecommENDation IS NOT NULL and OADRating IS NOT NULL AND OADWatchRecommENDation IS NOT NULL
               AND NIRating IS NOT NULL AND  NIWatchRecommENDation IS NOT NULL and NFMCRating IS NOT NULL AND  NFMCWatchRecommENDation IS NOT NULL 
               AND NHPRating IS NOT NULL AND  NHPWatchRecommENDation IS NOT NULL and NREPRating IS NOT NULL AND  NREPWatchRecommENDation IS NOT NULL)
               --AND F.[Review Date] IS NOT NULL
              ) AS dt 
         INNER JOIN tblRatingDetail tr
         ON dt.PCODE = tr.PCODE
      --) 
		 JOIN  dbo.tblOnSiteRatings  OS
		 ON OS.PCODE = dt.PCODE
    ) 
SELECT  DISTINCT *
FROM cte 
WHERE cte.RatingRecommendation != '' and cte.WatchRecommENDation != ''
--AND PCODE = 8300


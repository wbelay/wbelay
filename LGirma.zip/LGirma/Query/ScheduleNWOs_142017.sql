SELECT DISTINCT O.PCODE
	   ,SUBSTRING(O.DistrictName,1, CHARINDEX(' ',O.DistrictName+' ')-1) AS Region
	   ,O.Name, O.CharterDate, FiscalYear AS AuditYear, CAST([AUDITDUE] AS DATE) AS AuditDue 
	   ,(SELECT DATENAME(MONTH,DATEADD(MONTH,(MAX(MONTH(A.ReviewDate))),0)-1) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=2) AS [Default PRO MO]
	   ,'' AS Comments
	   ,CASE WHEN AC.Received =1 THEN 'True' 
			 WHEN AC.Received =0 THEN 'False' END AS AuditRecived
	   ,CAST([Received Date] AS DATE) AS [Audit Recived Date]
	   ,CAST([DateEligible] AS DATE) AS [Audit Reviewed Date]
	   ,'' AS FinancialAnalysisComplitionDate 
	   ,[MAStaff] AS [CPA Assigned]
	   ,O.RMName AS [Relationship Manager]
	   ,'' AS OHTSRating
	   ,'' AS WatchList
	   ,'' AS NextOnsiteReviewDate
	   ,(SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=1) AS [Last Onsite Review Date]
	   ,''OnSitePPS
	   ,''OnsiteRMFM
	   ,''OnsiteOMBG
	   ,''OnsiteCA
	   ,''OnsiteAFI
	   ,(SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=2) AS [Last PROReview Date]
	   ,''PROPPS
	   ,''PROMFM
	   ,''PROOMBG
	   ,CASE WHEN (SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=1)>(SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=2) THEN 'OnSite'
			 WHEN (SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=1)<(SELECT MAX(A.ReviewDate) FROM tblAssessment A WHERE O.PCODE = A.PCODE AND A.ReviewType=2) THEN 'PRO' END AS MostRecentReview
FROM [dbo].[tblOrganization] O
LEFT JOIN [dbo].[tblScheduleAssessment] S
ON O.PCODE = S.PCODE
LEFT JOIN [HARP].[dbo].[tblAuditCompliance] AC
ON O.PCODE = AC.PCODE
WHERE AC.FiscalYear = 2014 and S.ScheduleNotes is not null
GROUP BY O.PCODE, O.DistrictName, O.Name, O.CharterDate, S.AuditReceivedDate, O.RMName, O.WatchListStartDate,FiscalYear
        ,[AUDITDUE] ,[MAStaff],[DateEligible] ,[Received Date],Received
		

/*Field not found
Comments, Financial Analysis, Completion Date, OHTS Rating, Next Onsite ReviewDate
Onsite PPS, Onsite RMFM, Onsite OMBG, Onsite CA, Onsite AFI, PRO PPS, PRO OMBG*/
With cte AS (
SELECT CORE.PCODE
		, CORE.ReviewType
		, CORE.AssessmentDate
		, CORE.MeetingDate
		, CASE 
			WHEN CORE.AssignedTo IS NULL THEN ASG.Leader 
			ELSE CORE.AssignedTo 
		   END AS AssignedTo, CORE.CreatedBy, CORE.CreatedDate
                ,rn=ROW_NUMBER() OVER (PARTITION BY CORE.PCODE,CORE.AssessmentDate ORDER BY ABS (DATEDIFF(day,CORE.AssessmentDate,CORE.MeetingDate)) ASC) 
FROM
(SELECT  r.PCODE AS PCODE
        , case 
            when r.ReviewFlag = 'Y' then 'On-Site'
            when r.ReviewPROFlag = 'Y' then 'Off-Site'
            when r.AuditReviewFlag = 'Y' then 'Audit Review'
            when r.OthersFlag = 'Y' then 'Other'
            else '' 
          end as ReviewType
        , CONVERT(varchar(20), Max(OFR.ReviewDate), 101) AS AssessmentDate
        , CONVERT(varchar(20), r.MeetingDate, 101) AS MeetingDate 
        ,  rd.OADReviewerName AS AssignedTo
        , '' AS CreatedBy
        , '' AS CreatedDate
FROM tblRating r
LEFT JOIN tblRatingDetail rd
   ON rd.PCODE = r.PCODE AND rd.MeetingDate 
   = r.MeetingDate
Left Join dbo.OnOffSiteReviews OFR
	ON (r.PCODE = OFR.PCODE AND (case 
            when r.ReviewFlag = 'Y' then 'On-Site'
            when r.ReviewPROFlag = 'Y' then 'Off-Site'
            when r.AuditReviewFlag = 'Y' then 'Audit Review'
            when r.OthersFlag = 'Y' then 'Other'
            else '' 
          end) = OFR.ReviewType)
                        
WHERE OFR.ReviewDate <= r.MeetingDate
	  AND YEAR(r.MeetingDate) != 2050
	  AND YEAR(OFR.ReviewDate) != 2050
	  --AND r.MeetingDate <= GETDATE()
      AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
GROUP BY r.PCODE, r.MeetingDate, r.ReviewFlag, r.ReviewPROFlag, r.AuditReviewFlag, r.OthersFlag,  rd.OADReviewerName, ReviewType) CORE
LEFT OUTER JOIN dbo.OnOffSiteReviews ASG
	ON CORE.PCODE=ASG.PCODE AND CORE.ReviewType=ASG.ReviewType AND CORE.AssessmentDate=ASG.ReviewDate
WHERE CORE.PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
)
SELECT cte.PCODE
	   ,cte.ReviewType
	   ,AssessmentDate
       ,MeetingDate 
	   ,cte.AssignedTo
	   ,cte.CreatedBy
	   ,cte.CreatedDate 
FROM cte where rn=1
--order by assessmentdate desc

UNION

SELECT [PCODE]
      ,[ReviewType]
      ,CONVERT(VARCHAR(20),[ReviewDate],101) AS AssessmentDate
      ,''
      ,''
      ,''
      ,''
FROM [HARP].[dbo].[OnOffSiteReviews]
WHERE ReviewDate>=GETDATE()
--ORDER BY AssessmentDate DESC

--select pcode,[RacDate] 
--from stgFindings
--where [RacDate]not in(select AssessmentDate from Assessment ) and racdate>=GETDATE()
--order by [RacDate] desc
SELECT *
FROM
(
SELECT a.PCODE
	  ,a.MeetingDate
FROM dbo.stgAssessment_MeetingDate a
LEFT JOIN dbo.stgCurrentRatings c
ON a.PCODE = c.PCODE
LEFT JOIN dbo.StgEarlyAlert e
ON a.PCODE = e.PCODE
LEFT JOIN dbo.stgRiskObserved r
ON a.PCODE = r.PCODE
LEFT JOIN dbo.StgRatingsandLOB rl
ON a.PCODE = rl.PCODE
LEFT JOIN dbo.StgSummaryUpdates s
ON a.PCODE = s.PCODE
)P
PIVOT
(
COUNT(MEETINGDATE)
FOR PCODE IN
([8198],[8149],[8523],[8328],[8272],[8187],[8070],[8342],[8372],[8205],[8300],[8308],[8274],[8425],[8528])
)pvt
SELECT pcode
	  ,FC.[Type] AS FindingGroup
	  ,FC.Category AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(F.MeetingDate AS DATE) AS FindingDate
	  ,[dbo].[udf_StripHTML](F.Finding) AS FindingDescription---chk
	  ,F.OAD AS OADRecommendation
	  ,F.Field AS FieldRecommendation
	  ,F.ClosedFlag AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,'' AS FieldResolutionComments
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE F.[Pcode] in ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')

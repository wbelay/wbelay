

WITH CTE
AS
(
SELECT OS.PCODE,OS.ReviewDate,'1' AS [TYPE]
FROM dbo.tblOnSiteReviewLineOfBusiness OS
WHERE YEAR(ReviewDate)>2009 
AND ReviewDate<= GETDATE()

UNION ALL

SELECT O.PCODE, O.ReviewDate,'2' AS [TYPE]
FROM dbo.tblOnSiteReview O
WHERE YEAR(ReviewDate)>2009 
AND ReviewDate<= GETDATE()
)
SELECT PCODE,ReviewDate,[type],COUNT(TYPE) AS [MinCount] 
into #t
FROM CTE 
GROUP BY PCODE, ReviewDate,[type]
HAVING COUNT(TYPE)<2

select PCODE,ReviewDate,[type]
from #t

drop table #t



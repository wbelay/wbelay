SELECT  r.PCODE AS PCODE --N
        ,CONVERT(varchar(20), tblProRating.ReviewDate, 101) AS ReviewDate    ----tblProRating is not present in the current HARP database 
        --,CONVERT(varchar(20), r.MeetingDate, 101) AS MeetingDate --N
        ,case 
            when r.ReviewFlag = 'Y' then 'On-Site Review'
            when r.ReviewPROFlag = 'Y' then 'Off-Site Review'
            when r.AuditReviewFlag = 'Y' then 'Audit Review'
            when r.OthersFlag = 'Y' then 'Other'
         else '' 
              end as ReviewReason --ReviewType must filter for on-site/off-site reviews only
         ,rd.OADReviewerName AS AssignedTo
            
FROM tblRating r
--seperate pass for review date
LEFT JOIN tblRatingDetail rd
      ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate
LEFT JOIN (
            SELECT PCODE
            , CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1') AS ReviewDate, 
            ProductionProgramServicesDescription AS P_Text, ResourceFinancialManagementDescription AS R_Text, OrganizationalManagementDescription AS O_Text  
            FROM tblOffSiteRating 
            UNION All 
            SELECT PCODE, ReviewDate, ProductionProgramServicesText, ResourceManagementText, OrganizationalManagementText FROM tblOnSiteRatings
           )tblProRating 
ON tblProRating.PCODE = r.PCODE AND tblProRating.ReviewDate = 
(SELECT MAX(ReviewDate) 
 FROM (
        SELECT PCODE, CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1') AS ReviewDate
        FROM tblOffSiteRating 
        --where CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1')  < Getdate()
        UNION All 
        SELECT PCODE, ReviewDate
        FROM tblOnSiteRatings 
        where ReviewDate < Getdate()
       ) AS tblLatestProRating WHERE tblLatestProRating.PCODE = r.PCODE
)
                        
WHERE tblProRating.ReviewDate <= r.MeetingDate
            AND r.MeetingDate <= GETDATE()
            AND r.PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8255,8011)  
            --AND r.PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
            --AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
            
ORDER BY 2,3 ASC

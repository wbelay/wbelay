/*SQL code to produce Resdential Loan Portfolio and Delinquencies graph on OHTS report
We use fact_RLF_Portfolio_Status, dim_Organization tables*/
--=============================================================================
SELECT DISTINCT PCode
	  ,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	  ,CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [FirstMortgageNumberOfOutstandingRLFLoans]
	  ,CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [FirstMortgageAmountOfOutstandingRLFLoans]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans30to59DaysDelinquent]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans60to89DaysDelinquent]
	  ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [FirstMortgageNumberOfRLFLoans90+DaysDelinquent]
      ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [FirstMortgageAmountOfRLFLoans90DaysPlusDelinquent]
      ,CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [SubMortgageNumberOfOutstandingRLFLoans]
	  ,CONVERT(MONEY, [Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [SubMortgageAmountOfOutstandingRLFLoans]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans30to59DaysDelinquent]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans60to89DaysDelinquent]
      ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans90+DaysDelinquent] 
      ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans90+DaysDelinquent]
	  ,CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [1st% of $ 90+ Delinquent]
	  ,CONVERT(DECIMAL(4,3),[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [2nd% of $ 90+ Delinquent]    
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
WHERE PCODE IS NOT NULL
--ORDER BY PCODE ASC

  
 






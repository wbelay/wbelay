
SELECT A.PCODE, A.ReviewType, A.AssessmentDate,
(SELECT MIN(M.MeetingDate) 
from StgAssessment_MeetingDate M INNER Join StgAssessment X on M.Pcode=X.Pcode and m.AssessmentDate=X.AssessmentDate 
where A.AssessmentDate<=M.MeetingDate and  M.PCODE=A.PCODE) AS MeetingDate
,'SwitchBoardImport' AS CreatedBy
,CONVERT(VARCHAR(10),GETDATE(),101) AS CreatedDate
, case when am.DeferredFlag IS NULL THEN 'N' END AS DeferredFlag
--INTO #t
FROM dbo.StgAssessment A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode AND A.AssessmentDate=AM.AssessmentDate
WHERE AM.PCODE IS NULL and A.AssessmentDate IS NOT NULL AND A.AssessmentStatus='Complete'

--INSERT INTO StgAssessment_MeetingDate_Test (pcode,AssessmentDate,MeetingDate,CreatedBy,CreatedDate,DeferredFlag)
--SELECT pcode,assessmentdate,meetingdate,CreatedBy,CreatedDate,DeferredFlag
--FROM #t t


--DROP TABLE #t
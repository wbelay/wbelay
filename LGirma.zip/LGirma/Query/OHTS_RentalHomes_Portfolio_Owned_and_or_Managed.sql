/*SQL code to produce Rental Homes Portfolio, Owned and/or Managed graph on OHTS report
We use agg_Comprensive, dim_Organization tables*/
--=============================================================================
SELECT PCode
      ,LEFT(C.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	  ,[Rental_Homes_Portfolio_Owned]
	  ,[Rental_Homes_Portfolio_Managed_Not_Owned]
FROM [DataWarehouse].[dbo].[agg_Comprehensive] C
LEFT JOIN [dbo].[dim_Organization] O
ON C.dim_Organization_key = O.dim_Organization_key

--SELECT * INTO StgOrphan
--FROM(
SELECT  C.*
FROM [dbo].[StgCurrentRating_112216] C 
LEFT JOIN [HARP].[dbo].[StgCurrentRating] R
ON C.Pcode=R.Pcode and C.MeetingDate=R.Meetingdate
WHERE R.PCODE IS NULL
--ORDER BY C.pcode, C.meetingdate DESC
--) AS N

--SELECT DISTINCT O.PCODE, MAX(O.MeetingDate)AS MeetingDate ,ONF.ReviewDate
--FROM StgOrphan O
--LEFT JOIN dbo.OnOffSiteReviews ONF
--ON O.PCODE = ONF.PCODE 
--WHERE ONF.ReviewDate<= O.MeetingDate
--GROUP BY O.PCODE, ONF.ReviewDate
--ORDER BY O.PCODE

SELECT DISTINCT 
O.PCODE, Max(ReviewDate) as ReviewDate,O.MeetingDate
FROM StgOrphan O
LEFT JOIN dbo.OnOffSiteReviews ONF
ON O.PCODE = ONF.PCODE 
WHERE ONF.ReviewDate<= O.MeetingDate
GROUP BY O.PCODE,O.MeetingDate
order by pcode,O.meetingdate




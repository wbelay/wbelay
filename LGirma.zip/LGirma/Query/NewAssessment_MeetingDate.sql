SELECT  r.PCODE AS PCODE
        , CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        , CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
		,'SwitchBoardImport' AS CreatedBy
        ,CAST(GETDATE() AS DATE) AS CreatedDate
FROM tblRating r
LEFT JOIN dbo.OnOffSiteReviews OFR
	ON r.PCODE = OFR.PCODE                      
WHERE OFR.ReviewDate <= r.MeetingDate
	  AND r.MeetingDate <= GETDATE()
      AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y')
      AND R.PCODE IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
GROUP BY r.PCODE, r.MeetingDate
ORDER BY r.PCODE, r.MeetingDate 

SELECT DISTINCT O.PCODE, SUBSTRING(O.DistrictName,1, CHARINDEX(' ',O.DistrictName+' ')-1) AS Region, 
		O.Name, O.CharterDate, FiscalYear AS AuditYear, CAST([AUDITDUE] AS DATE) AS AuditDue 
	   ,CASE WHEN A.ReviewType=2 THEN DATENAME(MONTH,DATEADD(MONTH,(MAX(MONTH(A.ReviewDate))),0)-1)END AS [Default PRO MO]
	   ,'' AS Comments
	   ,CASE WHEN AC.Received =1 THEN 'True' 
			 WHEN AC.Received =0 THEN 'False' END AS AuditRecived
	   ,CAST([Received Date] AS DATE) AS [Audit Recived Date]
	   ,CAST([DateEligible] AS DATE) AS [Audit Reviewed Date]
	   ,'' AS FinancialAnalysisComplitionDate 
	   ,[MAStaff] AS [CPA Assigned]
	   ,O.RMName AS [Relationship Manager]
	   ,'' AS OHTSRating
	   ,'' AS WatchList
	   ,'' AS NextOnsiteReviewDate
	   ,CASE WHEN A.ReviewType=1 THEN MAX(A.ReviewDate) END AS [Last Onsite Review Date]
	   ,''OnSitePPS
	   ,''OnsiteRMFM
	   ,''OnsiteOMBG
	   ,''OnsiteCA
	   ,''OnsiteAFI
	   ,CASE WHEN A.ReviewType=2 THEN MAX(A.ReviewDate) END AS [Last PROReview Date]
	   ,''PROPPS
	   ,''PROMFM
	   ,''PROOMBG
	   ,''MostRecentReview
FROM [dbo].[tblOrganization] O
LEFT JOIN [dbo].[tblScheduleAssessment] S
ON O.PCODE = S.PCODE
LEFT JOIN tblAssessment A
ON O.PCODE=A.PCODE 
LEFT JOIN [HARP].[dbo].[tblAuditCompliance] AC
ON O.PCODE = AC.PCODE
WHERE AC.FiscalYear = 2014 AND O.PCODE = 3015
GROUP BY O.PCODE, O.DistrictName, O.Name, O.CharterDate, S.AuditReceivedDate, O.RMName, O.WatchListStartDate,FiscalYear,A.ReviewType
        ,[AUDITDUE] ,[MAStaff],[DateEligible] ,[Received Date],Received


	     

/*Field not found
Comments, Audit Recived, Financial Analysis, Completion Date, OHTS Rating, Next Onsite ReviewDate
Onsite PPS, Onsite RMFM, Onsite OMBG, Onsite CA, Onsite AFI, PRO PPS, PRO OMBG*/
CREATE PROCEDURE Create_All_Staging_Tables
AS 
BEGIN

--&&&&&&&&&&&&&&&&&&& StgOrganization &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
 
 /*SQL code to produce conversion file StgOrganization*/
SELECT * INTO StgOrganization
FROM(
SELECT [PCODE]
	  ,[DistrictName]
      ,[Name]
      ,[PresidentCEOName] AS EDName
      ,[BusEmail] AS EDEmailAddress
      ,[CharterDate]
      ,CASE 
		WHEN LEN([FiscalYearEndMonthAndDay])= 3
		THEN LEFT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),1) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),2)
        ELSE LEFT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2)
        END AS [FiscalYearEndMonthAndDay] 
      ,[City]
      ,[State]
      ,[RMName]
      ,[RMTitle]
      ,[OrgStatusName]
      ,[StreetAddrLine1]
      ,[StreetAddrLine2]
      ,[StreetAddrLine3]
      ,[StreetAddrZipCode]
      ,[BusPhone]
      ,[BusFax]
      ,[DateIncoporated]
      ,[MeetingDateID]
      ,[DateOrganizationDisaffiliated]
FROM [HARP].[dbo].[tblOrganization]
) AS N;
 
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& StgExcludedNWOs &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce exclude pcodes list from migration*/
SELECT * INTO StgExcludedNWOs
FROM
(
SELECT CASE WHEN PCODE IS NOT NULL THEN PCODE
			ELSE(SELECT [Pcodes to exclude from data migration] FROM dbo.ExcludedXLS2016) END AS PCODE
	  ,CASE WHEN OrgStatusName LIKE 'Disaffiliation' THEN 'Disaffiliation'
			WHEN OrgStatusName LIKE'Suspended' THEN 'Suspended'
			ELSE 'OHTS 3/17' END AS ExcludedReason	  ,[DistrictName]	  ,[Name]	  ,[PresidentCEOName]	  ,[CharterDate]	  ,CASE 
		WHEN LEN([FiscalYearEndMonthAndDay])= 3
		THEN LEFT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),1) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay] AS VARCHAR(10)),2)
        ELSE LEFT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2) + '/'+ RIGHT(CAST([FiscalYearEndMonthAndDay]AS VARCHAR(10)),2)
        END AS [FiscalYearEndMonthAndDay]       ,[City]      ,[State]      ,[Title]      ,[RMName]      ,[RMTitle]      ,[OrgStatusName]      ,[StreetAddrLine1]      ,[StreetAddrLine2]      ,[StreetAddrLine3]      ,[StreetAddrZipCode]      ,[BusPhone]      ,[BusFax]      ,[BusEmail]      ,[DateIncoporated]      ,[MeetingDateID]      ,[DateOrganizationDisaffiliated]      ,[ED_Name]      ,[OrgEmail]
      ,[Org_Phone]
FROM tblOrganization
WHERE PCODE IN(SELECT [Pcodes to exclude from data migration] FROM dbo.ExcludedXLS2016)OR(OrgStatusName LIKE 'Disaffiliation' OR OrgStatusName LIKE 'Suspended')
) AS N ;

--&&&&&&&&&&&&&&&&&&&&&&&&&& StgAssessment Table &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce conversion file Assessment*/
WITH CTE
AS
(
SELECT PCODE 
	  ,CAST(ReviewDate AS DATE) AS ReviewDate
	  ,ReviewType
	  ,Leader AS AssignedTo
	  ,'' AS RN
FROM OnOffSiteReviews o
WHERE (reviewdate>getdate() and leader is not null) OR (reviewdate<getdate()) 
	  AND YEAR(ReviewDate)>=2009
	  AND ReviewType = 'On-Site'
	   	  
UNION ALL

SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,MAX(rd.OADReviewerName)AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR),r.ReviewPROFlag ORDER BY OFS.PCODE)RN
FROM dbo.tblOffSiteRating OFS
LEFT JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	  CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND  r.ReviewPROFlag = 'Y'
	  AND CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)<=GETDATE()
GROUP BY OFS.PCODE,OFS.FiscalMonth,OFS.FiscalYearYear,R.ReviewPROFlag
)
SELECT * INTO StgAssessment
FROM(
SELECT PCODE
	  ,ReviewDate AS AssessmentDate
	  ,ReviewType
	  ,AssignedTo
	  ,CASE WHEN CTE.PCODE IN (SELECT CTE.PCODE FROM [dbo].[tblOHTSMeeting] r WHERE cte.pcode=r.pcode and cte.ReviewDate<=r.meetingDate)
		THEN 'Complete' ELSE 'Current' END AS AssessmentStatus	
	  ,'History' AS RecordStatus----History is the default Value
	  ,CASE WHEN ReviewType = 'Off-Site' THEN '2000-01-01' ELSE '' END AS FinalReportApprovedDate
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate 
FROM CTE
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND YEAR(ReviewDate)<'2018'
	  AND PCODE IN(SELECT PCODE FROM tblOrganization)
	   
) AS N 
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& Update StgAssessment Table after it's created &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE IN (SELECT PCODE FROM StgAssessment_MeetingDate
				WHERE DeferredFlag = 'Y' and StgAssessment.AssessmentDate=StgAssessment_MeetingDate.AssessmentDate)-- we comment this update statment because business told us not to update 
																													to current when deferredflag is 'Y' */

--UPDATE dbo.StgAssessment 
--SET AssessmentStatus= 'Current'
--WHERE PCODE =8046 and AssessmentDate = '2016-06-20'

--UPDATE dbo.StgAssessment 
--SET RecordStatus = 'OADDraftReport'---Default value is History
--WHERE AssessmentStatus = 'Current' 

--UPDATE dbo.StgAssessment
--SET AssignedTo = 'Promptoadreviewer1'
--WHERE AssessmentStatus = 'Current'

--ALTER TABLE dbo.StgAssessment
--ALTER COLUMN RecordStatus text

--ALTER TABLE dbo.StgAssessment_MeetingDate
--ALTER COLUMN MeetingDate DATE

--UPDATE dbo.StgAssessment
--SET  FinalReportApprovedDate = '2000-01-01'
--WHERE AssessmentStatus = 'Complete' AND CONVERT(NVARCHAR(MAX),RecordStatus) <> N'OADDraftReport'

--&&&&&&&&&&&&&&&&&&&&&&&&&& StgAssessment_MeetingDate Table &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce conversion file Assessment_MeetingDate*/
-- Changes on 20161104  a) Exclude Reviews in process 
--                      b) No longer use future OHTS meeting dates from tblrating since only send at closed OHTS
--                      c) Allow review date .eq. to meetingdate
--
SELECT OS.PCODE 
         ,CONVERT(VARCHAR(10),MAX(AssessmentDate),101) AS AssessmentDate
         ,CONVERT(VARCHAR(10),MeetingDate,101)  AS MeetingDate
         ,'SwitchBoardImport' AS CreatedBy
         ,CONVERT(VARCHAR(10),GETDATE(),101) AS CreatedDate
         ,CASE WHEN OS.PCODE IN(SELECT PCODE--MeetingDate,ActionsFromOHTSMeetingSummary
								FROM [HARP].[dbo].[tblOHTSMeeting]
								WHERE ActionsFromOHTSMeetingSummary like '%defer%' AND PCODE<>8271 
									  AND meetingdate=r.meetingdate AND meetingdate=(SELECT MAX(meetingdate)FROM [HARP].[dbo].[tblOHTSMeeting]))THEN 'Y'
		  ELSE 'N' END AS DeferredFlag 
         INTO #T
FROM [dbo].[tblOHTSMeeting] r---We make it primary table to get rid of null
LEFT OUTER JOIN dbo.StgAssessment OS--JOIN TO GET ASSESSMENTDATE
ON r.PCODE = OS.PCODE AND OS.AssessmentDate <= R.MeetingDate
LEFT Outer JOIN [dbo].[OnOffSiteReviews] SB 
ON OS.Pcode = SB.PCODE AND OS.AssessmentDate = SB.ReviewDate AND OS.ReviewType = SB.ReviewType
WHERE OS.PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
        AND SB.InProcess <> 1  
             
GROUP BY OS.PCODE,MeetingDate,CAST(R.ActionsFromOHTSMeetingSummary AS NVARCHAR),SB.InProcess
SELECT * INTO StgAssessment_MeetingDate
FROM(
SELECT *
FROM #T 
)AS N
DROP TABLE #T

--&&&&&&&&&&&&&&&&&&&&&&&&&&&& StgCurrentRating &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce conversion file CurrentRating*/
SELECT * INTO StgCurrentRating
FROM(
SELECT M.PCODE AS PCODE
      ,r.CurrentRatingText AS FinalOHTSRecommendation 
      ,A.MeetingDate
      ,CASE WHEN r.WatchFlag = 'N' THEN NULL
		    WHEN r.WatchFlag = 'Y' AND r.OnWatchListSinceDate IS NULL THEN r.MeetingDate
		    ELSE r.OnWatchListSinceDate END AS WatchListStartDate
      ,r.ProvisionalCharterFlag AS ProvisionalCharterStatus 
      ,CASE WHEN r.ProvisionalCharterFlag = 'N' THEN NULL
			WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NOT NULL THEN r.ProvisionalStartDate 
			WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate < r.MeetingDate THEN P.MinProvisionalStartDate
            WHEN r.ProvisionalCharterFlag = 'Y' AND (r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate IS NULL AND P.MaxProvisionalStartDate< r.MeetingDate) THEN P.MaxProvisionalStartDate
            ELSE r.MeetingDate END AS ProvisionCharterStatusDate
FROM tblOHTSMeeting M
INNER JOIN tblRating r 
ON M.PCODE=R.PCODE AND M.MeetingDate = R.MeetingDate
INNER JOIN dbo.StgAssessment_MeetingDate A
ON M.PCODE = A.PCODE AND M.MeetingDate = A.MeetingDate
LEFT JOIN dbo.view_ProvisionalStartDate P
ON P.PCODE = r.PCODE
WHERE YEAR(r.MeetingDate)>2009
	  AND r.PCODE NOT IN (SELECT PCODE FROM dbo.StgExcludedNWOs)
GROUP BY M.PCODE, r.CurrentRatingText, R.MeetingDate, A.MeetingDate, r.WatchFlag, r.OnWatchListSinceDate, r.ProvisionalCharterFlag, r.ProvisionalStartDate, P.MinProvisionalStartDate, P.MaxProvisionalStartDate
) AS N;
 
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& StgDivisionRatings &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce conversion file DivisionRatings*/
WITH CTE 
AS(
	SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		   ,CASE				
			    WHEN FieldRating IS NOT NULL OR FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
			END AS Division		   
		   ,CASE 				
				WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
			END AS RatingRecommendation		    
		   ,CASE 				
			     WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			 END AS WatchListRecommendation		   
			,ModifiedBy		   
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  	                       
	UNION
	                       
	  SELECT R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				 WHEN OADRating IS NOT NULL OR OADWatchRecommendation IS NOT NULL THEN 'OAD' 
			 END AS Division
		    ,CASE 
				  WHEN 'OADRating' IS NOT NULL THEN OADRating
			  END AS RatingRecommendation
			 ,CASE 
				  WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
			  END AS WatchListRecommendation
			 ,ModifiedBy
			 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	   FROM dbo.tblRatingDetail R
	   
	UNION
					
	    SELECT R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				   WHEN NIRating IS NOT NULL OR NIWatchRecommendation IS NOT NULL THEN 'NI' 
			   END AS Division
			  ,CASE 
				   WHEN 'NIRating' IS NOT NULL THEN NIRating
			   END AS RatingRecommendation
			  ,CASE 
				   WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			   END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
							
	UNION
					
	    SELECT R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				   WHEN NFMCRating IS NOT NULL OR NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			   END AS Division
			  ,CASE 
				   WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
				END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		 FROM dbo.tblRatingDetail R
		 
	UNION

		SELECT R.PCODE
			   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	   ,CASE 
				   WHEN NHPRating IS NOT NULL OR NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			   END AS Division
			   ,CASE 
				   WHEN 'NHPRating' IS NOT NULL THEN NHPRating
			   END AS RatingRecommendation
			   ,CASE 
				   WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			   END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		
	UNION

		SELECT R.PCODE
			   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN NREPRating IS NOT NULL OR NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
				END AS Division
			   ,CASE 
					WHEN 'NREPRating' IS NOT NULL THEN NREPRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
				END AS WatchListRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
	)
SELECT * INTO StgDivisionRatings
FROM(
SELECT A.PCODE
	  ,A.MeetingDate
	  ,CTE.Division
	  ,CTE.RatingRecommendation
	  ,CTE.WatchListRecommendation
	  ,CTE.ModifiedBy
	  ,CTE.ModifiedDate
FROM dbo.StgAssessment_MeetingDate A 
LEFT JOIN  CTE
ON A.PCODE=CTE.PCODE AND A.Meetingdate = CTE.MeetingDate 
WHERE RatingRecommendation IS NOT NULL AND RatingRecommendation!=''
AND A.PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
)N;
			
--&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& StgOADRatingandLOB_PROMPT &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

/*SQL code to produce conversion file OADRatingandLOB_PROMPT*/
WITH CTE 
AS 
(
	SELECT  os.PCODE
			,os.ReviewDate
			,os.ProductionProgramServicesText AS PROMPTRating_P
			,os.ResourceManagementText AS PROMPTRating_R
			,os.OrganizationalManagementText AS PROMPTRating_O
			,os.PersonnelManagementText AS PROMPTRating_M
			,os.PlanningText AS PROMPTRating_PM
			,os.TechnicalOperationsSystemsText AS PROMPTRating_T 
			,orv.HomeownershipPreservationFlag 
			,orv.HomeownershipPromotionServicesFlag 
			,orv.CommunityBuildingandOrganizingFlag 
			,orv.AssetAndPropertyManagementFlag
			,orv.RealEstateDevelopmentFlag 
			,orv.LendingandPortfolioManagementFlag 
			,orv.OtherServicesFlag
			,(SELECT Division FROM StgDivisionRatings WHERE Division = 'OAD')AS OADDivision 
	FROM dbo.tblOnSiteRatings OS
	LEFT OUTER JOIN [tblOnSiteReviewLineOfBusiness] ORV
	ON OS.PCODE = ORV.PCODE
	   AND OS.ReviewDate = ORV.ReviewDate
			 
UNION ALL 
			  
	  SELECT [PCODE]
             ,CAST([Month] AS varchar(12)) + '/' + '1' + '/' + CAST(FYear as varchar(6)) AS ReviewDate
			 ,CASE WHEN ProdRate = 1 THEN 'Exceed'
				   WHEN ProdRate = 3 THEN 'Meet' 
				   WHEN ProdRate = 5 THEN 'Fail' END AS PROMPTRating_P
			 ,CASE WHEN ResRate = 1 THEN 'Exceed'
				   WHEN ResRate = 3 THEN 'Meet' 
				   WHEN ResRate = 5 THEN 'Fail' END AS  PROMPTRating_R
		    ,CASE WHEN OMRate = 1 THEN 'Exceed'
				  WHEN OMRate = 3 THEN 'Meet' 
				  WHEN OMRate = 5 THEN 'Fail' END AS PROMPTRating_O
			,'' AS PROMPTRating_M
			,'' AS PROMPTRating_PM
			,'' AS PROMPTRating_T
			,dbo.fn_BooleanToYN(RE_Off) AS HomeonwhershipPreservationFlag
			,dbo.fn_BooleanToYN(HOME_Off) AS HomeownerhipPormotionServicesFlag
			,dbo.fn_BooleanToYN(CBE_Off) AS CommunityBuildingandOrganizingFlag
			,dbo.fn_BooleanToYN(PM_Off)AS AssetAndPropertyManagementFlag
			,dbo.fn_BooleanToYN(RED_Off)AS RealEstateDevelomentFlag
			,dbo.fn_BooleanToYN(LEND_Off)AS LendingandPortfolioManagementFlag
			,'' AS OtherServicesFlag
			,(SELECT Division FROM StgDivisionRatings WHERE Division = 'OAD')AS OADDivision
	 FROM [HARP].[dbo].[RiskFactorOAD]
			 
)
		   
SELECT A.PCODE
	  ,A.AssessmentDate
	  ,CTE.PROMPTRating_P AS PROMPTRating_P
	  ,CTE.PROMPTRating_R AS PROMPTRating_R
	  ,CTE.PROMPTRating_O AS PROMPTRating_O
	  ,CTE.PROMPTRating_PM AS PROMPTRating_PM
	  ,CTE.PROMPTRating_M AS PROMPTRating_M 
	  ,CTE.PROMPTRating_T AS PROMPTRating_T 
	  ,CTE.HomeownershipPreservationFlag  AS HomeOwnershipPreservationServices
      ,CTE.HomeownershipPromotionServicesFlag AS HomeOwnershipPromotion
      ,CTE.CommunityBuildingandOrganizingFlag  AS CommunityBuildingandEngagement
      ,CTE.AssetAndPropertyManagementFlag  AS PropertyManagement
      ,CTE.RealEstateDevelopmentFlag  AS RealEstateDevelopment
      ,CTE.LendingandPortfolioManagementFlag AS LendingandLoanPortfolio 
      ,CTE.OtherServicesFlag  AS OtherServices   
      ,ROW_NUMBER() OVER(PARTITION BY A.PCODE,A.AssessmentDate, PROMPTRating_P, PROMPTRating_R,PROMPTRating_O, PROMPTRating_PM,PROMPTRating_M,PROMPTRating_T ORDER BY A.PCODE)RN
	  INTO #T1
FROM dbo.StgAssessment A 
LEFT JOIN cte
ON A.PCODE=cte.PCODE AND A.AssessmentDate = CTE.ReviewDate
WHERE A.AssessmentDate <= GETDATE()
	  AND A.PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND (CTE.PROMPTRating_P IS NOT NULL AND CTE.PROMPTRating_R IS NOT NULL AND CTE.PROMPTRating_O IS NOT NULL AND
	       CTE.PROMPTRating_PM IS NOT NULL OR CTE.PROMPTRating_M IS NOT NULL AND CTE.PROMPTRating_T IS NOT NULL) 
ORDER BY 1,2 DESC
  
SELECT * INTO StgOADRatingsandLOB_PROMPT
FROM(  
SELECT pcode,AssessmentDate, PROMPTRating_P,PROMPTRating_R, PROMPTRating_O,PROMPTRating_PM, PROMPTRating_M, PROMPTRating_T
	  ,HomeOwnershipPreservationServices, HomeOwnershipPromotion, CommunityBuildingandEngagement, PropertyManagement
	  ,RealEstateDevelopment, LendingandLoanPortfolio, OtherServices
FROM #T1
WHERE RN = 1
) AS N
DROP TABLE #T1
			 
--***********************StgEarlyAlert********************************

/*SQL code to produce conversion file Early Alerts*/
SELECT * INTO StgEarlyAlert
FROM
(
SELECT   
       [PCODE]
      ,CASE WHEN CONVERT(VARCHAR(20),MeetingDate,101) = '01/01/2050' AND PCODE = 8487 THEN '12/16/2015'--we update the date'12/14/2015' to '12/16/2015'
       ELSE CONVERT(VARCHAR(20),MeetingDate,101)END AS MeetingDate
	  ,[dbo].[udf_StripHTML](IssueIdentified) AS [IssueIdentifiedDesc]
      ,[IssuedBy] AS [Division]
      ,[LastUpdate] AS [LastUpdateDesc]
      ,'' AS [ResolvedWhenDesc]
      ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed]--to be used as flag for reporting
      ,[CreatedBy]
      ,[CreatedDate]
      ,[ModifiedBy]
      ,[ModifiedDate]
FROM [HARP].[dbo].[tblEAROIssues]
WHERE [Type] = 'Early Alert'
	  AND PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
) AS N

---**************************StgFindings************************************

/*SQL code to produce conversion file Findings*/
SELECT pcode 
	   ,CASE WHEN MeetingDate >(select max(meetingdate)from tblOHTSMeeting) THEN NULL
			 WHEN  MeetingDate = '12/15/15' THEN '12/16/15'
		     WHEN MeetingDate IS NOT NULL AND MeetingDate NOT IN (SELECT meetingDate FROM dbo.tblOHTSMeeting OHTS 
		     WHERE F.PCODE=OHTS.PCODE AND F.MeetingDate=OHTS.meetingDate) THEN 
			 (SELECT MIN(meetingDate) FROM dbo.tblOHTSMeeting OHTS WHERE F.PCODE=OHTS.PCODE AND OHTS.meetingDate>F.MeetingDate)
			  ELSE CAST(MeetingDate AS DATE)---update 
	   END AS MeetingDate
	   ,'' AS AssessmentDate
	  ,FC.[Type] AS FindingGroup
	  ,CASE WHEN FC.ID = 5 THEN 'PL' ELSE FC.Category END AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(FindingDate AS DATE) AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,CASE WHEN F.closedflag = 1 AND (F.OAD IS NULL OR F.OAD = ' ') THEN 'Clear' 
	   ELSE F.OAD END AS OADRecommendation
	  ,CASE WHEN F.closedflag = 1 AND (F.Field IS NULL OR F.Field = ' ') THEN 'Keep'
	   ELSE F.Field END AS FieldRecommendation
	  ,dbo.fn_BooleanToYN(F.ClosedFlag) AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,REPLACE([dbo].[udf_StripHTML](Resolution),'CHAR(13) + CHAR(10)','') AS FieldResolutionComments
	  INTO #T2
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND Year(FindingDate)>=2009
	    
SELECT * INTO StgFinding
FROM
(
SELECT t.Pcode,t.MeetingDate,
	   CASE WHEN t.MeetingDate IS NULL 
                                 THEN (SELECT MAX(AssessmentDate) FROM StgAssessment B 
                                 WHERE t.pcode=B.PCODE AND B.AssessmentDate<=t.FindingDate) 
             ELSE (SELECT MAX(AssessmentDate) FROM StgAssessment_MeetingDate B 
                                 WHERE t.pcode=B.PCODE AND t.MeetingDate=B.MeetingDate)
         END AS Assessmentdate
         ,t.FindingGroup,t.FindingCategory,t.FindingType,t.FindingDate,t.FindingDescription,t.OADRecommendation
         ,t.Isclosed,t.CreatedBy,t.CreatedDate,t.ModifiedBy,t.ModifiedDate,t.TaskDescription,t.TaskCompleted
         ,t.OADResolutionComments,t.FieldResolutionComments
FROM #T2 t
WHERE t.FindingDescription<>'Delete'
)AS N
DROP TABLE #T2

--------*************StgMOU***************************

/*SQL code to produce conversion file MOU*/
SELECT * INTO StgMOU
FROM 
(
SELECT a.[PCODE] 
      ,a.[MOUStartDate]
      ,a.[MOUExpirationDate]
      ,REPLACE([dbo].[udf_StripHTML]([MOUDescription]),'CHAR(13) + CHAR(10)','')AS [MOUDescription]
      ,[dbo].[udf_StripHTML]([MOUTopic])AS [MOUTopic]
      ,'' AS CreatedBy
      ,'' AS CreatedDate
      ,'' AS ModifiedBy
      ,'' AS ModifiedDate
      ,dbo.fn_BooleanToYN(a.MOUCreated) AS IsClosed  --- flag showing MOU closed or not
  FROM [HARP].[dbo].[tblMOU] as a
  WHERE YEAR(MOUStartDate)>=2009
		AND PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
) AS N
	
------***************StgMOU_Updates**************************************

--ALTER TABLE StgMOU
--ADD Is_Closed_New Char(1)

--UPDATE StgMOU
--SET Is_Closed_New='Y'
--WHERE IsClosed='N'

--UPDATE StgMOU
--SET Is_Closed_New='N'
--WHERE IsClosed='Y'

--SELECT *
--FROM StgMOU

--UPDATE StgMOU
--SET IsClosed='Y'
--WHERE Is_Closed_New='Y'

--UPDATE StgMOU
--SET IsClosed='N'
--WHERE Is_Closed_New='N'

--ALTER TABLE StgMOU
--DROP COLUMN Is_Closed_New 

-----*****************StgRiskObserved**************************************	

/*SQL code to produce conversion file RiskObserved*/
SELECT * INTO StgRiskObserved
FROM
(
 SELECT [PCODE]
	   ,CONVERT(VARCHAR(20),MeetingDate,101) AS MeetingDate
	   ,'' AS [RiskCategory]
	   ,'' AS [RiskType]
	   ,[dbo].[udf_StripHTML](IssueIdentified) AS [RiskIdentifiedDesc]
       ,[IssuedBy] AS [Division]
       ,[LastUpdate] AS [LastUpdateDesc]
       ,''AS [ResolvedWhenDesc]
       ,dbo.fn_BooleanToYN(ClosedFlag) AS [IsClosed] --to be used as flag for reporting
       ,[CreatedBy]
       ,[CreatedDate]
       ,[ModifiedBy]
       ,[ModifiedDate]
  FROM [HARP].[dbo].[tblEAROIssues]
  WHERE [Type]='Risk Observed' 
	and PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
)AS N;

-----****************StgSummaryUpdates***********************************

/*SQL code to produce conversion file SummaryUpdates*/
WITH cte
AS (
	 SELECT [pcode]
			,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
			,CASE 
				 WHEN [Field Rank Com]  IS NOT NULL THEN 'Field' 
			 END AS [Division]
			,CASE 
				 WHEN [Field Rank Com] IS NOT NULL THEN [Field Rank Com] 
			 END AS [Summary]
			,'' AS ModifiedBy
			,'' AS ModifiedDate
	  FROM stgRankings
	  	  		
UNION ALL

	 SELECT [pcode]
		   ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		   ,CASE
				WHEN [OAD Rank Com]   IS NOT NULL THEN 'OAD' 
			END AS [Division]
		   ,CASE 
				WHEN [OAD Rank Com] IS NOT NULL THEN [OAD Rank Com] 
			END AS [Summary]
		   ,'' AS ModifiedBy
		   ,'' AS ModifiedDate
	 FROM stgRankings
	
UNION ALL

	SELECT [pcode]
		  ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		  ,CASE 
				WHEN [MFI Comment] IS NOT NULL THEN 'NREP' 
			END AS [Division]
		  ,CASE 
				WHEN [MFI Comment] IS NOT NULL THEN [MFI Comment] 
			END AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM stgRankings

UNION ALL

	SELECT [pcode]
		  ,CONVERT(VARCHAR(20),[Date],101) AS MeetingDate
		  ,CASE 
    		  WHEN [HOC Comment] IS NOT NULL THEN 'NHP' 
		   END AS [Division]
		  ,CASE 
			  WHEN [HOC Comment] IS NOT NULL THEN [HOC Comment] 
		   END  AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM stgRankings
	 
UNION ALL

	SELECT PCODE
		  ,MeetingDate
		  ,CASE 
			  WHEN RatingComment IS NOT NULL THEN 'NFMC' 
		   END AS [Division]
		  ,CASE 
			  WHEN RatingComment IS NOT NULL THEN [RatingComment] 
		   END AS [Summary]
		  ,'' AS ModifiedBy
		  ,'' AS ModifiedDate
	FROM dbo.tblNFMC
	WHERE [RatingComment] IS NOT NULL 
		  

UNION ALL
		
	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			   WHEN CapCorpsSummary IS NOT NULL THEN 'CapCorps'
		   END AS Division
		  ,CASE
				WHEN CapCorpsSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (CapCorpsSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	

UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
          ,CASE 
     			WHEN FieldSummary IS NOT NULL THEN 'Field'
		   END AS Division
		  ,CASE
				WHEN FieldSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (FieldSummary)
		  END AS Summary
		 ,ModifiedBy
		 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
				WHEN OADSummary IS NOT NULL THEN 'OAD'
		   END AS Division
		  ,CASE
				WHEN OADSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (OADSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
     		   WHEN NISummary IS NOT NULL THEN 'NI'
		   END AS Division
		  ,CASE
		  	  WHEN NISummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NISummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
     		  WHEN NFMCSummary IS NOT NULL THEN 'NFMC'
		   END AS Division
		  ,CASE
			  WHEN NFMCSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NFMCSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
UNION ALL

	SELECT R.PCODE
		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			  WHEN NHPSummary IS NOT NULL THEN 'NHP'
		   END AS Division
		  ,CASE
			  WHEN NHPSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NHPSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
			  
UNION ALL

	SELECT R.PCODE
	      ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		  ,CASE 
			   WHEN NREPSummary IS NOT NULL THEN 'NREP'
		   END AS Division
		  ,CASE
			   WHEN NREPSummary IS NOT NULL THEN [dbo].[udf_StripHTML] (NREPSummary)
		   END AS Summary
		  ,ModifiedBy
		  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	
)	

SELECT C.PCODE
	  ,C.MeetingDate
	  ,C.Division
	  ,C.Summary
	  ,C.ModifiedBy
	  ,C.ModifiedDate 
	  ,ROW_NUMBER()OVER(PARTITION BY C.PCODE,C.MeetingDate,C.Division ORDER BY C.PCODE)AS RN
	   INTO #t3 
FROM cte C
WHERE C.Division IS NOT NULL AND (C.Summary IS NOT NULL AND CONVERT(NVARCHAR(MAX),Summary) !=N'')---To Exclude NULL Summary
ORDER BY C.MeetingDate DESC

SELECT * INTO StgSummaryUpdates
FROM(
SELECT t.PCODE
	  ,t.MeetingDate
	  ,t.Division
	  ,REPLACE(CAST(t.Summary AS VARCHAR(MAX)),'CHAR(13) + CHAR(10)',',')AS Summary
	  ,t.ModifiedBy
	  ,t.ModifiedDate 
FROM #t3 t
WHERE RN = 1 
	  AND YEAR(MeetingDate) <> 2050 
	  AND YEAR(MeetingDate)>2009
	  AND PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND t.MeetingDate<= '12/01/2016'  
) AS N
DROP TABLE #t3 
   
END
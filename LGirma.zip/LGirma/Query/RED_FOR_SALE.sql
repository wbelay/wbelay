/*SQL code to produce RealEstateDevelopmentForSale graph on OHTS report
We use fact_Real_Estate_Development, dim_Organization and fact_Inventory_Of_For_Sale_Units tables*/
--=============================================================================
--To reterive information about numberofUnitsForSale
SELECT DISTINCT PCode
      ,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	  ,ISNULL(SUM(R.Total_Units),0) AS NumberOfUnitsForSale
	  ,ISNULL(SUM(A.[Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter]),0) AS NumberOfUnitsHeld
FROM [dbo].[fact_Real_Estate_Development] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
LEFT OUTER JOIN [dbo].[fact_Inventory_Of_For_Sale_Units] A
ON R.dim_Organization_key=A.dim_Organization_key AND R.dim_ReportingQuarter_key=A.dim_ReportingQuarter_key
WHERE O.PCODE IS NOT NULL 
GROUP BY PCode, R.dim_ReportingQuarter_key



--INSERT INTO STGASSESSMENT(PCODE,AssessmentDate, ReviewType, AssignedTo, AssessmentStatus, RecordStatus, FinalReportApprovedDate, CreatedBy, CreatedDate)
SELECT 
      new.[PCODE]
      ,new.[AssessmentDate]
      ,new.[ReviewType]
      ,new.[AssignedTo]
      ,new.[AssessmentStatus]
      ,new.[RecordStatus]
      ,new.[FinalReportApprovedDate]
      ,new.[CreatedBy]
      ,CAST(GetDate() AS DATE) as [CreatedDate]
FROM
stgassessment_1517 new 
left join stgassessment old on new.pcode=old.pcode
and new.AssessmentDate=Old.AssessmentDate
and New.ReviewType=old.ReviewType 
WHERE 
new.ReviewType='Off-Site'
and old.pcode is null

--=================================================================
--StgAssessmentMeetingDate

--UPDATE [HARP].[dbo].[StgAssessment_MeetingDate] 
--SET AssessmentDate='2015-09-01', CreatedDate=CAST(GetDate() AS DATE)
--WHERE PCODE=8210 and MeetingDate='2015-09-16'

--======================================================================

--StgOADRatingsandLOB_PROMPT
--INSERT INTO [StgOADRatingsandLOB_PROMPT](PCODE,AssessmentDate,[PROMPTRating_P],[PROMPTRating_R],[PROMPTRating_O],[PROMPTRating_PM]
--			,[PROMPTRating_M],[PROMPTRating_T],[HomeOwnershipPreservationServices],[HomeOwnershipPromotion],[CommunityBuildingandEngagement]
--			,[PropertyManagement],[RealEstateDevelopment],[LendingandLoanPortfolio],[OtherServices])
SELECT [pcode]
      ,'2015-09-01' as AssessmentDate
      ,[PROMPTRating_P]
      ,[PROMPTRating_R]
      ,[PROMPTRating_O]
      ,[PROMPTRating_PM]
      ,[PROMPTRating_M]
      ,[PROMPTRating_T]
      ,[HomeOwnershipPreservationServices]
      ,[HomeOwnershipPromotion]
      ,[CommunityBuildingandEngagement]
      ,[PropertyManagement]
      ,[RealEstateDevelopment]
      ,[LendingandLoanPortfolio]
      ,[OtherServices]
FROM [HARP].[dbo].[StgOADRatingsandLOB_PROMPT]
WHERE pCODE=8210 and AssessmentDate='2013-06-01'

---===================================================
--StgFinding

--UPDATE [HARP].[dbo].[StgFinding] 
--SET AssessmentDate='2015-09-01', ModifiedDate=CAST(GetDate() AS DATE)
--WHERE PCODE=8210 and MeetingDate='2015-09-16'

--=======================================================
--StgScheduleAssessmentMeetingDate
UPDATE [HARP].[dbo].[StgScheduleAssessmentMeetingDate] 
SET MeetingDate='2017-03-09', CreatedDate=CAST(GetDate() AS DATE)
WHERE MeetingDate is null
--=========================================================


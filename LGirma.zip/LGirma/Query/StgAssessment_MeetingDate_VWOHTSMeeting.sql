-- Changes on 20161104  a) Exclude Reviews in process 
--                      b) No longer use future OHTS meeting dates from tblrating since only send at closed OHTS
--                      c) Allow review date .eq. to meetingdate
--
SELECT OS.PCODE
         ,CONVERT(VARCHAR(10),MAX(AssessmentDate),101) AS AssessmentDate
         ,CONVERT(VARCHAR(10),MeetingDate,101)  AS MeetingDate
         ,'SwitchBoardImport' AS CreatedBy
         ,CONVERT(VARCHAR(10),GETDATE(),101) AS CreatedDate
         ,CASE WHEN OS.PCODE IN(SELECT PCODE--MeetingDate,ActionsFromOHTSMeetingSummary
								FROM [HARP].[dbo].[tblOHTSMeeting]
								WHERE ActionsFromOHTSMeetingSummary like '%defer%' AND PCODE<>8271 
									  AND meetingdate=r.meetingdate AND meetingdate=(SELECT MAX(meetingdate)FROM [HARP].[dbo].[tblOHTSMeeting]))THEN 'Y'
		  ELSE 'N' END AS  DeferredFlag 
         INTO #T
FROM dbo.VW_OHTSMeeting r---We make it primary table to get rid of null
LEFT OUTER JOIN dbo.StgAssessment OS--JOIN TO GET MEETINGDATE
ON r.PCODE = OS.PCODE AND OS.AssessmentDate<=R.MeetingDate
LEFT Outer JOIN [dbo].[OnOffSiteReviews] SB 
ON OS.Pcode=SB.PCODE and OS.AssessmentDate=SB.ReviewDate AND OS.ReviewType=SB.ReviewType
WHERE OS.PCODE IN(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8046,8040,8255,8011,8231,8379,8411,8494,8044,8355)--26 Test Pcodes  
        AND SB.InProcess <> 1  
             
GROUP BY OS.PCODE,MeetingDate,CAST(R.ActionsFromOHTSMeetingSummary AS NVARCHAR),SB.InProcess
--SELECT * INTO StgAssessment_MeetingDate_Test
--FROM(
SELECT *
FROM #T 
--)AS N
DROP TABLE #T


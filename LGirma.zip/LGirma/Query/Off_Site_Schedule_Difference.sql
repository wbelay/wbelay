SELECT R.PCODE
	  ,R.[Last Offsite Review Date]
	  ,R.[Last Onsite Review Date]
FROM [PromptPortal].[dbo].[VW_OnOffSite_PRO_Ratings] R
WHERE R.[Last Offsite Review Date] IS NOT NULL OR R.[Last OnSite Review Date] IS NOT NULL

EXCEPT

SELECT C.PCODE
	  ,C.[Last Offsite Review Date]
	  ,C.[Last OnSite Review Date]
FROM [PromptPortal].[dbo].[VW_ContinuousScheduling_Offsite] C
WHERE C.[Last Offsite Review Date] IS NOT NULL OR C.[Last OnSite Review Date] IS NOT NULL
--------===============================================================================================

SELECT R.PCODE
	  ,R.[Last Offsite Review Date]
	  ,R.[Last Onsite Review Date]
FROM [PromptPortal].[dbo].[VW_OnOffSite_PRO_Ratings] R
WHERE R.PCODE IN ( SELECT C.PCODE
					FROM [PromptPortal].[dbo].[VW_ContinuousScheduling_Offsite] C
					WHERE R.[Last Offsite Review Date]<>C.[Last Offsite Review Date] OR R.[Last Onsite Review Date]<>C.[Last OnSite Review Date])

SELECT C.PCODE
	  ,C.[Last Offsite Review Date]
	  ,C.[Last OnSite Review Date]
FROM [PromptPortal].[dbo].[VW_ContinuousScheduling_Offsite] C
WHERE PCODE = 8210 

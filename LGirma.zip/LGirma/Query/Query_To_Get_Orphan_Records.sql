SELECT A.PCODE, A.ReviewType, A.AssessmentDate,
(SELECT MIN(M.MeetingDate) 
from StgAssessment_MeetingDate M INNER Join StgAssessment X on M.Pcode=X.Pcode and m.AssessmentDate=X.AssessmentDate 
where A.AssessmentDate<=M.MeetingDate and  M.PCODE=A.PCODE) AS MeetingDate
FROM dbo.StgAssessment A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode and A.AssessmentDate=AM.AssessmentDate
WHERE AM.PCODE IS NULL and A.AssessmentDate IS NOT NULL AND A.AssessmentStatus<>'Complete'

------------------------------------------------------------------------------------------------------------------
SELECT PCODE,COUNT(a.pcode) Total_Pcode, MIN(ReviewDate) [Min_Date],MAX(reviewdate) [Max_Date]
FROM [PromptPortal].[dbo].[tblAssessment] a
WHERE pcode IN(SELECT DISTINCT PCODE FROM [Staging_HARP].[dbo].[StgAssessment] t )
GROUP BY a.pcode

------------------------------------------------------------------------------------------------------------------
SELECT A.*
FROM [PromptPortal].[dbo].[tblAssessment] A
LEFT JOIN [Staging_HARP].[dbo].[StgAssessment] t
ON A.Pcode=t.Pcode AND a.[ReviewDate]=t.AssessmentDate
WHERE A.PCODE IS NULL and a.[ReviewDate] IS NOT NULL

-------------------------------------------------------------------------------------------------------------------

SELECT *--distinct a.PCODE 
FROM [Staging_HARP].[dbo].[StgAssessment] A 
LEFT JOIN [PromptPortal].[dbo].[tblAssessment] P 
ON A.PCODE=P.PCODE and A.AssessmentDate=P.Reviewdate 
WHERE p.pcode IS NULL



WITH CTE
AS
(
SELECT PCODE 
	  ,CAST(ReviewDate AS DATE) AS ReviewDate
	  ,ReviewType
	  ,Leader AS AssignedTo
	  ,'' AS RN
FROM OnOffSiteReviews o
WHERE (reviewdate>getdate() and leader is not null) OR (reviewdate<getdate()) 
	  AND YEAR(ReviewDate)>=2009
	  AND ReviewType = 'On-Site'
	   	  
UNION ALL

SELECT OFS.PCODE 
	 ,CAST(CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)AS DATE)AS ReviewDate
	 ,'Off-Site' AS ReviewType
     ,MAX(rd.OADReviewerName)AS AssignedTo
	 ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR) ORDER BY OFS.PCODE)RN
FROM dbo.tblOffSiteRating OFS
LEFT JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	 CAST(CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR)AS DATE)<=R.MeetingDate
	 AND R.MeetingDate<=GETDATE()
	 AND CAST(CAST(ofs.FiscalMonth AS VARCHAR) + '/' + CAST('1' AS VARCHAR) + '/' + CAST(ofs.FiscalYearYear AS VARCHAR) AS DATE)<=GETDATE()
GROUP BY OFS.PCODE,OFS.FiscalMonth,OFS.FiscalYearYear
)
--SELECT * INTO StgAssessment_1517
--FROM(
SELECT PCODE
	  ,ReviewDate As AssessmentDate
	  ,ReviewType
	  ,AssignedTo
	  ,CASE WHEN CTE.PCODE IN (SELECT CTE.PCODE FROM [dbo].[tblOHTSMeeting] r WHERE cte.pcode=r.pcode and cte.ReviewDate<=r.meetingDate)
		THEN 'Complete' ELSE 'Current' END AS AssessmentStatus	
	  ,'History' AS RecordStatus----History is the default Value
	  ,CASE WHEN ReviewType = 'Off-Site' THEN '2000-01-01' ELSE '' END AS FinalReportApprovedDate
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate 
FROM CTE
WHERE PCODE NOT IN(SELECT PCODE FROM dbo.StgExcludedNWOs)
	  AND YEAR(ReviewDate)<'2018'
	  AND PCODE IN(SELECT PCODE FROM tblOrganization)
	   
--) AS N 




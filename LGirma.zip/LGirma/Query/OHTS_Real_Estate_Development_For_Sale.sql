/*SQL code to produce RealEstateDevelopmentForSale graph on OHTS report
We use fact_Real_Estate_Development, dim_Organization and fact_Inventory_Of_For_Sale_Units tables*/
--=============================================================================
SELECT DISTINCT 
 ISNULL(A.pcode , B.pcode) AS PCODE
,ISNULL(A.FisicalYear , B.FisicalYear) AS FiscalYear
,ISNULL(A.FisicalYearQuarter , B.FisicalYearQuarter) AS FiscalYearQuarter
,ISNULL(A.NumberOfUnitsForSale,0) AS [For-Sale Homes Developed]
,ISNULL(B.NumberOfUnitsHeld,0) AS [Units Held in Portfilio at End of Quarter]
FROM
(
--To reterive information about numberofUnitsForSale
SELECT PCode
      ,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	  ,SUM(Total_Units) AS NumberOfUnitsForSale
FROM [dbo].[fact_Real_Estate_Development] R
LEFT JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
GROUP BY PCode, R.dim_ReportingQuarter_key
)A
FULL OUTER JOIN 
(
--To reterive information about Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter
SELECT PCode
      ,LEFT(A.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	  ,SUM([Total_For_Sale_Units_Held_In_Portfolio_At_End_Of_Quarter]) AS NumberOfUnitsHeld
FROM[dbo].[fact_Inventory_Of_For_Sale_Units] A
LEFT JOIN [dbo].[dim_Organization] O
ON A.dim_Organization_key = O.dim_Organization_key
GROUP BY PCode, A.dim_ReportingQuarter_key
)B
ON A.pcode = B.pcode AND A.FisIcalYear = B.FisIcalYear AND A.FisicalYearQuarter = B.FisicalYearQuarter
WHERE A.PCODE IS NOT NULL OR B.PCODE IS NOT NULL
ORDER BY PCODE ASC


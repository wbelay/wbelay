SELECT b.Value as Division
	  ,a.RecommendationID
	  ,COUNT(a.pcode)
FROM [PromptPortal].[dbo].[tblFinalRatingRecommendations] a
LEFT OUTER JOIN PromptPortal.dbo.tblReferenceTableValue b
ON a.DivisionID=b.ID and b.TableID=2 and b.[Group]!='NI'
WHERE a.DivisionID != 2 and RecommendationID is not null
GROUP BY b.value, a.RecommendationID
ORDER BY b.value
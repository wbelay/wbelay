
SELECT * 
INTO #t
FROM (
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
			  ,CASE				
				  WHEN FieldRating IS NOT NULL OR FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
			  END AS Division		   
			  ,CASE 				
				  WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
			  END AS RatingRecommendation		    
			  ,CASE 				
				  WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			  END AS WatchListRecommendation		   
			  ,ModifiedBy		   
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			    AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
			    AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	UNION
	                       
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				  WHEN OADRating IS NOT NULL OR OADWatchRecommendation IS NOT NULL THEN 'OAD' 
			  END AS Division
			  ,CASE 
				  WHEN 'OADRating' IS NOT NULL THEN OADRating
			  END AS RatingRecommendation
			  ,CASE 
				  WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
			  END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	   FROM dbo.tblRatingDetail R
	   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			     AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			     AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				  WHEN NIRating IS NOT NULL OR NIWatchRecommendation IS NOT NULL THEN 'NI' 
			  END AS Division
			  ,CASE 
				  WHEN 'NIRating' IS NOT NULL THEN NIRating
			  END AS RatingRecommendation
			  ,CASE 
				  WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			  END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 			AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			    AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			    AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
	UNION
					
	    SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NFMCRating IS NOT NULL OR NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
				END AS Division
				,CASE 
					WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			      AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			      AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    		,CASE 
					WHEN NHPRating IS NOT NULL OR NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
				END AS Division
				,CASE 
					WHEN 'NHPRating' IS NOT NULL THEN NHPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			      AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			      AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NREPRating IS NOT NULL OR NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
				END AS Division
				,CASE 
					WHEN 'NREPRating' IS NOT NULL THEN NREPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			      AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			      AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
  ) AS Rating
			
SELECT *
INTO #t2
FROM (
	  SELECT  A.PCODE
			 ,A.AssessmentDate
			 ,t.MeetingDate
			 ,t.Division
			 ,t.ModifiedBy
			 ,t.ModifiedDate
			 ,t.RatingRecommendation
			 ,t.WatchListRecommendation
			 ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.ProductionProgramServicesText,'Meet','Met')
			   	   WHEN Division = 'OAD'AND A.ReviewType = 'Off-site' AND A.MeetingDate=t.MeetingDate THEN REPLACE(CAST(ofr.ProductionProgramServicesDescription AS VARCHAR(55)),'Meet','Met')
			  END AS PROMPTRating_P
			 ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.ResourceManagementText,'Meet','Met')
				   WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN REPLACE(CAST(ofr.ResourceFinancialManagementDescription AS VARCHAR(55)),'Meet','Met')
			  END AS PROMPTRating_R
             ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.OrganizationalManagementText,'Meet','Met')
				   WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN REPLACE(CAST(ofr.OrganizationalManagementDescription AS VARCHAR(55)),'Meet','Met')
			 END AS PROMPTRating_O
             ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.PersonnelManagementText, 'Meet', 'Met')
				   WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN '' END AS PROMPTRating_M
             ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.PlanningText,'Meet','Met') 
				   WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN '' END AS PROMPTRating_PM
             ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.TechnicalOperationsSystemsText,'Meet','Met')       
				   WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN ''
			 ELSE '' END AS PROMPTRating_T
			 ,CASE WHEN Division = 'OAD'THEN HomeownershipPreservationFlag END AS HomeOwnershipPreservationServices
			 ,CASE WHEN Division = 'OAD'THEN HomeownershipPromotionServicesFlag END AS HomeOwnershipPromotion
			 ,CASE WHEN Division = 'OAD'THEN CommunityBuildingandOrganizingFlag END AS CommunityBuildingandEngagement
			 ,CASE WHEN Division = 'OAD'THEN RealEstateDevelopmentFlag END AS RealEstateDevelopment
			 ,CASE WHEN Division = 'OAD'THEN LendingandPortfolioManagementFlag END AS LendingandLoanPortfolio 
			 ,CASE WHEN Division = 'OAD'THEN OtherServicesFlag ELSE '' END AS OtherServices			
	 FROM dbo.Assessment A
	 LEFT JOIN dbo.tblOnSiteRatings OS 
	 ON OS.PCODE = A.PCODE and A.ReviewType = 'On-Site'
	 LEFT JOIN dbo.tblOffSiteRating OFR 
	 ON OFR.PCODE = A.PCODE and A.ReviewType = 'Off-Site'
	 JOIN _Stg.vwLinesofBus B 
	 ON B.PCODE = a.PCODE
	 JOIN #t t 
	 ON t.PCODE = a.PCODE AND t.MeetingDate = a.MeetingDate
    ) AS temp2

SELECT pcode
	  ,AssessmentDate
	  ,MeetingDate
	  ,Division
	  ,RatingRecommendation
	  ,WatchListRecommendation
	  ,ModifiedBy
	  ,ModifiedDate
	  ,PROMPTRating_P
	  ,PROMPTRating_R
	  ,PROMPTRating_O
	  ,PROMPTRating_M
	  ,PROMPTRating_PM
	  ,PROMPTRating_T
	  ,HomeOwnershipPreservationServices
	  ,HomeOwnershipPromotion
	  ,CommunityBuildingandEngagement
	  ,RealEstateDevelopment
	  ,LendingandLoanPortfolio 
	  ,OtherServices
      ,ROW_NUMBER()OVER(PARTITION BY PCODE,AssessmentDate,MeetingDate,Division
                        ORDER BY PCODE)RN
INTO #t3
FROM #t2
SELECT PCODE
	  ,AssessmentDate
	  ,MeetingDate
	  ,Division
	  ,RatingRecommendation
	  ,WatchListRecommendation
	  ,ModifiedBy
	  ,ModifiedDate
	  ,PROMPTRating_P
	  ,PROMPTRating_R
	  ,PROMPTRating_O
	  ,PROMPTRating_M
	  ,PROMPTRating_PM
	  ,PROMPTRating_T
	  ,HomeOwnershipPreservationServices
	  ,HomeOwnershipPromotion
	  ,CommunityBuildingandEngagement
	  ,RealEstateDevelopment
	  ,LendingandLoanPortfolio
	  ,OtherServices
FROM #t3
WHERE Division !='' 
      AND RN=1 --AND PCODE =  8270
GROUP BY PCODE
        ,AssessmentDate
        ,MeetingDate
        ,Division
        ,RatingRecommendation
	    ,WatchListRecommendation
		,ModifiedBy
		,ModifiedDate
		,PROMPTRating_P
		,PROMPTRating_R
		,PROMPTRating_O
		,PROMPTRating_M
		,PROMPTRating_PM
		,PROMPTRating_T
		,HomeOwnershipPreservationServices
	    ,HomeOwnershipPromotion
	    ,CommunityBuildingandEngagement
	    ,RealEstateDevelopment
	    ,LendingandLoanPortfolio 
	    ,OtherServices
ORDER BY #t3.MeetingDate DESC

DROP TABLE #t
DROP TABLE #t2
DROP TABLE #t3


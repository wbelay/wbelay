WITH cte
AS 
(
  SELECT DISTINCT dt.*
			  ,CASE os.ProductionProgramServicesText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_P
			  ,CASE os.ResourceManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_R
              ,CASE os.OrganizationalManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_O
              ,CASE os.PersonnelManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_M
              ,CASE os.PlanningText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_PM
              ,CASE os.TechnicalOperationsSystemsText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_T      
  FROM (
        SELECT  R.PCODE
	            ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		        ,CASE				
		            WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
		         END AS Division		   
		        ,CASE 				
		           WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
		        END AS RatingRecommendation		    
		       ,CASE 				
		           WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			    END AS WatchRecommendation		   
			   ,ModifiedBy		   
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
        FROM dbo.tblRatingDetail R
        WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	          AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
	          AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
	          AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	   UNION
	                       
	   SELECT  R.PCODE
	  		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
				END AS Division
			   ,CASE 
					WHEN 'OADRating' IS NOT NULL THEN OADRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
				END AS WatchRecommendation
			   ,ModifiedBy
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	   FROM dbo.tblRatingDetail R
	   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		     AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		     AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		     AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
			END AS Division
			,CASE 
				WHEN 'NIRating' IS NOT NULL THEN NIRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
   FROM dbo.tblRatingDetail R
   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 		 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		 AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		 AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
   UNION
					
   SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			END AS Division
			,CASE 
				WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	,CASE 
				WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			END AS Division
			,CASE 
				WHEN 'NHPRating' IS NOT NULL THEN NHPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
		    ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		    ,CASE 
				WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
			END AS Division
			,CASE 
				WHEN 'NREPRating' IS NOT NULL THEN NREPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	)AS dt  
	JOIN dbo.tblOnSiteRatings OS
	ON OS.PCODE = dt.PCODE

UNION 

SELECT DISTINCT ft.*
			  --,CONVERT(VARCHAR(20),dt2.ReviewDate,101) AS AssessmentDate
			  ,CASE CONVERT(VARCHAR(20),ofr.ProductionProgramServicesDescription,101)  WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_P
			  ,CASE CONVERT(VARCHAR(20),ofr.ResourceFinancialManagementDescription,101) WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_R
              ,CASE CONVERT(VARCHAR(20),ofr.OrganizationalManagementDescription,101) WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_O
              ,''AS PROMPTRating_M
              ,'' AS PROMPTRating_PM
              ,'' AS PROMPTRating_T
		         
FROM (
      SELECT  R.PCODE
	          ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		      ,CASE				
		          WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
		       END AS Division		   
		       ,CASE 				
		           When 'FieldRating' IS NOT NULL THEN FieldRating			
		       END AS RatingRecommendation		    
		       ,CASE 				
		           When 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			    END AS WatchRecommendation		   
			   ,ModifiedBy		   
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
       FROM dbo.tblRatingDetail R
       WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	         AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
	         AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
	         AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	   UNION
	                       
	   SELECT  R.PCODE
	  		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
				END AS Division
			   ,CASE 
					When 'OADRating' IS NOT NULL THEN OADRating
				END AS RatingRecommendation
			   ,CASE 
					When 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	 FROM dbo.tblRatingDetail R
	 WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		   AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		   AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		   AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
			END AS Division
			,CASE 
				When 'NIRating' IS NOT NULL THEN NIRating
			END AS RatingRecommendation
			,CASE 
				When 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
   FROM dbo.tblRatingDetail R
   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 		 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		 AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		 AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
   UNION
					
   SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			END AS Division
			,CASE 
				When 'NFMCRating' IS NOT NULL THEN NFMCRating
			END AS RatingRecommendation
			,CASE 
				When 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	,CASE 
				WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			END AS Division
			,CASE 
				When 'NHPRating' IS NOT NULL THEN NHPRating
			END AS RatingRecommendation
			,CASE 
				When 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		    ,CASE 
				WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
			END AS Division
			,CASE 
				When 'NREPRating' IS NOT NULL THEN NREPRating
			END AS RatingRecommendation
			,CASE 
				When 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	)AS ft  
	JOIN  dbo.tblOffSiteRating  ofr
	ON Ofr.PCODE = ft.PCODE
)
SELECT DISTINCT cte.PCODE
       ,dt2.ReviewDate AS AssessmentDate
       ,cte.MeetingDate
       --,dt2.ReviewType
       ,cte.Division
       ,cte.RatingRecommendation
	   ,cte.WatchRecommendation
	   ,cte.ModifiedBy
	   ,cte.PROMPTRating_P
	   ,cte.PROMPTRating_R
	   ,cte.PROMPTRating_O
	   ,cte.PROMPTRating_M
	   ,cte.PROMPTRating_PM
	   ,cte.PROMPTRating_T
		--,HARP.dbo.fn_BooleanToYN([Lines of Bus].[RE?]) AS HomeOwnershipPreservationServices
        --,HARP.dbo.fn_BooleanToYN([Lines of Bus].[HOME?])AS HomeOwnershipPromotion
        --,HARP.dbo.fn_BooleanToYN([Lines of Bus].[CB?])AS CommunityBuildingandEngagement
        --,HARP.dbo.fn_BooleanToYN([Lines of Bus].[PM?])AS PropertyManagement
        --,HARP.dbo.fn_BooleanToYN([Lines of Bus].[RED?])AS RealEstateDevelopment
        --,HARP.dbo.fn_BooleanToYN([Lines of Bus].[LEND?])AS LendingandLoanPortfolio 
	   ,HomeownershipPreservationFlag AS HomeOwnershipPreservationServices
	   ,HomeownershipPromotionServicesFlag AS HomeOwnershipPromotion
	   ,CommunityBuildingandOrganizingFlag AS CommunityBuildingandEngagement
	   ,RealEstateDevelopmentFlag AS RealEstateDevelopment
	   ,LendingandPortfolioManagementFlag AS LendingandLoanPortfolio 
	   ,OtherServicesFlag AS OtherServices
       ,ROW_NUMBER()OVER(PARTITION BY CTE.PCODE, dt2.ReviewDate, cte.MeetingDate
                                      ,cte.Division,cte.RatingRecommendation 
                          ORDER BY cte.PCODE)RN
       --,ROW_NUMBER()OVER(PARTITION BY CTE.PCODE, dt2.ReviewDate ORDER BY cte.PCODE)RN1
        INTO #t
FROM cte JOIN( 
				SELECT PCODE
					  ,CONVERT(VARCHAR(20),ReviewDate,101) AS ReviewDate
					  ,ReviewType
			    FROM dbo.OnOffSiteReviews              
                --select PCODE,max(ReviewDate) as maxDate 
                --from tblOnSiteRatings 
                --group by PCODE
             ) AS dt2                    
         ON cte.PCODE = dt2.PCODE --and dt2.ReviewDate = dt2.maxDate
         --JOIN DataTrf.dbo.[Lines of Bus]
         JOIN _Stg.vwLinesofBus
         ON _Stg.vwLinesofBus.PCODE = cte.PCODE AND _Stg.vwLinesofBus.ReviewDate = dt2.ReviewDate
WHERE cte.RatingRecommendation != '' AND cte.WatchRecommendation != ''AND cte.Division !=''
      
GROUP BY cte.PCODE
         ,dt2.ReviewDate 
         ,cte.MeetingDate
         --,dt2.ReviewType
         ,cte.Division
         ,cte.RatingRecommendation
		 ,cte.WatchRecommendation
		 ,cte.ModifiedBy
		 ,cte.MeetingDate
		 ,cte.PROMPTRating_P
		 ,cte.PROMPTRating_R
		 ,cte.PROMPTRating_O
		 ,cte.PROMPTRating_M
		 ,cte.PROMPTRating_PM
		 ,cte.PROMPTRating_T
		 ,HomeownershipPreservationFlag 
		 ,HomeownershipPromotionServicesFlag 
		 ,CommunityBuildingandOrganizingFlag 
		 ,RealEstateDevelopmentFlag 
		 ,LendingandPortfolioManagementFlag 
		 ,OtherServicesFlag 
ORDER BY PCODE DESC


SELECT *
FROM #t 
WHERE RN=1 
--and PCODE = 8300

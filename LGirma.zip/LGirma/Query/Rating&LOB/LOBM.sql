WITH cte
AS 
(
SELECT DISTINCT dt.*
			  --,CONVERT(VARCHAR(20),dt2.ReviewDate,101) AS AssessmentDate
			  ,CASE os.ProductionProgramServicesText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_P
			  ,CASE os.ResourceManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_R
              ,CASE os.OrganizationalManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_O
              ,CASE os.PersonnelManagementText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_M
              ,CASE os.PlanningText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_PM
              ,CASE os.TechnicalOperationsSystemsText WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_T
		         
FROM (
      SELECT  R.PCODE
	          ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		      ,CASE				
		          WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
		       END AS Division		   
		       ,CASE 				
		           When 'FieldRating' IS NOT NULL THEN FieldRating			
		       END AS RatingRecommendation		    
		       ,CASE 				
		           When 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			    END AS WatchRecommendation		   
			   ,ModifiedBy		   
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
       FROM dbo.tblRatingDetail R
       WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	         AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
	         AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
	         AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	   UNION
	                       
	   SELECT  R.PCODE
	  		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
				END AS Division
			   ,CASE 
					WHEN 'OADRating' IS NOT NULL THEN OADRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	 FROM dbo.tblRatingDetail R
	 WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		   AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		   AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		   AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
			END AS Division
			,CASE 
				WHEN 'NIRating' IS NOT NULL THEN NIRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
   FROM dbo.tblRatingDetail R
   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 		 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		 AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		 AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
   UNION
					
   SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			END AS Division
			,CASE 
				WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	,CASE 
				WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			END AS Division
			,CASE 
				WHEN 'NHPRating' IS NOT NULL THEN NHPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
			END AS Division
			,CASE 
				WHEN 'NREPRating' IS NOT NULL THEN NREPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	)AS dt  
	JOIN  dbo.tblOnSiteRatings  OS
	ON OS.PCODE = dt.PCODE

UNION 

SELECT DISTINCT ft.*
			  --,CONVERT(VARCHAR(20),dt2.ReviewDate,101) AS AssessmentDate
			  ,CASE CONVERT(VARCHAR(20),ofr.ProductionProgramServicesDescription,101)  WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_P
			  ,CASE CONVERT(VARCHAR(20),ofr.ResourceFinancialManagementDescription,101) WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_R
              ,CASE CONVERT(VARCHAR(20),ofr.OrganizationalManagementDescription,101) WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_O
              ,''AS PROMPTRating_M
              ,'' AS PROMPTRating_PM
              ,'' AS PROMPTRating_T
		         
FROM (
      SELECT  R.PCODE
	          ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		      ,CASE				
		          WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
		       END AS Division		   
		       ,CASE 				
		           WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
		       END AS RatingRecommendation		    
		       ,CASE 				
		           WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			    END AS WatchRecommendation		   
			   ,ModifiedBy		   
			   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
       FROM dbo.tblRatingDetail R
       WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	         AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
	         AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
	         AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	   UNION
	                       
	   SELECT  R.PCODE
	  		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			   ,CASE 
					WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
				END AS Division
			   ,CASE 
					WHEN 'OADRating' IS NOT NULL THEN OADRating
				END AS RatingRecommendation
			   ,CASE 
					WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	 FROM dbo.tblRatingDetail R
	 WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		   AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		   AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		   AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			,CASE 
				WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
			END AS Division
			,CASE 
				WHEN 'NIRating' IS NOT NULL THEN NIRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
   FROM dbo.tblRatingDetail R
   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 		 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		 AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		 AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
   UNION
					
   SELECT  R.PCODE
		   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
			END AS Division
			,CASE 
				WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    	,CASE 
				WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
			END AS Division
			,CASE 
				WHEN 'NHPRating' IS NOT NULL THEN NHPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

	SELECT  R.PCODE
			,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		   ,CASE 
				WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
			END AS Division
			,CASE 
				WHEN 'NREPRating' IS NOT NULL THEN NREPRating
			END AS RatingRecommendation
			,CASE 
				WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
			END AS WatchRecommendation
			,ModifiedBy
			,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	FROM dbo.tblRatingDetail R
	WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
		  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
		  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
		  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	)AS ft  
	JOIN  dbo.tblOffSiteRating  ofr
	ON Ofr.PCODE = ft.PCODE
)
SELECT cte.PCODE
       ,cte.MeetingDate
       ,cte.Division
       ,cte.RatingRecommendation
       ,cte.WatchRecommendation
       ,cte.ModifiedBy        
       ,cte.ModifiedDate
       ,cte.PROMPTRating_P
       ,cte.PROMPTRating_R
       ,cte.PROMPTRating_O
       ,cte.PROMPTRating_PM
       ,cte.PROMPTRating_M
       ,cte.PROMPTRating_T
	  
FROM cte JOIN (SELECT CORE.PCODE
		              , CORE.ReviewType
					  , CORE.AssessmentDate
					  , CORE.MeetingDate
					  , CASE 
							WHEN CORE.AssignedTo IS NULL THEN ASG.Leader 
					    ELSE CORE.AssignedTo 
					    END AS AssignedTo, CORE.CreatedBy, CORE.CreatedDate
                FROM
					(SELECT  r.PCODE AS PCODE
							, CASE 
								 WHEN r.ReviewFlag = 'Y' then 'On-Site'
								 WHEN r.ReviewPROFlag = 'Y' then 'Off-Site'
								 WHEN r.AuditReviewFlag = 'Y' then 'Audit Review'
								 WHEN r.OthersFlag = 'Y' then 'Other'
							ELSE '' 
							END AS ReviewType
							, CONVERT(varchar(20), Max(OFR.ReviewDate), 101) AS AssessmentDate
							, CONVERT(varchar(20), r.MeetingDate, 101) AS MeetingDate 
							,  rd.OADReviewerName AS AssignedTo
							, '' AS CreatedBy
							, '' AS CreatedDate
						FROM tblRating r
						LEFT JOIN tblRatingDetail rd
						ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate
						LEFT JOIN dbo.OnOffSiteReviews OFR
						ON (r.PCODE = OFR.PCODE 
							AND (CASE 
									WHEN r.ReviewFlag = 'Y' then 'On-Site'
									WHEN r.ReviewPROFlag = 'Y' then 'Off-Site'
									WHEN r.AuditReviewFlag = 'Y' then 'Audit Review'
									WHEN r.OthersFlag = 'Y' then 'Other'
								 ELSE '' 
								 END) = OFR.ReviewType)
						WHERE OFR.ReviewDate <= r.MeetingDate
							  AND r.MeetingDate <= GETDATE()
							  AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
						GROUP BY r.PCODE
								 , r.MeetingDate
								 , r.ReviewFlag
								 , r.ReviewPROFlag
								 , r.AuditReviewFlag
								 , r.OthersFlag
								 , rd.OADReviewerName
								 , ReviewType) CORE
LEFT OUTER JOIN dbo.OnOffSiteReviews ASG
ON CORE.PCODE=ASG.PCODE AND CORE.ReviewType=ASG.ReviewType AND CORE.AssessmentDate=ASG.ReviewDate
WHERE CORE.PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
) AS dte 
ON cte.PCODE=dte.PCODE AND cte.MeetingDate=dte.MeetingDate

--select *
--from #t
--WHERE rn=1
--AND Division !='' AND RatingRecommendation !=''OR WatchRecommendation !=''
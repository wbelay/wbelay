WITH cte
AS 
(
  SELECT distinct dt.*
		   ,REPLACE(os.ProductionProgramServicesText,'Meet','Met') AS PROMPTRating_P
		   ,REPLACE(os.ResourceManagementText,'Meet','Met') AS PROMPTRating_R
		   ,REPLACE(os.OrganizationalManagementText,'Meet','Met') AS	PROMPTRating_O
		   ,REPLACE(os.PersonnelManagementText,'Meet','Met') As PROMPTRating_M 
		   ,REPLACE(os.PlanningText,'Meet','Met') AS PROMPTRating_PM  
		   ,REPLACE(os.TechnicalOperationsSystemsText,'Meet','Met') AS PROMPTRating_T 
			   
      --,ISNULL(CASE dt.Division 
      --        WHEN 'Field' THEN tr.FieldRating
      --        WHEN 'OAD' THEN tr.OADRating
      --        WHEN 'NI' THEN tr.NIRating
      --        WHEN 'NFMC' THEN tr.NFMCRating 
      --        WHEN 'NHP' THEN tr.NHPRating
      --        ELSE tr.NREPRating
      --        END,'') AS RatingRecommendation
            
      --,ISNULL(CASE dt.Division 
      --        WHEN 'Field' THEN tr.FieldWatchRecommENDation
      --        WHEN 'OAD' THEN tr.OADWatchRecommENDation
      --        WHEN 'NI' THEN tr.NIWatchRecommENDation
      --        WHEN 'NFMC' THEN tr.NFMCWatchRecommENDation 
      --        WHEN 'NHP' THEN tr.NHPWatchRecommENDation
      --        ELSE tr.NREPWatchRecommENDation
      --        END,'') AS WatchRecommENDation
       
  FROM (
         SELECT  R.PCODE
		         ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		         ,CASE 
				     WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'
			     END AS Division
		         ,CASE 
					 WHEN 'FieldRating' IS NOT NULL THEN FieldRating
			     END AS WatchRecommEndation
		         ,CASE 
					 WHEN 'FieldWatchRecommendation' IS NOT NULL THEN FieldWatchRecommendation
			     END AS RatingRecommendation
		         ,ModifiedBy
				 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			  AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
			  AND NHPRating IS NOT NULL AND  NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)
UNION

SELECT  R.PCODE
		,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		,CASE 
			 WHEN OADRating IS NOT NULL AND  OADWatchRecommendation IS NOT NULL THEN 'OAD' 
		 END AS Division
	    ,CASE 
			WHEN 'OADRating' IS NOT NULL THEN OADRating
		END AS RatingRecommendation
		,CASE 
			WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
		END AS WatchRecommEndation
	   ,ModifiedBy
	   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
FROM dbo.tblRatingDetail R
WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
      AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
      AND NHPRating IS NOT NULL AND  NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)

UNION

SELECT  R.PCODE
	   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	   ,CASE 
  		   WHEN NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL THEN 'NI' 
	    END AS Division
	   ,CASE 
			WHEN 'NIRating' IS NOT NULL THEN NIRating
		END AS RatingRecommendation
	   ,CASE 
			WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
		END AS WatchRecommEndation
	   ,ModifiedBy
	   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
FROM dbo.tblRatingDetail R
WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommENDation IS NOT NULL
      AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
      AND NHPRating IS NOT NULL AND  NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)

UNION

SELECT  R.PCODE
	    ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
		,CASE 
			WHEN NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
	    END AS Division
		,CASE 
			WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
		END AS RatingRecommendation
		,CASE 
			WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
	    END AS WatchRecommEndation
		,ModifiedBy
		,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
FROM dbo.tblRatingDetail R
WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
      AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
      AND NHPRating IS NOT NULL AND  NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)

UNION

SELECT  R.PCODE
	   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	   ,CASE 
			WHEN NHPRating IS NOT NULL AND  NHPWatchRecommENDation IS NOT NULL THEN 'NHP' 
   	   END AS Division
	  ,CASE 
	  	  WHEN 'NHPRating' IS NOT NULL THEN NHPRating
	   END AS RatingRecommendation
	  ,CASE 
	   	  WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
	  END AS WatchRecommEndation
      ,ModifiedBy
	  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
FROM dbo.tblRatingDetail R
WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
      AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
      AND NHPRating IS NOT NULL AND  NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)

UNION

SELECT  R.PCODE
	   ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	   ,CASE 
			WHEN NREPRating IS NOT NULL AND  NREPWatchRecommEndation IS NOT NULL THEN 'NREP' 
 	   END AS Division
   	  ,CASE 
			When 'NREPRating' IS NOT NULL THEN NREPRating
			END AS RatingRecommendation
		    ,CASE 
				When 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
			END AS WatchRecommEndation
		   ,ModifiedBy
		   ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
FROM dbo.tblRatingDetail R
WHERE 
	  PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
      AND NIRating IS NOT NULL AND  NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND  NFMCWatchRecommendation IS NOT NULL 
      AND NHPRating IS NOT NULL AND  NHPWatchRecommEndation IS NOT NULL OR NREPRating IS NOT NULL AND  NREPWatchRecommendation IS NOT NULL)
)AS dt  
--LEFT JOIN tblRatingDetail tr
--ON dt.PCODE = tr.PCODE
LEFT JOIN  dbo.tblOnSiteRatings  OS
ON OS.PCODE = dt.PCODE
)
SELECT  distinct *--pcode, meetingdate, Division, RatingRecommendation, WatchRecommendation, ModCASEiedBy,ModCASEiedDate
        --,CASE PROMPTRating_P WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_P
        --,CASE PROMPTRating_R WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_R
        --,CASE PROMPTRating_O WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_O
        --,CASE PROMPTRating_M WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_M
        --,CASE PROMPTRating_PM WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_PM
        --,CASE PROMPTRating_T WHEN 'Meet' THEN 'Met' WHEN 'Exceed'THEN 'Exceed' ELSE 'Fail' END AS PROMPTRating_T
        --,RANK()OVER(PARTITION BY PCODE,MeetingDate,Division,ModCASEiedBy,ModCASEiedDate ORDER BY MeetingDate)Rank
FROM cte 
WHERE cte.RatingRecommendation != '' AND cte.WatchRecommENDation != ''AND cte.Division !=''
ORDER BY MeetingDate  DESC



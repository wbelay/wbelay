SELECT * 
INTO #t
FROM (
	  SELECT R.PCODE
		     ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
		     ,CASE				
		         WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
		     END AS Division		   
		     ,CASE 				
		         WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
		     END AS RatingRecommendation		    
		     ,CASE 				
		         WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			 END AS WatchRecommendation		   
			 ,ModifiedBy		   
			 ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
			AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	UNION
	                       
	  SELECT  R.PCODE
	  		  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
			   	  WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
			  END AS Division
			  ,CASE 
				  WHEN 'OADRating' IS NOT NULL THEN OADRating
			  END AS RatingRecommendation
		   	  ,CASE 
				  WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
			  END AS WatchRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
	  	    AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
				END AS Division
				,CASE 
					WHEN 'NIRating' IS NOT NULL THEN NIRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		 FROM dbo.tblRatingDetail R
		 WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 			   AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			   AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			   AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
	UNION
					
		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
				END AS Division
				,CASE 
					WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	   			,CASE 
					WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
				END AS Division
				,CASE 
					WHEN 'NHPRating' IS NOT NULL THEN NHPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
				END AS Division
				,CASE 
					WHEN 'NREPRating' IS NOT NULL THEN NREPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
				END AS WatchRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
			  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
			  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
) AS Review
			
SELECT *
INTO #t2
FROM (
	  SELECT  A.PCODE AS pcode
			  , ReviewType
			  , AssessmentDate
			  , a.MeetingDate 
			  , t.Division
			  , t.ModifiedBy
			  , t.RatingRecommendation
			  , t.WatchRecommendation
			  , CASE 
				   WHEN A.ReviewType = 'On-Site' AND t.Division = 'OAD' THEN REPLACE(ONR.ProductionProgramServicesText,'Meet','Met')
				   WHEN A.ReviewType = 'Off-Site' AND t.Division = 'OAD' THEN REPLACE(CAST(OFFR.ProductionProgramServicesDescription AS VARCHAR(255)),'Meet','Met')
			  END AS PROMPTRating_P
			  , CASE 
				   WHEN A.ReviewType = 'On-Site' AND t.Division = 'OAD' THEN REPLACE(ONR.ResourceManagementText,'Meet','Met')
				   WHEN A.ReviewType = 'Off-Site' AND t.Division = 'OAD' THEN REPLACE(CAST(OFFR.ResourceFinancialManagementDescription AS VARCHAR(255)),'Meet','Met')
			  END AS PROMPTRating_R
		   	  , CASE
		   		   WHEN A.ReviewType = 'On-Site' AND t.Division = 'OAD' THEN REPLACE(ONR.PersonnelManagementText,'Meet','Met')
				   WHEN A.ReviewType = 'Off-Site' AND t.Division = 'OAD' THEN REPLACE(CAST(OFFR.OrganizationalManagementDescription AS VARCHAR(255)),'Meet','Met')
			  END AS PROMPTRating_O
			  ,CASE WHEN Division = 'OAD'THEN REPLACE(ONR.PersonnelManagementText,'Meet','Met') END AS PROMPTRating_M
			  ,CASE WHEN Division = 'OAD'THEN REPLACE(ONR.PlanningText,'Meet','Met') END AS PROMPTRating_PM
			  ,CASE WHEN Division = 'OAD'THEN REPLACE(ONR.TechnicalOperationsSystemsText,'Meet','Met')       
			  ELSE '' END AS PROMPTRating_T
			  , TechnicalOperationsSystemsText
		   	  , HomeownershipPreservationFlag
		   	  , CommunityBasedEconomicDevelopmentFlag
		      , AssetandPropertyManagementFlag
		      , RealEstateDevelopmentFlag
			  , LendingandPortfolioManagementFlag
			  , OtherServicesFlag 
FROM dbo.Assessment A
LEFT JOIN  dbo.tblOnSiteRatings ONR 
ON ONR.PCODE = a.PCODE AND a.ReviewType = 'On-Site'
LEFT JOIN dbo.tblOffSiteRating OFFR 
ON OFFR.PCODE = a.PCODE AND a.ReviewType = 'Off-Site'
JOIN _Stg.vwLinesofBus B 
ON B.PCODE = a.PCODE
JOIN #t t 
ON t.PCODE = a.PCODE
) AS temp2

SELECT pcode
	   ,AssessmentDate
	   ,MeetingDate
	   ,Division
	   ,ModifiedBy
	   ,RatingRecommendation
	   ,WatchRecommendation
	   ,CAST(PROMPTRating_P AS VARCHAR(55))AS PROMPTRating_P
	   ,CAST(PROMPTRating_R AS VARCHAR(55))AS PROMPTRating_R
	   ,CAST(PROMPTRating_O AS VARCHAR(55))AS PROMPTRating_O
	   ,PROMPTRating_M
	   ,PROMPTRating_PM
	   ,PROMPTRating_T
	   ,HomeownershipPreservationFlag
	   ,CommunityBasedEconomicDevelopmentFlag
	   ,AssetandPropertyManagementFlag
	   ,RealEstateDevelopmentFlag
	   ,LendingandPortfolioManagementFlag
	   ,OtherServicesFlag
	   ,ROW_NUMBER()OVER(PARTITION BY PCODE,AssessmentDate, MeetingDate, Division ORDER BY Pcode)RN 
	   INTO #t3
FROM #t2

SELECT pcode
	   ,AssessmentDate
	   ,MeetingDate
	   ,Division
	   ,ModifiedBy
	   ,RatingRecommendation
	   ,WatchRecommendation
	   ,CAST(PROMPTRating_P AS VARCHAR(55))AS PROMPTRating_P
	   ,CAST(PROMPTRating_R AS VARCHAR(55))AS PROMPTRating_R
	   ,CAST(PROMPTRating_O AS VARCHAR(55))AS PROMPTRating_O
	   ,PROMPTRating_M
	   ,PROMPTRating_PM
	   ,PROMPTRating_T
	   ,HomeownershipPreservationFlag
	   ,CommunityBasedEconomicDevelopmentFlag
	   ,AssetandPropertyManagementFlag
	   ,RealEstateDevelopmentFlag
	   ,LendingandPortfolioManagementFlag
	   ,OtherServicesFlag
FROM #t3
WHERE Division!='' AND RN = 1
GROUP BY pcode
		 ,AssessmentDate
		 ,MeetingDate
		 ,Division
		 ,ModifiedBy
		 ,RatingRecommendation
		 ,WatchRecommendation
		 ,CAST(PROMPTRating_P as varchar(55))
		 ,CAST(PROMPTRating_R as varchar(55))
		 ,CAST(PROMPTRating_O as varchar(55))
		 ,PROMPTRating_M
	     ,PROMPTRating_PM
	     ,PROMPTRating_T
		 ,HomeownershipPreservationFlag
		 ,CommunityBasedEconomicDevelopmentFlag
		 ,AssetandPropertyManagementFlag
		 ,RealEstateDevelopmentFlag
		 ,LendingandPortfolioManagementFlag
		 ,OtherServicesFlag
ORDER BY MeetingDate DESC

DROP TABLE #t
DROP TABLE #t2
DROP TABLE #t3
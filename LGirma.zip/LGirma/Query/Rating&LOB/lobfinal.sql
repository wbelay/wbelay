WITH CTE 
AS (
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate		   
			  ,CASE				
				  WHEN FieldRating IS NOT NULL OR FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
			  END AS Division		   
			  ,CASE 				
				  WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
			  END AS RatingRecommendation		    
			  ,CASE 				
				  WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
			  END AS WatchListRecommendation		   
			  ,ModifiedBy		   
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	  FROM dbo.tblRatingDetail R
	  WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
				AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
	UNION
	                       
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				  WHEN OADRating IS NOT NULL OR OADWatchRecommendation IS NOT NULL THEN 'OAD' 
			  END AS Division
			  ,CASE 
				  WHEN 'OADRating' IS NOT NULL THEN OADRating
			  END AS RatingRecommendation
			  ,CASE 
				  WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
			  END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
	   FROM dbo.tblRatingDetail R
	   WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			 AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				 AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				 AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION
					
	  SELECT  R.PCODE
			  ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
			  ,CASE 
				  WHEN NIRating IS NOT NULL OR NIWatchRecommendation IS NOT NULL THEN 'NI' 
			  END AS Division
			  ,CASE 
				  WHEN 'NIRating' IS NOT NULL THEN NIRating
			  END AS RatingRecommendation
			  ,CASE 
				  WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
			  END AS WatchListRecommendation
			  ,ModifiedBy
			  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
	UNION
					
	    SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NFMCRating IS NOT NULL OR NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
				END AS Division
				,CASE 
					WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
	    		,CASE 
					WHEN NHPRating IS NOT NULL OR NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
				END AS Division
				,CASE 
					WHEN 'NHPRating' IS NOT NULL THEN NHPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

	UNION

		SELECT  R.PCODE
				,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
				,CASE 
					WHEN NREPRating IS NOT NULL OR NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
				END AS Division
				,CASE 
					WHEN 'NREPRating' IS NOT NULL THEN NREPRating
				END AS RatingRecommendation
				,CASE 
					WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
				END AS WatchListRecommendation
				,ModifiedBy
				,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
		FROM dbo.tblRatingDetail R
		WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
			  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
  )
			  
,CTE2 AS 
	   (
	     SELECT CTE.PCODE
				,A.AssessmentDate
				,CTE.MeetingDate
				,CTE.Division
				,CTE.RatingRecommendation
				,CTE.WatchListRecommendation
				,CTE.ModifiedBy
				,CTE.ModifiedDate
		 FROM CTE JOIN Assessment a 
		 ON CTE.PCODE=A.PCODE AND CTE.MeetingDate=A.MeetingDate
		)
,CTE3 AS 
	   (
	    SELECT  os.PCODE
			    ,os.ReviewDate
                ,REPLACE(os.ProductionProgramServicesText,'Meet','Met') AS PROMPTRating_P
                ,REPLACE(os.ResourceManagementText,'Meet','Met') AS PROMPTRating_R
                ,REPLACE(os.OrganizationalManagementText,'Meet','Met') AS PROMPTRating_O
				,REPLACE(os.PersonnelManagementText,'Meet','Met') AS PROMPTRating_M
				,REPLACE(os.PlanningText,'Meet','Met') AS PROMPTRating_PM
				,REPLACE(os.TechnicalOperationsSystemsText,'Meet','Met') AS PROMPTRating_T 
		FROM dbo.tblOnSiteRatings OS 
		WHERE OS.PCODE in ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
		
		UNION  
		
		SELECT ofs.PCODE
			   ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
			   ,REPLACE(CAST(ofs.ProductionProgramServicesDescription AS VARCHAR(55)),'Meet','Met') AS PROMPTRating_P
			   ,REPLACE(CAST(ofs.ResourceFinancialManagementDescription AS VARCHAR(55)),'Meet','Met')  AS PROMPTRating_R
			   ,REPLACE(CAST(ofs.OrganizationalManagementDescription AS VARCHAR(55)),'Meet','Met')  AS PROMPTRating_O
			   ,'' AS PROMPTRating_M
			   ,'' AS PROMPTRating_PM
			   ,'' AS PROMPTRating_T 
		FROM dbo.tblOffSiteRating ofs 
		WHERE ofs.PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
	   )
,CTE4 AS 
		(
		 SELECT CTE2.PCODE
				,CTE2.AssessmentDate
				,CTE2.MeetingDate
				,CTE2.Division
				,CTE2.RatingRecommendation
				,CTE2.WatchListRecommendation
				,CTE2.ModifiedBy
				,CTE2.ModifiedDate
				,CASE WHEN cte2.Division='OAD' then CTE3.PROMPTRating_P ELSE '' END AS PROMPTRating_P
				,CASE WHEN CTE2.Division='OAD' then CTE3.PROMPTRating_R ELSE '' END AS PROMPTRating_R
				,CASE WHEN CTE2.Division='OAD' then CTE3.PROMPTRating_O ELSE '' END AS PROMPTRating_O
				,CASE WHEN CTE2.Division='OAD' then CTE3.PROMPTRating_PM ELSE '' END AS PROMPTRating_PM
				,CASE WHEN CTE2.Division='OAD' then CTE3.PROMPTRating_M ELSE '' END AS PROMPTRating_M 
				,CASE WHEN cte2.Division='OAD' then CTE3.PROMPTRating_T ELSE '' END AS PROMPTRating_T 
		FROM CTE2 join CTE3 ON CTE2.PCODE=CTE3.PCODE AND CTE2.AssessmentDate=CTE3.ReviewDate
		WHERE CTE2.Division!=''AND (CTE2.RatingRecommendation!=''OR CTE2.WatchListRecommendation!='')
	   )
,CTE5 AS(
		  SELECT cte4.PCODE
				,cte4.AssessmentDate
				,cte4.MeetingDate
				,cte4.Division
				,cte4.RatingRecommendation
				,cte4.WatchListRecommendation
				,cte4.ModifiedBy
				,cte4.ModifiedDate
				,cte4.PROMPTRating_P
				,cte4.PROMPTRating_R
				,cte4.PROMPTRating_O
				,cte4.PROMPTRating_M
				,cte4.PROMPTRating_PM
				,cte4.PROMPTRating_T
				,CASE WHEN cte4.Division = 'OAD'THEN HomeownershipPreservationFlag END AS HomeOwnershipPreservationServices
				,CASE WHEN cte4.Division = 'OAD'THEN HomeownershipPromotionServicesFlag END AS HomeOwnershipPromotion
				,CASE WHEN cte4.Division = 'OAD'THEN CommunityBuildingandOrganizingFlag END AS CommunityBuildingandEngagement
				,CASE WHEN cte4.Division = 'OAD'THEN RealEstateDevelopmentFlag END AS RealEstateDevelopment
				,CASE WHEN cte4.Division = 'OAD'THEN LendingandPortfolioManagementFlag END AS LendingandLoanPortfolio 
				,CASE WHEN cte4.Division = 'OAD'THEN OtherServicesFlag ELSE '' END AS OtherServices
				,ROW_NUMBER()OVER(PARTITION BY CTE4.PCODE,CTE4.AssessmentDate,CTE4.MeetingDate,CTE4.Division,cte4.ratingrecommendation
											  ,CTE4.WatchListRecommendation,CTE4.ModifiedBy,CTE4.ModifiedDate,CAST(CTE4.PROMPTRating_P AS VARCHAR(55)),CAST(CTE4.PROMPTRating_R AS VARCHAR(55))
											 ,CAST(CTE4.PROMPTRating_O AS VARCHAR(55)),CTE4.PROMPTRating_PM,CTE4.PROMPTRating_M,CTE4.PROMPTRating_T
									         --,HomeownershipPreservationFlag,HomeownershipPromotionServicesFlag,CommunityBuildingandOrganizingFlag
									         --,RealEstateDevelopmentFlag,LendingandPortfolioManagementFlag,OtherServicesFlag
									ORDER BY CTE4.PCODE)RN

		FROM CTE4 
		LEFT JOIN _Stg.vwLinesofBus LB 
		ON cte4.PCODE=LB.PCODE --AND cte4.AssessmentDate=LB.ReviewDate
	   )
 SELECT CTE5.PCODE
		,CTE5.AssessmentDate
		,CTE5.MeetingDate
		,CTE5.Division
		,CTE5.RatingRecommendation
		,CTE5.WatchListRecommendation
		,CTE5.ModifiedBy
		,CTE5.ModifiedDate
		,CTE5.PROMPTRating_P
		,CTE5.PROMPTRating_R
		,CTE5.PROMPTRating_O
		,CTE5.PROMPTRating_M
		,CTE5.PROMPTRating_PM
		,CTE5.PROMPTRating_T
		,CTE5.HomeOwnershipPreservationServices
		,CTE5.HomeOwnershipPromotion
		,CTE5.CommunityBuildingandEngagement
		,CTE5.RealEstateDevelopment
		,CTE5.LendingandLoanPortfolio
		,CTE5.OtherServices
 FROM CTE5
 WHERE RN=1 
 

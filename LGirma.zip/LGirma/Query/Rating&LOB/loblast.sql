WITH cte
AS
(
		SELECT dt.*
			  ,A.AssessmentDate
			  ,A.MeetingDate
			  ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.ProductionProgramServicesText,'Meet','Met')
					WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN REPLACE(CAST(ofr.ProductionProgramServicesDescription AS VARCHAR(55)),'Meet','Met')
					END AS PROMPTRating_P
			  ,CASE  WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.ResourceManagementText,'Meet','Met')
					WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN REPLACE(CAST(ofr.ResourceFinancialManagementDescription AS VARCHAR(55)),'Meet','Met')
					END AS PROMPTRating_R
              ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.OrganizationalManagementText,'Meet','Met')
					WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN REPLACE(CAST(ofr.OrganizationalManagementDescription AS VARCHAR(55)),'Meet','Met')
					END AS PROMPTRating_O
              ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.PersonnelManagementText,'Meet','Met') 
					WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN '' END AS PROMPTRating_M
              ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.PlanningText,'Meet','Met') 
					WHEN Division = 'OAD'AND A.ReviewType = 'Off-site'THEN '' END AS PROMPTRating_PM
              ,CASE WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN REPLACE(os.TechnicalOperationsSystemsText,'Meet','Met')       
					WHEN Division = 'OAD'AND A.ReviewType = 'On-site'THEN ''
			   ELSE '' END AS PROMPTRating_T
			  --,REPLACE('MEET','','')---REPLACE MEET WITH MET
		FROM(
              SELECT  R.PCODE		   
					  ,CASE				
						  WHEN FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL THEN 'Field'			 
					  END AS Division		   
					  ,CASE 				
						  WHEN 'FieldRating' IS NOT NULL THEN FieldRating			
					  END AS RatingRecommendation		    
					  ,CASE 				
						  WHEN 'FieldWatchRecommendation'IS NOT NULL THEN FieldWatchRecommendation 
					  END AS WatchRecommendation		   
			          ,ModifiedBy		   
					  ,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL       
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
	                       
			UNION
	                       
			SELECT  R.PCODE
			        ,CASE 
						WHEN OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL THEN 'OAD' 
					END AS Division
					,CASE 
						WHEN 'OADRating' IS NOT NULL THEN OADRating
					END AS RatingRecommendation
					,CASE 
						WHEN 'OADWatchRecommendation' IS NOT NULL THEN OADWatchRecommendation
					END AS WatchRecommendation
					,ModifiedBy
					,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

			UNION
					
			SELECT  R.PCODE
					,CASE 
						WHEN NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL THEN 'NI' 
					END AS Division
					,CASE 
						WHEN 'NIRating' IS NOT NULL THEN NIRating
					END AS RatingRecommendation
					,CASE 
						WHEN 'NIWatchRecommendation' IS NOT NULL THEN NIWatchRecommendation
					END AS WatchRecommendation
					,ModifiedBy
					,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
 				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
					
			UNION
					
			SELECT  R.PCODE
					,CASE 
						WHEN NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL THEN 'NFMC' 
					END AS Division
					,CASE 
						WHEN 'NFMCRating' IS NOT NULL THEN NFMCRating
					END AS RatingRecommendation
					,CASE 
						WHEN 'NFMCWatchRecommendation' IS NOT NULL THEN NFMCWatchRecommendation
					END AS WatchRecommendation
					,ModifiedBy
					,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

			UNION

			SELECT  R.PCODE
	    			,CASE 
						WHEN NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL THEN 'NHP' 
					END AS Division
					,CASE 
						WHEN 'NHPRating' IS NOT NULL THEN NHPRating
					END AS RatingRecommendation
					,CASE 
						WHEN 'NHPWatchRecommendation' IS NOT NULL THEN NHPWatchRecommendation
					END AS WatchRecommendation
					,ModifiedBy
					,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)

			UNION

			SELECT  R.PCODE
					,CASE 
						WHEN NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL THEN 'NREP' 
					END AS Division
					,CASE 
						WHEN 'NREPRating' IS NOT NULL THEN NREPRating
					END AS RatingRecommendation
					,CASE 
						WHEN 'NREPWatchRecommendation' IS NOT NULL THEN NREPWatchRecommendation
					END AS WatchRecommendation
					,ModifiedBy
					,CONVERT(VARCHAR(20),ModifiedDate,101) AS ModifiedDate
			FROM dbo.tblRatingDetail R
			WHERE PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')  
				  AND(FieldRating IS NOT NULL AND FieldWatchRecommendation IS NOT NULL OR OADRating IS NOT NULL AND OADWatchRecommendation IS NOT NULL
				  AND NIRating IS NOT NULL AND NIWatchRecommendation IS NOT NULL OR NFMCRating IS NOT NULL AND NFMCWatchRecommendation IS NOT NULL 
				  AND NHPRating IS NOT NULL AND NHPWatchRecommendation IS NOT NULL OR NREPRating IS NOT NULL AND NREPWatchRecommendation IS NOT NULL)
		)AS dt  
		LEFT JOIN dbo.tblOnSiteRatings OS
		ON OS.PCODE = dt.PCODE 	
		JOIN Assessment A
		ON A.PCODE = dt.PCODE AND A.PCODE = OS.PCODE
		LEFT JOIN dbo.tblOffSiteRating OFR
		ON OFR.PCODE = dt.PCODE
)

SELECT  cte.PCODE
       ,cte.AssessmentDate
       ,cte.MeetingDate
       ,cte.Division
       ,cte.RatingRecommendation
	   ,cte.WatchRecommendation
	   ,cte.ModifiedBy
	   ,cte.PROMPTRating_P
	   ,cte.PROMPTRating_R
	   ,cte.PROMPTRating_O
	   ,cte.PROMPTRating_M
	   ,cte.PROMPTRating_PM
	   ,cte.PROMPTRating_T
	   ,CASE WHEN Division = 'OAD'THEN HomeownershipPreservationFlag END AS HomeOwnershipPreservationServices
	   ,CASE WHEN Division = 'OAD'THEN HomeownershipPromotionServicesFlag END AS HomeOwnershipPromotion
	   ,CASE WHEN Division = 'OAD'THEN CommunityBuildingandOrganizingFlag END AS CommunityBuildingandEngagement
	   ,CASE WHEN Division = 'OAD'THEN RealEstateDevelopmentFlag END AS RealEstateDevelopment
	   ,CASE WHEN Division = 'OAD'THEN LendingandPortfolioManagementFlag END AS LendingandLoanPortfolio 
	   ,CASE WHEN Division = 'OAD'THEN OtherServicesFlag ELSE '' END AS OtherServices
       ,ROW_NUMBER()OVER(PARTITION BY CTE.PCODE, cte.AssessmentDate,cte.MeetingDate,cte.Division
                         ORDER BY cte.PCODE)RN
       --,ROW_NUMBER()OVER(PARTITION BY CTE.PCODE, cte.AssessmentDate,cte.MeetingDate ORDER BY cte.PCODE)RN1
       INTO #t
FROM cte 
JOIN _Stg.vwLinesofBus
ON _Stg.vwLinesofBus.PCODE = cte.PCODE AND _Stg.vwLinesofBus.ReviewDate = cte.AssessmentDate
WHERE  cte.Division !='' AND (cte.RatingRecommendation != '' OR cte.WatchRecommendation != '')
     
GROUP BY cte.PCODE
         ,cte.AssessmentDate
         ,cte.MeetingDate
         ,cte.Division
         ,cte.RatingRecommendation
	     ,cte.WatchRecommendation
		 ,cte.ModifiedBy
		 ,cte.ModifiedDate
		 ,cte.PROMPTRating_P
		 ,cte.PROMPTRating_R
		 ,cte.PROMPTRating_O
		 ,cte.PROMPTRating_M
		 ,cte.PROMPTRating_PM
		 ,cte.PROMPTRating_T
		 ,HomeownershipPreservationFlag 
		 ,HomeownershipPromotionServicesFlag 
		 ,CommunityBuildingandOrganizingFlag 
		 ,RealEstateDevelopmentFlag 
		 ,LendingandPortfolioManagementFlag 
		 ,OtherServicesFlag 
ORDER BY CTE.MeetingDate DESC


SELECT PCODE
	   ,AssessmentDate
	   ,MeetingDate
	   ,Division
	   ,RatingRecommendation
	   ,WatchRecommendation
	   ,ModifiedBy
	   ,MeetingDate
	   ,PROMPTRating_P
	   ,PROMPTRating_R
	   ,PROMPTRating_O
	   ,PROMPTRating_M
	   ,PROMPTRating_PM
	   ,PROMPTRating_T
	   ,HomeOwnershipPreservationServices
	   ,HomeOwnershipPromotion
	   ,CommunityBuildingandEngagement
	   ,RealEstateDevelopment
	   ,LendingandLoanPortfolio
	   ,OtherServices
FROM #t
WHERE RN=1 --AND RN1=1
AND PCODE = 8187

DROP TABLE #t
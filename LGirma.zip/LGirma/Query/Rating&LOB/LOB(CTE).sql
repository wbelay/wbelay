USE HARP
GO

WITH cte
AS 
(
  SELECT dt.*
        ,ISNULL(CASE dt.Division 
                          WHEN 'Field' THEN [dbo].[udf_StripHTML] (tr.FieldSummary)
                          WHEN 'OAD' THEN [dbo].[udf_StripHTML] (tr.OADSummary)
                          WHEN 'NI' THEN [dbo].[udf_StripHTML] (tr.NISummary)
                          WHEN 'NFMC' THEN [dbo].[udf_StripHTML] (tr.NFMCSummary) 
                          WHEN 'NHP' THEN [dbo].[udf_StripHTML] (tr.NHPSummary)
                          --WHEN 'CapCandps' THEN [dbo].[udf_StripHTML] (tr.CapCandpsSummary)
                          ELSE [dbo].[udf_StripHTML] (tr.NREPSummary)
                        END,'') AS Summary
        ,tr.ModifiedBy
        ,CONVERT(VARCHAR(20),tr.ModifiedDate,101) AS ModifiedDate
  FROM (
        SELECT R.PCODE
               ,CONVERT(VARCHAR(20),R.MeetingDate,101) AS MeetingDate
               ,CASE 
                  WHEN FieldRating IS NOT NULL AND FieldWatchRecommENDation IS NOT NULL THEN 'Field'
                  WHEN OADRating IS NOT NULL AND  OADWatchRecommENDation IS NOT NULL THEN 'OAD' 
                  WHEN NIRating IS NOT NULL AND  NIWatchRecommENDation IS NOT NULL THEN 'NI' 
                  WHEN NFMCRating IS NOT NULL AND  NFMCWatchRecommENDation IS NOT NULL THEN 'NFMC' 
                  WHEN NHPRating IS NOT NULL AND  NHPWatchRecommENDation IS NOT NULL THEN 'NHP' 
                  WHEN NREPRating IS NOT NULL AND  NREPWatchRecommENDation IS NOT NULL THEN 'NREP' 
                --WHEN CapCandpsSummary IS NOT NULL THEN 'CapCandps'
              END AS Division
        FROM dbo.tblRatingDetail R
      --WHERE CapCandpsSummary IS NOT NULL
        WHERE (FieldRating IS NOT NULL AND FieldWatchRecommENDation IS NOT NULL and OADRating IS NOT NULL AND OADWatchRecommENDation IS NOT NULL
               AND NIRating IS NOT NULL AND  NIWatchRecommENDation IS NOT NULL and NFMCRating IS NOT NULL AND  NFMCWatchRecommENDation IS NOT NULL 
               AND NHPRating IS NOT NULL AND  NHPWatchRecommENDation IS NOT NULL and NREPRating IS NOT NULL AND  NREPWatchRecommENDation IS NOT NULL)
       )AS dt 
 INNER JOIN tblRatingDetail tr
 ON dt.PCODE = tr.PCODE
) 
SELECT * 
FROM cte 
WHERE cte.Summary != '' AND Division='CapCandps'
      --AND PCODE IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
ORDER BY Division ASC



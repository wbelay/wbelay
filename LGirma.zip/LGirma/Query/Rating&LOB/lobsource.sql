
BEGIN TRY
                --BEGIN TRANSACTION;
                                
                                
                                /*** incremental - Delete all HARP records that have a review date 
                                                3 months earlier than the current date or are in the future.
                                                changed to 9 months 01/29/2013 
                                                changed to 60 months 01/30/2013***/
                                DELETE FROM [HARP].[dbo].[tblOnSiteReviewLineOfBusiness]
                                WHERE ReviewDate  >= DATEADD(m,-60,getdate());

                                /**** insert records ******/
                                INSERT INTO [HARP].[dbo].[tblOnSiteReviewLineOfBusiness]
           ([PCODE]
           ,[ReviewDate]           
           ,[HomeownershipPreservationFlag]
           ,[HomeownershipPreservationAssessment]
           ,[HomeownershipPreservationExplanation]           
           ,[HomeownershipPromotionServicesFlag]
           ,[HomeownershipPromotionServicesAssessment]
           ,[HomeownershipPromotionServicesExplanation]           
           ,[CommunityBasedEconomicDevelopmentFlag]
           ,[CommunityBasedEconomicDevelopmentAssessment]
           ,[CommunityBasedEconomicDevelopmentExplanation]           
           ,[CommunityBuildingandOrganizingFlag]
           ,[CommunityBuildingandOrganizingAssessment]
           ,[CommunityBuildingandOrganizingExplanation]           
           ,[AssetandPropertyManagementFlag]
           ,[AssetandPropertyManagementAssessment]
           ,[AssetandPropertyManagementExplanation]           
           ,[RealEstateDevelopmentFlag]
           ,[RealEstateDevelopmentAssessment]
           ,[RealEstateDevelopmentExplanation]           
           ,[LendingandPortfolioManagementFlag]
           ,[LendingandPortfolioManagementAssessment]
           ,[LendingandPortfolioManagementExplanation]           
           ,[OtherServicesFlag]           
           ,[OtherServicesAssessment]
           ,[OtherServicesExplanation])
                                SELECT Distinct 
                                                Findings.pcode, Findings.racdate
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[RE?])        ,
                                                CASE [Lines of Bus].[RE]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[REExp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[HOME?]),
                                                CASE [Lines of Bus].[HOME]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[HOMEexp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[ED?]),
                                                CASE [Lines of Bus].[ED]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[EDExp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[CB?]),
                                                CASE [Lines of Bus].[CB]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[CBExp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[PM?]),
                                                CASE [Lines of Bus].[PM]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[PMexp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[RED?]),
                                                CASE [Lines of Bus].[RED]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[REDexp]
                                                ,HARP.dbo.fn_BooleanToYN([Lines of Bus].[LEND?]),
                                                CASE [Lines of Bus].[LEND]WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[LENDEXP]
                                                ,CASE WHEN Cast(Isnull([Lines of Bus].[OT],0)as varchar(1)) = '1' then 'Y' else 'N' end,
                                                CASE [Lines of Bus].[OT] WHEN 1 Then 'Exceed Standards'
                                                WHEN 2 THEN 'Meet Standards'
                                                WHEN 3 THEN 'Fail Standards'
                                                ELSE 'Not rated' END
                                                ,[Lines of Bus].[OTEXP]
                                FROM DataTrf.dbo.[Lines of Bus] 
                                --INNER JOIN Datatrf.dbo.[OAD Manager] ON [Lines of Bus].rcode=[OAD Manager].rcode
                                INNER JOIN Datatrf.dbo.Findings ON Findings.rcode=[Lines of Bus].rcode
                                INNER JOIN HARP.dbo.tblOrganization ON tblOrganization.PCODE = Findings.pcode
                                WHERE Findings.racdate is not null 
                                --and [OAD Manager].[version] like '%Final%'
                                                AND not exists ( SELECT * FROM [HARP].[dbo].[tblOnSiteReviewLineOfBusiness] t
                                                                WHERE t.PCODE = Findings.PCODE AND t.ReviewDate = Findings.racdate);









--=================================SQL CODES TO PRODUCE STAGING TABLES CLONE================================================

/*SQL Code to produce StgAssessment_Clone*/
INSERT INTO StgAssessment_Clone(PCODE,AssessmentDate, ReviewType, AssignedTo, AssessmentStatus, RecordStatus, FinalReportApprovedDate, CreatedBy, CreatedDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	  ,AssessmentDate, ReviewType, AssignedTo, AssessmentStatus, RecordStatus, FinalReportApprovedDate, CreatedBy, CreatedDate
FROM StgAssessment
WHERE PCODE IN(8187,8070,8272,8300)

--SELECT *
--INTO StgSummaryUpdates_Clone
--FROM StgSummaryUpdates
--WHERE 1=2

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&========================================================

/*SQL Code to produce StgAssessment_MeetingDate_Clone*/
INSERT INTO StgAssessment_MeetingDate_Clone(PCODE,AssessmentDate, MeetingDate, CreatedBy, CreatedDate,DeferredFlag)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	  ,AssessmentDate, MeetingDate, CreatedBy, CreatedDate, DeferredFlag
FROM StgAssessment_MeetingDate
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&=======================================================

/*SQL Code to produce StgCurrentRating_Clone*/
INSERT INTO StgCurrentRating_Clone(PCODE, FinalOHTSRecommendation, MeetingDate, WatchListStartDate, ProvisionalCharterStatus, ProvisionCharterStatusDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,FinalOHTSRecommendation, MeetingDate, WatchListStartDate, ProvisionalCharterStatus, ProvisionCharterStatusDate
FROM StgCurrentRating
WHERE PCODE IN(8187,8070,8272,8300)

--=========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&======================================================

/*SQL Code to produce StgDivisionRatings_Clone*/
INSERT INTO StgDivisionRatings_Clone(PCODE, MeetingDate, Division, RatingRecommendation, WatchListRecommendation, ModifiedBy, ModifiedDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MeetingDate, Division, RatingRecommendation, WatchListRecommendation, ModifiedBy, ModifiedDate
FROM StgDivisionRatings
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&=======================================================

/*SQL Code to produce StgEarlyAlert_Clone*/
INSERT INTO StgEarlyAlert_Clone(PCODE, MeetingDate, IssueIdentifiedDesc, Division, LastUpdateDesc, ResolvedWhenDesc, IsClosed,CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MeetingDate, IssueIdentifiedDesc, Division, LastUpdateDesc, ResolvedWhenDesc, IsClosed,CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
FROM StgEarlyAlert
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&==========================================================

/*SQL Code to produce StgFinding_Clone*/
INSERT INTO StgFinding_Clone(PCODE, MeetingDate, Assessmentdate, FindingGroup, FindingDate, FindingDescription,OADRecommendation, Isclosed, 
			 CreatedBy, CreatedDate, ModifiedBy, ModifiedDate, TaskDescription, TaskCompleted, OADResolutionComments, FieldResolutionComments)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MeetingDate, Assessmentdate, FindingGroup, FindingDate, FindingDescription,OADRecommendation, Isclosed, CreatedBy, CreatedDate,
	    ModifiedBy, ModifiedDate, TaskDescription, TaskCompleted, OADResolutionComments, FieldResolutionComments
FROM StgFinding
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&==========================================================

/*SQL Code to produce StgMOU_Clone*/
INSERT INTO StgMOU_Clone(PCODE, MOUStartDate, MOUExpirationDate, MOUTopic, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate, IsClosed)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MOUStartDate, MOUExpirationDate, MOUTopic, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate, IsClosed
FROM StgMOU
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&==========================================================

/*SQL Code to produce StgRiskObserved_Clone*/
INSERT INTO StgRiskObserved_Clone(PCODE, MeetingDate, RiskCategory, RiskIdentifiedDesc, Division, LastUpdateDesc,
			ResolvedWhenDesc, IsClosed, CreatedBy, CreatedDate, ModifiedBy, MeetingDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MeetingDate, RiskCategory, RiskIdentifiedDesc, Division, LastUpdateDesc,ResolvedWhenDesc, IsClosed, CreatedBy, CreatedDate, ModifiedBy, MeetingDate
FROM StgRiskObserved
WHERE PCODE IN(8187,8070,8272,8300)

--==========================================&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&=========================================================

/*SQL Code to produce StgSummaryUpdates_Clone*/
INSERT INTO StgSummaryUpdates_Clone(PCODE, MeetingDate, Division, Summary, ModifiedBy, ModifiedDate)
SELECT CASE WHEN PCODE = 8187 THEN 9900
			WHEN PCODE = 8070 THEN 9901
			WHEN PCODE = 8272 THEN 9902
			WHEN PCODE = 8300 THEN 9903 END AS PCODE
	   ,MeetingDate, Division, Summary, ModifiedBy, ModifiedDate
FROM StgSummaryUpdates
WHERE PCODE IN(8187,8070,8272,8300)
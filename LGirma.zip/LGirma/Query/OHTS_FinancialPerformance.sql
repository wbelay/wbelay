SELECT PCODE
	 , FiscalYear
	 , RANK()OVER(PARTITION BY pcode ORDER BY FiscalYear DESC) AS [Rank]
	  ,FA.CashAndCashEquivalentsAmount
	  ,FA.CurrentLiabilitiesOverNetAssetsPercentage 
	  ,FA.DefensiveIntRatio
	  ,FA.DepreciationExpenseAmount
	  ,FA.ExpenseAmount
																							--,FiscalYear
																							--,FiscalYearEndMonthAndDay
	  ,FA.LiabilitiesOverNetAssetsPercentage
	  ,(ISNULL(fa.MAndGExpenseOverTotalPercentage,0)) AS MAndGExpenseOverTotalPercentage
	  ,FA.NetAssetsAmount
	  ,FA.CAssets
	  ,FA.CLiab
	  ,FA.NetCashFromOperationsAmount
	  ,FA.NetIncomeAmount
	  ,FA.RevenueAmount
	  ,FA.UnrestrictedCurrentRatio
	  ,FA.CurrentRatio
	  ,FA.QuickCashRatio
	  ,FA.TotalDaysCash
	  ,FA.UnrestrictedNetAssetsAmount
	  ,FA.UnrestrictedNetAssetsOverNetAssetsPercentage
	  ,FA.UnrestrictedNetIncomeAmount
	  ,FA.UnrestrictedNumberOfDaysCash
	  ,FA.UnrestrictedCash
	  ,FA.ReservesCash
	  ,FA.Loans
	  ,FA.FixedAssets
	  ,FA.TAssets
	  ,FA.LTLiab
	  ,FA.TLiab
	  ,FA.NonControllingActivityAmount
	  ,FA.PriorPeriodAdjustmentsAmount
																		  --,FA.RatingAndAFICAComments
																		  --,FA.AuditorOpinionandCommunicationComments
																		  --,FA.NWCapitalFundComments
	  ,FA.OHPSummaryComments
	  --,CASE WHEN FA.FiscalYear = MAX(FA.FiscalYear) THEN  FA.OHPSummaryComments
	  --      ELSE NULL END AS OHPSummaryComments--------------------------defect
	  ,FA.FiscalYearEndMonthAndDay
	  ,FA.CompDate------------------------------------defect
	  ,FA.A133Risk
																		  --,FA.MaterialWeaknesses
																		  --,FA.SignificantDeficiencies
																		  --,'' AS FISICALYEAR
	  ,GETDATE() AS CREATEDDATE
FROM tblFinancialAudit FA
WHERE FA.FiscalYear>=2013
ORDER BY FA.FiscalYear DESC




SELECT  r.PCODE AS PCODE 
        , CONVERT(VARCHAR(20), tblProRating.ReviewDate, 101) AS ReviewDate     
        , CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
        , CASE  
              WHEN r.ReviewFlag = 'Y' THEN 'On-Site Review'
              WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site Review'
              WHEN r.AuditReviewFlag = 'Y' THEN 'Audit Review'
              WHEN r.OthersFlag = 'Y' THEN 'Other'
          ELSE'' 
          END AS ReviewReason --ReviewType must filter for on-site/off-site reviews only
        , rd.OADReviewerName AS AssignedTo
            
FROM tblRating r
--seperate pass for review date
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate
LEFT JOIN (
            SELECT PCODE
				   , CONVERT(DATETIME, CONVERT(VARCHAR(4),FiscalYearYear) + '-' + CONVERT(VARCHAR(2),FiscalMonth) +'-' + '1') AS ReviewDate
                   , ProductionProgramServicesDescription AS P_Text
                   , ResourceFinancialManagementDescription AS R_Text
                   , OrganizationalManagementDescription AS O_Text  
            FROM tblOffSiteRating 
            
            UNION All 
            
            SELECT PCODE
				   , ReviewDate
				   , ProductionProgramServicesText
				   , ResourceManagementText
				   , OrganizationalManagementText 
			FROM tblOnSiteRatings
          ) tblProRating 
ON tblProRating.PCODE = r.PCODE 
   AND tblProRating.ReviewDate = (SELECT MAX(ReviewDate) 
                                  FROM(
                                       SELECT PCODE
											  , CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1') AS ReviewDate
                                       FROM tblOffSiteRating 
                                          --where CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1')  < Getdate()
                                    
                                    UNION All 
                                    
										SELECT PCODE
										       , ReviewDate
                                        FROM tblOnSiteRatings 
                                        WHERE ReviewDate < Getdate()
                                       ) AS tblLatestProRating WHERE tblLatestProRating.PCODE = r.PCODE
                                )
                        
WHERE tblProRating.ReviewDate <= r.MeetingDate
      AND r.MeetingDate <= GETDATE()
      AND r.PCODE = 8272--IN ('8187','8205','8270','8272','8274','8300','8308','8342','8372','8425')
      AND (r.ReviewFlag = 'Y' OR r.ReviewPROFlag = 'Y' OR r.AuditReviewFlag = 'Y' OR r.OthersFlag = 'Y')
            



--SELECT * INTO StgCurrentRating
--FROM(
SELECT M.PCODE AS PCODE
       ,r.CurrentRatingText AS FinalOHTSRecommendation 
       --,m.MeetingDate
       ,CASE WHEN r.MeetingDate = '8/4/2011' THEN '8/16/2011'ELSE r.MeetingDate END AS MeetingDate
       --,r.WatchFlag
       ,CASE WHEN r.WatchFlag = 'N' THEN NULL
			 WHEN r.WatchFlag = 'Y' AND r.OnWatchListSinceDate IS NULL THEN r.MeetingDate
		     ELSE r.OnWatchListSinceDate END AS WatchListstartDate
       ,r.ProvisionalCharterFlag AS ProvisionalCharterStatus 
       ,CASE WHEN r.ProvisionalCharterFlag = 'N' THEN NULL
			 WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NOT NULL THEN r.ProvisionalStartDate 
			 WHEN r.ProvisionalCharterFlag = 'Y' AND r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate < r.MeetingDate THEN P.MinProvisionalStartDate
             WHEN r.ProvisionalCharterFlag = 'Y' AND (r.ProvisionalStartDate IS NULL AND P.MinProvisionalStartDate IS NULL AND P.MaxProvisionalStartDate< r.MeetingDate) THEN P.MaxProvisionalStartDate
             ELSE  r.MeetingDate END AS ProvisionCharterStatusDate
FROM tblOhtsMeeting M
INNER JOIN tblRating r 
ON M.PCODE=R.PCODE AND M.MeetingDate=R.MeetingDate
LEFT JOIN dbo.view_ProvisionalStartDate P
ON P.PCODE = r.PCODE
WHERE YEAR(r.MeetingDate) <> '2050'
	  AND YEAR(r.MeetingDate)>2009
	  AND r.PCODE in (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528,8139,8255,8046,8011,8040)
	  AND r.MeetingDate <= '10/01/2016'
GROUP BY M.PCODE, r.CurrentRatingText, r.MeetingDate, m.MeetingDate, r.WatchFlag, r.OnWatchListSinceDate, r.ProvisionalCharterFlag, r.ProvisionalStartDate, P.MinProvisionalStartDate, P.MaxProvisionalStartDate
--) AS N
 





      
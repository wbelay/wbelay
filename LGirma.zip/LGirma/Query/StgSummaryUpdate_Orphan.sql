SELECT  C.PCODE, C.MeetingDate, C.Division, C.Summary, C.ModifiedBy ,C.ModifiedDate
INTO #T
FROM dbo.StgSummaryUpdates_12816 C 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON C.Pcode=R.Pcode and C.MeetingDate=R.Meetingdate
WHERE R.PCODE IS NULL and C.MeetingDate is not null 

--------------------------------------------------------------------------
SELECT c.PCODE,c.MeetingDate AS MeetingDate
	  ,t.MeetingDate AS OrphanMeetingDate
,DATEDIFF(MONTH,t.MeetingDate,c.MeetingDate) AS DIFF_In_Month
FROM dbo.StgSummaryUpdates C 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON C.Pcode=R.Pcode and C.MeetingDate=R.Meetingdate
JOIN #T t on c.Division= t.Division and c.PCODE=t.PCODE and c.Summary=t.Summary and c.ModifiedDate=t.ModifiedDate

DROP Table #T
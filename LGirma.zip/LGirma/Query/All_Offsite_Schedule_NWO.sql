select a.pcode,a.Region,a.NAME,a.CharterDate,b.AuditYear
	  ,c.[AUDIT DUE],a.[Default PRO MO],a.Comments,a.AuditReceived
	  ,a.AuditRecivedDate,a.FinancialAnalysisComplitionDate,a.[CPA Assigned],a.[Relationship Manager]
	  ,a.OHTSRating,a.WatchList,a.NextOnsiteReviewDate,a.[Last Onsite Review Date],a.OnSitePPS
	  ,a.OnsiteRMFM,a.OnsiteOMBG,a.OnsiteCA,a.OnsiteAFI,a.[Last PROReview Date],a.PROPPS,a.PROMFM
	  ,a.PROOMBG,a.MostRecentReview
from
(
SELECT DISTINCT 
              G.PCODE 
                       ,''                                                             AS Region 
              ,G.Name 
                       ,''                                                             AS CharterDate
              ,f.Year                                                     AS AuditYear 
                       ,g.[AUDIT DUE]                                   AS AuditDue 
              ,''                                                             AS [Default PRO MO] 
                       ,''                                                             AS Comments 
              ,''                                                             AS AuditReceived 
             ,CAST(G.[Received Date] AS DATE)                                 AS AuditRecivedDate
                     ,CAST(F.CompDate AS DATE)                                                    AS FinancialAnalysisComplitionDate
                     ,G.[MAStaff]                                                     AS [CPA Assigned]
                     ,F.MAStaff                                                       AS [Relationship Manager]
                     ,''                                                              AS OHTSRating
                     ,''                                                              AS WatchList 
                     ,''                                                              AS NextOnsiteReviewDate
             ,''                                                              AS [Last Onsite Review Date]
             ,''                                                              AS OnSitePPS
             ,''                                                              AS OnsiteRMFM
             ,''                                                              AS OnsiteOMBG
             ,''                                                              AS OnsiteCA
             ,''                                                              AS OnsiteAFI
             ,''                                                              AS [Last PROReview Date]
             ,''                                                              AS PROPPS
             ,''                                                              AS PROMFM
             ,''                                                              AS PROOMBG
             ,''                                                              AS MostRecentReview
FROM [DataTrf].[dbo].[Grant Eligibility]  G
LEFT JOIN [DataTrf].[dbo].[FinHealth]   F
ON G.PCODE = F.PCODE
)a
left join 
(
select pcode
	   ,max([year]) as [AuditYear]
from FinHealth
where compdate is not null 
group by pcode
) b
on a.pcode=b.pcode and a.[AuditYear]= b.[AuditYear]
left join 
(
select pcode
	   ,max(cast([AUDIT DUE] as date)) as [AUDIT DUE]
from [dbo].[Grant Eligibility]
group by pcode
) c
on a.pcode=c.PCODE and a.AuditDue=c.[AUDIT DUE]
where b.[AuditYear] is not null and c.[AUDIT DUE] is not null 



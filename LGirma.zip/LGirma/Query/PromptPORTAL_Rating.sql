select *
from
(
SELECT Value as rating
  ,a.PCODE
   ,PCODE as orgid   
  FROM [PromptPortal].[dbo].[tblOrganization] a
  left outer join [PromptPortal].[dbo].[tblReferenceTableValue] b
on a.CurrentRatingID=b.ID and b.TableID=17

 -- group by Value
 )p
 PIVOT
(
COUNT (PCODE)
FOR rating IN
( [Provisional  Satisfactory], [Provisional  Strong],[Exemplary],[Satisfactory],[Strong],
[Provisional  Vulnerable],[Vulnerable],[NULL])
) AS pvt
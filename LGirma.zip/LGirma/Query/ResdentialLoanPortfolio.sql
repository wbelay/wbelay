--SELECT
--*
--FROM (
SELECT DISTINCT PCode
      ,LEFT(R.dim_ReportingQuarter_key,4) as FisicalYear
	  ,CASE WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=3 THEN 01 
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=6 THEN 02
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=9 THEN 03
			WHEN RIGHT(LEFT(R.dim_ReportingQuarter_key,6),2)=12 THEN 04 END AS FisicalYearQuarter
	 ,CONVERT(INT,[First_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [NumberOfOutstandingLoans]
	 ,CONVERT(MONEY,[First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [AmountOfOutstandingLoans]
	 ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [NumberOf 30 to 59 Days Delinqunet]
	 ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [AmountOf 30 to 59 Days Delinqunet]
	 ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [NumberOf 60 to 89 Days Delinqunet]
	 ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [AmountOf 60 to 89 Days Delinqunet]
	 ,CONVERT(INT,[First_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [NumberOf 90 + Days Delinqunet]
	 ,CONVERT(MONEY,[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [AmountOf 90 + Days Delinqunet]
	 ,CONVERT(DECIMAL(4,3),[First_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]/NULLIF([First_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans],0)) AS [% of $ 90+ Delinquent]
	 ,CONVERT(INT,[Second_Mortgage_Total_Number_Of_Outstanding_RLF_Loans]) AS [SubMortgageNumberOfOutstandingRLFLoans]
	 ,CONVERT(MONEY, [Second_Mortgage_Total_Dollar_Value_Of_Outstanding_RLF_Loans]) AS [SubMortgageAmountOfOutstandingRLFLoans]
	 ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans30to59DaysDelinquent]
	 ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_30_To_59_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans30to59DaysDelinquent]
	 ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans60to89DaysDelinquent]
	 ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Currently_60_To_89_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans60to89DaysDelinquent]
	 ,CONVERT(INT,[Sec_Mor_Number_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageNumberOfRLFLoans90+DaysDelinquent] 
	 ,CONVERT(MONEY,[Sec_Mor_Value_Of_RLF_Loans_Greater_Than_90_Days_Delinquent]) AS [SubMortgageAmountOfRLFLoans90+DaysDelinquent]
FROM [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R
JOIN [dbo].[dim_Organization] O
ON R.dim_Organization_key = O.dim_Organization_key
WHERE PCODE IS NOT NULL --AND LEFT(R.dim_ReportingQuarter_key,4) in ((select MAX(LEFT(R.dim_ReportingQuarter_key,4)) from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R))
----,(select MAX(D.fin_year)-1 from [DataWarehouse].[dbo].[fact_RLF_Portfolio_Status] R LEFT JOIN [dbo].[dim_date] D ON R.dim_ReportingQuarter_key = D.dim_date_key))
----AND right(D.fin_quarter,1)=(select MAX(right(D.fin_quarter,1)) from [dbo].[dim_date] D)
--) as n


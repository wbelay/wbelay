SELECT PCODE
	  ,DistrictName AS Region
	  ,Name
	  ,CharterDate
FROM [dbo].[tblOrganization]
SELECT
  sys.columns.name AS ColumnName,
  sys.tables.name AS TableName
FROM
  sys.columns
JOIN sys.tables
  on sys.columns.object_id = sys.tables.object_id
WHERE
  sys.columns.name LIKE '%PROMPT Dimension Rating Choices%'
---------------------------------------------------------------------------------
SELECT name 
FROM sysobjects 
WHERE id IN ( SELECT id 
              FROM syscolumns 
              WHERE name like '%PROMPT Dimension Rating Choices%')
---------------------------------------------------------------------------------
SELECT * FROM  INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME LIKE '%PROMPT Dimension Rating Choices%'
---------------------------------------------------------------------------------

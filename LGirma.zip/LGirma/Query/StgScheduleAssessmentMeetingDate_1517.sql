--SELECT * INTO StgScheduleAssessmentMeetingDate
--FROM(
SELECT 
[PCODE]
      ,[ScheduleType]
      ,[RequestedAssessmentDate]
      ,[ConfirmedAssessmentDate]
      ,[LastAssessmentDate]
      ,(SELECT MAX(MeetingDate) FROM dbo.TblOHTSMeeting M where A.PCODE=M.PCODE and A.LastAssessmentDate <= M.MeetingDate) as MeetingDate
      ,[CreatedBy]
      ,getDate() as CreatedDate

  FROM [HARP].[dbo].[stgScheduleAssessment] as A
--) AS N

--Assessment
SELECT A.*
FROM dbo.StgAssessment A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode and A.AssessmentDate=AM.AssessmentDate
WHERE AM.PCODE IS NULL and A.AssessmentDate is not null
--AND RecordStatus like 'history'
----------------------
----Early Alert
SELECT *
FROM dbo.StgEarlyAlert A ----no records
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON A.Pcode=R.Pcode and A.MeetingDate=R.Meetingdate
WHERE R.PCODE IS NULL and A.MeetingDate is not null
--------------------
--MOU
SELECT *
FROM dbo.StgMOU A 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON A.Pcode=R.Pcode
WHERE R.PCODE IS NULL
---No Orphan Data
-------------------------------
SELECT *
FROM dbo.StgOADRatingsandLOB_PROMPT A 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON A.Pcode=R.Pcode 
WHERE R.PCODE IS NULL
--No Orphan Data
------------------------------------
SELECT *
FROM dbo.StgRiskObserved A 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON A.Pcode=R.Pcode and A.MeetingDate=R.Meetingdate 
WHERE R.PCODE IS NULL and A.MeetingDate is not null
---No Orphan Data
----------------------
SELECT *
FROM dbo.StgAssessment A 
LEFT JOIN [HARP].[dbo].[tblOHTSMeeting] R
ON A.Pcode=R.Pcode --and A.MeetingDate=R.Meetingdate 
WHERE R.PCODE IS NULL --and A.MeetingDate is not null
--------------------------
SELECT A.*
FROM dbo.StgOADRatingsandLOB_PROMPT A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode and A.AssessmentDate=AM.AssessmentDate
WHERE AM.PCODE IS NULL and A.AssessmentDate is not null
----49 Orphan Records
-----------------------------
SELECT A.*
FROM dbo.StgRiskObserved A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode and A.MeetingDate=AM.MeetingDate
WHERE AM.PCODE IS NULL and A.MeetingDate is not null
--5 Orphan Records
---------------------------------
SELECT A.*
FROM dbo.StgSummaryUpdates A
LEFT JOIN dbo.StgAssessment_MeetingDate AM
ON A.Pcode=AM.Pcode and A.MeetingDate=AM.MeetingDate
WHERE AM.PCODE IS NULL and A.MeetingDate is not null
----615 Orphan Records
-------------------------------------


SELECT  r.PCODE AS PCODE --N
       ,tblProRating.ReviewDate AS ReviewDate
       ,CONVERT(varchar(20), r.MeetingDate, 101) AS MeetingDate --N
       ,case 
            when r.ReviewFlag = 'Y' then 'On-Site Review'
            when r.ReviewPROFlag = 'Y' then 'Off-Site Review'
            when r.AuditReviewFlag = 'Y' then 'Audit Review'
            when r.OthersFlag = 'Y' then 'Other'
            else '' 
              end as ReviewReason --ReviewType must filter for on-site/off-site reviews only
            --, r.o AS AssignedTo 
FROM tblRating r
--seperate pass for review date
LEFT JOIN (
            SELECT PCODE, CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1') AS ReviewDate, 
                   ProductionProgramServicesDescription AS P_Text
                   ,ResourceFinancialManagementDescription AS R_Text
                   ,OrganizationalManagementDescription AS O_Text  
            FROM tblOffSiteRating 
                        
            UNION All 
            
            SELECT PCODE, ReviewDate
				  ,ProductionProgramServicesText
				  ,ResourceManagementText
				  ,OrganizationalManagementText 
            FROM tblOnSiteRatings
            ) AS tblProRating 
ON tblProRating.PCODE = r.PCODE 
AND tblProRating.ReviewDate = (SELECT MAX(ReviewDate) 
     FROM (
           SELECT PCODE, CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1') AS ReviewDate
           FROM tblOffSiteRating 
          --where CONVERT(datetime, CONVERT(varchar(4),FiscalYearYear) + '-' + CONVERT(varchar(2),FiscalMonth) +'-' + '1')  < Getdate()
                                   
           UNION All 
                
           SELECT PCODE, ReviewDate
           FROM tblOnSiteRatings 
           where ReviewDate < Getdate()
          ) AS tblLatestProRating WHERE tblLatestProRating.PCODE = r.PCODE
              )

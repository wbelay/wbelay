UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE IN (SELECT PCODE FROM StgAssessment_MeetingDate
				WHERE DeferredFlag = 'Y' and StgAssessment.AssessmentDate=StgAssessment_MeetingDate.AssessmentDate)


UPDATE dbo.StgAssessment 
SET AssessmentStatus= 'Current'
WHERE PCODE =8046 and AssessmentDate = '2016-06-20'

SELECT *
FROM dbo.StgAssessment 
WHERE AssessmentStatus='Current'

UPDATE dbo.StgAssessment 
SET RecordStatus= 'OADDraftReport'
WHERE AssessmentStatus= 'Current' 

UPDATE dbo.StgAssessment
SET AssignedTo='Promptoadreviewer1'
WHERE AssessmentStatus= 'Current'


ALTER TABLE dbo.StgAssessment
ALTER COLUMN RecordStatus text

ALTER TABLE dbo.StgAssessment_MeetingDate--dbo.OnOffSiteReviews
ALTER COLUMN meetingDate date
--------------Update pcodes 8355 and 8046 inprocess to 1
--UPDATE [HARP].[dbo].[OnOffSiteReviews]
--SET [InProcess]=1
--WHERE PCODE =8355 AND ReviewDate='09/12/2016'
--AND PCODE =8046 AND ReviewDate='06/20/2016'
IF OBJECT_ID('tempdb..#OnSiteReview') IS NOT NULL
 DROP TABLE #OnSiteReview
    
CREATE TABLE #OnSiteReview  
(
 Region VARCHAR(120)
,Pcode INT 
,Name VARCHAR(500)
,[City_State] VARCHAR(500)
,ReviewType INT 
,[On_Site_Review] DATE
,WatchList VARCHAR(10)
)


INSERT INTO #OnSiteReview
SELECT DISTINCT 
DistrictName AS Region
,O.PCODE
,Name
,ISNULL([City],'') +','+ ' '+ ISNULL([State],'') AS [City,State]
,a.ReviewType 
,a.ReviewDate as [On-Site Review]
,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
FROM dbo.tblOrganization o
 JOIN dbo.tblAssessment a 
 ON o.PCODE = a.PCODE
 JOIN dbo.tblOrganizationMeetingDates om 
 ON om.PCODE = o.PCODE
 and a.ID= om.AssessmentID
WHERE a.ReviewType=1 and (OM.IsOnWatchList=1 OR om.IsOnWatchList is null)
AND ReviewDate = (
SELECT max(c.ReviewDate) [On-Site Review]
FROM dbo.tblAssessment c
where c.PCODE=a.PCODE
and a.ReviewType=c.ReviewType
)
IF OBJECT_ID('tempdb..#OffSiteReview') IS NOT NULL
DROP TABLE #OffSiteReview
    
CREATE TABLE #OffSiteReview  
(
 Region VARCHAR(120)
,Pcode INT 
,Name VARCHAR(500)
,[City_State] VARCHAR(500)
,ReviewType INT 
,[Off_Site_Review] DATE
,WatchList VARCHAR(10)
)
INSERT INTO #OffSiteReview
SELECT DISTINCT 
       DistrictName AS Region
       ,O.PCODE
	  ,Name
	  ,ISNULL([City],'') +','+ ' '+ ISNULL([State],'') AS [City,State]
	  ,a.ReviewType 
	  ,a.ReviewDate AS [Off-Site Review]
	  ,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
FROM dbo.tblOrganization o
 JOIN dbo.tblAssessment a 
 ON o.PCODE = a.PCODE
 JOIN dbo.tblOrganizationMeetingDates om 
 ON om.PCODE = o.PCODE
 and a.ID= om.AssessmentID
WHERE a.ReviewType=2 and (OM.IsOnWatchList=1 OR om.IsOnWatchList is null)
AND ReviewDate = (
SELECT max(c.ReviewDate) [On-Site Review]
FROM dbo.tblAssessment c
where c.PCODE=a.PCODE
and a.ReviewType=c.ReviewType
)

SELECT 
 ISNULL(ons.Pcode, ofs.Pcode) as Pcode
,ISNULL(ons.Name, ofs.Name) as Name 
,ISNULL(ons.Region, ofs.Region) as Region 
,ISNULL(ons.City_State, ofs.City_State) as City_State
,ISNULL(ons.WatchList,ofs.WatchList) as WatchList
,ons.On_Site_Review
,ofs.Off_Site_Review
FROM #OnSiteReview Ons
full outer join 
#OffSiteReview ofs
on ons.Pcode=ofs.Pcode 
--WHERE
--ISNULL(ons.Name, ofs.Name) LIKE '%West Elmwood Housing Development Corp.%'

order by ISNULL(ons.Name, ofs.Name) 

--SELECT *
--FROM dbo.tblAssessment a
--join dbo.tblOrganization b
--on a.PCODE=b.PCODE
--where b.Name='West Elmwood Housing Development Corp.'
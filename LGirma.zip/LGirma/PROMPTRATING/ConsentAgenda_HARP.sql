SELECT o.DistrictName AS Region
	   ,o.Name
	   ,o.City +', '+o.State AS City_State
	   ,r.WatchFlag AS WatchList
	   ,r.CurrentRatingText AS OHTSRatings
	   ,CASE WHEN r.ReviewFlag = 'Y' THEN osd.OnsiteDate END AS [On-Site Review]
	   ,CASE WHEN r.ReviewPROFlag= 'Y' THEN ofd.OffsiteDate END AS [Off-Site Review]
	   ,rd.ConsentAgenda
	   ,ROW_NUMBER()OVER(PARTITION BY o.DistrictName,o.Name,o.City ,o.State,r.WatchFlag ORDER BY o.DistrictName)RN
	   INTO #t
FROM tblRating r 
JOIN tblOrganization o
ON r.PCODE = o.PCODE
JOIN tblRatingDetail rd
ON r.PCODE = rd.PCODE
LEFT JOIN
(SELECT 
PCODE
,MAX(ReviewDate) AS OnsiteDate
FROM dbo.tblOnSiteRatings
GROUP BY PCODE
)osd ON osd.PCODE = O.PCODE
LEFT JOIN
(
SELECT Pcode,
MAX(CONVERT(DATE, CONVERT(VARCHAR(4),offr.FiscalYearYear) + '-' + CONVERT(VARCHAR(2),offr.FiscalMonth) +'-' + '1')) AS OffsiteDate
FROM dbo.tblOffSiteRating offr
GROUP BY Pcode
)ofd ON ofd.PCODE = o.PCODE

SELECT t.Region
	  ,t.Name
	  ,t.City_State
	  ,t.WatchList
	  ,t.OHTSRatings
	  ,t.[On-Site Review]
	  ,t.[Off-Site Review]
FROM #t t 
WHERE t.ConsentAgenda = 'True'
	  AND t.WatchList = 'Y'
	  AND RN = 1
	  
ORDER BY Region DESC
	  
DROP TABLE #t

SELECT DistrictName AS Region
	  ,Name
	  ,ISNULL([City],'') +','+ ' '+ ISNULL([State],'') AS [City,State]
	  ,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
	  ,CASE WHEN [RecommendationID] = 1 THEN 'Exemplary'
			WHEN [RecommendationID] = 2 THEN 'Strong'
			WHEN [RecommendationID] = 3 THEN 'Satisfactory'
			WHEN [RecommendationID] = 4 THEN 'Vulnerable'
			WHEN [RecommendationID] = 5 THEN 'N/A'
		END AS [OHTS Ratings]	 
	  ,MAX(CASE WHEN a.ReviewType = 1 THEN a.ReviewDate END) AS [On-Site Review]
	  ,MAX(CASE WHEN a.ReviewType = 2 THEN a.ReviewDate END) AS [Off-Site Review]
	  
FROM dbo.tblOrganization o
LEFT JOIN dbo.tblAssessment a
ON o.PCODE = a.PCODE
LEFT JOIN dbo.tblOrganizationMeetingDates om
ON om.PCODE = o.PCODE
JOIN dbo.tblFinalRatingRecommendations f
ON F.PCODE = o.PCODE
WHERE f.IsConsentAgenda IS NOT NULL
	  AND IsOnWatchList != 0
GROUP BY 
 DistrictName 
,Name
,ISNULL([City],'') +','+ ' '+ ISNULL([State],'')
,IsOnWatchList,[RecommendationID]  
ORDER BY Region,Name,[City,State]

--SELECT DISTINCT  DistrictName
--FROM tblOrganization
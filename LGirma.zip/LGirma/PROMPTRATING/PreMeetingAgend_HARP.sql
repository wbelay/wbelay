SELECT o.DistrictName AS Region
	   ,o.Name
	   ,o.City +', '+o.State AS City_State
	   ,r.WatchFlag AS WatchList
	   ,CASE WHEN r.ReviewFlag = 'Y' THEN osd.OnsiteDate END AS [On-Site Review]
	   ,CASE WHEN r.ReviewPROFlag= 'Y' THEN ofd.OffsiteDate END AS [Off-Site Review]
	   ,ROW_NUMBER()OVER(PARTITION BY o.DistrictName,o.Name,o.City ,o.State,r.WatchFlag ORDER BY o.DistrictName)RN
	   INTO #t
FROM tblRating r
JOIN tblOrganization o
ON r.PCODE = o.PCODE
LEFT JOIN
(Select 
PCODE
,MAX(ReviewDate) As OnsiteDate
from dbo.tblOnSiteRatings
Group By PCODE
)osd ON osd.PCODE = O.PCODE
LEFT JOIN
(
Select Pcode,
MAX( CONVERT(varchar(2),ofr.FiscalMonth) + '/'+'01'  + '/' + CONVERT(varchar(4),ofr.FiscalYearYear)) AS OffsiteDate
from dbo.tblOffSiteRating ofr
Group By Pcode
)ofd ON ofd.PCODE = o.PCODE
SELECT t.Region
	  ,t.Name
	  ,t.City_State
	  ,t.WatchList
	  ,t.[On-Site Review]
	  ,t.[Off-Site Review]
FROM #t t
WHERE t.WatchList = 'Y'
	  AND (t.[On-Site Review] IS NOT NULL OR t.[Off-Site Review] IS NOT NULL)
	  AND RN = 1
DROP TABLE #t

--SELECT *
--FROM tblRating
--WHERE WatchFlag = 'Y'
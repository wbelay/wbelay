SELECT o.PCODE
	  ,o.Name
	  ,o.RMName
	  ,o.DistrictName
	  ,a.OADReviewerName
	  ,om.WatchListStartDate
	  ,'' AS ProvisionalCharter
	  ,o.ProvisionalCharterDate
	  ,CASE WHEN l.LOBTypeID = 1 THEN 'HomeOwnerShipPreservationServices'
		    WHEN l.LOBTypeID = 2 THEN 'HomeOwnerShipPromotion'
		    WHEN l.LOBTypeID = 3 THEN 'CommunityBuilding&Engagement'
		    WHEN l.LOBTypeID = 4 THEN 'PropertyManagement'
		    WHEN l.LOBTypeID = 5 THEN 'RealEstateDevelopment'
		    WHEN l.LOBTypeID = 6 THEN 'Lending&LoanPortfolioManagment'
		    WHEN l.LOBTypeID = 7 THEN 'OtherServices' 
		END AS 'LOBsAssessedbyOAD'
	  ,m.MOUStartDate
	  ,m.MOUExpirationDate
	  ,m.MOUDescription
	  ,CASE WHEN w.DivisionID = 1 THEN 'Field'
			WHEN w.DivisionID = 2 THEN 'OAD'
			WHEN w.DivisionID = 3 THEN 'NI'
			WHEN w.DivisionID = 4 THEN 'NFMC'
			WHEN w.DivisionID = 5 THEN 'NHP'
			WHEN w.DivisionID = 6 THEN 'NREP' 
		END AS NewRatingRecommendations
FROM dbo.tblOrganization o
JOIN dbo.tblAssessment a
ON o.PCODE = a.PCODE
JOIN dbo.tblOrganizationMeetingDates om
ON om.PCODE = o.PCODE
JOIN dbo.tblAssessmentLineOfBusiness l
ON o.PCODE =a.PCODE
JOIN dbo.tblMOU m
ON o.PCODE = m.PCODE
JOIN dbo.tblWatchListRecommendations w
ON o.PCODE = w.PCODE
SELECT DistrictName
	  ,o.PCODE
	  ,Name
	  ,City
	  ,State
	  ,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
	  ,'' AS CurrentOHTSRating
	  ,CASE WHEN a.ReviewType = 1 THEN MAX(a.ReviewDate) END AS [Last-On-Site-Review]
	  ,CASE WHEN a.ReviewType = 2 THEN MAX(a.ReviewDate) END AS [Last Off-Site_Review]
	  ,'' AS FinHealthYear
	  ,'' AS Recived
	  ,'' AS RecivedDate
	  ,'' AS AuditDue
	  ,'' AS CompDate
	  ,'' AS [Last Financial Review Date]
FROM dbo.tblOrganization o
JOIN dbo.tblOrganizationMeetingDates om
ON O.PCODE = om.pcode
JOIN dbo.tblAssessment a
ON a.PCODE = o.PCODE
WHERE IsOnWatchList IS NOT NULL
GROUP BY DistrictName, o.PCODE, Name,City,State,IsOnWatchList,ReviewType
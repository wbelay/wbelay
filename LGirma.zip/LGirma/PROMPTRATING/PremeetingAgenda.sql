SELECT DistrictName AS Region
	  ,Name
	  ,ISNULL([City],'') +','+ ' '+ ISNULL([State],'') AS [City,State]
	  ,MAX(CASE WHEN a.ReviewType = 1 THEN a.ReviewDate END) AS [On-Site Review]
	  ,MAX(CASE WHEN a.ReviewType = 2 THEN a.ReviewDate END) AS [Off-Site Review]
	  ,HARP.dbo.fn_BooleanToYN(IsOnWatchList) AS WatchList
FROM dbo.tblOrganization o
 JOIN dbo.tblAssessment a 
 ON o.PCODE = a.PCODE
 JOIN dbo.tblOrganizationMeetingDates om 
 ON om.PCODE = o.PCODE
WHERE  o.Name='Manna, Inc.'
GROUP BY 
 DistrictName 
,Name
,ISNULL([City],'') +','+ ' '+ ISNULL([State],'')
,IsOnWatchList 
ORDER BY Region,Name,[City,State]


IF OBJECT_ID('tempdb..#PreMeetingAgenda') IS NOT NULL
 DROP TABLE #PreMeetingAgenda
    
CREATE TABLE #PreMeetingAgenda  
(
 Region VARCHAR(120)
,Pcode INT 
,Name VARCHAR(500)
,[City_State] VARCHAR(500)
,ReviewType INT 
,[On_Site_Review] DATE
,[Off_Site_Review] DATE
,WatchList VARCHAR(10)
)
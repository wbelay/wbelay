--SELECT * INTO stgFinding
--FROM
--(
SELECT pcode
	  ,CASE 
		  WHEN YEAR(MeetingDate)=2050 and YEAR(FindingDate)>=2014 THEN '12/08/2016' 
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8526 THEN '12/08/2016'
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8341 THEN '09/08/2016'
	      WHEN YEAR(MeetingDate)=2050 AND PCODE = 8233 THEN '09/08/2016'
          WHEN YEAR(MeetingDate)=2050 AND PCODE = 8177 THEN ''
          WHEN  MeetingDate = '12/15/15' THEN '12/16/15'
	   	  ELSE CONVERT(VARCHAR(20),MeetingDate,101)
	   END AS MeetingDate
	  ,FC.[Type] AS FindingGroup
	  ,CASE WHEN FC.ID = 5 THEN 'PL' ELSE FC.Category END AS FindingCategory
	  ,'' AS FindingType 
	  ,CAST(FindingDate AS DATE) AS FindingDate
	  ,REPLACE([dbo].[udf_StripHTML](F.Finding),'CHAR(13) + CHAR(10)','') AS FindingDescription
	  ,F.OAD AS OADRecommendation
	  ,F.Field AS FieldRecommendation
	  ,dbo.fn_BooleanToYN(F.ClosedFlag) AS IsClosed
	  ,F.CreatedBy 
	  ,CAST(F.CreatedDate AS DATE) AS CreatedDate
	  ,F.ModifiedBy
	  ,CAST(F.ModifiedDate AS DATE) AS ModifiedDate
	  ,FC.[Description] AS TaskDescription
	  ,'' AS TaskCompleted
	  ,'' AS OADResolutionComments
	  ,dbo.udf_StripHTML(Resolution)AS FieldResolutionComments
FROM dbo.tblFindings F
JOIN dbo.tblFindingCategories FC
ON F.CategoryId = FC.ID AND F.[Type] = FC.[Type]
WHERE PCODE  IN (8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)


--) AS stgFindings






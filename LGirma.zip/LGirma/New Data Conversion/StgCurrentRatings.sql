SELECT r.PCODE AS PCODE
       ,r.CurrentRatingText ASFinalOHTSRecommendation 
       ,r.MeetingDate AS MeetingDate
       ,r.OnWatchListSinceDate AS WatchListstartDate 
 FROM tblRating r --where  PCODE in (8272,8187,8270,8342,8372,8205,8300,8308,8274,8425)
WHERE YEAR(r.MeetingDate) != '2050'

      
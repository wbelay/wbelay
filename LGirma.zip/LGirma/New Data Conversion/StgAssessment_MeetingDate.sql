--SELECT * INTO Test_Assessment
--FROM (
SELECT  r.PCODE AS PCODE
        , CONVERT(VARCHAR(20), MAX(OFR.ReviewDate), 101) AS AssessmentDate
        , CONVERT(VARCHAR(20), r.MeetingDate, 101) AS MeetingDate 
 FROM tblRating r
LEFT JOIN dbo.OnOffSiteReviews OFR
	ON r.PCODE = OFR.PCODE                       
WHERE OFR.ReviewDate <= r.MeetingDate 
	  AND r.MeetingDate <= GETDATE() 
	  AND YEAR(OFR.ReviewDate)>= 2009
	  AND YEAR(r.MeetingDate)>= 2009
GROUP BY r.PCODE, r.MeetingDate
--) as n
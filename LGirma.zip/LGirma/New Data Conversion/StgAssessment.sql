
WITH CTE
AS
(
SELECT OS.PCODE 
	  ,OS.ReviewDate
	  ,CASE 
            WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
            ELSE '' 
          END AS ReviewType
      ,rd.OADReviewerName AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OS.PCODE,OS.REVIEWDATE,r.ReviewFlag ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOnSiteReview OS
JOIN dbo.tblRating r 
ON r.PCODE = os.PCODE
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE  
	   OS.ReviewDate<=R.MeetingDate
	   AND OS.ReviewDate<=GETDATE()

UNION ALL

SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,rd.OADReviewerName AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar),r.ReviewPROFlag ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOffSiteRating OFS
JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	   CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=GETDATE()
)

SELECT PCODE
	  ,ReviewDate AS AssessmentDate
	  ,ReviewType
	  ,MAX(AssignedTo) AS AssignedTo
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate
	  INTO #T
FROM CTE
WHERE  RN=1
	  AND ReviewType = 'On-Site' or ReviewType = 'Off-Site'
GROUP BY PCODE,ReviewDate,ReviewType
--SELECT * INTO StgAssessment
--FROM(
SELECT T.PCODE,T.AssessmentDate
	  ,CASE WHEN A.AssignedTo IS NOT NULL THEN A.AssignedTo ELSE T.AssignedTo END AS AssignedTo
	  ,t.ReviewType,t.CreatedBy,t.CreatedDate
FROM #T T
LEFT JOIN AssessmentFull A
ON T.PCODE = A.PCODE AND T.AssessmentDate = A.AssessmentDate 
where t.PCODE = 8070-- in(8198,8149,8523,8328,8272,8187,8070,8342,8372,8205,8300,8308,8274,8425,8528)
--)N

drop table #T
	  
	  
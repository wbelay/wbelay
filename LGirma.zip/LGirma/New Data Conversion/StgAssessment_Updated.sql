
WITH CTE
AS
(
SELECT OS.PCODE 
	  ,OS.ReviewDate
	  ,CASE 
            WHEN r.ReviewFlag = 'Y' THEN 'On-Site'
            ELSE '' 
          END AS ReviewType
      ,rd.OADReviewerName AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OS.PCODE,OS.REVIEWDATE,r.ReviewFlag ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOnSiteReview OS
JOIN dbo.tblRating r 
ON r.PCODE = os.PCODE
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE  
	   OS.ReviewDate<=R.MeetingDate
	   AND OS.ReviewDate<=GETDATE()

UNION ALL

SELECT OFS.PCODE 
	  ,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)AS ReviewDate
	  ,CASE 
            WHEN r.ReviewPROFlag = 'Y' THEN 'Off-Site'
            ELSE '' 
       END AS ReviewType
      ,rd.OADReviewerName AS AssignedTo
	  ,ROW_NUMBER()OVER (PARTITION BY OFS.PCODE,CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar),r.ReviewPROFlag ORDER BY R.MEETINGDATE)RN
FROM dbo.tblOffSiteRating OFS
JOIN dbo.tblRating r 
ON r.PCODE = OFS.PCODE 
LEFT JOIN tblRatingDetail rd
ON rd.PCODE = r.PCODE AND rd.MeetingDate = r.MeetingDate 
WHERE 
	   CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=R.MeetingDate
	  AND R.MeetingDate<=GETDATE()
	  AND CAST(ofs.FiscalMonth AS varchar) + '/' + CAST('1' AS varchar) + '/' + CAST(ofs.FiscalYearYear as varchar)<=GETDATE()
)

SELECT PCODE
	  ,ReviewDate AS AssessmentDate
	  ,ReviewType
	  ,MAX(AssignedTo) AS AssignedTo
	  ,'SwitchBoardImport' AS CreatedBy
	  ,CAST(GETDATE() AS DATE) AS CreatedDate
FROM CTE
WHERE  RN=1
	  AND ReviewType = 'On-Site' or ReviewType = 'Off-Site'
GROUP BY PCODE,ReviewDate,ReviewType
	  
	  
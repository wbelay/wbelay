﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.Office.Server;
using Microsoft.Office.Server.UserProfiles;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Security.Principal;
using System.Linq;
using System.Web.Services;
using MemberJobPostingFeature2010.JobPostingWS;
using System.Web.Configuration;

namespace MemberJobPostingFeature2010
{
    public class JobPostingEventHandlerMgr
    {
        JobPostingService jobPosting = null;

        SPUser user;
        string errMsg = string.Empty;

        public string InsertItem(SPListItem item)
        {
            SPUser currentUser = item.ParentList.ParentWeb.CurrentUser;
            ClientMsg clientMsg = null;
            try
            {
                this.SetJobPostingWS();

                item["DBUpdatedStatus"] = "SetJobPostingWS done";
                item.SystemUpdate();

                Job job = this.GetJobInfo(item);
                item["DBUpdatedStatus"] = "GetJobInfo done ";
                item.SystemUpdate();

                int pcode = job.CompanyID;
                string compName = job.CompanyName;

                clientMsg = jobPosting.InsertJobInfo(job);
                item["DBUpdatedStatus"] = "InsertJobInfo done ";
                item.SystemUpdate();

                item["DBUpdatedStatus"] = "Current User: " + currentUser.LoginName + ", " + errMsg + "<br>" + clientMsg.ErrorMsg.ToString();
                item["DBUpdatedDate"] = DateTime.Now;
                item["Job Listing ID"] = clientMsg.JobListingID.ToString();
                item["Job Status"] = clientMsg.JobStatus;
                item["Employer"] = job.CompanyName;
                item["pcode"] = job.CompanyID;
                item.SystemUpdate();

                this.SetPermissions(item.ParentList, item.ID, "c:0-.f|ldaprole|" + job.GroupName + "_admins");
                item["DBUpdatedStatus"] = "SetPermissions done <br> " + errMsg;
                item.SystemUpdate();

                return "True";
            }
            catch (Exception ex)
            {
                if (clientMsg != null)
                    item["DBUpdatedStatus"] = "CurrentUser: " + currentUser.LoginName + ", " + errMsg + clientMsg.ErrorMsg.ToString();
                else
                    item["DBUpdatedStatus"] = "CurrentUser: " + currentUser.LoginName + ", Error occurred: " + errMsg;

                item.SystemUpdate();
            }

            return "False";
        }
        
        public string UpdateItem(SPListItem item)
        {
            this.SetJobPostingWS();

            Job job = this.GetJobInfo(item);                
            item["DBUpdatedStatus"] = "GetJobInfo done ";
                item.SystemUpdate();

            ClientMsg clientMsg = jobPosting.UpdateJobInfo(job);

            item["DBUpdatedStatus"] = clientMsg.ErrorMsg.ToString() + " " + clientMsg.JobStatus;
            item["DBUpdatedDate"] = DateTime.Now;
            item["Job Status"] = clientMsg.JobStatus;

            item.SystemUpdate();

            return "True";
        }

        public string DeleteItem(SPListItem item)
        {
            this.SetJobPostingWS();
            int jobListID = 0;
            if (item["Job Listing ID"] != null)
            {
                jobListID = Int32.Parse(item["Job Listing ID"].ToString());
            }

            ClientMsg clientMsg = jobPosting.DeleteJob(jobListID);

            item["DBUpdatedStatus"] = clientMsg.ErrorMsg.ToString();
            item["DBUpdatedDate"] = DateTime.Now;
            item.SystemUpdate();

            return "True";
        }

        protected void SetJobPostingWS()
        {
            jobPosting = new JobPostingWS.JobPostingService();
            jobPosting.Credentials = System.Net.CredentialCache.DefaultCredentials;
        }

        public void SetPermissions(SPList spList, int itemID, string groupName)
        {
                
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPListItem item = null;
                    try
                    {
                        if (groupName != null)
                        {
                            // Get references to the site collection and site for the current context.
                            // The using statement makes sures these references are disposed properly.
                            using (SPSite siteCollection = new SPSite(spList.ParentWeb.Site.Url))
                            {
                                errMsg += "<br> siteCollection Url: " + siteCollection.Url;
                                errMsg += "<br> spList.ParentWebUrl: " + spList.ParentWebUrl;

                                using (SPWeb spWeb = siteCollection.OpenWeb(spList.ParentWebUrl))
                                {
                                    spWeb.AllowUnsafeUpdates = true;
                                    errMsg += "<br> spWeb Url: " + spWeb.Url;

                                    SPList elevatedList = spWeb.Lists[spList.ID];
                                    errMsg += "<br> elevatedList =" + elevatedList.Title;
                                    item = elevatedList.GetItemById(itemID);

                                    errMsg += "<br>Elevated User: " + spWeb.CurrentUser.LoginName + "<br>";
                                    item.ResetRoleInheritance();
                                    if (!item.HasUniqueRoleAssignments)
                                    {
                                        item.BreakRoleInheritance(false);
                                    }

                                    errMsg += " BreakRoleInheritance done";

                                    SPRoleAssignment spAssignment;
                                    SPRoleDefinition spRoleDefn;

                                    SPGroup spGroup = spWeb.ParentWeb.Groups["Member Site Owners"];

                                    if (spGroup != null)
                                    {
                                        spAssignment = new SPRoleAssignment(spGroup);
                                        spRoleDefn = item.Web.RoleDefinitions["Full Control"];
                                        spAssignment.RoleDefinitionBindings.Add(spRoleDefn);
                                        item.RoleAssignments.Add(spAssignment);
                                    }

                                    errMsg += "<br>" + "groupName: " + groupName;

                                    if ((this.user.LoginName.ToLower().Contains("neighborworks")) || (this.user.LoginName.ToLower().Contains("dev\\")) || (this.user.LoginName.ToLower().Contains("sharepoint\\")))
                                    {
                                        groupName = "nw_jobposting_admins";
                                        spGroup = spWeb.ParentWeb.Groups["nw_jobposting_admins"];

                                        if (spGroup != null)
                                        {
                                            spAssignment = new SPRoleAssignment(spGroup);
                                            spRoleDefn = item.Web.RoleDefinitions["Contribute"];
                                            spAssignment.RoleDefinitionBindings.Add(spRoleDefn);
                                            item.RoleAssignments.Add(spAssignment);
                                        }
                                    }
                                    else
                                    {
                                        spAssignment = new SPRoleAssignment(groupName, "", groupName, "");
                                        spRoleDefn = item.Web.RoleDefinitions["contribute"];
                                        spAssignment.RoleDefinitionBindings.Add(spRoleDefn);
                                        item.RoleAssignments.Add(spAssignment);
                                    }
                                    spWeb.AllowUnsafeUpdates = false;
                                }
                            }
                        }
                    }

                    catch (Exception ex)
                    {
                        errMsg = "In SetPerm (1): " + errMsg + "<br>" + ex.Message + "<br>" + ex.StackTrace;
                        if (item != null)
                        {
                            item.ResetRoleInheritance();
                            item.SystemUpdate();
                        }
                    }
                    
                });
            }
            

        protected void SetUserProfileInfo(Job job, string siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                SPWeb spWeb = null;
                try
                {
                    //errMsg = siteUrl;
                    spWeb = site.OpenWeb();
                    user = spWeb.CurrentUser;
                    string loginName = user.LoginName;
                    //if (loginName.ToLower().Contains("ldapmembership"))
                      // loginName = loginName.Replace("ldapmembership:", "members\\");
                    if ((user.LoginName.ToLower().Contains("neighborworks")) || (user.LoginName.ToLower().Contains("dev\\")) || (user.LoginName.ToLower().Contains("sharepoint\\")))
                    {
                        job.CompanyID = 0;
                        job.CompanyName = "NeighborWorks America";
                    }
                    else
                    {
                        //ServerContext spServerContext = ServerContext.GetContext(site);
                        SPServiceContext spServerContext = SPServiceContext.GetContext(site);
                        UserProfileManager spUserProfileManager = new UserProfileManager(spServerContext);
                        //errMsg += ", " + loginName; 
                        UserProfile spUserProfile = spUserProfileManager.GetUserProfile(loginName);
                        
                        job.CompanyName = "Company Not Found";
                        job.CompanyID = 0101;

                        if (spUserProfile == null)
                            errMsg += ", user profile null";
                        else
                        {
                            //Microsoft.Office.Server.UserProfiles.PropertyCollection propColl = spUserProfile.ProfileManager.PropertiesWithSection;

                            if (spUserProfile != null)
                            {                             
                                //Property prop;                             

                                //prop = propColl..GetPropertyByName("OrgID");
                                //if (prop != null)
                                //{
                                    if (spUserProfile["OrgID"].Value != null)
                                        job.CompanyID = Int32.Parse((spUserProfile["OrgID"].Value.ToString()));
                                //}

                                //prop = propColl.GetPropertyByName("Company");
                                //if (prop != null)
                                //{
                                    if (spUserProfile["Company"].Value != null)
                                        job.CompanyName = spUserProfile["Company"].Value.ToString();
                                //}

                                //prop = propColl.GetPropertyByName("BusinessCategory");
                                //if (prop != null)
                                //{
                                    //errMsg += " <br> >>>> GroupName: BusinessCategory";
                                    if (spUserProfile["BusinessCategory"].Value != null)
                                        job.GroupName = spUserProfile["BusinessCategory"].Value.ToString();
                                //}
                            }
                        }
                    }


                }
                catch (Exception ex)
                {

                    errMsg += ex.Message + "<br>" + ex.StackTrace;
                    throw;
                }
                finally
                {
                    if (spWeb != null)
                        spWeb.Close();
                }
            }
        }

        protected string GetState(string state)
        {
            string s = string.Empty;
            switch (state)
            {
                case "Alabama":
                    s = "AL";
                    break;
                case "Alaska":
                    s = "AK";
                    break;
                case "Arizona":
                    s = "AZ";
                    break;
                case "Arkansas":
                    s = "AR";
                    break;
                case "California":
                    s = "CA";
                    break;
                case "Colorado":
                    s = "CO";
                    break;
                case "Connecticut":
                    s = "CT";
                    break;
                case "Delaware":
                    s = "DE";
                    break;
                case "District of Columbia":
                    s = "DC";
                    break;
                case "Florida":
                    s = "FL";
                    break;
                case "Georgia":
                    s = "GA";
                    break;
                case "Hawaii":
                    s = "HI";
                    break;
                case "Idaho":
                    s = "ID";
                    break;
                case "Illinois":
                    s = "IL";
                    break;
                case "Indiana":
                    s = "IN";
                    break;
                case "Iowa":
                    s = "IA";
                    break;
                case "Kansas":
                    s = "KS";
                    break;
                case "Kentucky":
                    s = "KY";
                    break;
                case "Louisiana":
                    s = "LA";
                    break;
                case "Maine":
                    s = "ME";
                    break;
                case "Maryland":
                    s = "MD";
                    break;
                case "Massachusetts":
                    s = "MA";
                    break;
                case "Michigan":
                    s = "MI";
                    break;
                case "Minnesota":
                    s = "MN";
                    break;
                case "Mississippi":
                    s = "MS";
                    break;
                case "Missouri":
                    s = "MO";
                    break;
                case "Montana":
                    s = "MT";
                    break;
                case "Nebraska":
                    s = "NE";
                    break;
                case "Nevada":
                    s = "NV";
                    break;
                case "New Hampshire":
                    s = "NH";
                    break;
                case "New Jersey":
                    s = "NJ";
                    break;
                case "New Mexico":
                    s = "NM";
                    break;
                case "New York":
                    s = "NY";
                    break;
                case "North Carolina":
                    s = "NC";
                    break;
                case "North Dakota":
                    s = "ND";
                    break;
                case "Ohio":
                    s = "OH";
                    break;
                case "Oklahom":
                    s = "OK";
                    break;
                case "Oregon":
                    s = "OR";
                    break;
                case "Pennsylvania":
                    s = "PA";
                    break;
                case "Puerto Rico":
                    s = "PR";
                    break;
                case "Rhode Island":
                    s = "RI";
                    break;
                case "South Carolina":
                    s = "SC";
                    break;
                case "South Dakota":
                    s = "SD";
                    break;
                case "Tennessee":
                    s = "TN";
                    break;
                case "Texas":
                    s = "TX";
                    break;
                case "Utah":
                    s = "UT";
                    break;
                case "Vermont":
                    s = "VT";
                    break;
                case "Virginia":
                    s = "VA";
                    break;
                case "West Virginia":
                    s = "WV";
                    break;
                case "Wisconsin":
                    s = "WI";
                    break;
                case "Wyoming":
                    s = "WY";
                    break;
            }
            return s;
           
        }

        protected Job GetJobInfo(SPListItem item)
        {
            Job job = new Job();
            string s = string.Empty;

            SetUserProfileInfo(job, item.ParentList.ParentWeb.Site.Url);

            if (item["Mailing Address"] != null)
                job.ContactAddress = item["Mailing Address"].ToString();
            if (item["Email"] != null)
                job.ContactEmail = item["Email"].ToString();
            if (item["Fax"] != null)
                job.ContactFax = item["Fax"].ToString();
            if (item["Contact Name"] != null)
                job.ContactName = item["Contact Name"].ToString();
            if (item["Telephone"] != null)
                job.ContactPhone = item["Telephone"].ToString();
            if (item["Website"] != null)
                job.ContactWebsite = item["Website"].ToString();
            if (item["Closing Date"] != null)
                job.DateClosed = (DateTime)item["Closing Date"];
            if (item["Date Filled"] != null)
                job.DateFilled = (DateTime)item["Date Filled"];
            if (item["Posted Date"] != null)
                job.DatePosted = (DateTime)item["Posted Date"];

            job.ExemptionStatusLookupName = item["Exemption Status"].ToString();
            job.EmployStatusLookupName = item["Employment Status"].ToString();
            job.JobCategoryLookupName = item["Job Category"].ToString();

            if (item["Publish"].ToString().Equals("True"))
                job.IsActive = "Y";
            else
                job.IsActive = "N";

            if (item["Job Description"] != null)
                job.JobDescription = item["Job Description"].ToString();
            
            if (item["Job Title"] != null)
                job.JobTitle = item["Job Title"].ToString();

            if (item["Job Requirements"] != null)
                job.JobRequirements = item["Job Requirements"].ToString();

            if (item["Apply now"] != null)
                job.JobRequirements = job.JobRequirements + "<br><br>" + item["Apply now"].ToString();

            if (item["Job Status"] != null)
                job.JobStatus = item["Job Status"].ToString();

            if (item["Salary Max"] != null)
                job.MaxSalary = Int32.Parse(item["Salary Max"].ToString());
            if (item["Salary Min"] != null)
                job.MinSalary = Int32.Parse(item["Salary Min"].ToString());
            if (item["Notes"] != null)
                job.Notes = item["Notes"].ToString();

            if (item["Travel Required"] != null)
                job.PctTravel = int.Parse(item["Travel Required"].ToString());

            job.SalaryStatusLookupName = item["Salary Status"].ToString();

            if (item["City"] != null)
                job.City1 = item["City"].ToString();
            if (item["City 2"] != null)
                job.City2 = item["City 2"].ToString();
            if (item["City 3"] != null)
                job.City3 = item["City 3"].ToString();
            if (item["City 4"] != null)
                job.City4 = item["City 4"].ToString();
            if (item["Filled By"] != null)
                job.FilledBy = item["Filled By"].ToString();
            if (item["State"] != null)
                job.State1 = GetState(item["State"].ToString());
            if (item["State 2"] != null)
                job.State2 = GetState(item["State 2"].ToString());
            if (item["State 3"] != null)
                job.State3 = GetState(item["State 3"].ToString());
            if (item["State 4"] != null)
                job.State4 = GetState(item["State 4"].ToString());

            if (item["How to Contact"] != null)
            {
                s = item["How to Contact"].ToString();
            }

            if (s.Length > 0 && s.ToLower().Contains("mail"))
                job.UseAddress = "Y";
            else
                job.UseAddress = "N";

            if (s.Length > 0 && s.ToLower().Contains("email"))
                job.UseEmail = "Y";
            else
                job.UseEmail = "N";

            if (s.Length > 0 && s.ToLower().Contains("phone"))
                job.UsePhone = "Y";
            else
                job.UsePhone = "N";

            if (s.Length > 0 && s.ToLower().Contains("fax"))
                job.UseFax = "Y";
            else
                job.UseFax = "N";

            if (s.Length > 0 && s.ToLower().Contains("website"))
                job.UseWebsite = "Y";
            else
                job.UseWebsite = "N";
            

            job.SaveDefaultContact = "N";

            if (item["Equal Opportunity Employer M/F/D/V"].ToString().Equals("True"))
                job.EqlOpEmp = "Y";
            else
                job.EqlOpEmp = "N";

            if (item["Job Listing ID"] != null)
            {
                job.JobListingID = Int32.Parse(item["Job Listing ID"].ToString());
            }

            return job;
        }
    }    
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
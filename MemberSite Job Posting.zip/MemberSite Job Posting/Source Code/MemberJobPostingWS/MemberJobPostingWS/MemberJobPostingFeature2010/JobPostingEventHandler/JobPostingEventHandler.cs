﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace MemberJobPostingFeature2010
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class JobPostingEventHandler : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            try
            {
                this.EventFiringEnabled = false;

                base.ItemAdded(properties);
                JobPostingEventHandlerMgr mgr = new JobPostingEventHandlerMgr();
                mgr.InsertItem(properties.ListItem);
            }
            catch (Exception ex)
            {
                properties.ListItem["DBUpdatedStatus"] = ex.Message + " at " +
                DateTime.Now.ToString() + "<br>" + ex.StackTrace;
                properties.ListItem.SystemUpdate();
            }
            finally
            {
                this.EventFiringEnabled = true;
            }
        }

        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                this.EventFiringEnabled = false;
                base.ItemUpdated(properties);
                SPListItem item = properties.ListItem;
                JobPostingEventHandlerMgr mgr = new JobPostingEventHandlerMgr();
                mgr.UpdateItem(properties.ListItem);
            }
            catch (Exception ex)
            {
                properties.ListItem["DBUpdatedStatus"] = ex.Message + " at " +
                DateTime.Now.ToString() + "<br>" + ex.StackTrace;
                properties.ListItem.SystemUpdate();
            }
            finally
            {
                this.EventFiringEnabled = true;
            }
        }

        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
        }



        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
            try
            {
                this.EventFiringEnabled = false;

                base.ItemDeleting(properties);
                JobPostingEventHandlerMgr mgr = new JobPostingEventHandlerMgr();
                mgr.DeleteItem(properties.ListItem);
            }
            catch (Exception ex)
            {
                properties.ListItem["DBUpdatedStatus"] = ex.Message + " at " +
                DateTime.Now.ToString() + "<br>" + ex.StackTrace;
                properties.ListItem.SystemUpdate();
            }
            finally
            {
                this.EventFiringEnabled = true;
            }
        }

    }
}

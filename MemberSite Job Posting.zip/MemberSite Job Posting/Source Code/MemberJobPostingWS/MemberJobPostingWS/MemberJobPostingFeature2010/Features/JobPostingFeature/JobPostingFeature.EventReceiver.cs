using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace MemberJobPostingFeature2010.Features.JobPostingFeature
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("4de24bdf-afd2-4502-b7cd-1ef78288e905")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        private string asmName = System.Reflection.Assembly.GetExecutingAssembly().FullName;
        private string listName = "Job Posting";

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWeb spWeb = (SPWeb)properties.Feature.Parent;
            SPList spList = spWeb.Lists[listName];

            // Delete currently installed event receiver
            for (int i = 0; i < spList.EventReceivers.Count; i++)
            {
                if (spList.EventReceivers[i].Assembly.Equals(asmName))
                {
                    spList.EventReceivers[i].Delete();
                }
            }

            string className = "MemberJobPostingFeature2010.JobPostingEventHandler";
            spList.EventReceivers.Add(SPEventReceiverType.ItemAdded, asmName, className);
            spList.EventReceivers.Add(SPEventReceiverType.ItemUpdated, asmName, className);
            spList.EventReceivers.Add(SPEventReceiverType.ItemDeleting, asmName, className);
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWeb spWeb = (SPWeb)properties.Feature.Parent;
            SPList spList = spWeb.Lists[listName];

            // Delete currently installed event receiver
            for (int i = 0; i < spList.EventReceivers.Count; i++)
            {
                if (spList.EventReceivers[i].Assembly.Equals(asmName))
                {
                    spList.EventReceivers[i].Delete();
                }
            }
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            //throw new Exception("The method or operation is not implemented.");
        }

        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}

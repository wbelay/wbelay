﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;

namespace MemberJobPostingWS
{

    public class JobDALC
    {

        //private  string myConnectionString = "Data Source=10.1.1.122;Database=NWOrg;Integrated Security=SSPI;";

        private string myConnectionString = ConfigurationManager.ConnectionStrings["JobPostingDBConn"].ConnectionString;
        public Job[] GetAllJobs(ClientMsg clientMsg)
        {
            List<Job> results = new List<Job>();

            //SqlDatabase db = new SqlDatabase(myConnectionString);
            string storedProcName = "pr_GetAllJobs";

            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = myConnectionString;
            SqlCommand command = new SqlCommand(storedProcName, connection);
            command.CommandType = CommandType.StoredProcedure;
            connection.Open();

            using (command)
            {

                using (IDataReader rdr = command.ExecuteReader())
                {
                    clientMsg.ErrorMsg += "Field Count: " + rdr.FieldCount.ToString();
                    while (rdr.Read())
                    {
                        results.Add(this.Construct(rdr, clientMsg));
                    }
                    //rdr.Close();
                    return results.ToArray();
                }
            }
        }

        public Job Construct(IDataReader reader, ClientMsg clientMsg)
        {
            Job result = new Job();

            int JobListingIDIndex = reader.GetOrdinal("JobListingID");
            if (!reader.IsDBNull(JobListingIDIndex))
            {
                clientMsg.ErrorMsg += ", JobListingID:" + reader.GetValue(JobListingIDIndex).ToString();
                result.JobListingID = Int32.Parse(reader.GetValue(JobListingIDIndex).ToString());
            }

            int ExemptionStatusLookupNameIndex = reader.GetOrdinal("ExemptionStatusLookupName");
            if (!reader.IsDBNull(ExemptionStatusLookupNameIndex))
            {
                result.ExemptionStatusLookupName = (string)reader.GetValue(ExemptionStatusLookupNameIndex);
            }

            int EmploymentStatusLookupNameIndex = reader.GetOrdinal("EmploymentStatusLookupName");
            if (!reader.IsDBNull(EmploymentStatusLookupNameIndex))
                result.EmployStatusLookupName = (string)reader.GetValue(EmploymentStatusLookupNameIndex);

            int SalaryStatusLookupNameIndex = reader.GetOrdinal("SalaryStatusLookupName");
            if (!reader.IsDBNull(SalaryStatusLookupNameIndex))
                result.SalaryStatusLookupName = (string)reader.GetValue(SalaryStatusLookupNameIndex);

            int JobCategoryLookupNameIndex = reader.GetOrdinal("JobCategoryLookupName");
            if (!reader.IsDBNull(JobCategoryLookupNameIndex))
                result.JobCategoryLookupName = (string)reader.GetValue(JobCategoryLookupNameIndex);

            int IsActiveIndex = reader.GetOrdinal("IsActive");
            if (!reader.IsDBNull(IsActiveIndex))
            {
                result.IsActive = (string)reader.GetValue(IsActiveIndex);
            }

            int JobStatusIndex = reader.GetOrdinal("JobStatus");
            if (!reader.IsDBNull(JobStatusIndex))
                result.JobStatus = (string)reader.GetValue(JobStatusIndex);

            int DatePostedIndex = reader.GetOrdinal("DatePosted");
            if (!reader.IsDBNull(DatePostedIndex))
                result.DatePosted = (DateTime)reader.GetValue(DatePostedIndex);

            int DateClosedIndex = reader.GetOrdinal("DateClosed");
            if (!reader.IsDBNull(DateClosedIndex))
                result.DateClosed = (DateTime)reader.GetValue(DateClosedIndex);

            int JobTitleIndex = reader.GetOrdinal("JobTitle");
            if (!reader.IsDBNull(JobTitleIndex))
            {
                result.JobTitle = (string)reader.GetValue(JobTitleIndex);
            }

            int JobDescriptionIndex = reader.GetOrdinal("JobDescription");
            if (!reader.IsDBNull(JobDescriptionIndex))
                result.JobDescription = (string)reader.GetValue(JobDescriptionIndex);

            int JobRequirementsIndex = reader.GetOrdinal("JobRequirements");
            if (!reader.IsDBNull(JobRequirementsIndex))
                result.JobRequirements = (string)reader.GetValue(JobRequirementsIndex);

            int MinSalaryIndex = reader.GetOrdinal("MinSalary");
            if (!reader.IsDBNull(MinSalaryIndex))
                result.MinSalary = (int)reader.GetValue(MinSalaryIndex);

            int MaxSalaryIndex = reader.GetOrdinal("MaxSalary");
            if (!reader.IsDBNull(MaxSalaryIndex))
                result.MaxSalary = (int)reader.GetValue(MaxSalaryIndex);

            int PctTravelIndex = reader.GetOrdinal("PctTravel");
            if (!reader.IsDBNull(PctTravelIndex))
                result.PctTravel = (int)reader.GetValue(PctTravelIndex);

            int City1Index = reader.GetOrdinal("City1");
            if (!reader.IsDBNull(City1Index))
                result.City1 = (string)reader.GetValue(City1Index);

            int State1Index = reader.GetOrdinal("State1");
            if (!reader.IsDBNull(State1Index))
            {
                result.State1 = (string)reader.GetValue(State1Index);
            }

            int City2Index = reader.GetOrdinal("City2");
            if (!reader.IsDBNull(City2Index))
                result.City2 = (string)reader.GetValue(City2Index);

            int State2Index = reader.GetOrdinal("State2");
            if (!reader.IsDBNull(State2Index))
                result.State2 = (string)reader.GetValue(State2Index);

            int City3Index = reader.GetOrdinal("City3");
            if (!reader.IsDBNull(City3Index))
                result.City3 = (string)reader.GetValue(City3Index);

            int State3Index = reader.GetOrdinal("State3");
            if (!reader.IsDBNull(State3Index))
                result.State3 = (string)reader.GetValue(State3Index);

            int City4Index = reader.GetOrdinal("City4");
            if (!reader.IsDBNull(City4Index))
                result.City4 = (string)reader.GetValue(City4Index);

            int State4Index = reader.GetOrdinal("State4");
            if (!reader.IsDBNull(State4Index))
            {
                result.State4 = (string)reader.GetValue(State4Index);
            }
            int CompanyIDIndex = reader.GetOrdinal("CompanyID");
            if (!reader.IsDBNull(CompanyIDIndex))
                result.CompanyID = Int32.Parse(reader.GetValue(CompanyIDIndex).ToString());

            int CompanyNameIndex = reader.GetOrdinal("CompanyName");
            if (!reader.IsDBNull(CompanyNameIndex))
                result.CompanyName = (string)reader.GetValue(CompanyNameIndex);

            int ContactAddressIndex = reader.GetOrdinal("ContactAddress");
            if (!reader.IsDBNull(ContactAddressIndex))
                result.ContactAddress = (string)reader.GetValue(ContactAddressIndex);

            int ContactPhoneIndex = reader.GetOrdinal("ContactPhone");
            if (!reader.IsDBNull(ContactPhoneIndex))
                result.ContactAddress = (string)reader.GetValue(ContactPhoneIndex);

            int ContactFaxIndex = reader.GetOrdinal("ContactFax");
            if (!reader.IsDBNull(ContactFaxIndex))
                result.ContactFax = (string)reader.GetValue(ContactFaxIndex);

            int ContactEmailIndex = reader.GetOrdinal("ContactEmail");
            if (!reader.IsDBNull(ContactEmailIndex))
                result.ContactEmail = (string)reader.GetValue(ContactEmailIndex);

            int ContactWebsiteIndex = reader.GetOrdinal("ContactWebsite");
            if (!reader.IsDBNull(ContactWebsiteIndex))
                result.ContactWebsite = (string)reader.GetValue(ContactWebsiteIndex);

            int EOEIndex = reader.GetOrdinal("EOE");
            if (!reader.IsDBNull(EOEIndex))
                result.EqlOpEmp = (string)reader.GetValue(EOEIndex);

            int DateFilledIndex = reader.GetOrdinal("DateFilled");
            if (!reader.IsDBNull(DateFilledIndex))
                result.DateFilled = (DateTime)reader.GetValue(DateFilledIndex);

            int FilledByIndex = reader.GetOrdinal("FilledBy");
            if (!reader.IsDBNull(FilledByIndex))
            {
                clientMsg.ErrorMsg += ", FilledBy:" + reader.GetValue(FilledByIndex).ToString();
                result.FilledBy = (string)reader.GetValue(FilledByIndex);
            }

            int NotesIndex = reader.GetOrdinal("Notes");
            if (!reader.IsDBNull(NotesIndex))
                result.Notes = (string)reader.GetValue(NotesIndex);

            return result;


        }

        public int InsertJob(Job jobInfo)
        // public string InsertJob(Job jobInfo)
        {
            // SqlDatabase db = new SqlDatabase(myConnectionString);
            string storedProcName = "pr_InsertJobListingWS";

            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = myConnectionString;

            //using (DbCommand command = this.ConstructCommand(db, jobInfo, storedProcName, "insert"))
            using (SqlCommand command = this.ConstructCommand(jobInfo, storedProcName, "insert"))
            {
                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                {
                    int jobListingID = int.Parse(command.Parameters["@id"].Value.ToString());
                    return jobListingID;
                }
            }
        }

        public string GetJobStatus(int jobListingID)
        {
            //SqlDatabase db = new SqlDatabase(myConnectionString);
            string storedProcName = "pr_GetJobStatus";
            string jobStatus = string.Empty;

            using (SqlCommand command = this.ConstructDeleteCommand(jobListingID, storedProcName))
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = myConnectionString;
                command.Connection = connection;

                try
                {
                    connection.Open();
                    using (IDataReader rdr = command.ExecuteReader())
                    {
                        rdr.Read();
                        int jobStatusIndex = rdr.GetOrdinal("JobStatus");
                        if (!rdr.IsDBNull(jobStatusIndex))
                            jobStatus = (string)rdr.GetValue(jobStatusIndex);


                    }
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    connection.Close();
                }
                return jobStatus;
            }

        }

        public string UpdateJob(Job jobInfo)
        {
            //SqlDatabase db = new SqlDatabase(myConnectionString);
            string storedProcName = "pr_UpdateJobListing";
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = myConnectionString;

            using (SqlCommand command2 = this.ConstructCommand(jobInfo, storedProcName, "update"))
            {
                command2.Connection = connection;
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
                {
                    return "Success";
                }
            }
        }


        public string DeleteJob(int jobListingID)
        {
            string storedProcName = "pr_DeleteJobListing";
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = myConnectionString;

            using (SqlCommand command = this.ConstructDeleteCommand(jobListingID, storedProcName))
            {
                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                {
                    return "Success";
                }
            }
        }



        public SqlCommand ConstructDeleteCommand(int jobListingID, string storedProcName)
        {
            //DbCommand command = db.GetStoredProcCommand(storedProcName);
            //db.AddInParameter(command, "@JobListingID", DbType.Int32, jobListingID);
            SqlCommand command = new SqlCommand(storedProcName);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@JobListingID", SqlDbType.Int).Value = jobListingID;
            return command;
        }

        public SqlCommand ConstructCommand(Job jobInfo, string storedProcName, string dbAction)
        {
            //DbCommand command = db.GetStoredProcCommand(storedProcName);

            //SqlConnection connection = new SqlConnection();
            //connection.ConnectionString = connectionString;
            SqlCommand command = new SqlCommand(storedProcName);
            command.CommandType = CommandType.StoredProcedure;
            //connection.Open();

            if (dbAction == "insert")
            {
                //db.AddOutParameter(command, "@id", DbType.Int32, 4);
                SqlParameter sqlparameterInsert = command.Parameters.Add("@id", SqlDbType.Int, 4);
                sqlparameterInsert.Direction = ParameterDirection.Output;
            }

            if (dbAction == "update")
            {
                //db.AddInParameter(command, "@JobListingID", DbType.Int32, jobInfo.JobListingID);

                //SqlParameter sqlparamUpdate = new SqlParameter();
                //sqlparamUpdate = command.Parameters.Add("@JobListingID", SqlDbType.Int, jobInfo.JobListingID);
                command.Parameters.Add("@JobListingID", SqlDbType.Int).Value = jobInfo.JobListingID;//219;//
            }

            if (jobInfo.ExemptionStatusLookupName != null)
            {
                //db.AddInParameter(command, "@ExemptionStatusLookupName", DbType.String, jobInfo.ExemptionStatusLookupName);
                command.Parameters.Add("@ExemptionStatusLookupName", SqlDbType.VarChar).Value = jobInfo.ExemptionStatusLookupName;
            }

            if (jobInfo.EmployStatusLookupName != null)
            {
                //db.AddInParameter(command, "@EmploymentStatusLookupName", DbType.String, jobInfo.EmployStatusLookupName);
                command.Parameters.Add("@EmploymentStatusLookupName", SqlDbType.VarChar).Value = jobInfo.EmployStatusLookupName;
            }

            if (jobInfo.SalaryStatusLookupName != null)
            {
                //db.AddInParameter(command, "@SalaryStatusLookupName", DbType.String, jobInfo.SalaryStatusLookupName);
                command.Parameters.Add("@SalaryStatusLookupName", SqlDbType.VarChar).Value = jobInfo.SalaryStatusLookupName;
            }

            if (jobInfo.JobCategoryLookupName != null)
            {
                //db.AddInParameter(command, "@JobCategoryLookupName", DbType.String, jobInfo.JobCategoryLookupName);
                command.Parameters.Add("@JobCategoryLookupName", SqlDbType.VarChar).Value = jobInfo.JobCategoryLookupName;
            }


            //db.AddInParameter(command, "@IsActive", DbType.String, jobInfo.IsActive);
            command.Parameters.Add("@IsActive", SqlDbType.VarChar).Value = jobInfo.IsActive;


            if (DateTime.Compare(jobInfo.DatePosted, DateTime.Now.AddYears(-100)) > 0)
            {
                //db.AddInParameter(command, "@DatePosted", DbType.Date, jobInfo.DatePosted);
                command.Parameters.Add("@DatePosted", SqlDbType.DateTime).Value = jobInfo.DatePosted;
            }
            else
            {
                //db.AddInParameter(command, "@DatePosted", DbType.Date, DBNull.Value);
                command.Parameters.Add("@DatePosted", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (DateTime.Compare(jobInfo.DateClosed, DateTime.Now.AddYears(-100)) > 0)
            {
                //db.AddInParameter(command, "@DateClosed", DbType.Date, jobInfo.DateClosed);
                command.Parameters.Add("@DateClosed", SqlDbType.DateTime).Value = jobInfo.DateClosed;
            }
            else
            {
                //db.AddInParameter(command, "@DateClosed", DbType.Date, DBNull.Value);
                command.Parameters.Add("@DateClosed", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (jobInfo.JobTitle != null)
            {
                //db.AddInParameter(command, "@JobTitle", DbType.String, jobInfo.JobTitle);
                command.Parameters.Add("@JobTitle", SqlDbType.VarChar).Value = jobInfo.JobTitle;
            }

            if (jobInfo.JobDescription != null)
            {
                //db.AddInParameter(command, "@JobDescription", DbType.String, jobInfo.JobDescription);
                command.Parameters.Add("@JobDescription", SqlDbType.VarChar).Value = jobInfo.JobDescription;
            }

            if (jobInfo.JobRequirements != null)
            {
                //db.AddInParameter(command, "@JobRequirements", DbType.String, jobInfo.JobRequirements);
                command.Parameters.Add("@JobRequirements", SqlDbType.VarChar).Value = jobInfo.JobRequirements;
            }

            //db.AddInParameter(command, "@MinSalary", DbType.Int32, jobInfo.MinSalary);
            if (jobInfo.MinSalary != 0)
            {
                command.Parameters.Add("@MinSalary", SqlDbType.Int).Value = jobInfo.MinSalary;
            }
            else {
                command.Parameters.Add("@MinSalary", SqlDbType.Int).Value = DBNull.Value;
            }

            //db.AddInParameter(command, "@MaxSalary", DbType.Int32, jobInfo.MaxSalary);
            if (jobInfo.MaxSalary != 0)
            {
                command.Parameters.Add("@MaxSalary", SqlDbType.Int).Value = jobInfo.MaxSalary;
            }
            else
            {
                command.Parameters.Add("@MaxSalary", SqlDbType.Int).Value = DBNull.Value;
            }

            //db.AddInParameter(command, "@PctTravel", DbType.Int32, jobInfo.PctTravel);
            command.Parameters.Add("@PctTravel", SqlDbType.Int).Value = jobInfo.PctTravel;

            if (jobInfo.City1 != null)
            {
                //db.AddInParameter(command, "@City1", DbType.String, jobInfo.City1);
                command.Parameters.Add("@City1", SqlDbType.VarChar).Value = jobInfo.City1;
            }

            if (jobInfo.State1 != null)
            {
                //db.AddInParameter(command, "@State1", DbType.String, jobInfo.State1);
                command.Parameters.Add("@State1", SqlDbType.VarChar).Value = jobInfo.State1;
            }
            else
            {
                //db.AddInParameter(command, "@State1", DbType.String, DBNull.Value);
                command.Parameters.Add("@State1", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.City2 != null)
            {
                //db.AddInParameter(command, "@City2", DbType.String, jobInfo.City2);
                command.Parameters.Add("@City2", SqlDbType.VarChar).Value = jobInfo.City2;
            }
            else
            {
                //db.AddInParameter(command, "@City2", DbType.String, DBNull.Value);
                command.Parameters.Add("@City2", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.State2 != null)
            {
                //db.AddInParameter(command, "@State2", DbType.String, jobInfo.State2);
                command.Parameters.Add("@State2", SqlDbType.VarChar).Value = jobInfo.State2;
            }
            else
            {
                //db.AddInParameter(command, "@State2", DbType.String, DBNull.Value);
                command.Parameters.Add("@State2", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.City3 != null)
            {
                //db.AddInParameter(command, "@City3", DbType.String, jobInfo.City3);
                command.Parameters.Add("@City3", SqlDbType.VarChar).Value = jobInfo.City3;
            }
            else
            {
                //db.AddInParameter(command, "@City3", DbType.String, DBNull.Value);
                command.Parameters.Add("@City3", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.State3 != null)
            {
                //db.AddInParameter(command, "@State3", DbType.String, jobInfo.State3);
                command.Parameters.Add("@State3", SqlDbType.VarChar).Value = jobInfo.State3;
            }
            else
            {
                //db.AddInParameter(command, "@State3", DbType.String, DBNull.Value);
                command.Parameters.Add("@State3", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.City4 != null)
            {
                //db.AddInParameter(command, "@City4", DbType.String, jobInfo.City4);
                command.Parameters.Add("@City4", SqlDbType.VarChar).Value = jobInfo.City4;
            }
            else
            {
                //db.AddInParameter(command, "@City4", DbType.String, DBNull.Value);
                command.Parameters.Add("@City4", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.State4 != null)
            {
                //db.AddInParameter(command, "@State4", DbType.String, jobInfo.State4);
                command.Parameters.Add("@State4", SqlDbType.VarChar).Value = jobInfo.State4;
            }
            else
            {
                //db.AddInParameter(command, "@State4", DbType.String, DBNull.Value);
                command.Parameters.Add("@State4", SqlDbType.VarChar).Value = DBNull.Value;
            }
            if (jobInfo.ContactEmail != null)
            {
                //db.AddInParameter(command, "@ContactEmail", DbType.String, jobInfo.ContactEmail);
                command.Parameters.Add("@ContactEmail", SqlDbType.VarChar).Value = jobInfo.ContactEmail;
            }
            else
            {
                //db.AddInParameter(command, "@ContactEmail", DbType.String, DBNull.Value);
                command.Parameters.Add("@ContactEmail", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.ContactWebsite != null)
            {
                //db.AddInParameter(command, "@ContactWebsite", DbType.String, jobInfo.ContactWebsite);
                command.Parameters.Add("@ContactWebsite", SqlDbType.VarChar).Value = jobInfo.ContactWebsite;
            }
            else
            {
                //db.AddInParameter(command, "@ContactWebsite", DbType.String, DBNull.Value);
                command.Parameters.Add("@ContactWebsite", SqlDbType.VarChar).Value = DBNull.Value;
            }
            command.Parameters.Add("@CompanyID", SqlDbType.Int, 4).Value = jobInfo.CompanyID;
            command.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = jobInfo.CompanyName;
            command.Parameters.Add("@SaveDefaultContact", SqlDbType.VarChar).Value = jobInfo.SaveDefaultContact;

            if (jobInfo.ContactName != null)
            {
                //db.AddInParameter(command, "@ContactName", DbType.String, jobInfo.ContactName);
                command.Parameters.Add("@ContactName", SqlDbType.VarChar).Value = jobInfo.ContactName;
            }

            if (jobInfo.ContactAddress != null)
            {
                //db.AddInParameter(command, "@ContactAddress", DbType.String, jobInfo.ContactAddress);
                command.Parameters.Add("@ContactAddress", SqlDbType.VarChar).Value = jobInfo.ContactAddress;
            }
            else
            {
                //db.AddInParameter(command, "@ContactAddress", DbType.String, DBNull.Value);
                command.Parameters.Add("@ContactAddress", SqlDbType.VarChar).Value = DBNull.Value;
            }
            if (jobInfo.ContactPhone != null)
            {
                //db.AddInParameter(command, "@ContactPhone", DbType.String, jobInfo.ContactPhone);
                command.Parameters.Add("@ContactPhone", SqlDbType.VarChar).Value = jobInfo.ContactPhone;
            }
            else
            {
                //db.AddInParameter(command, "@ContactPhone", DbType.String, DBNull.Value);
                command.Parameters.Add("@ContactPhone", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.ContactFax != null)
            {
                //db.AddInParameter(command, "@ContactFax", DbType.String, jobInfo.ContactFax);
                command.Parameters.Add("@ContactFax", SqlDbType.VarChar).Value = jobInfo.ContactFax;
            }
            else
            {
                //db.AddInParameter(command, "@ContactFax", DbType.String, DBNull.Value);
                command.Parameters.Add("@ContactFax", SqlDbType.VarChar).Value = DBNull.Value;
            }
            //db.AddInParameter(command, "@UseAddress", DbType.String, jobInfo.UseAddress);
            command.Parameters.Add("@UseAddress", SqlDbType.VarChar).Value = jobInfo.UseAddress;
            //db.AddInParameter(command, "@UsePhone", DbType.String, jobInfo.UseAddress);
            command.Parameters.Add("@UsePhone", SqlDbType.VarChar).Value = jobInfo.UsePhone;
            //db.AddInParameter(command, "@UseFax", DbType.String, jobInfo.UseFax);
            command.Parameters.Add("@UseFax", SqlDbType.VarChar).Value = jobInfo.UseFax;
            //db.AddInParameter(command, "@UseEmail", DbType.String, jobInfo.UseEmail);
            command.Parameters.Add("@UseEmail", SqlDbType.VarChar).Value = jobInfo.UseEmail;
            //db.AddInParameter(command, "@UseWebsite", DbType.String, jobInfo.UseWebsite);
            command.Parameters.Add("@UseWebsite", SqlDbType.VarChar).Value = jobInfo.UseWebsite;
            //db.AddInParameter(command, "@EOE", DbType.String, jobInfo.EqlOpEmp);
            command.Parameters.Add("@EOE", SqlDbType.VarChar).Value = jobInfo.EqlOpEmp;


            if (DateTime.Compare(jobInfo.DateFilled, DateTime.Now.AddYears(-100)) > 0)
            {
                //db.AddInParameter(command, "@DateFilled", DbType.Date, jobInfo.DateFilled);
                command.Parameters.Add("@DateFilled", SqlDbType.VarChar).Value = jobInfo.DateFilled;
            }
            else
            {
                //db.AddInParameter(command, "@DateFilled", DbType.Date, DBNull.Value);
                command.Parameters.Add("@DateFilled", SqlDbType.VarChar).Value = DBNull.Value;
            }

            if (jobInfo.FilledBy != null)
            {
                //db.AddInParameter(command, "@FilledBy", DbType.String, jobInfo.FilledBy);
                command.Parameters.Add("@FilledBy", SqlDbType.VarChar).Value = jobInfo.FilledBy;
            }
            else
            {
                //db.AddInParameter(command, "@FilledBy", DbType.String, DBNull.Value);
                command.Parameters.Add("@FilledBy", SqlDbType.VarChar).Value = DBNull.Value;
            }
            if (dbAction == "insert")
            {
                if (jobInfo.JobStatus != null)
                {
                    //db.AddInParameter(command, "@JobStatus", DbType.String, jobInfo.JobStatus);
                    command.Parameters.Add("@JobStatus", SqlDbType.VarChar).Value = jobInfo.JobStatus;
                }
                else
                {
                    //db.AddInParameter(command, "@JobStatus", DbType.String, DBNull.Value);
                    command.Parameters.Add("@JobStatus", SqlDbType.VarChar).Value = DBNull.Value;
                }
            }
            if (jobInfo.Notes != null)
            {
                //db.AddInParameter(command, "@Notes", DbType.String, jobInfo.Notes);
                command.Parameters.Add("@Notes", SqlDbType.VarChar).Value = jobInfo.Notes;
            }
            else
            {
                //db.AddInParameter(command, "@Notes", DbType.String, DBNull.Value);
                command.Parameters.Add("@Notes", SqlDbType.VarChar).Value = DBNull.Value;
            }
            return command;
        }
    }
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
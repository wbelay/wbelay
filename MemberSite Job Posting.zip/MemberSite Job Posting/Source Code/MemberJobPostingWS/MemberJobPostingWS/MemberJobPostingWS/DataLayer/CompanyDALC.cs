﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;


namespace MemberJobPostingWS
{
    public class CompanyDALC
    {
        //private string myConnectionString = "Data Source=10.1.1.122;Database=NWOrg;Integrated Security=SSPI;";
        private string myConnectionString = ConfigurationManager.ConnectionStrings["JobPostingDBConn"].ConnectionString;
        public DataSet GetAllCompany(ClientMsg clientMsg)
        {
            DataSet results = new DataSet();
            try
            {
                //SqlDatabase db = new SqlDatabase(myConnectionString);
                string storedProcName = "pr_GetNwoList";
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = myConnectionString;
                SqlCommand command = new SqlCommand(storedProcName, connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                using (command)
                {
                    //results = db.ExecuteDataSet(command);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    dataAdapter.Fill(results);
                }
            }
            catch (Exception ex)
            {
                clientMsg.ErrorMsg = ex + ", " + ex.StackTrace;
            }

            return results;
        }
    }
}

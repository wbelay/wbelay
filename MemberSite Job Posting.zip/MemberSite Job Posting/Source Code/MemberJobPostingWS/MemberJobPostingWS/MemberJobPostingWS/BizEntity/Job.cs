﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace MemberJobPostingWS
{
    [Serializable]
    [XmlInclude(typeof(Job))]
    public class Job
    {
        private int companyID;
        private string companyName;
        private int jobListingID;
        private string contactName;
        private string contactAddress;
        private string contactPhone;
        private string contactFax;
        private string contactEmail;
        private string contactWebsite;
        private string saveDefaultContact;
        private string exemptionStatusLookupName;
        private string employStatusLookupName;
        private string salaryStatusLookupName;
        private string jobCategoryLookupName;
        private string isActive;
        private DateTime datePosted;
        private DateTime dateClosed;
        private string jobTitle;
        private string jobDescription;
        private string jobRequirements;
        private string jobStatus;
        private int minSalary;
        private int maxSalary;
        private int pctTravel;
        private string city1;
        private string state1;
        private string city2;
        private string state2;
        private string city3;
        private string state3;
        private string city4;
        private string state4;
        private string useAddress;
        private string usePhone;
        private string useFax;
        private string useEmail;
        private string useWebsite;
        private string eqlOpEmp;
        private DateTime dateFilled;
        private string filledBy;
        private string notes;
        private string groupName;


        public int CompanyID
        {
            get
            {
                return companyID;
            }
            set
            {
                companyID = value;
            }
        }
        


        public string CompanyName
        {
            get
            {
                return companyName;
            }
            set
            {
                companyName = value;
            }
        }

        public int JobListingID
        {
            get
            {
                return jobListingID;
            }
            set
            {
                jobListingID = value;
            }
        }

        public string ContactName
        {
            get
            {
                return contactName;
            }
            set
            {
                contactName = value;
            }
        }

        public string ContactAddress
        {
            get
            {
                return contactAddress;
            }
            set
            {
                contactAddress = value;
            }
        }

        public string ContactPhone
        {
            get
            {
                return contactPhone;
            }
            set
            {
                contactPhone = value;
            }
        }

        public string ContactFax
        {
            get
            {
                return contactFax;
            }
            set
            {
                contactFax = value;
            }
        }

        public string ContactEmail
        {
            get
            {
                return contactEmail;
            }
            set
            {
                contactEmail = value;
            }
        }

        public string ContactWebsite
        {
            get
            {
                return contactWebsite;
            }
            set
            {
                contactWebsite = value;
            }
        } 

        public string SaveDefaultContact
        {
            get
            {
                return saveDefaultContact;
            }
            set
            {
                saveDefaultContact = value;
            }
        }

        public string ExemptionStatusLookupName
        {
            get
            {
                return exemptionStatusLookupName;
            }
            set
            {
                exemptionStatusLookupName = value;
            }
        }

        public string EmployStatusLookupName
        {
            get
            {
                return employStatusLookupName;
            }
            set
            {
                employStatusLookupName = value;
            }
        }

        public string SalaryStatusLookupName
        {
            get
            {
                return salaryStatusLookupName;
            }
            set
            {
                salaryStatusLookupName = value;
            }
        }

        public string JobCategoryLookupName
        {
            get
            {
                return jobCategoryLookupName;
            }
            set
            {
                jobCategoryLookupName = value;
            }
        }

        public string IsActive
        {
            get
            {
                return isActive;
            }
            set
            {
                isActive = value;
            }
        }

        

        public DateTime DatePosted
        {
            get
            {
                return datePosted;
            }
            set
            {
                datePosted = value;
            }
        }

        public DateTime DateClosed
        {
            get
            {
                return dateClosed;
            }
            set
            {
                dateClosed = value;
            }
        }

        public string JobTitle
        {
            get
            {
                return jobTitle;
            }
            set
            {
                jobTitle = value;
            }
        }

        public string JobDescription
        {
            get
            {
                return jobDescription;
            }
            set
            {
                jobDescription = value;
            }
        }

        public string JobRequirements
        {
            get
            {
                return jobRequirements;
            }
            set
            {
                jobRequirements = value;
            }
        }

        public string JobStatus
        {
            get
            {
                return jobStatus;
            }
            set
            {
                jobStatus = value;
            }
        }

        public int MinSalary
        {
            get
            {
                return minSalary ;
            }
            set
            {
                minSalary = value;
            }
        }

        public int MaxSalary
        {
            get
            {
                return maxSalary;
            }
            set
            {
                maxSalary = value;
            }
        }

        public int PctTravel
        {
            get
            {
                return pctTravel;
            }
            set
            {
                pctTravel = value;
            }
        }

        public string City1
        {
            get
            {
                return city1;
            }
            set
            {
                city1 = value;
            }
        }

        public string State1
        {
            get
            {
                return state1;
            }
            set
            {
                state1 = value;
            }
        }

        public string City2
        {
            get
            {
                return city2;
            }
            set
            {
                city2 = value;
            }
        }

        public string State2
        {
            get
            {
                return state2;
            }
            set
            {
                state2 = value;
            }
        }

        public string City3
        {
            get
            {
                return city3;
            }
            set
            {
                city3 = value;
            }
        }

        public string State3
        {
            get
            {
                return state3;
            }
            set
            {
                state3 = value;
            }
        }

        public string City4
        {
            get
            {
                return city4;
            }
            set
            {
                city4 = value;
            }
        }

        public string State4
        {
            get
            {
                return state4;
            }
            set
            {
                state4 = value;
            }
        }

        public string UseAddress
        {
            get
            {
                return useAddress;
            }
            set
            {
                useAddress = value;
            }
        }

        public string UsePhone
        {
            get
            {
                return usePhone;
            }
            set
            {
                usePhone = value;
            }
        }

        public string UseFax
        {
            get
            {
                return useFax;
            }
            set
            {
                useFax = value;
            }
        }

        public string UseEmail
        {
            get
            {
                return useEmail;
            }
            set
            {
                useEmail = value;
            }
        }

        public string UseWebsite
        {
            get
            {
                return useWebsite;
            }
            set
            {
                useWebsite = value;
            }
        }

        public string EqlOpEmp
        {
            get
            {
                return eqlOpEmp;
            }
            set
            {
                eqlOpEmp = value;
            }
        }

        public DateTime DateFilled
        {
            get
            {
                return dateFilled;
            }
            set
            {
                dateFilled = value;
            }
        }

        public string FilledBy
        {
            get
            {
                return filledBy;
            }
            set
            {
                filledBy = value;
            }
        }

        public string Notes
        {
            get
            {
                return notes;
            }
            set
            {
                notes = value;
            }
        }

        public string GroupName
        {
            get
            {
                return groupName;
            }
            set
            {
                groupName = value;
            }
        }

    }
}

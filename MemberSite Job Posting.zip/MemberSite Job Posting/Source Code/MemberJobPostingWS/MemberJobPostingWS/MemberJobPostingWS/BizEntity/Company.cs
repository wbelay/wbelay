﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace MemberJobPostingWS
{
    [Serializable]
    [XmlInclude(typeof(Company))]
    public class Company
    {
        private string companyName;
        private int companyID;

        public string CompanyName
        {
            get
            {
                return CompanyName;
            }
            set 
            { 
                companyName = value; 
            }
        }

        public int CompanyID
        {
            get
            {
                return companyID;
            }
            set
            {
                companyID = value;
            }
        }
    }
}

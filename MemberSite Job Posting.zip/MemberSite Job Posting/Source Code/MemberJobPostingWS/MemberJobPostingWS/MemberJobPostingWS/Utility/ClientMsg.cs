﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MemberJobPostingWS
{
    public class ClientMsg
    {
        private string errorMsg = "";
        private int jobListingID = 0;
        private bool success = false;
        private string jobStatus = "";
        private Job[] jobs = null;

        public bool Success
        {
            get { return success; }
            set { success = value; }
        }

        public string ErrorMsg
        {
            get { return errorMsg; }
            set { errorMsg = value; }
        }

        public int JobListingID
        {
            get { return jobListingID; }
            set { jobListingID = value; }
        }

        public string JobStatus
        {
            get { return jobStatus; }
            set { jobStatus = value; }
        }

        public Job[] Jobs
        {
            get { return jobs; }
            set { jobs = value; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace MemberJobPostingWS
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class JobPostingService : System.Web.Services.WebService
    {
        [WebMethod]
        public ClientMsg InsertJobInfo(Job job)
        {
            ClientMsg clientMsg = new ClientMsg();
            try
            {
                JobDALC jobDALC = new JobDALC();
                int id = jobDALC.InsertJob(job);
                string jobStatus = jobDALC.GetJobStatus(id);

                clientMsg.JobListingID = id;
                clientMsg.Success = true;
                clientMsg.JobStatus = jobStatus;
                return clientMsg;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;

                if (ShowDetailErrors())
                    msg += "<br>" + ex.StackTrace;

                clientMsg.ErrorMsg = msg;

                return clientMsg;
            }
        }

        private bool ShowDetailErrors()
        {
            bool showDetailError = false;
            try
            {
                if (System.Configuration.ConfigurationManager.AppSettings["ShowDetailError"].Equals("true"))
                    showDetailError = true;
            }
            catch (Exception ex)
            {

            }

            return showDetailError;
        }

        [WebMethod]
        public ClientMsg UpdateJobInfo(Job job)
        {
            ClientMsg clientMsg = new ClientMsg();
            try
            {
                JobDALC jobDALC = new JobDALC();
                string msg = jobDALC.UpdateJob(job);
                string jobStatus = jobDALC.GetJobStatus(job.JobListingID);

                clientMsg.Success = true;
                clientMsg.JobStatus = jobStatus;
                return clientMsg;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;

                if (ShowDetailErrors())
                    msg += "<br>" + ex.StackTrace;

                clientMsg.ErrorMsg = msg;

                return clientMsg;
            }
        }

        [WebMethod]
        public DataSet GetAllCompanies()
        {
            ClientMsg clientMsg = new ClientMsg();
            try
            {
                CompanyDALC companyDALC = new CompanyDALC();
                DataSet companyDataSet = companyDALC.GetAllCompany(clientMsg);


                clientMsg.Success = true;

                return companyDataSet;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
        }

        [WebMethod]
        public ClientMsg DeleteJob(int jobListingID)
        {
            ClientMsg clientMsg = new ClientMsg();
            try
            {
                JobDALC jobDALC = new JobDALC();
                // added 
                string ww = jobDALC.DeleteJob(jobListingID);
                // end added
                clientMsg.Success = true;
                return clientMsg;


            }
            catch (Exception ex)
            {
                string msg = ex.Message;

                if (ShowDetailErrors())
                    msg += "<br>" + ex.StackTrace;

                clientMsg.ErrorMsg = msg;

                return clientMsg;
            }


        }

        [WebMethod]
        public ClientMsg GetAllJobs()
        {
            ClientMsg clientMsg = new ClientMsg();

            try
            {
                Job[] jobs;
                JobDALC jobDALC = new JobDALC();

                jobs = jobDALC.GetAllJobs(clientMsg);
                clientMsg.Success = true;
                clientMsg.Jobs = jobs;
            }
            catch (Exception ex)
            {
                clientMsg.Success = false;
                clientMsg.ErrorMsg += ex.Message + "<br>" + ex.StackTrace;
            }

            return clientMsg;
        }

        [WebMethod]
        public string TestUser()
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            return userName;
        }

        [WebMethod]
        public string TestDBConn()
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            string myConnectionString = "Data Source=10.1.1.122;Database=NWOrg;Integrated Security=SSPI;";

            //SqlDatabase db = new SqlDatabase(myConnectionString);

            using (SqlCommand command = this.ConstructSelectAllCommand(myConnectionString))
            {
                try
                {
                    using (IDataReader rdr = command.ExecuteReader())
                    {
                        userName += "; count: " + rdr.FieldCount.ToString();
                        while (rdr.Read())
                        {
                            //results.Add(this.Construct(rdr));
                        }
                    }
                }
                catch (SqlException ex)
                {
                    string[] messageParts = ex.Errors[0].Message.Split(':');
                    userName = ex.Message;

                    //HandleSqlException(ex, messageParts[0]);
                }
            }

            return userName;
        }

        /// <summary>
        /// Method to generate select all dbcommand
        /// </summary>
        public SqlCommand ConstructSelectAllCommand(string connectionString)
        {
            //DbCommand command = db.GetStoredProcCommand("dbo.pr_getjoblist");
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = connectionString;
            SqlCommand command = new SqlCommand("dbo.pr_getjoblist", connection);
            command.CommandType = CommandType.StoredProcedure;
            connection.Open();

            command.Parameters.Add("@jobstatus", SqlDbType.VarChar).Value = "P";
            command.Parameters.Add("@companyid", SqlDbType.VarChar).Value = "1";
            command.Parameters.Add("@count", SqlDbType.Int).Value = 1000;
            command.Parameters.Add("@sortorder", SqlDbType.VarChar).Value = "ASC";
            //db.AddInParameter(command, "@jobstatus", DbType.String, "P");
            //db.AddInParameter(command, "@companyid", DbType.String, "1");
            //db.AddInParameter(command, "@count", DbType.Int32, 1000);
            //db.AddInParameter(command, "@sortorder", DbType.String, "ASC");

            //connection.Close();
            return command;
        }
    }
}

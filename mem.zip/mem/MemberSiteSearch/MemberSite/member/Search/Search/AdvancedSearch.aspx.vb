Public Class Accommodations
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "


    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdDistricts = New System.Data.SqlClient.SqlCommand
        Me.connTEAM = New System.Data.SqlClient.SqlConnection
        Me.cmdStates = New System.Data.SqlClient.SqlCommand
        Me.connGROA = New System.Data.SqlClient.SqlConnection
        Me.cmdCommunity = New System.Data.SqlClient.SqlCommand
        Me.cmdInitiative = New System.Data.SqlClient.SqlCommand
        Me.cmdProgram = New System.Data.SqlClient.SqlCommand
        Me.cmdMembers = New System.Data.SqlClient.SqlCommand
        Me.connNRCFIN = New System.Data.SqlClient.SqlConnection
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection
        Me.connTEAMOle = New System.Data.OleDb.OleDbConnection
        Me.cmdBusinessLine = New System.Data.SqlClient.SqlCommand

    End Sub

    Protected WithEvents connGROA As New System.Data.SqlClient.SqlConnection
    Protected WithEvents cmdDistricts As System.Data.SqlClient.SqlCommand
    Protected WithEvents connTEAM As System.Data.SqlClient.SqlConnection
    Protected WithEvents cmdStates As System.Data.SqlClient.SqlCommand
    Protected WithEvents cmdInitiative As System.Data.SqlClient.SqlCommand
    Protected WithEvents cmdCommunity As System.Data.SqlClient.SqlCommand
    Protected WithEvents cmdProgram As System.Data.SqlClient.SqlCommand
    Protected drStates As System.Data.SqlClient.SqlDataReader
    Protected drDistricts As System.Data.SqlClient.SqlDataReader
    Protected drMembers As System.Data.SqlClient.SqlDataReader
    Protected WithEvents lstMemberOrgs As System.Web.UI.WebControls.DataList
    Protected WithEvents cmdMembers As System.Data.SqlClient.SqlCommand
    Protected WithEvents connNRCFIN As System.Data.SqlClient.SqlConnection
    Protected WithEvents drpDistrict As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblState As System.Web.UI.WebControls.Label
    Dim startIndex As Integer = 0
    Protected WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Protected WithEvents connTEAMOle As System.Data.OleDb.OleDbConnection
    Protected WithEvents dsMembers As New System.Data.DataSet
    Protected WithEvents daMembers As System.Data.OleDb.OleDbDataAdapter
    Protected WithEvents Organization As System.Data.DataTable
    Protected WithEvents lblDistrictLink As System.Web.UI.WebControls.Label
    Protected WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
    Protected WithEvents lblDistrict As System.Web.UI.WebControls.Label
    Protected WithEvents btnSearch As System.Web.UI.WebControls.Button
    Protected WithEvents drpState As System.Web.UI.WebControls.DropDownList
    Protected WithEvents drpBusinessLine As System.Web.UI.WebControls.ListBox

    Protected WithEvents drpStaffSize As System.Web.UI.WebControls.DropDownList
    Protected WithEvents grdMemberOrgs As System.Web.UI.WebControls.DataGrid
    Protected WithEvents drpCommunity As System.Web.UI.WebControls.ListBox
    Protected WithEvents drpInitiative As System.Web.UI.WebControls.ListBox
    Protected WithEvents drpProgram As System.Web.UI.WebControls.ListBox
    Protected WithEvents lblMsg As System.Web.UI.WebControls.Label
    Protected WithEvents RecordsPerPageDropDownList As System.Web.UI.WebControls.DropDownList
    Dim dsDistricts As New DataSet
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents CheckBoxListInitiative As New System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents CheckBoxListProgram As New System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents CheckBoxListService As New System.Web.UI.WebControls.CheckBoxList
    Protected WithEvents program As System.Web.UI.WebControls.Panel
    Protected WithEvents Service As System.Web.UI.WebControls.Panel
    Protected WithEvents Initiative As System.Web.UI.WebControls.Panel
    Protected WithEvents Size As System.Web.UI.WebControls.Panel
    Protected WithEvents t1 As New System.Web.UI.WebControls.Panel

    Dim search As String
    Dim recordPerPage As Integer
    Protected WithEvents lblSearch As New System.Web.UI.WebControls.Label
    Protected WithEvents BusinessLine As System.Web.UI.WebControls.Panel
    Protected WithEvents cmdBusinessLine As System.Data.SqlClient.SqlCommand
    Protected WithEvents CheckBoxListBusinessLine As New System.Web.UI.WebControls.CheckBoxList

    Protected WithEvents btnBusiness As System.Web.UI.WebControls.LinkButton
    Protected WithEvents btnInitiative As System.Web.UI.WebControls.LinkButton
    Protected WithEvents btnProgram As System.Web.UI.WebControls.LinkButton
    Protected WithEvents btnService As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblNoData As System.Web.UI.WebControls.Label
    Protected WithEvents lblZip As System.Web.UI.WebControls.Label
    Protected WithEvents txtZIp As System.Web.UI.WebControls.TextBox
    Protected WithEvents RadioButtonListBusinessLine As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents RadioButtonListInitiative As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents RadioButtonListProgram As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents lblProgram As System.Web.UI.WebControls.Label
    Protected WithEvents lblInitiative As System.Web.UI.WebControls.Label
    Protected WithEvents lblBusiness As System.Web.UI.WebControls.Label
    Protected WithEvents lblService As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButtonListService As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents txtOrgname As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents btnClear As System.Web.UI.WebControls.Button
    Protected WithEvents btnSearchTest As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

        '       AddHandler grdMemberOrgs.PageIndexChanged, _
        '      AddressOf grdMemberOrgs_PageIndexChanged
        'cmdStates
        '
        Me.cmdStates.Connection = Me.connGROA
        '
        Me.connGROA.ConnectionString = CType(New System.Configuration.AppSettingsReader().GetValue("cnDataSync.ConnectionString", GetType(System.String)), String)

        'cmdMembers
        '
        Me.cmdMembers.Connection = Me.connGROA

        search = Request("search")
        Me.lblSearch.Text = search

        Try
            'FillList()
            Select Case search
                Case "Service"
                    FillState()
                    FillService()
                    Me.Initiative.Visible = False
                    Me.program.Visible = False

                Case "Initiative"
                    FillState()
                    FillInitiative()
                    Me.Service.Visible = False
                    Me.program.Visible = False

                Case "Program"
                    FillState()
                    FillProgram()
                    Me.Initiative.Visible = False
                    Me.Service.Visible = False
                    Me.Size.Visible = False
                Case "Size"
                    FillState()
                    Me.Initiative.Visible = False
                    Me.program.Visible = False
                    Me.Service.Visible = False
                Case Else
                    FillState()
                    FillInitiative()
                    FillProgram()
                    FillService()
                    FillBusinessLine()

            End Select

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

        'drpProgram.Items(0).Selected = True
        'drpCommunity.Items(0).Selected = True
        'drpInitiative.Items(0).Selected = True

    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        Dim valDistrict = Me.drpDistrict.SelectedValue()
        Dim valDesc As String

        lblNoData.Text = ""
        recordPerPage = Request("RecordsPerPageDropDownList")


        'If Not IsPostBack Then
        'FillList()
        'Else
        'reQuery()
        If valDistrict <> "[All]" Then
            Dim FoundRows() As DataRow = dsDistricts.Tables("Districts").Select("districtID = " & drpDistrict.SelectedValue(), "", DataViewRowState.CurrentRows)

            Dim r1 As DataRow

            For Each r1 In FoundRows
                valDesc = r1.Item("districtDescription")
            Next
        End If

        If valDistrict <> "[All]" Then
            Me.lblDistrictLink.Text = "<A HREF=" & valDesc & ">" & Me.drpDistrict.SelectedItem().ToString() & " District Office</A>"
        Else
            Me.lblDistrictLink.Text = ""
        End If
        'End If

        If IsPostBack And grdMemberOrgs.CurrentPageIndex > 0 Then

            If Not dsMembers.Tables("Organization") Is Nothing Then
                dsMembers.Tables("Organization").Clear()
                dsMembers.Tables("Organization").AcceptChanges()
            End If

            If Not (sender.GetType() Is CType(grdMemberOrgs, DataGrid)) Then
                'grdMemberOrgs.CurrentPageIndex = 0
                '           BindGrid()
                '        Response.Write("BIND in POST BACK")
            End If
            '    reQuery()

            '          BindGrid()
            '         connGROA.Close()
        End If



    End Sub

    Public Sub FillState()
        Dim daStates As New SqlClient.SqlDataAdapter(cmdStates)
        Dim dsStates As New DataSet

        Dim daDistricts As New SqlClient.SqlDataAdapter(cmdDistricts)
        Me.connGROA.Open()
        Try

            Me.cmdDistricts.CommandType = CommandType.StoredProcedure
            Me.cmdDistricts.CommandText = "pr_GetDistrictLookup"
            Me.cmdDistricts.Connection = Me.connGROA

            daDistricts.Fill(dsDistricts, "Districts")

            Me.drpDistrict.DataSource = dsDistricts
            Me.drpDistrict.DataTextField = "districtName"
            Me.drpDistrict.DataValueField = "districtID"
            Me.drpDistrict.DataBind()
            'dsDistricts.Clear()


            cmdStates.CommandType = CommandType.StoredProcedure
            cmdStates.CommandText = "pr_GetStateLookup"
            daStates.Fill(dsStates, "States")


            Me.drpState.DataSource = dsStates
            Me.drpState.DataTextField = "stateName"
            Me.drpState.DataValueField = "stateCode"
            Me.drpState.DataBind()
            ' dsStates.Clear()
        Catch ex As Exception

        End Try
        Me.drpState.Items.Insert(0, "[All]")
        Me.drpDistrict.Items.Insert(0, "[All]")
        Me.connGROA.Close()
    End Sub
    Public Sub FillInitiative()
        Dim daInitiative As New SqlClient.SqlDataAdapter(cmdInitiative)
        Dim dsInitiative As New DataSet
        Me.connGROA.Open()

        Try


            cmdInitiative.CommandType = CommandType.StoredProcedure
            cmdInitiative.CommandText = "pr_GetInitiativeLookup"
            cmdInitiative.Connection = Me.connGROA

            daInitiative.Fill(dsInitiative, "Initiative")

            Me.drpInitiative.DataSource = dsInitiative
            Me.drpInitiative.DataTextField = "InitiativeName"
            Me.drpInitiative.DataValueField = "InitiativeID"
            Me.drpInitiative.DataBind()
            Me.drpInitiative.Items.Insert(0, "[All]")


            Me.CheckBoxListInitiative.DataSource = dsInitiative
            Me.CheckBoxListInitiative.DataTextField = "InitiativeName"
            Me.CheckBoxListInitiative.DataValueField = "InitiativeID"
            Me.CheckBoxListInitiative.DataBind()
            dsInitiative.Clear()
        Catch ex As Exception

        End Try
        Me.connGROA.Close()

    End Sub
    Public Sub FillBusinessLine()
        Dim daBusinessLine As New SqlClient.SqlDataAdapter(cmdBusinessLine)
        Dim dsBusinessLine As New DataSet
        Me.connGROA.Open()

        cmdBusinessLine.CommandType = CommandType.StoredProcedure
        cmdBusinessLine.CommandText = "pr_GetBusinessLineLookup"
        cmdBusinessLine.Connection = Me.connGROA

        daBusinessLine.Fill(dsBusinessLine, "BusinessLine")

        'Me.drpBusinessLine.DataSource = dsBusinessLine
        'Me.drpBusinessLine.DataTextField = "BusinessLineName"
        'Me.drpBusinessLine.DataValueField = "BusinessLineID"
        'Me.drpBusinessLine.DataBind()
        'Me.drpBusinessLine.Items.Insert(0, "[All]")
        Try

            Me.CheckBoxListBusinessLine.DataSource = dsBusinessLine
            Me.CheckBoxListBusinessLine.DataTextField = "BusinessLineName"
            Me.CheckBoxListBusinessLine.DataValueField = "BusinessLineID"
            Me.CheckBoxListBusinessLine.DataBind()


        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
        dsBusinessLine.Clear()

        Me.connGROA.Close()

    End Sub

    Public Sub FillService()
        Dim daCommunity As New SqlClient.SqlDataAdapter(cmdCommunity)
        Dim dsCommunity As New DataSet
        Me.connGROA.Open()


        cmdCommunity.CommandType = CommandType.StoredProcedure
        cmdCommunity.CommandText = "pr_GetServiceLookup"
        cmdCommunity.Connection = Me.connGROA
        Try

            daCommunity.Fill(dsCommunity, "Community")

            Me.drpCommunity.DataSource = dsCommunity
            Me.drpCommunity.DataTextField = "ServiceName"
            Me.drpCommunity.DataValueField = "ServiceID"
            Me.drpCommunity.DataBind()
            Me.drpCommunity.Items.Insert(0, "[All]")

            Me.CheckBoxListService.DataSource = dsCommunity
            Me.CheckBoxListService.DataTextField = "ServiceName"
            Me.CheckBoxListService.DataValueField = "ServiceID"
            Me.CheckBoxListService.DataBind()
            Me.CheckBoxListService.CssClass = "listBox"
            dsCommunity.Clear()
        Catch ex As Exception

        End Try
        Me.connGROA.Close()
    End Sub

    Public Sub FillProgram()
        Dim daProgram As New SqlClient.SqlDataAdapter(cmdProgram)
        Dim dsProgram As New DataSet
        Me.connGROA.Open()
        cmdProgram.CommandType = CommandType.StoredProcedure
        cmdProgram.CommandText = "pr_GetProgramLookup"
        cmdProgram.Connection = Me.connGROA

        Try



            daProgram.Fill(dsProgram, "Program")

            Me.drpProgram.DataSource = dsProgram
            Me.drpProgram.DataTextField = "ProgramName"
            Me.drpProgram.DataValueField = "ProgramID"
            Me.drpProgram.DataBind()
            Me.drpProgram.Items.Insert(0, "[All]")

            Me.CheckBoxListProgram.DataSource = dsProgram
            Me.CheckBoxListProgram.DataTextField = "ProgramName"
            Me.CheckBoxListProgram.DataValueField = "ProgramID"
            Me.CheckBoxListProgram.DataBind()
            dsProgram.Clear()
        Catch ex As Exception

        End Try
        Me.connGROA.Close()
    End Sub


    Public Sub FillList()


        Dim daStates As New SqlClient.SqlDataAdapter(cmdStates)
        Dim dsStates As New DataSet

        Dim daDistricts As New SqlClient.SqlDataAdapter(cmdDistricts)

        Dim daCommunity As New SqlClient.SqlDataAdapter(cmdCommunity)
        Dim dsCommunity As New DataSet

        Dim daInitiative As New SqlClient.SqlDataAdapter(cmdInitiative)
        Dim dsInitiative As New DataSet

        Dim daProgram As New SqlClient.SqlDataAdapter(cmdProgram)
        Dim dsProgram As New DataSet

        Try

            Me.connGROA.Open()

            Me.cmdDistricts.CommandType = CommandType.StoredProcedure
            Me.cmdDistricts.CommandText = "pr_GetDistrictLookup"
            Me.cmdDistricts.Connection = Me.connGROA

            daDistricts.Fill(dsDistricts, "Districts")

            Me.drpDistrict.DataSource = dsDistricts
            Me.drpDistrict.DataTextField = "districtName"
            Me.drpDistrict.DataValueField = "districtID"
            Me.drpDistrict.DataBind()
            'dsDistricts.Clear()


            cmdStates.CommandType = CommandType.StoredProcedure
            cmdStates.CommandText = "pr_GetStateLookup"
            daStates.Fill(dsStates, "States")


            Me.drpState.DataSource = dsStates
            Me.drpState.DataTextField = "stateName"
            Me.drpState.DataValueField = "stateCode"
            Me.drpState.DataBind()
            'dsStates.Clear()

            Me.drpState.Items.Insert(0, "[All]")
            Me.drpDistrict.Items.Insert(0, "[All]")

            cmdCommunity.CommandType = CommandType.StoredProcedure
            cmdCommunity.CommandText = "pr_GetServiceLookup"
            cmdCommunity.Connection = Me.connGROA


            daCommunity.Fill(dsCommunity, "Community")

            Me.drpCommunity.DataSource = dsCommunity
            Me.drpCommunity.DataTextField = "ServiceName"
            Me.drpCommunity.DataValueField = "ServiceID"
            Me.drpCommunity.DataBind()

            Me.CheckBoxListService.DataSource = dsCommunity
            Me.CheckBoxListService.DataTextField = "ServiceName"
            Me.CheckBoxListService.DataValueField = "ServiceID"
            Me.CheckBoxListService.DataBind()
            dsCommunity.Clear()

            cmdInitiative.CommandType = CommandType.StoredProcedure
            cmdInitiative.CommandText = "pr_GetInitiativeLookup"
            cmdInitiative.Connection = Me.connGROA

            daInitiative.Fill(dsInitiative, "Initiative")

            Me.drpInitiative.DataSource = dsInitiative
            Me.drpInitiative.DataTextField = "InitiativeName"
            Me.drpInitiative.DataValueField = "InitiativeID"
            Me.drpInitiative.DataBind()

            Me.CheckBoxListInitiative.DataSource = dsInitiative
            Me.CheckBoxListInitiative.DataTextField = "InitiativeName"
            Me.CheckBoxListInitiative.DataValueField = "InitiativeID"
            Me.CheckBoxListInitiative.DataBind()
            dsInitiative.Clear()

            cmdProgram.CommandType = CommandType.StoredProcedure
            cmdProgram.CommandText = "pr_GetProgramLookup"
            cmdProgram.Connection = Me.connGROA


            daProgram.Fill(dsProgram, "Program")

            Me.drpProgram.DataSource = dsProgram
            Me.drpProgram.DataTextField = "ProgramName"
            Me.drpProgram.DataValueField = "ProgramID"
            Me.drpProgram.DataBind()

            Me.CheckBoxListProgram.DataSource = dsProgram
            Me.CheckBoxListProgram.DataTextField = "ProgramName"
            Me.CheckBoxListProgram.DataValueField = "ProgramID"
            Me.CheckBoxListProgram.DataBind()
            dsProgram.Clear()

            Me.drpCommunity.Items.Insert(0, "[All]")
            Me.drpInitiative.Items.Insert(0, "[All]")
            Me.drpProgram.Items.Insert(0, "[All]")

            FillBusinessLine()


        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

        Me.grdMemberOrgs.Visible = False
        ' reQuery()
        '   Dim daMembers As New SqlClient.SqlDataAdapter(GetNWOList("None", -1))
        '  daMembers.Fill(dsMembers, "Organization")
        ' reQuery()
        'BindGrid()
        If grdMemberOrgs.CurrentPageIndex > 0 Then
            reQuery()
        End If

        Me.connGROA.Close()
    End Sub
    Public Function GetNWOList(ByVal State As String, ByVal District As Integer)
        'Public Function GetNWOList()

        Dim cmd As New SqlClient.SqlCommand
        Dim dr As SqlClient.SqlDataReader
        Dim sCommunity As String
        Dim sInitiative As String
        Dim sSize As String
        Dim sFName As String
        Dim sLame As String
        Dim param As SqlClient.SqlParameter

        Dim MyVar As Object
        MyVar = System.DBNull.Value

        Dim ErrStr As String
        'param.Direction = ParameterDirection.Input
        'tempString = New System.Text.StringBuilder
        'param.Value = NR.Utility.ParseListItemCollection(Me.listTrack.Items, ",")

        'sCommunity.Append(Me.drpCommunity.Items)
        'sCommunity.Append(",")
        'sCommunity = CType(NWOFactSheets.Utility.ParseListItemCollection(Me.drpCommunity.Items, ","), String)


        Try
            'For Each li As ListItem In radBusinessLine.Items
            '    'For Each li As ListItem In CheckBoxListBusinessLine.Items
            '    'If li.Selected Then
            '    'Response.Write(li.Text)
            '    ' End If
            'Response.Write(Me.radBusinessLine.SelectedItem.Value)
            'Next

            cmd.Connection = connGROA
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "pr_FS_GetNwoListAdvanced"
            param = New SqlClient.SqlParameter("@UserAccountID", SqlDbType.Int, 9)
            param.Value = 0
            cmd.Parameters.Add(param)

            param = New SqlClient.SqlParameter("@SearchState", SqlDbType.Char, 2)
            'If State = "None" Then
            '    param.Value = MyVar
            'Else
            '    param.Value = State
            'End If
            If Me.drpState.SelectedValue = "[All]" Then
                param.Value = MyVar
            Else
                param.Value = Me.drpState.SelectedValue
            End If
            cmd.Parameters.Add(param)

            param = New SqlClient.SqlParameter("@SearchDistrict", SqlDbType.Int, 9)
            'If District = -1 Then
            '    param.Value = MyVar
            'Else
            '    param.Value = District
            'End If
            If Me.drpDistrict.SelectedValue = "[All]" Then
                param.Value = MyVar
            Else
                param.Value = Me.drpDistrict.SelectedValue
            End If
            cmd.Parameters.Add(param)

            param = New SqlClient.SqlParameter("@SearchZipCode", SqlDbType.VarChar, 10)

            If Trim(txtZIp.Text) = "" Then
                param.Value = MyVar
            Else
                param.Value = Trim(txtZIp.Text).ToString
            End If
            cmd.Parameters.Add(param)

            param = New SqlClient.SqlParameter("@SearchName", SqlDbType.VarChar, 250)
            If Trim(Me.txtOrgname.Text) = "" Then
                param.Value = MyVar
            Else
                param.Value = txtOrgname.Text.ToString
            End If
            cmd.Parameters.Add(param)

            'param = New SqlClient.SqlParameter("@keyword", SqlDbType.VarChar, 250)
            'param.Value = MyVar
            'cmd.Parameters.Add(param)

            param = New SqlClient.SqlParameter("@staffSize", SqlDbType.Char, 1)
            If drpStaffSize.SelectedValue = "" Then
                param.Value = MyVar
            Else
                param.Value = Me.drpStaffSize.SelectedValue
            End If
            cmd.Parameters.Add(param)


            param = New SqlClient.SqlParameter("@BusinessLineList", SqlDbType.VarChar, 250)
            param.Direction = ParameterDirection.Input
            'If (Me.RadioButtonListBusinessLine.SelectedIndex > -1) Then
            '    If Me.RadioButtonListBusinessLine.SelectedItem.Value = "All" Then
            '        param.Value = MyVar
            '    Else
            'param.Value = NWOFactSheets.Utility.ParseListItemCollection(Me.CheckBoxListBusinessLine.Items, ",")
            '    End If
            'Else
            param.Value = MyVar
            'End If
            'Dim strCOmm As String
            'strCOmm = param.Value
            'strCOmm.Remove(strCOmm.Length - 1, 1)
            'If strCOmm = "" Then
            '    param.Value = MyVar
            'Else
            '    param.Value = strCOmm
            'End If
            cmd.Parameters.Add(param)
            'Response.Write(param.Value)

            param = New SqlClient.SqlParameter("@InitiativeList", SqlDbType.VarChar, 250)
            param.Direction = ParameterDirection.Input
            'If (Me.RadioButtonListInitiative.SelectedIndex > -1) Then
            '    If Me.RadioButtonListInitiative.SelectedItem.Value = "All" Then
            '        param.Value = MyVar
            '    Else
            'param.Value = NWOFactSheets.Utility.ParseListItemCollection(Me.CheckBoxListInitiative.Items, ",")
            '    End If
            'Else
            param.Value = MyVar
            'End If
            cmd.Parameters.Add(param)
            'Response.Write(param.Value & ",")


            param = New SqlClient.SqlParameter("@ProgramList", SqlDbType.VarChar, 250)
            param.Direction = ParameterDirection.Input
            'If (Me.RadioButtonListProgram.SelectedIndex > -1) Then
            '    If Me.RadioButtonListProgram.SelectedItem.Value = "All" Then
            '        param.Value = MyVar
            '    Else
            'param.Value = NWOFactSheets.Utility.ParseListItemCollection(Me.CheckBoxListProgram.Items, ",")
            '    End If
            'Else
            param.Value = MyVar
            'End If
            cmd.Parameters.Add(param)
            'Response.Write(param.Value & ",")
            param = New SqlClient.SqlParameter("@ServiceList", SqlDbType.VarChar, 250)
            param.Direction = ParameterDirection.Input
            'If (Me.RadioButtonListService.SelectedIndex > -1) Then
            '    If Me.RadioButtonListService.SelectedItem.Value = "All" Then
            '        param.Value = MyVar
            '    Else
            'param.Value = NWOFactSheets.Utility.ParseListItemCollection(Me.CheckBoxListService.Items, ",")
            '    End If
            'Else
            param.Value = MyVar
            'End If
            cmd.Parameters.Add(param)
            'Response.Write(param.Value & ",")

            cmd.Prepare()

            Return (cmd)

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try


        'Response.Write(cmd.Parameters.Item(8).Value & ", ")
        '        Response.Write(cmd.Parameters.Item(9).Value & ", ")
        '       Response.Write(cmd.Parameters.Item(10).Value & ", ")
        '      Response.Write(cmd.Parameters.Item(11).Value & ", ")
        '     Response.Write(cmd.Parameters.Item(12).Value & ", ")
        '    Response.Write(cmd.Parameters.Item(13).Value & ", ")
        '   Response.Write(cmd.Parameters.Item(14).Value & ", ")
        '  Response.Write(cmd.Parameters.Item(15).Value & ", ")
        ' Response.Write(cmd.Parameters.Item(16).Value & ", ")
        'Response.Write(cmd.Parameters.Item(17).Value & ", ")
        '        Response.Write(cmd.Parameters.Item(18).Value & ", ")

    End Function

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        '   Me.grdMemberOrgs.PageSize = 5
        '      If grdMemberOrgs.PageCount >= 0 Then


        grdMemberOrgs.CurrentPageIndex = 0
        grdMemberOrgs.Visible = True

        If Not dsMembers.Tables("Organization") Is Nothing Then
            dsMembers.Tables("Organization").Clear()
            dsMembers.Tables("Organization").AcceptChanges()
        End If

        reQuery()
    End Sub

    Private Sub reQuery()

        Dim cmdTxt As String
        Dim valState As String


        Dim arrDistrictIDDesc As Array = Split(Me.drpDistrict.SelectedValue(), "_")
        Dim valDistrictID = arrDistrictIDDesc(0)

        valState = drpState.SelectedValue()

        Try


            Dim daMembers As New SqlClient.SqlDataAdapter(GetNWOList("None", -1))

            'Dim daMembers As New SqlClient.SqlDataAdapter(GetNWOList())

            daMembers.Fill(dsMembers, "Organization")


            If valState <> "[All]" Or drpDistrict.SelectedValue <> "[All]" Then
                Dim selectTxt As String = ""
                If valState <> "[All]" Then
                    selectTxt = "TRIM(OrganizationState) = '" & Trim(valState) & "'"
                    If drpDistrict.SelectedValue <> "[All]" Then
                        selectTxt = selectTxt & " AND "
                    End If
                End If

                If drpDistrict.SelectedValue <> "[All]" Then
                    selectTxt = selectTxt & " districtID = " & drpDistrict.SelectedValue
                End If
                Dim FoundRows() As DataRow = dsMembers.Tables("Organization").Select(selectTxt, "OrganizationName DESC", DataViewRowState.CurrentRows)
                '            DataRowArray.Initialize()
                '            For Each DataRow As DataRow In DataRowArray(0)
                '           DataRowArray.Add(DataRow)
                '          Next
                PrintRows(FoundRows, "Organizations")
                '            dsMembers.Clear()
                '           dsMembers.AcceptChanges()

                '            For Each DataRow As DataRow In FoundRows
                '           '             Response.Write(DataRow.Item("organizationname") & "<BR>")
                '          dsMembers.Tables("Organization").Rows.Add(DataRow)
                ''         Next
                '       dsMembers.AcceptChanges()

                lblMsg.Visible = True
                lblDistrictLink.Visible = True
            Else

                BindGrid()

            End If

        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

    End Sub
    Private Sub PrintRows(ByVal rows() As DataRow, ByVal label As String)
        'Response.Write(label)
        '     If rows.Length <= 0 Then
        '    Response.Write("no rows found")
        '   Exit Sub
        '  End If
        ' Dim r As DataRow
        '        Dim c As DataColumn
        '       For Each r In rows
        '      For Each c In r.Table.Columns
        '     Response.Write(r(c))
        '    Next c
        '   Response.Write("<BR>")
        '  Next r
        '
        Dim i As Integer = 0
        '      Dim DataTable As New DataTable
        Dim Found As Boolean

        i = 0
        For Each r1 As DataRow In dsMembers.Tables("Organization").Rows
            For Each r2 As DataRow In rows
                '                Response.Write(r2.Item("RecordKeyOrg") & "__" & r1.Item("RecordKeyOrg") & "<BR>")
                If Trim(r1.Item("RecordKeyOrg")) = Trim(r2.Item("RecordKeyOrg")) Then
                    '       Response.Write("Match FOUND<BR>")
                    Found = True

                    '         Exit For
                End If
            Next
            If Found = False Then

                r1.Delete()
                'dsMembers.Tables("Organization").Rows(i).Delete()
            End If
            Found = False
            i = i + i
        Next
        dsMembers.Tables("Organization").AcceptChanges()
        BindGrid()

    End Sub

    Private Sub BindGrid()

        '    reQuery()
        '   Me.connGROA.Open()

        If (Me.RecordsPerPageDropDownList.SelectedValue = "0") Then
            grdMemberOrgs.AllowPaging = False
        Else
            grdMemberOrgs.AllowPaging = True
            If RecordsPerPageDropDownList.SelectedValue.Length = 0 Then
                grdMemberOrgs.PageSize = 5
            Else
                grdMemberOrgs.PageSize = CInt(RecordsPerPageDropDownList.SelectedValue)
            End If
        End If

        Me.grdMemberOrgs.DataSource = DataBinder.Eval(dsMembers, "Tables[Organization]")
        Me.grdMemberOrgs.DataMember = "organizationName"

        Me.grdMemberOrgs.DataBind()

        If grdMemberOrgs.Items.Count > 0 Then
            grdMemberOrgs.Visible = True
            lblMsg.Visible = True
            lblDistrictLink.Visible = True

        Else
            grdMemberOrgs.Visible = False
            lblMsg.Visible = False

            lblNoData.Text = "[No data to display]"
        End If

        '       Me.connGROA.Close()

    End Sub

    Private Sub drpDistrict_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles drpDistrict.SelectedIndexChanged

        Dim arrDistrictIDDesc As Array = Split(Me.drpDistrict.SelectedValue(), "_")
        Dim valDistrictID = arrDistrictIDDesc(0)

        '       Me.cmdStates.CommandText = "SELECT * FROM State "
        Dim daStates As New SqlClient.SqlDataAdapter(cmdStates)
        Dim dsStates As New DataSet

        daStates.Fill(dsStates, "States")

        If valDistrictID <> "[All]" Then
            For Each Row As DataRow In dsStates.Tables("States").Rows
                If Row.Item("districtID") <> valDistrictID Then
                    Row.Delete()
                End If
            Next

            dsStates.Tables("States").AcceptChanges()
            '            Me.cmdStates.CommandText = Me.cmdStates.CommandText & "WHERE districtID = " & valDistrictID
        End If

        '      Me.grdMemberOrgs.CurrentPageIndex = 1
        '     Me.setVirtualItemCount()

        '      Me.connGROA.Open()
        '     Me.drStates = Me.cmdStates.ExecuteReader()

        Dim currentStateCd = Me.drpState.SelectedValue

        Me.drpState.DataSource = dsStates.Tables("States")
        Me.drpState.DataBind()
        '        drStates.Close()

        Me.drpState.Items.Insert(0, "[All]")
        If valDistrictID = "[All]" Then
            Me.drpState.SelectedValue = currentStateCd
        End If
        Me.connGROA.Close()
        grdMemberOrgs.Visible = False
        '  BindGrid()
        grdMemberOrgs.CurrentPageIndex = 0
        If Not dsMembers.Tables("Organization") Is Nothing Then
            dsMembers.Tables("Organization").Clear()
            dsMembers.Tables("Organization").AcceptChanges()
        End If
        reQuery()

    End Sub

    Private Sub grdMemberOrgs_PageIndexChanged(ByVal sender As System.Object, ByVal e As DataGridPageChangedEventArgs) Handles grdMemberOrgs.PageIndexChanged

        If Not dsMembers.Tables("Organization") Is Nothing Then
            dsMembers.Tables("Organization").Clear()
            dsMembers.Tables("Organization").AcceptChanges()
        End If
        reQuery()

        '  Response.Write(e.NewPageIndex & "------------")
        grdMemberOrgs.CurrentPageIndex = e.NewPageIndex

        '        If grdMemberOrgs.CurrentPageIndex = 200 Then
        '       grdMemberOrgs.CurrentPageIndex = e.NewPageIndex + 20
        '      ElseIf grdMemberOrgs.CurrentPageIndex = 300 Then
        '         grdMemberOrgs.CurrentPageIndex = e.NewPageIndex + 40
        '
        '       End If

        BindGrid()

        '       If e.NewPageIndex = 20 Then
        '      grdMemberOrgs.CurrentPageIndex = 200
        '     ElseIf e.NewPageIndex = 21 Then
        '        grdMemberOrgs.CurrentPageIndex = 300
        '   End If
    End Sub

    Private Sub btnBusiness_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBusiness.Click
        'If Me.RadioButtonListBusinessLine.Visible = False Then
        '    Me.RadioButtonListBusinessLine.Visible = True
        '    Me.CheckBoxListBusinessLine.Visible = True
        '    Me.BusinessLine.Visible = True
        '    Exit Sub
        'End If

        'If Me.RadioButtonListBusinessLine.Visible = True Then
        '    Me.RadioButtonListBusinessLine.Visible = False
        '    Me.CheckBoxListBusinessLine.Visible = False
        '    Me.RadioButtonListBusinessLine.SelectedIndex = -1
        '    Me.CheckBoxListBusinessLine.SelectedIndex = -1
        'End If

        If Me.CheckBoxListBusinessLine.Visible = False Then
            Me.CheckBoxListBusinessLine.Visible = True
            Me.BusinessLine.Visible = True
            Exit Sub
        End If

        If Me.CheckBoxListBusinessLine.Visible = True Then
            Me.CheckBoxListBusinessLine.Visible = False
            Me.CheckBoxListBusinessLine.SelectedIndex = -1
        End If
    End Sub

    Private Sub btnInitiative_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInitiative.Click
        'If Me.RadioButtonListInitiative.Visible = False Then
        '    Me.RadioButtonListInitiative.Visible = True
        '    Me.CheckBoxListInitiative.Visible = True
        '    Exit Sub
        'End If

        'If Me.RadioButtonListInitiative.Visible = True Then
        '    Me.RadioButtonListInitiative.Visible = False
        '    Me.CheckBoxListInitiative.Visible = False
        '    Me.RadioButtonListInitiative.SelectedIndex = -1
        '    Me.CheckBoxListInitiative.SelectedIndex = -1
        'End If

        If Me.CheckBoxListInitiative.Visible = False Then
            Me.CheckBoxListInitiative.Visible = True
            Me.Initiative.Visible = True
            Exit Sub
        End If

        If Me.CheckBoxListInitiative.Visible = True Then
            Me.CheckBoxListInitiative.Visible = False
            Me.CheckBoxListInitiative.SelectedIndex = -1
        End If
    End Sub

    Private Sub btnProgram_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnProgram.Click
        'If Me.RadioButtonListProgram.Visible = False Then
        '    Me.RadioButtonListProgram.Visible = True
        '    Me.CheckBoxListProgram.Visible = True

        '    Exit Sub
        'End If

        'If Me.RadioButtonListProgram.Visible = True Then
        '    Me.RadioButtonListProgram.Visible = False
        '    Me.CheckBoxListProgram.Visible = False
        '    Me.RadioButtonListProgram.SelectedIndex = -1
        '    Me.CheckBoxListProgram.SelectedIndex = -1
        'End If


        If Me.CheckBoxListProgram.Visible = False Then
            Me.CheckBoxListProgram.Visible = True
            Me.program.Visible = True
            Exit Sub
        End If

        If Me.CheckBoxListProgram.Visible = True Then
            Me.CheckBoxListProgram.Visible = False
            Me.CheckBoxListProgram.SelectedIndex = -1
        End If
    End Sub

    Private Sub btnService_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnService.Click
        'If Me.RadioButtonListService.Visible = False Then
        '    Me.RadioButtonListService.Visible = True
        '    Me.CheckBoxListService.Visible = True
        '    Exit Sub
        'End If

        'If Me.RadioButtonListService.Visible = True Then
        '    Me.RadioButtonListService.Visible = False
        '    Me.CheckBoxListService.Visible = False
        '    Me.RadioButtonListService.SelectedIndex = -1
        '    Me.CheckBoxListService.SelectedIndex = -1
        'End If

        If Me.CheckBoxListService.Visible = False Then
            Me.CheckBoxListService.Visible = True
            Me.Service.Visible = True
            Exit Sub
        End If

        If Me.CheckBoxListService.Visible = True Then
            Me.CheckBoxListService.Visible = False
            Me.CheckBoxListService.SelectedIndex = -1
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Me.grdMemberOrgs.Visible = False
        Me.lblMsg.Visible = False
        Me.lblNoData.Visible = False
        Me.lblDistrictLink.Visible = False
        Me.txtOrgname.Text = ""
        Me.txtZIp.Text = ""
        Me.drpDistrict.SelectedIndex = "0"
        Me.drpState.SelectedIndex = "0"
        Me.CheckBoxListBusinessLine.SelectedIndex = "-1"
        Me.CheckBoxListInitiative.SelectedIndex = "-1"
        Me.CheckBoxListProgram.SelectedIndex = "-1"
        Me.CheckBoxListService.SelectedIndex = "-1"
        Me.CheckBoxListBusinessLine.Visible = False
        Me.CheckBoxListInitiative.Visible = False
        Me.CheckBoxListProgram.Visible = False
        Me.CheckBoxListService.Visible = False



    End Sub
End Class



Public Class NWOReport_View
    Inherits System.Web.UI.Page
#Region " My Declarations"
    Public WithEvents NWOReport1 As NWOReport
#End Region

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lnkPrint As System.Web.UI.WebControls.HyperLink

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim _orgID As Integer
        'Put user code to initialize the page here

        NWOReport1.ShowLogo = False

        'NWOReport1.OrgID = 8274
        'NWOReport1.GetData()
        'If Request.QueryString("orgid") Is Nothing Then
        '    _orgID = 8274  'just some dummy data for debugging
        'Else
        '    _orgID = CType(Request.QueryString("OrgID"), Integer)
        'End If
        ''NWOReport1.GetData(_orgID)
        'NWOReport1.GetOrgData(_orgID)

        lnkPrint.NavigateUrl &= "?OrgID=" & Request.QueryString("OrgID").ToString()
    End Sub

   
End Class

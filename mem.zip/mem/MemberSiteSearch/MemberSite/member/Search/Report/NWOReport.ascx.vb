Option Explicit On 
Option Strict On
Imports System
Imports System.Data.SqlClient
Imports System.Configuration.ConfigurationSettings
Imports NWOFactSheets
Public Class NWOReport
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblName As System.Web.UI.WebControls.Label
    Protected WithEvents lnkWebsite As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblContactName As System.Web.UI.WebControls.Label
    Protected WithEvents lblContactPhone As System.Web.UI.WebControls.Label
    Protected WithEvents lnkContactEmail As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblBackground As System.Web.UI.WebControls.Label
    Protected WithEvents lblMission As System.Web.UI.WebControls.Label
    Protected WithEvents dlAccomplishments As System.Web.UI.WebControls.DataList
    Protected WithEvents grdAccomplishments As System.Web.UI.WebControls.DataGrid
    Protected WithEvents rptAccomplishments As System.Web.UI.WebControls.Repeater
    Protected WithEvents lblDistFax As System.Web.UI.WebControls.Label
    Protected WithEvents lblDistPhone As System.Web.UI.WebControls.Label
    Protected WithEvents lblDistContact As System.Web.UI.WebControls.Label
    Protected WithEvents ContactName As System.Web.UI.WebControls.Label
    Protected WithEvents ContactPhone As System.Web.UI.WebControls.Label
    Protected WithEvents ContactEmail As System.Web.UI.WebControls.Label
    Protected WithEvents AddAccomplishments As System.Web.UI.WebControls.Label
    Protected WithEvents CommunityService As System.Web.UI.WebControls.Label
    Protected WithEvents Initiatives As System.Web.UI.WebControls.Label
    Protected WithEvents BOD As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictContact As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictContactName As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictContactPhone As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictContactEmail As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictContactFax As System.Web.UI.WebControls.Label
    Protected WithEvents lblCharteredMember As System.Web.UI.WebControls.Label
    Protected WithEvents lnkDistEmail As System.Web.UI.WebControls.HyperLink
    Protected WithEvents imgLogo As System.Web.UI.WebControls.Image
    Protected WithEvents lblPhone As System.Web.UI.WebControls.Label
    Protected WithEvents lblFax As System.Web.UI.WebControls.Label
    Protected WithEvents lblED As System.Web.UI.WebControls.Label
    Protected WithEvents lblContactFax As System.Web.UI.WebControls.Label
    Protected WithEvents ContactFax As System.Web.UI.WebControls.Label
    Protected WithEvents lblAddress As System.Web.UI.WebControls.Label
    Protected WithEvents lblStaffSize As System.Web.UI.WebControls.Label
    Protected WithEvents lblBudget As System.Web.UI.WebControls.Label
    Protected WithEvents dlCommServ As System.Web.UI.WebControls.DataList
    Protected WithEvents lblDistrict As System.Web.UI.WebControls.Label
    Protected WithEvents Budget As System.Web.UI.WebControls.Label
    Protected WithEvents District As System.Web.UI.WebControls.Label
    Protected WithEvents dlAdditionalAccomplishments As System.Web.UI.WebControls.DataList
    Protected WithEvents dlBoardOfDirectors As System.Web.UI.WebControls.DataList
    Protected WithEvents lblAdditionalAccomplishments As System.Web.UI.WebControls.Label
    Protected WithEvents lblNoBoardMember As System.Web.UI.WebControls.Label
    Protected WithEvents CharteredMember As System.Web.UI.WebControls.Label
    Protected WithEvents grdBoardOfDirectors As System.Web.UI.WebControls.DataGrid
    Protected WithEvents dlLegacyAccomplishments As System.Web.UI.WebControls.DataList
    Protected WithEvents StaffSize As System.Web.UI.WebControls.Label
    Protected WithEvents lblMailingAddress As System.Web.UI.WebControls.Label
    Protected WithEvents MailingAddressLabel As System.Web.UI.WebControls.Label
    Protected WithEvents rptInitiative As System.Web.UI.WebControls.DataList
    Protected WithEvents lblDistrictTollFreePhone As System.Web.UI.WebControls.Label
    Protected WithEvents DistrictTollFree As System.Web.UI.WebControls.Label
    Protected WithEvents BillingAddressLabel As System.Web.UI.WebControls.Label
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region " My Declarations"
    Private _orgID As Int32 = -1 '-1 indicates org id has not been set
    Private _recordIsMod As Boolean = False
    Private _util As New Utility
    Public _organization As Organization
#End Region
#Region "Public Properties"
    Public Property OrgID() As Int32
        Get
            Return _orgID
        End Get
        Set(ByVal Value As Int32)
            If Value > 0 Then
                _orgID = Value
            Else
                Err.Raise(vbObjectError, "NWOFactSheets.NWOReport", "OrgID must be greater than zero")
            End If
        End Set
    End Property
    Public Property ShowLogo() As Boolean
        Get
            Return imgLogo.Visible
        End Get
        Set(ByVal Value As Boolean)
            imgLogo.Visible = Value
        End Set
    End Property
#End Region
#Region "Private Subs & Functions"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        '_organization = New Organization(CType(Session("UserID"), Int32), _
        '    AppSettings.Item("cn.ConnectionString").ToString(), _
        '    CType(Request.QueryString("orgID"), Int32), False)
        'hardcoded 0 for user account for now
        _organization = New Organization(0, AppSettings.Item("cn.ConnectionString").ToString(), CType(Request.QueryString("orgID"), Long))
        With _organization
            lblName.Text = .OrganizationName
            lblAddress.Text = .GetFullAddressInHTML()
            If (.MailingAddress.Count > 0) Then
                lblMailingAddress.Text = CType(.MailingAddress.Item(0), AddressDisplay).GetFullAddress(False, True) 'GetFullAddress(bool ShowOnSingleLine,bool ShowHTMLVersion)
            Else
                lblMailingAddress.Visible = False
                MailingAddressLabel.Visible = False
            End If



            lblFax.Text = .Fax.ToString()
            lblPhone.Text = .Phone.ToString()
            lnkWebsite.Text = .Website.ToString()
            lnkWebsite.NavigateUrl = "http://" & .Website.ToString()
            lblBackground.Text = .Background.ToString()
            lblMission.Text = .Mission.ToString()
            If ((Not .BudgetFiscalYear Is Nothing) AndAlso .BudgetFiscalYear.Length > 0) Then
                Budget.Text &= String.Format(" ({0})", .BudgetFiscalYear)
            End If
            Budget.Text &= ": "
            lblBudget.Text = String.Format("{0:'$'#,###'</p>'}", .BudgetExpense)
            If .StaffSizeYear Is Nothing Then
                StaffSize.Visible = False
            Else
                StaffSize.Text &= IIf(.StaffSizeYear.Length > 0, String.Format(" in {0}: ", .StaffSizeYear), ":").ToString()
            End If
            If .StaffSize.Length > 0 Then
                lblStaffSize.Text = Decimal.Parse(.StaffSize).ToString("#.#'<br/>")
            End If
            dlAdditionalAccomplishments.DataSource = .Accomplishments
            dlAdditionalAccomplishments.DataBind()
            dlAdditionalAccomplishments.Visible = (.Accomplishments.Count > 0)
            lblAdditionalAccomplishments.Visible = (.Accomplishments.Count > 0)
            dlAccomplishments.DataSource = .LegacyAccomplishments
            dlAccomplishments.DataBind()

            rptInitiative.DataSource = .Initiatives
            rptInitiative.DataBind()
            Initiatives.Visible = (.Initiatives.Count > 0)
            rptInitiative.ShowFooter = (.Initiatives.Count > 0)
            dlCommServ.DataSource = .Services
            dlCommServ.DataBind()
            dlCommServ.Visible = (.Services.Count > 0)
            CommunityService.Visible = (.Services.Count > 0)

            grdBoardOfDirectors.DataSource = .BoardOfDirectors
            grdBoardOfDirectors.DataBind()
            grdBoardOfDirectors.Visible = (.BoardOfDirectors.Count > 0)
            BOD.Visible = (.BoardOfDirectors.Count > 0)
            For Each r As DataGridItem In grdBoardOfDirectors.Items
                If Trim(r.Cells(2).Text) = "Not Applicable" Then r.Cells(2).Text = ""
            Next

            lblED.Text = .GetED("<br>")
            lblContactName.Text = .NWOContactName
            lblContactPhone.Text = .NWOContactPhone
            lblContactFax.Text = .NWOContactFax
            lnkContactEmail.Text = .NWOContactEmail
            lnkContactEmail.NavigateUrl = "mailto:" & .NWOContactEmail
            lblDistrict.Text = .DistrictName
            lblDistContact.Text = .DistrictContactName
            lblDistFax.Text = .DistrictContactFax
            lblDistPhone.Text = .DistrictContactPhone
            lnkDistEmail.Text = .DistrictContactEmail
            lnkDistEmail.NavigateUrl = "mailto:" & .DistrictContactEmail
            lblDistrictTollFreePhone.Text = .DistrictContactTollFreePhone
            lblCharteredMember.Text = .AboutTheNetwork

            'hide stuff that's blank
            If _organization.BudgetExpense = 0D Then
                Budget.Visible = False
                lblBudget.Visible = False
            End If
            dlAccomplishments.Visible = (.LegacyAccomplishments.Count > 0)
            If .StaffSize = "0" Then
                lblStaffSize.Visible = False
            End If
            If .Initiatives.Count = 0 Then
                rptInitiative.Visible = False
            End If
            If .LegacyAccomplishments.Count = 0 Then
                Me.dlAccomplishments.Visible = False
            End If
        End With


    End Sub
    Private Function _fetchAccomplishments(ByRef cn As SqlConnection) As Boolean
        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If
            Dim cmd As New SqlCommand
            cmd.CommandText = "dbo.pr_GetOrgAccomplishmentList_02a"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cn
            Dim param As New SqlParameter
            param.ParameterName = "@UserAccountID"
            param.SqlDbType = SqlDbType.Int
            param.Value = Session("UserID")
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@OrgRecordIsMod"
            param.SqlDbType = SqlDbType.Char
            param.Size = 1
            param.Value = _util.TranslateBoolean(_recordIsMod)
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@OrganizationID"
            param.Value = _orgID
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeOrig"
            param.SqlDbType = SqlDbType.Char
            param.Value = "Y"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeMods"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeDrafts"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeActive"
            param.SqlDbType = SqlDbType.Char
            param.Value = "Y"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeInactive"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            dlAccomplishments.DataSource = dr
            dlAccomplishments.DataBind()
            dr.Close()
            dr = cmd.ExecuteReader
            rptAccomplishments.DataSource = dr
            rptAccomplishments.DataBind()
            dlAccomplishments.Dispose()
            dr.Close()
            dlAccomplishments.ShowFooter = (dlAccomplishments.Items.Count = 0)
            'rptAccomplishments.FooterTemplateShowFooter = (grdAccomplishments.Items.Count = 0)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function
    Private Function _fetchAccomplishmentsForFiscalYear(ByRef cn As SqlConnection) As Boolean
        Return _fetchAccomplishmentsForFiscalYear(cn, CType(IIf(System.DateTime.Now.Month > 9, DateTime.Now.Year + 1, Now.Year), Short))
    End Function
    Private Function _fetchAccomplishmentsforFiscalYear(ByRef cn As SqlConnection, ByVal Fiscalyear As Short) As Boolean
        Try


            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            Dim cmd As New SqlCommand
            cmd.CommandText = "dbo.pr_GetOrgAccomplishmentList_02a"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cn
            Dim param As New SqlParameter
            param.ParameterName = "@UserAccountID"
            param.SqlDbType = SqlDbType.Int
            param.Value = Session("UserID")
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@OrgRecordIsMod"
            param.SqlDbType = SqlDbType.Char
            param.Size = 1
            param.Value = _util.TranslateBoolean(_recordIsMod)
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@OrganizationID"
            param.Value = _orgID
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeOrig"
            param.SqlDbType = SqlDbType.Char
            param.Value = "Y"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeMods"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeDrafts"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeActive"
            param.SqlDbType = SqlDbType.Char
            param.Value = "Y"
            cmd.Parameters.Add(param)
            param = New SqlParameter
            param.ParameterName = "@IncludeInactive"
            param.SqlDbType = SqlDbType.Char
            param.Value = "N"
            cmd.Parameters.Add(param)
            Dim dr As SqlDataReader
            dr = cmd.ExecuteReader
            dlAccomplishments.DataSource = dr
            dlAccomplishments.DataBind()
            dr.Close()
            dr = cmd.ExecuteReader
            grdAccomplishments.DataSource = dr
            grdAccomplishments.DataBind()
            dlAccomplishments.Dispose()
            dr.Close()
            dlAccomplishments.ShowFooter = (dlAccomplishments.Items.Count = 0)
            grdAccomplishments.ShowFooter = (grdAccomplishments.Items.Count = 0)
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function
    Private Function _fetchOrganizationData(ByRef cn As SqlClient.SqlConnection) As Boolean
        Dim blnSucess As Boolean = False
        'open the connection if it is closed
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandText = "pr_GetOrganizationList_03"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        Dim param As New SqlParameter
        param.ParameterName = "@UserAccountID"
        param.SqlDbType = SqlDbType.Int
        param.Value = CType(Session("UserID"), String)
        cmd.Parameters.Add(param)
        param = New SqlClient.SqlParameter
        param.ParameterName = "@RecordIsMod"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrganizationID"
        param.SqlDbType = SqlDbType.Int
        param.Value = _orgID
        cmd.Parameters.Add(param)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        If (dr.Read) Then

            lblName.Text = _util.FormatBlank(dr("OrganizationName").ToString())
            lblBackground.Text = _util.FormatBlank(dr("OrganizationBackground").ToString())
            lblMission.Text = _util.FormatBlank(dr("OrganizationMission").ToString())
            lblBudget.Text = _util.FormatBlank(String.Format("{0:C}", dr("OrganizationBudget")))
            lblStaffSize.Text = _util.FormatBlank(dr("OrganizationStaffCount").ToString())

            lblDistrict.Text = dr("districtname").ToString()
            blnSucess = True
        End If
        dr.Close()

        cmd.Dispose()
        Return blnSucess

    End Function
    Private Function _fetchInitiatives(ByRef cn As SqlConnection) As Boolean
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandText = "pr_GetOrgInitiativeList_02a"
        cmd.CommandType = CommandType.StoredProcedure
        Dim param As New SqlParameter
        param.ParameterName = "@UserAccountID"
        param.Value = Session("UserID")
        param.SqlDbType = SqlDbType.Int
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrgRecordIsMod"
        param.Value = "N"
        param.SqlDbType = SqlDbType.Char
        cmd.Parameters.Add(param)

        param = New SqlParameter
        param.ParameterName = "@OrganizationID"
        param.Value = _orgID
        param.SqlDbType = SqlDbType.Int
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeOrig"
        param.Value = "Y"
        param.SqlDbType = SqlDbType.Char
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeMods"
        param.Value = "Y"
        param.SqlDbType = SqlDbType.Char
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeDrafts"
        param.Value = "N"
        param.SqlDbType = SqlDbType.Char
        cmd.Parameters.Add(param)
        cmd.Connection = cn
        Trace.Write(cmd.ToString())

        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        rptInitiative.DataSource = dr
        rptInitiative.DataBind()
        rptInitiative.ShowFooter = (rptInitiative.Items.Count = 0)

        dr.Close()
        cmd.Dispose()
    End Function
    Private Function _fetchOrgAddress(ByRef cn As SqlConnection) As Boolean
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
        Dim cmd As New SqlCommand
        cmd.CommandText = "dbo.pr_GetOrgAddressList_02a"
        cmd.Connection = cn
        cmd.CommandType = CommandType.StoredProcedure
        Dim param As New SqlParameter
        'With param
        param.ParameterName = "@UserAccountID"
        param.Value = Session("UserID")
        param.SqlDbType = SqlDbType.Int
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrgRecordIsMod"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrganizationID"
        param.SqlDbType = SqlDbType.Int
        param.Value = _orgID
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeOrig"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "Y"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeMods"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeDrafts"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeActive"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "Y"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeInactive"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        'End With
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader()
        Dim Address As New System.Text.StringBuilder
        While (dr.Read And Address.Length = 0)
            If CType(dr("AddressTypeID"), Integer) = 1 Then    'i is business mailing
                With Address
                    .Append(dr("AddressLine1").ToString().Trim())
                    If dr("addressLine2").ToString().Trim().Length > 0 Then
                        .Append("<br>")
                        .Append(dr("addressline2").ToString())
                    End If
                    .Append("<br>")
                    .Append(dr("AddressCity").ToString())
                    .Append(", ")
                    .Append(dr("AddressState").ToString())
                    .Append(Chr(32))
                    .Append(dr("AddressZipCode"))
                End With
            End If
        End While
        lblAddress.Text = Address.ToString()
        dr.Close()
        cmd = New SqlCommand
        cmd.CommandText = "dbo.pr_fs_GetOrganizationED"
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Connection = cn
        param = New SqlParameter
        param.ParameterName = "@OrganizationID"
        param.Value = _orgID
        param.SqlDbType = SqlDbType.Int
        cmd.Parameters.Add(param)
        dr = cmd.ExecuteReader(CommandBehavior.SingleRow)
        If dr.Read() Then
            lblED.Text = dr("FirstName").ToString() & Chr(32) & dr("lastname").ToString() & ", Executive Director"
        End If
        dr.Close()
        cmd.Dispose()



    End Function
    Private Function _fetchOrgContact(ByVal cn As SqlConnection) As Boolean

        Utility.OpenConnection(cn)
        Dim cmd As New SqlCommand
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "dbo.pr_GetOrgContactList_02a"
        cmd.Connection = cn
        Dim param As New SqlParameter
        param.ParameterName = "@UserAccountID"
        param.SqlDbType = SqlDbType.Int
        param.Value = Session("UserID")
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrgRecordIsMod"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@OrganizationID"
        param.SqlDbType = SqlDbType.Int
        param.Value = _orgID
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeOrig"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "Y"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeMods"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeDrafts"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeActive"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "Y"
        cmd.Parameters.Add(param)
        param = New SqlParameter
        param.ParameterName = "@IncludeInactive"
        param.SqlDbType = SqlDbType.Char
        param.Size = 1
        param.Value = "N"
        cmd.Parameters.Add(param)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        While dr.Read
            Select Case dr("contacttypeid")
                Case 11 'business website
                    lnkWebsite.Text = dr("contactvalue").ToString()
                    lnkWebsite.NavigateUrl = "http://" & dr("contactvalue").ToString()
                Case 5  'business phone
                    lblPhone.Text = dr("contactvalue").ToString()
                Case 3
                    lblFax.Text = dr("contactvalue").ToString()

            End Select
        End While
        dr.Close()
        cmd.Dispose()
    End Function
#End Region
#Region "Public Subs & Functions"

    Public Function GetData() As Boolean

        If _orgID <= 0 Then
            _util.ThrowException("OrgID must be greater than 0 before fetching data", Me.ID)
        End If
        Dim cn As New SqlConnection(New AppSettingsReader().GetValue("cn.ConnectionString", Type.GetType("String")).ToString())
        If Not _fetchAccomplishments(cn) Then
            Return False
        End If
        If Not _fetchOrganizationData(cn) Then
            Return False
        End If
        _fetchInitiatives(cn)
        _fetchOrgAddress(cn)
        _fetchOrgContact(cn)
        cn.Close()
        cn.Dispose()
        Return True
    End Function
    Public Function GetData(ByVal OrgID As Int32) As Boolean   'returns sucess of operation
        If OrgID > 0 Then
            _orgID = OrgID
            GetData()
        Else
            Err.Raise(vbObjectError, "NWOFactSheets.NWOReport", "OrgID must be greater than zero")
        End If

    End Function
    Public Sub GetOrgData(ByVal OrgID As Long)
        Dim org As New NWOFactSheets.Organization(CType(Session.Item("UserID"), Long), _
            AppSettings("cn.ConnectionString"), OrgID)
        lblName.Text = org.OrganizationName
        lblBackground.Text = org.OrganizationBackground.Value
        'lblMission.Text=org.org
    End Sub
    Public Sub GetOrgData()
        If _orgID <= 0 Then
            Err.Raise(vbObjectError, "NWOFactSheets.NWOReport", "OrgID must be greater than zero")
        End If
        GetOrgData(_orgID)
    End Sub
#End Region



End Class

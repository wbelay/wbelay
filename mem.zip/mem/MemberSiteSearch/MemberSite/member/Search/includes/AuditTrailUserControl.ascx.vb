Public Class AuditTrailUserControl
    Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblEnterBy As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedBy As System.Web.UI.WebControls.Label
    Protected WithEvents lblEnterPhone As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedPhone As System.Web.UI.WebControls.Label
    Protected WithEvents lblEnterDate As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedDate As System.Web.UI.WebControls.Label
    Protected WithEvents lnkEnterEmail As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lnkLastModifiedEmail As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblEnterByLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblEnterByPhoneLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblEnterByDateLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedByLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedPhoneLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedEmailLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblLastModifiedDateLabel As System.Web.UI.WebControls.Label
    Protected WithEvents lblAuditTrail As System.Web.UI.WebControls.Label
    Protected WithEvents lblEnterByEmailLabel As System.Web.UI.WebControls.Label
    'Private arrLabels(7) As WebControl
    'Private arrControls() As Object = {lblEnterBy, lblLastModifiedBy, lblEnterPhone, lblEnterPhone, _
    '         lblLastModifiedPhone, lblEnterDate, lblLastModifiedDate, lnkEnterEmail, lnkLastModifiedEmail}
    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()

    End Sub

#End Region
    Private Sub AuditTrailUserControl()
        Dim i As Int32
        'For i = 0 To arrControls.Length - 1
        '    arrControls(i).text = ""
        'Next
        'lblEnterBy.Text = ""

    End Sub
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub
    Public Property EnterBy() As String
        Get
            Return lblEnterBy.Text
        End Get
        Set(ByVal Value As String)
            lblEnterBy.Text = Value
        End Set
    End Property
    Public Property LastModifiedBy() As String
        Get
            Return lblLastModifiedBy.Text
        End Get
        Set(ByVal Value As String)
            lblLastModifiedBy.Text = Value
        End Set
    End Property
    Public Property EnterPhone() As String
        Get
            Return lblEnterPhone.Text
        End Get
        Set(ByVal Value As String)
            lblEnterPhone.Text = Value
        End Set
    End Property
    Public Property EnterDate() As String
        Get
            Return lblEnterDate.Text
        End Get
        Set(ByVal Value As String)
            lblEnterDate.Text = Value
        End Set
    End Property
    Public Property LastModifiedPhone() As String
        Get
            Return lblLastModifiedPhone.Text
        End Get
        Set(ByVal Value As String)
            lblLastModifiedPhone.Text = Value
        End Set
    End Property
    Public Property EnterEmail() As String
        Get
            Return lnkEnterEmail.Text
        End Get
        Set(ByVal Value As String)
            lnkEnterEmail.Text = Value
            lnkEnterEmail.NavigateUrl = Value

        End Set
    End Property
    Public Property LastModifiedDate() As String
        Get
            Return lblLastModifiedDate.Text
        End Get
        Set(ByVal Value As String)
            lblLastModifiedDate.Text = Value
        End Set
    End Property
    Public Property LastModifiedEmail() As String
        Get
            Return lnkLastModifiedEmail.Text
        End Get
        Set(ByVal Value As String)
            lnkLastModifiedEmail.Text = Value
            lnkLastModifiedEmail.NavigateUrl = Value
        End Set
    End Property
    Public WriteOnly Property ControlClass() As String
        Set(ByVal Value As String)
            'Dim i As Int16
            'For i = 0 To arrControls.Length - 1
            '    If arrControls(i) Is Nothing Then
            '        Return
            '    End If
            '    arrControls(i).CssClass = Value
            'Next
            Dim ctl As WebControl

            lblEnterBy.CssClass = Value
            lblEnterDate.CssClass = Value
            lblEnterPhone.CssClass = Value
            lnkEnterEmail.CssClass = Value
            lblLastModifiedBy.CssClass = Value
            lblLastModifiedDate.CssClass = Value
            lblLastModifiedPhone.CssClass = Value
            lnkLastModifiedEmail.CssClass = Value
        End Set
    End Property
    Public WriteOnly Property LabelClass() As String
        Set(ByVal Value As String)
            lblEnterByLabel.CssClass = Value
            lblEnterByDateLabel.CssClass = Value
            lblEnterByPhoneLabel.CssClass = Value
            lblEnterByEmailLabel.CssClass = Value
            lblLastModifiedByLabel.CssClass = Value
            lblLastModifiedDateLabel.CssClass = Value
            lblLastModifiedPhoneLabel.CssClass = Value
            lblLastModifiedEmailLabel.CssClass = Value
        End Set
    End Property
    Public Property HeaderClass() As String
        Get
            Return lblAuditTrail.CssClass
        End Get
        Set(ByVal Value As String)
            lblAuditTrail.CssClass = Value
        End Set
    End Property

    Private Sub lnkEnterEmail_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkEnterEmail.PreRender, lnkLastModifiedEmail.PreRender
        sender.NavigateUrl = "mailto:" & sender.text
    End Sub
End Class

// main menu item is the one with 3 elements - folder of submenu (if none, use a space), menu text, menu path
// sub menu item is the one with 4 elements - sub menu text, sub menu path, sub menu folder, 3rd level menu array (if none, leave empty)
// If you are using quotations (") or an ampersand (&) you will need to put a backslash (\) in front of it.
// For an external link, you the following as an example of code, javascript:newWindow('http://www.cnn.com')

arrMenu = new Array (
	new Array(
		new Array("grants", "Grants", "/grants/default.asp"),  //Grants section (folder)
		new Array("Investment and Grant Agreement", "/grants/iga/default.asp", "iga", ""),
		new Array("GrantWorks","javascript:newWindow('https://grantworks.nw.org')", "test ","test")
	),
	new Array(
		new Array("Membership", "Membership", "/grants/membership/default.asp")
	),
	
	new Array(
		new Array("nationalprogs", "National Initiatives", "/nationalprogs/default.asp"), //National Initiatives section (folder)
		new Array("National Homeownership Programs", "/nationalprogs/campaign/default.asp", "campaign", ""),
		new Array("Community Building and Organizing Initiative", "/nationalprogs/community/default.asp", "community", ""),
		new Array("National Real Estate Programs", "/nationalprogs/multifamily/default.asp", "multifamily", ""),
		new Array("Rural Initiative", "/nationalprogs/rural/default.asp", "rural", "")
		//new Array("NeighborWorks Store", "javascript:newWindow('http://www.neighborworksstore.com')", " ", "") //no comma after last item
	),
	
	new Array(
		new Array("marketing", "Marketing Center", "/marketing/default.asp"), //Marketing Center section (folder)
		new Array("Visibility", "/marketing/visibility/default.asp", "visibility", ""),
		new Array("Leveraging NeighborWorks", "/marketing/leveraging/default.asp", "leveraging", ""),
		new Array("Media Center", "/marketing/mediacenter/default.asp", "mediacenter", ""),
		new Array("Brand Manager", "/marketing/brandmanager/default.asp", "manager", ""),
		new Array("Resource Room", "/marketing/resourceroom.asp", "resourceroom", ""),
		new Array("Image Library", "/marketing/imagelibrary/default.asp", "imagelibrary", ""),
		new Array("NeighborWorks Week", "/marketing/neighborworksweek2009/index.html", "neighborworksweek", "")
		//new Array("NeighborWorks Store", "javascript:newWindow('http://www.neighborworksstore.com')", " ", "") //no comma after last item
	),

			 
	new Array(
		new Array("training", "Training \& Events", "/training/default.asp"), //Training & Events section (folder)
		new Array("Training Institutes & Slot Reports", "/training/slot/default.asp", "slot", ""),
		new Array("Community Leadership Institutes", "/training/clis/default.asp", "institutes", ""),
		new Array("ED Symposium", "/training/symposium/default.asp", "symposium", ""),
		new Array("Place-Based Training", "/training/pbt/default.asp", "training", ""),
		new Array("E-Learning", "/training/elearning/default.asp", "elearning", ""),
		new Array("Training Calendar", "/training/calendar/default.asp", "calendar", ""),
		new Array("Contact Us", "/training/contact/default.asp", "contact","")
 //no comma after last item
	),
	
	new Array(
		new Array("legislative", "Policy and Legislation", "/legislative/default.asp"), //Legislative & Regulatory section (folder)
		new Array("Legislative Updates", "/legislative/policybriefs.asp", "Legislative Updates", ""),
		new Array("Budget Justification", "/legislative/justification.asp", "Budget Justification", ""),
		new Array("Congressional Visits", "/legislative/congressional_visits.asp", "Cpngressional Visits", ""),
		new Array("Useful Links", "/legislative/links.asp", "Useful Links", ""),
		new Array("Government Service Award", "/legislative/award.asp", "Government Service Award", ""),
		new Array("Staff", "/legislative/staff.asp", "Staff", "")
//no comma after last item
	),
	new Array(
		new Array("nstep", "NSTEP", "/nstep/default.asp"), //NSTEP section (folder)
		new Array("Features", "/nstep/features/default.asp", "features", ""),
        new Array("Docs and Downloads", "/nstep/docs/default.asp", "docs", "DocumentTabs"),
		new Array("Support Services","/nstep/support/default.asp", "support", ""),
		new Array("Training Opportunities","/nstep/Calendar/default.asp", "calendar", ""),
		new Array("Videos", "/nstep/videos/default.asp", "videos", "")
		
		//no comma after last item
	),

	new Array(
		new Array("cmax", "CounselorMax", "/cmax/default.asp"), //CMAX section (folder)
		new Array("Features", "/cmax/features/default.asp", "features", ""),
		new Array("Training Opportunities", "/cmax/training/default.asp", "training opportunities", ""),
        new Array("Calendar", "/cmax/calendar/default.asp", "calendar", ""),
		new Array("Documents", "/cmax/docs and downloads/default.asp", "documents", ""),    
		new Array("Support Services", "/cmax/support/default.asp", "support", "")
		
		//no comma after last item
	),
    
	new Array(
		new Array("resdev", "Resource Development", "/resdev/default.asp"), //Resource Development section (folder)
		new Array("National Partnerships", "/resdev/partnerships/default.asp", "partnerships", ""),
		new Array("Grant Opportunities", "/resdev/Grants.asp", "Grants", ""),
		new Array("Fundraising Tools", "/resdev/tools/default.asp", "tools", "") //no comma after last item
	),

	new Array(
		new Array("orgdev", "Organizational Development", "/orgdev/default.asp"), //Organizational Development section (folder)
		new Array("Business Planning", "/orgdev/business/default.asp", "business", ""),
		new Array("Human Resources", "/orgdev/hr/default.asp", "hr", ""),
		new Array("Financial Management", "/orgdev/financial/default.asp", "financial", "") //no comma after last item
	),
	
	new Array(
		new Array("data", "Data Collection", "/data/default.asp"), //Data section (folder)
		new Array("Communication", "/data/communication.asp", "communication", ""),
		new Array("Quarterly Reports", "/data/quarterly.asp", "quarterly", ""),
		new Array("Annual Reports", "/data/annual.asp", "annual", ""),
		new Array("Instructions & \Reporting Tools", "/data/instructions_reporting.asp", "instructions_reporting", "") //no comma after last item
	),
	
	new Array(
		new Array("adcouncils", "Advisory Councils", "/adcouncils/adcouncils.asp", "adcouncils", "")//no comma after last item
	),
	
	new Array(
		new Array("board_resources", "Board Resources", "/board_resources/default.asp", "board_resources", "")//no comma after last item
	
) //no comma after last item

);

//these are the menus that appear in the third level box

DocumentTabs = new Array (
	new Array("Install and Update Files", "/nstep/docs/FileDownloads.asp"),
	new Array("How-To Documents", "/nstep/docs/How-ToDocuments.asp"),
	new Array("Crystal Reports", "/nstep/docs/CrystalReportDownloads.asp")

);
manualMenu = new Array (
	new Array("The NeighborWorks Identity ", "intro.asp"),
	new Array("Understanding The Basics", "basics.asp"),
	new Array("Incorrect Uses of the NeighborWorks Logo", "incorrect.asp"),
	new Array("Correct Uses of the NeighborWorks Logo", "correct.asp"),
	new Array("Other NeighborWorks Logo Variations", "other.asp"),
	new Array("NeighborWorks Chartered Member Logo for Download", "chartered.asp"),
	new Array("Download NeighborWorks Graphics Template", "templates.asp"),
	new Array("Using NeighborWorks Graphic Templates", "guidelines.asp"),
	new Array("Writing NeighborWorks", "writing.asp"),
	new Array("Talking NeighborWorks", "talking.asp"),
	new Array("Key Supporting Messages", "messages.asp"),
	new Array("Organizations \"doing business as\" NeighborWorks", "dba.asp"),
	new Array("Getting Help", "help.asp")
);

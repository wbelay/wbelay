var browserName = navigator.appName;
var browserAppVersion = navigator.appVersion;

makeFlyoutMenus();

function makeFlyoutMenus(){
	//each loop creates one complete menu	
	for (z=0; z<arrMenu.length; z++) {
		menu = arrMenu[z];
		menuItem = menu[0];
		if (menu.length > 1) {
			//build the outer shell
			document.write("<div id=\"" + menuItem[0] + "Closer\" class=\"layerCloser\">"); 
			document.write("<a href=\"#\" onMouseOver=\"P7_autoLayers(0)\"><img src=\"/images/spacer.gif\" width=200 height=200 border=0 alt=\"\"></a>");
			document.write("</div>");
			document.write("<div id=\"" + menuItem[0] + "Menu\" class=\"layerMenu\" onMouseOver=\"changeMainNavItem('" + menuItem[0] + "','on');\" onMouseOut=\"changeMainNavItem('" + menuItem[0] + "','off');\">");
			document.write("<table width=120 border=0 cellspacing=0 cellpadding=0><tr><td valign=middle class=\"flyoutShell\">");
			document.write("<table width=100% border=0 cellpadding=0 cellspacing=0><tr><td>");
			document.write("<span id=\"flyout\">"); 
			for (x=1; x<menu.length; x++) {
				currMenuItem = menu[x];
				if (currMenuItem.length == 4){
					document.write("<table width=100% border=0 cellspacing=0 cellpadding=0><tr><td>");
					document.write("<a href=\"" + currMenuItem[1] + "\">" + currMenuItem[0] + "</a>");
					document.write("</td></tr></table>");
				}
			}
			document.write("</span>");
			document.write("</td></tr></table>");
			document.write("</td></tr></table>");
			document.write("</div>");
		}
	}
}

function changeMainNavItem(id, state) {
	id1 = "itemShell_" + id;
	id2 = "item_" + id;
	if (state == "on"){
		document.getElementById(id1).className = "navItemShellON";
		document.getElementById(id2).className = "navItemON";
	}else{
		document.getElementById(id1).className = "";
		document.getElementById(id2).className = "";
	}
}

Level3NavOn = "";

function makeMenu(pageOn, subPageOn) {
	document.write("<table border=0 cellspacing=0 cellpadding=0 width=166><tr><td>");
	for (x=0; x<arrMenu.length; x++) {
		menu = arrMenu[x];
		menuItem = menu[0];
		//write the main nav item
		if (menuItem[0] == pageOn) { //no flyout
			document.write("<table class=\"navBullet\" border=0 cellspacing=0 cellpadding=0 width=100% id=\"" + menuItem[0] + "\"><tr><td id=\"navON\"><a href=\"/" + menuItem[0] + "/default.asp\" onMouseOver=\"P7_autoLayers(0)\">" + menuItem[1] + "</a></td></tr></table>");
		} else { //flyout
			document.write("<table class=\"navBullet\" border=0 cellspacing=0 cellpadding=0 width=100% id=\"" + menuItem[0] + "\" class=\"navItem\"><tr><td id=\"nav\"><span id=\"itemShell_" + menuItem[0] + "\" class=\"navItem\"><a href=\"/" + menuItem[0] + "/default.asp\" onMouseOver=\"P7_Snap('" + menuItem[0] + "','" + menuItem[0] + "Closer',166,-20,'" + menuItem[0] + "','" + menuItem[0] + "Menu',166,0); P7_autoLayers(0,'" + menuItem[0] + "Closer','" + menuItem[0] + "Menu');\"><span id=\"item_" + menuItem[0] + "\" class=\"navItem\">" + menuItem[1] + "</span></a></span></td></tr></table>");	
		}
		//if you are on that section, write the submenu items
		if (menuItem[0] == pageOn){
			document.write("<table width=100% border=0 cellspacing=0 cellpadding=0><tr><td>");
			for (y=1; y<menu.length; y++) {
				style = "";
				currMenuItem = menu[y];
				if (currMenuItem.length == 4) {
					if ((subPageOn == currMenuItem[2])||((subPage == currMenuItem[2])&&(subPageOn == ""))) {
						style = "ON";
						Level3NavOn = currMenuItem[3];
					}
					document.write("<table width=100% border=0 cellspacing=0 cellpadding=0><tr><td id=\"subNav" + style + "\">");
					document.write("<a href=\"" + currMenuItem[1] + "\" onMouseOver=\"P7_autoLayers(0)\">" + currMenuItem[0] + "</a>");
					document.write("</td></tr></table>");
					style = "";
				}
			}
			document.write("</td></tr></table>");
		}
		document.write("</td></tr><tr><td background=\"/images/navHorzDots.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td></tr><tr><td>");
	}
	document.write("</td></tr></table>");
	document.write("<img src=\"/images/spacer.gif\" width=165 height=15 alt=\"\" onMouseOver=\"P7_autoLayers(0)\">");
}

hdrWidth = "100%";

function makeThirdLevelMenu(pageOn, subPageOn, Level3NavOn) {
	if (Level3NavOn != "") {
		hdrWidth = "406";
		document.write("<table width=172 border=0 cellspacing=0 cellpadding=0 align=\"right\"><tr>");
		document.write("<td colspan=2 rowspan=2 align=\"left\" valign=\"top\" background=\"/images/bg_teal_light.gif\"><img src=\"/images/navBoxUL.gif\" alt=\"\" width=\"9\" height=\"9\"></td>");
		document.write("<td width=154 background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>");
		document.write("<td colspan=2 rowspan=\"2\" align=\"right\" valign=\"top\" background=\"/images/bg_teal_light.gif\"><img src=\"/images/navBoxUR.gif\" alt=\"\" width=\"9\" height=\"9\"></td>");
		document.write("</tr><tr>");
		document.write("<td height=8 background=\"/images/bg_teal_light.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>");
		document.write("</tr><tr>");
		document.write("<td rowspan=2 align=\"left\" valign=\"top\" background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>");
		document.write("<td rowspan=2 align=\"left\" valign=\"top\" background=\"/images/bg_teal_light.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=\"1\" height=\"1\"></td>");
		for (x=0; x<arrMenu.length; x++) {
			menu = arrMenu[x];
			menuItem = menu[0];
			if (menuItem[0] == pageOn) { 
				for (y=1; y<menu.length; y++) {
					currMenuItem = menu[y];
					if (subPageOn == currMenuItem[2]) {
						document.write("<td class=\"level3Hdr\" align=\"center\" background=\"/images/bg_teal_light.gif\">" + currMenuItem[0] + "</td>");
						document.write("<td rowspan=2 align=\"right\" valign=\"top\" background=\"/images/bg_teal_light.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("<td rowspan=2 align=\"right\" valign=\"top\" background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("</tr><tr>");
						document.write("<td align=\"center\" background=\"/images/bg_teal_light.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=4></td>");
						document.write("</tr><tr>");
						document.write("<td background=\"/images/bg_teal.gif\" height=1 colspan=5 align=\"left\" valign=\"top\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("</tr><tr>");
						document.write("<td width=1 rowspan=2 background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("<td width=8 rowspan=2><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("<td><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=8></td>");
						document.write("<td width=8 rowspan=2><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("<td width=1 rowspan=2 background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("</tr><tr><td>");
						document.write("<table border=0 cellpadding=3 cellspacing=0 width=97% align=center>");
						style = "";
						Level3MenuItem = eval(currMenuItem[3]);
                       	for (z=0; z<Level3MenuItem.length; z++) { //go to array in currMenuItem[3]
							currPage = subPage + ".asp";
							if (Level3MenuItem[z][1] == currPage) style = "ON";
							document.write("<tr><td width=4 valign=\"top\"><img src=\"/images/bullet_flyout" + style + ".gif\" width=4 height=6 alt=\"\" hspace=1 vspace=4></td><td><a href=\"" + Level3MenuItem[z][1] + "\" class=\"level3Nav" + style + "\">" + Level3MenuItem[z][0] + "</a></td></tr>");
							style = "";
						}
						document.write("</table>");
						document.write("</td></tr><tr>");
						document.write("<td colspan=2 rowspan=2 align=\"left\" valign=\"bottom\"><img src=\"/images/navBoxLL.gif\" alt=\"\" width=9 height=9></td>");
						document.write("<td height=8><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
						document.write("<td colspan=2 rowspan=2 align=\"right\" valign=\"bottom\"><img src=\"/images/navBoxLR.gif\" alt=\"\" width=9 height=9></td>");
						document.write("</tr><tr>");
						document.write("<td background=\"/images/bg_teal.gif\"><img src=\"/images/spacer.gif\" alt=\"\" width=1 height=1></td>");
					}
				}
			}
		}
		document.write("</tr></table>");
	}
}

function makeSectionHdr(pageOn) {
	for (x=0; x<arrMenu.length; x++) {
		menu = arrMenu[x];
		menuItem = menu[0];
		if (menuItem[0] == pageOn) {
			document.write(menuItem[1]);
		}
	}
}

/*
function makeSiteMap() {
	a = 0;
	b = 0;
	document.write("<table cellpadding=0 cellspacing=0 border=0 width=100%><tr><td 50% valign=top>");
	for (x=0; x<arrMenu.length; x++) {
		menu = arrMenu[x];
		menuItem = menu[0];
		a = Math.round((arrMenu.length/2));
		//write the main nav item
		if (b == a) {
			document.write("</td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td width=50% valign=top>");
		}
		document.write("<table cellpadding=0 cellspacing=0 border=0>");
		document.write("<tr><td><a href=\"/" + menuItem[0] + "/default.asp\" class=\"sitemapHdrBox\">" + menuItem[1] + "</a></td></tr>");
		b = b + 1;
		//write the submenu items
		for (y=1; y<menu.length; y++) {
			currMenuItem = menu[y];
			document.write("<tr><td>");
			document.write("<table cellpadding=0 cellspacing=0 border=0>");
			if (currMenuItem.length == 4) {
				document.write("<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href=\"" + currMenuItem[1] + "\" class=\"sitemapLinks\">" + currMenuItem[0] + "</a></td></tr>");
				//write level3 items
				if (currMenuItem[3] != "") {
					document.write("<tr><td width=5>&nbsp;</td><td>");
					document.write("<table cellpadding=0 cellspacing=0 border=0>");
					Level3MenuItem = eval(currMenuItem[3]);
                    for (z=0; z<Level3MenuItem.length; z++) { //go to array in currMenuItem[3]
						document.write("<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><a href=\"" + Level3MenuItem[z][1] + "\" class=\"sitemapLinks\">" + Level3MenuItem[z][0] + "</a></td></tr>");
					}
					document.write("</td></tr></table>");
					document.write("</td></tr>");
				}//end level3
			}
			document.write("</td></tr></table>");
			document.write("</td></tr>");
		} //end submenu
		document.write("</td></tr><tr><td>&nbsp;</td></tr></table>");
	}
	document.write("</td></tr></table>");
}
*/

function makeSiteMap(pageOn) {
	for (x=0; x<arrMenu.length; x++) {
		menu = arrMenu[x];
	
		if (menu[0] == pageOn) {
	
			if (menu[1] != "") {
				document.write("<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">");
				subMenu = eval(menu[1]);
				for (y=0; y<subMenu.length; y++) {
					document.write("<tr><td><div class=\"indent\"><a href=\"" + subMenu[y][1] + "\" class=\"sitemapLinks\">" + subMenu[y][0] + "</a></div></td></tr>");
				}
				document.write("</table>");
			} else {
				document.write("<img src=\"/member/images/spacer.gif\" height=1 width=1 alt=\"\">");
			}
		}
	}
}

function popUp(url) {
	genPopUp = window.open("","pop","toolbar=no,location=no,scrollbars=yes,directories=no,status=yes,menubar=no,resizable=yes,width=500,height=350");
	genPopUp.location.href = url;
	if (genPopUp.opener == null) genPopUp.opener = window;
	genPopUp.opener.name = "opener";
}

function printerFriendly() {
	genPopUp = window.open("","printer","toolbar=no,location=no,scrollbars=yes,directories=no,status=yes,menubar=yes,resizable=yes,width=760,height=600");
	genPopUp.location.href = "/includes/print.asp";
	if (genPopUp.opener == null) genPopUp.opener = window;
	genPopUp.opener.name = "opener";
}

function newWindow(url) {
	genPopUp = window.open("","newWindow","toolbar=yes,location=yes,scrollbars=yes,directories=yes,status=yes,menubar=yes,resizable=yes,width=800,height=600");
	genPopUp.location.href = url;
}

function MM_reloadPage(init) {  //Updated by PVII. Reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function P7_autoLayers() { //v1.2 by PVII
 var g,b,k,f,args=P7_autoLayers.arguments;
 var a = parseInt(args[0]);if(isNaN(a))a=0;
 if(!document.p7setc) {p7c=new Array();document.p7setc=true;
  for (var u=0;u<10;u++) {p7c[u] = new Array();}}
 for(k=0; k<p7c[a].length; k++) {
  if((g=MM_findObj(p7c[a][k]))!=null) {
   b=(document.layers)?g:g.style;b.visibility="hidden";}}
 for(k=1; k<args.length; k++) {
  if((g=MM_findObj(args[k])) != null) {
   b=(document.layers)?g:g.style;b.visibility="visible";f=false;
   for(j=0;j<p7c[a].length;j++) {
    if(args[k]==p7c[a][j]) {f=true;}}
  if(!f) {p7c[a][p7c[a].length++]=args[k];}}}
}

function P7_ReDoIt() { //v1.2 by PVII
 if(document.layers) {
	MM_reloadPage(false);
	}
}

function P7_Snap() { //v2.61 by PVII
  var x,y,ox,bx,oy,p,tx,a,b,k,d,da,e,el,args=P7_Snap.arguments;a=parseInt(a);
  for (k=0; k<(args.length-3); k+=4)
   if ((g=MM_findObj(args[k]))!=null) {
    el=eval(MM_findObj(args[k+1]));
    a=parseInt(args[k+2]);b=parseInt(args[k+3]);
    x=0;y=0;ox=0;oy=0;p="";tx=1;da="document.all['"+args[k]+"']";
    if(document.getElementById) {
     d="document.getElementsByName('"+args[k]+"')[0]";
     if(!eval(d)) {d="document.getElementById('"+args[k]+"')";if(!eval(d)) {d=da;}}
    }else if(document.all) {d=da;} 
    if (document.all || document.getElementById) {
     while (tx==1) {p+=".offsetParent";
      if(eval(d+p)) {x+=parseInt(eval(d+p+".offsetLeft"));y+=parseInt(eval(d+p+".offsetTop"));
      }else{tx=0;}}
     ox=parseInt(g.offsetLeft);oy=parseInt(g.offsetTop);var tw=x+ox+y+oy;
     if(tw==0 || (navigator.appVersion.indexOf("MSIE 4")>-1 && navigator.appVersion.indexOf("Mac")>-1)) {
      ox=0;oy=0;if(g.style.left){x=parseInt(g.style.left);y=parseInt(g.style.top);
      }else{var w1=parseInt(el.style.width);bx=(a<0)?-5-w1:-10;
      a=(Math.abs(a)<1000)?0:a;b=(Math.abs(b)<1000)?0:b;
      x=document.body.scrollLeft + event.clientX + bx;
      y=document.body.scrollTop + event.clientY;}}
   }else if (document.layers) {x=g.x;y=g.y;var q0=document.layers,dd="";
    for(var s=0;s<q0.length;s++) {dd='document.'+q0[s].name;
     if(eval(dd+'.document.'+args[k])) {x+=eval(dd+'.left');y+=eval(dd+'.top');break;}}}
   if(el) {e=(document.layers)?el:el.style;
   var xx=parseInt(x+ox+a),yy=parseInt(y+oy+b);
   if(navigator.appName=="Netscape" && parseInt(navigator.appVersion)>4){xx+="px";yy+="px";}
   if(navigator.appVersion.indexOf("MSIE 5")>-1 && navigator.appVersion.indexOf("Mac")>-1){
    xx+=parseInt(document.body.leftMargin);yy+=parseInt(document.body.topMargin);
    xx+="px";yy+="px";}e.left=xx;e.top=yy;}}
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function goodbye(){
	window.close();
}
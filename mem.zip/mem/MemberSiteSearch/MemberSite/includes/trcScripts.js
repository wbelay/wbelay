//Name	Date		Change
//===	========	===========================================================
//GSD	4/16/02		SCCS #26333 - fix for Netscape 4
//GSD	9/3/02		Added url parameter to popup function
//APM	10/02		Added Valid Date function 
//GSD	1/9/03		SCCS #35206 - Registered product changes

//Opens the Pop-up window
function OpenWindow(url) {
	popupWin1 = window.open(url, "Alert", "width=570,height=390,top=10,left=10,alwaysRaised=yes,toolbar=0,directories=0,menubar=0,status=0,resizable=no,location=0,scrollbars=1");
}


function HidePlaceHolder(){
	if (document.layers) {
		//don't do anything for Netscape 4
	}
	else {
		var PlaceHolder = document.getElementById("PlaceHolder");
		PlaceHolder.style.display = "none";
		document.body.style.cursor = "auto";
	}
}


//Prevents multiple submits
function CheckSubmit(theSubmit) {
	if (parseInt(submitcount) == 0) {
		submitcount++;
		theSubmit.disabled = true;
		theSubmit.form.submit();
	}
	else {
		alert("Your request is being processed.");
	}
	return false;
}

//function downmsg(theURL)
function downmsg(theURL, BrowserVersion, BrowserType)
{
	if (parseFloat(BrowserVersion) == 5.5 && BrowserType == "IE")
		{
			var msg = 	"Please update all participants after downloading the file.\n" +
						"If you experience any errors during the File Download, please apply the following security updates to your browser.\n" +
						"Go to the URL http://www.microsoft.com/windows/ie/downloads/default.htm and click on Critical Updates.\n" +
						"From there, apply:	Security Update, November 29, 2000\n" +
						"		Security Update 1, February 27, 2001\n" +
						"		Security Update, March 29, 2001.";
		}
	else
		{
			var msg = 	"Please update all participants after downloading the file.";
		}

	if (confirm(msg))
		{
			window.parent.location = theURL;
		}
}

//navigates to the value of a selectbox
function SelectLink(theSelect) { 
	var opIndex = theSelect.selectedIndex;
	var theURL = theSelect.options[opIndex].value;
	if (theURL != "blank") window.parent.location = theURL;
}

//displays the apropriate file transfer form
function SelectFormType(theSelect) {
	var opIndex = theSelect.selectedIndex;
	var theForm = theSelect.options[opIndex].value;
	ShowForm(theForm);
}

//Checks all Checkboxes in a form
function SelectAll(theElement, theValue) 
{
	var ElementName = theElement[0].name;
	for (count = 0; count < document.Main_Form.length; count++) {
		if (document.Main_Form.elements[count].name == ElementName) {
			document.Main_Form.elements[count].checked = theValue;
		}
	}
	return false;
}

function ShowForm(theForm){
	if (document.layers) {
		//don't do anything for Netscape 4
	}
	else {
		switch (theForm) {
			case "0":
				break;
			case "1":
				ContribForm.style.display = "none";
				OtherForm.style.display = "none";
				DXForm.style.display = "block";
				TRCForm.style.display = "none";
				break;
			case "2":
				ContribForm.style.display = "block";
				OtherForm.style.display = "none";
				DXForm.style.display = "none";
				TRCForm.style.display = "none";
				break;
			case "3":
				ContribForm.style.display = "none";
				OtherForm.style.display = "block";
				DXForm.style.display = "none";
				TRCForm.style.display = "none";
				break;
			case "4":
				ContribForm.style.display = "none";
				OtherForm.style.display = "none";
				DXForm.style.display = "none";
				TRCForm.style.display = "block";
				break;
		}
	}
}

function JSInitialize() {
	if ((document.all) || (document.layers)) {
		//already handled;
	}
	else if (document.getElementsByTagName("*")) {
		document.all = document.getElementsByTagName("*");
	}
	SetFormFocus();
}

//sets the focus to the first text input of a form
function SetFormFocus() {
	if (document.Main_Form) {
		for (count = 0; count < document.Main_Form.length; count++) {
			if (document.Main_Form.elements[count].type == "Text" || document.Main_Form.elements[count].type == "text") {
				document.Main_Form.elements[count].focus();
				break;
			}
		}
	}
}
//-------------------------------------------------------------------

	function isvalidDate(strDate,fieldname)
	//Purpose:
	//	verify date format and that the date is a valid date
	//Accepts FieldName and Date for prompt message
{
	var result = true;
 		var elems = strDate.split("/");
 		
 		result = (elems.length == 3); // should be three components
 		
 		if (result)
 		{
			if (elems[0].slice(0,1)== '0')
				{
					var month = elems[0].slice(1,2);
				}
			else
				{
					var month = parseInt(elems[0]);	
				}
 			if (elems[1].slice(0,1)=='0')
 				{
 					var day = elems[1].slice(1,2);
 				}
 			else
 				{ 			
  					var day = parseInt(elems[1]);
  				}
 			var year = parseInt(elems[2]);
			
			result = allDigits(elems[0]) && (month > 0) && (month < 13) &&
					 allDigits(elems[1]) && (day > 0) && (day < 32) &&
					 allDigits(elems[2]) && ((elems[2].length == 4));
 		}
 		
  		if (!result)
 		{
 			alert('Please enter the ' + fieldname + ' in the format mm/dd/yyyy.');
		}

	
	return result;
}
function allDigits(str)
{
	return inValidCharSet(str,"0123456789");
}
function inValidCharSet(str,charset)
{
	var result = true;

	// Note: doesn't use regular expressions to avoid early Mac browser bugs	
	for (var i=0;i<str.length;i++)
		if (charset.indexOf(str.substr(i,1))<0)
		{
			result = false;
			break;
		}
	
	return result;
}

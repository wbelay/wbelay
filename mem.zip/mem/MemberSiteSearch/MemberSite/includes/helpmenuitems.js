// main menu item is the one with 3 elements - folder of submenu (if none, use a space), menu text, menu path
// sub menu item is the one with 4 elements - sub menu text, sub menu path, sub menu folder, 3rd level menu array (if none, leave empty)
// If you are using quotations (") or an ampersand (&) you will need to put a backslash (\) in front of it.
// For an external link, you the following as an example of code, javascript:newWindow('http://www.cnn.com')

arrMenu = new Array (
	
	new Array(
		new Array("utilities/jobhelp/jobstates", "Job Posting Introduction \& Quick Start Guide", "/utilities/jobhelp/jobstates/default.asp")
	),

new Array(
		new Array("utilities/jobhelp/faqs", "FAQs", "/utilities/jobhelp/faqs/default.asp")
	),

	new Array(
		new Array("utilities/jobhelp/security", "Security", "/utilities/jobhelp/security/default.asp") 
		
	),
			
	new Array(
		new Array("utilities/jobhelp/active", "Active Jobs", "/utilities/jobhelp/active/default.asp"), 
		new Array("Add Active Jobs", "/utilities/jobhelp/active/addjob.asp", "active", ""),
		new Array("View Active Jobs", "/utilities/jobhelp/active/viewjob.asp", "active", ""),
		new Array("Edit  Active Jobs", "/utilities/jobhelp/active/editjob.asp", "active", ""),
		new Array("Delete Active Jobs", "/utilities/jobhelp/active/deletejob.asp", "active", "")
		
	),

	new Array(
		new Array("utilities/jobhelp/inactive", "Inactive Jobs", "/utilities/jobhelp/inactive/default.asp"), 
		new Array("Add Inactive Jobs", "/utilities/jobhelp/inactive/addjob.asp", "inactive", ""),
		new Array("View Inactive Jobs", "/utilities/jobhelp/inactive/viewjob.asp", "inactive", ""),
		new Array("Edit Inactive Jobs", "/utilities/jobhelp/inactive/editjob.asp", "inactive", ""),
		new Array("Delete Inactive Jobs", "/utilities/jobhelp/inactive/deletejob.asp", "inactive", "")
		
	),
	
	new Array(
		new Array("utilities/jobhelp/JobHistory", "Job History", "/utilities/jobhelp/jobhistory/default.asp"), 
		new Array("View Job History", "/utilities/jobhelp/jobhistory/viewjob.asp", "jobhistory", ""),
		new Array("Edit Job History", "/utilities/jobhelp/jobhistory/editjob.asp", "jobhistory", ""),
		new Array("Delete Job History", "/utilities/jobhelp/jobhistory/deletejob.asp", "jobhistory", "")
		
	),

		
	new Array(
		new Array("utilities/jobhelp/copyjobs", "Copy Jobs", "/utilities/jobhelp/copyjobs/default.asp")
	),
	
	new Array(
		new Array("utilities/jobhelp/glossary", "Glossary", "/utilities/jobhelp/glossary/default.asp")
	)

);

